package com.app.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Version;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 */
@Entity
@Table(name="mst_event")
@Data
@EntityListeners(AuditingEntityListener.class)
@AllArgsConstructor
@NoArgsConstructor
public class MstEventEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column
	private Integer id;

	@Column
	private String model_id;
	@Column
	private String serial_no;
	@Column
	private String event_id;
	@Column
	private String event_type;
	@Column
	private String event_level;
	@Column
	private String sensor_id;
	@Column
	private String name_locale1;
	@Column
	private String name_locale2;
	@Column
	private String name_locale3;
	@Column
	private String description_locale1;
	@Column
	private String description_locale2;
	@Column
	private String description_locale3;
	@Column
	private String chk_app_name;
	@Column
	private String chk_app_parameter;
	@Column
	private String check_timing;
	@Column
	private String note;
	@Version
	@Column
	private Long version;

	@CreatedBy
    @Column
	private String inserted;

	@Column
	private Timestamp insert_time;

	@PrePersist
    public void onPrePersist() {
        setInsert_time(new Timestamp(System.currentTimeMillis()));
        setUpdate_time(new Timestamp(System.currentTimeMillis()));
    }

	@LastModifiedBy
    @Column
	private String updated;

	@Column
	private Timestamp update_time;

	@PreUpdate
    public void onPreUpdate() {
        setUpdate_time(new Timestamp(System.currentTimeMillis()));
    }

}

