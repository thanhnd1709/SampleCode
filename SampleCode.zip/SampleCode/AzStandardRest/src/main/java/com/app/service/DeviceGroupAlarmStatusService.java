package com.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.entity.DeviceGroupAlarmStatusEntity;
import com.app.model.DeviceGroupAlarmStatusModel;
import com.app.model.ResponseDeviceGroupAlarmStatusModel;
import com.app.repository.DeviceGroupAlarmStatusRepositoryCustom;

@Service
@Transactional(readOnly = true)
public class DeviceGroupAlarmStatusService {

	/**
	 * デバイスグループアラーム状態取得サービスクラス
	 * @return デバイスグループアラーム状態リスト
	 */

	@Autowired private DeviceGroupAlarmStatusRepositoryCustom eventStatusRepositoryCustom;

	public List<ResponseDeviceGroupAlarmStatusModel> GetDeviceGroupAlarmStatus(DeviceGroupAlarmStatusModel reqModel) throws Exception{

		List<ResponseDeviceGroupAlarmStatusModel> lstDeviceGroupAlarmStatus = new ArrayList<>();

		// 取得フィールド処理
		ModelFilter mf = makeModelFilter(reqModel.getFields());

		// ソート処理
		String sort = null;
		if (reqModel.getSort() != null) {
			for (String item : reqModel.getSort().split(",")) {
				if (sort != null) {
					sort += ", ";
				} else {
					sort = "";
				}
				if (item.startsWith("-")) {
					if(item.equalsIgnoreCase("-max_event_level")) sort+= item.replace("-max_event_level", "event_level DESC");
					else sort += (item.toLowerCase()).replace("-", "") + " DESC";
				}
				else {
					if(item.equalsIgnoreCase("max_event_level")) sort+= item.replace("max_event_level", "event_level");
					else sort += item.toLowerCase();
				}
			}
		}

		// ページング処理
		Integer limit = null;
		Integer offset = null;
		if (reqModel.getPage() != null && reqModel.getLimit() != null) {
			limit = Integer.parseInt(reqModel.getLimit());
			offset = (Integer.parseInt(reqModel.getPage()) - 1) * limit;
		}

		if (StringUtil.IsNullOrEmpty(reqModel.getCompare_class())) reqModel.setCompare_class(Consts.COMPARE_CLASS_1);

		// デバイスグループアラーム状態取得処理
		List<DeviceGroupAlarmStatusEntity> entList = new ArrayList<>();

		//①取得情報区分が１(直下最大イベントレベル) の場合
		if(reqModel.getGet_info_class().equals( Consts.GET_INFO_CLASS_KBN_1)){
			entList = eventStatusRepositoryCustom.getParentEventLevel(reqModel, sort, limit, offset);
		}else {
		//②取得情報区分が2(配下最大イベントレベル) の場合
			entList = eventStatusRepositoryCustom.getChildEventLevel(reqModel, sort, limit, offset);
		}

		for (DeviceGroupAlarmStatusEntity dgaEntity : entList) {
			if (!StringUtil.IsNullOrEmpty(dgaEntity.getEvent_level())) {
				ResponseDeviceGroupAlarmStatusModel newModel = new ResponseDeviceGroupAlarmStatusModel();
				if (mf.device_group_id)
					newModel.setDevice_group_id(dgaEntity.getDevice_group_id());
				if (mf.detection_class)
					newModel.setDetection_class(dgaEntity.getDetection_class());
				if (mf.max_event_level)
					newModel.setMax_event_level(dgaEntity.getEvent_level());
				lstDeviceGroupAlarmStatus.add(newModel);
			}
		}
		return lstDeviceGroupAlarmStatus;
	}

	private ModelFilter makeModelFilter(String fields){
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if("device_group_id".equals(str)) mf.device_group_id = true;
				if("detection_class".equals(str)) mf.detection_class = true;
				if("max_event_level".equals(str)) mf.max_event_level = true;
			}
		}
		return mf;
	}
	class ModelFilter {
		public ModelFilter(boolean b) {
			device_group_id = b;
			detection_class = b;
			max_event_level = b;
		}
		public boolean device_group_id = true;
		public boolean detection_class = true;
		public boolean max_event_level = true;

	}
}

