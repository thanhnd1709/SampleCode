package com.app.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.exception.BadRequestException;
import com.app.model.DeviceGroupAlarmStatusModel;
import com.app.model.ResponseDeviceGroupAlarmStatusModel;
import com.app.model.SubResponseModel;
import com.app.service.DeviceGroupAlarmStatusService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * デバイスグループアラーム状態取得コントローラクラス
 * @author（TOSCO）エヒー
 */
@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_ALARM_EVENT_MGT)
@Api(tags= {Consts.TAGS_ALARM_EVENT_MGT,}, description = Consts.MSG_ALARM_EVENT_MGT)
public class GetDeviceGroupAlarmStatusAPIController {

	public static final Logger logger = LoggerFactory.getLogger(GetDeviceGroupAlarmStatusAPIController.class);

	@Autowired private DeviceGroupAlarmStatusService deviceGroupAlarmStatusService;
	@Autowired private MessageSource _msgSource;

	@ApiOperation(value = Consts.MSG_GET_DEVICE_GROUP_ALARM_STATUS, notes = Consts.MSG_GET_DEVICE_GROUP_ALARM_STATUS_01, nickname = Consts.OPERATIONID_GET_DEVICE_GROUP_ALARM_STATUS_INDEX)
	@ApiResponses(value = {
				@ApiResponse(code = 200, message = "OK", response = ResponseDeviceGroupAlarmStatusModel.class, responseContainer = "List"),
				@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
				@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
				@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_DEVICE_GROUP_ALARM_STATUS, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<List<ResponseDeviceGroupAlarmStatusModel>> index(Locale locale, @ModelAttribute @Valid DeviceGroupAlarmStatusModel reqModel, BindingResult errors) throws Exception {

		logger.info("Get開始");

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, reqModel, lstError);
		if(!lstError.isEmpty()){
			BadRequestException exp = new BadRequestException("");
			exp.setArgs(lstError);
			throw exp;
		}

		List<ResponseDeviceGroupAlarmStatusModel> result = deviceGroupAlarmStatusService.GetDeviceGroupAlarmStatus(reqModel);

        return new ResponseEntity<List<ResponseDeviceGroupAlarmStatusModel>>(result, HttpStatus.OK);
	}

	/**
	 * 入力チェック処理
	 * @param locale          ロケール
	 * @param reqModel        デバイスグループアラーム状態モデル
	 * @return List<SubResponseModel> エラーリスト
	 */
	private List<SubResponseModel> Validation(Locale locale
												, DeviceGroupAlarmStatusModel reqModel
												, List<SubResponseModel> lstError){

		// リクエスト．検出区分が null、又は 空白（""）の場合
		if (reqModel.getGet_class() == null || reqModel.getGet_class().length == 0) {
			lstError.add(new SubResponseModel("get_class"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));

		} else {
			// リクエスト．検出区分が 1/2/3/4/5 以外の場合
			for (String getClass : reqModel.getGet_class()) {
				if (StringUtil.IsValidNum(getClass)) {
					lstError.add(new SubResponseModel("get_class",
									_msgSource.getMessage(Consts.MESSAGE_E000046, null, locale)));
				}
			}
		}

		// リクエスト．発生復帰区分が入力されている場合
		if(!StringUtil.IsNullOrEmpty(reqModel.getIncident_class()) && !StringUtil.IsBlank(reqModel.getIncident_class())){
			// リクエスト．発生復帰区分が 1/2/3 以外の場合
			if(!StringUtil.IsChar2(reqModel.getIncident_class())){
				lstError.add(new SubResponseModel("incident_class"
						, _msgSource.getMessage(Consts.MESSAGE_E000045, null, locale)));
			}
		}

		// リクエスト．取得情報区分が null、又は 空白（""）の場合
		if(StringUtil.IsNullOrEmpty(reqModel.getGet_info_class())
				|| StringUtil.IsBlank(reqModel.getGet_info_class())){
			lstError.add(new SubResponseModel("get_info_class"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));

		}else{
			// リクエスト．取得情報区分が 1/2 以外の場合
			if(!StringUtil.IsChar1(reqModel.getGet_info_class())){
				lstError.add(new SubResponseModel("get_info_class"
						, _msgSource.getMessage(Consts.MESSAGE_E000044, null, locale)));
			}
		}

		// リクエスト．比較区分が 1/2 以外の場合
		if (!StringUtil.IsNullOrEmpty(reqModel.getCompare_class()) && !StringUtil.IsChar1(reqModel.getCompare_class())) {
			lstError.add(new SubResponseModel("compare_class",
							_msgSource.getMessage(Consts.MESSAGE_E000044, null, locale)));
		}

		int idx = 0;

		if(reqModel.getDevice_group_id() == null|| reqModel.getDevice_group_id().length == 0){
			lstError.add(new SubResponseModel("device_group_id"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}else{
			for(String deviceGroupId : reqModel.getDevice_group_id()){

				// リクエスト．[配列]デバイスグループID．デバイスグループIDが null、又は 空白（""）の場合
				if(StringUtil.IsNullOrEmpty(deviceGroupId) || StringUtil.IsBlank(deviceGroupId)){
					lstError.add(new SubResponseModel("[" + idx + "]:device_group_id"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
				}
				idx += 1;
			}
		}

		//Pageの指定が不正な場合
		try{
			if (reqModel.getPage() != null && Integer.parseInt(reqModel.getPage()) < 1){
				lstError.add(new SubResponseModel("page",
						_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		}catch (NumberFormatException e) {
			lstError.add(new SubResponseModel("page",
					_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}

		//limitの指定が不正な場合
		try{
			if (reqModel.getLimit() != null && Integer.parseInt(reqModel.getLimit())	 < 1){
				lstError.add(new SubResponseModel("limit",
						_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		}catch (NumberFormatException e) {
			lstError.add(new SubResponseModel("limit",
					_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}


		// ソートの指定が不正な場合
		if (reqModel.getSort() != null) {
			List<String> sortParams = new ArrayList<String>();
			for (String item : reqModel.getSort().split(",")) {
				sortParams.add(item.toLowerCase().replace("-", ""));
			}

			if (StringUtil.hasDuplicate(sortParams) ||
				 !StringUtil.hasProperty(new ResponseDeviceGroupAlarmStatusModel(), sortParams)) {
					lstError.add(
							new SubResponseModel("sort", _msgSource.getMessage(Consts.MESSAGE_E000049, null, locale)));
			}
		}
		// フィールドの指定が不正な場合
		if (reqModel.getFields() != null) {
			List<String> fieldParams = new ArrayList<String>();
			for (String item : reqModel.getFields().split(",")) {
				fieldParams.add(item.toLowerCase().replace("-", ""));
			}

			if (StringUtil.hasDuplicate(fieldParams) ||
				 !StringUtil.hasProperty(new ResponseDeviceGroupAlarmStatusModel(), fieldParams)) {
					lstError.add(
							new SubResponseModel("fields", _msgSource.getMessage(Consts.MESSAGE_E000049, null, locale)));
			}
		}

		return lstError;
	}
}

