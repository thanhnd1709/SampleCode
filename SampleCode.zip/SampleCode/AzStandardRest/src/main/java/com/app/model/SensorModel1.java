package com.app.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * デバイス情報モデルクラス
 * @author（TOSCO）ウェイ
 */
@Data
public class SensorModel1 {

	@ApiModelProperty(value = "機種ID ※デバイス(機種ID または S/N)どちらかは必須")
	private String model_id;

	@ApiModelProperty(value = "シリアルNo ※デバイス(機種ID または S/N)どちらかは必須")
	private String serial_no;

	@ApiModelProperty(value = "センサーID")
	private String sensor_id;

}
