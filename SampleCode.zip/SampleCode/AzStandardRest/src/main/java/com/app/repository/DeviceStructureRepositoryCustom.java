package com.app.repository;

import java.util.List;

import com.app.entity.DeviceStructureEntity;
import com.app.model.DeviceStructureModel;

/**
 * デバイス階層情報取得リポジトリクラス
 * @author (TOSCO) 9571
 */
public interface DeviceStructureRepositoryCustom {

	List<DeviceStructureEntity> getDeviceStructure(DeviceStructureModel reqModel,String sort,Integer limit,Integer offset);


}
