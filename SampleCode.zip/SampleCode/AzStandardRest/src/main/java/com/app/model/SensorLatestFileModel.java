package com.app.model;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;
import java.util.StringJoiner;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 最新センサーファイルモデルクラス
 * @author（TOSCO）ウェイ
 */
@Data
public class SensorLatestFileModel {

	private static final String ENCODING = "UTF-8";

	@ApiModelProperty(value = "センサリスト", required = true)
	private List<SensorModel1> sensor_list;

	@ApiModelProperty(value = "ID")
	private String[] id;

	@ApiModelProperty(value = "計測時刻")
	private String[] measure_time;

	@ApiModelProperty(value = "UpLoad時刻")
	private String[] upload_time;

	@ApiModelProperty(value = "圧縮有無")
	private String[] zip_flg;

	@ApiModelProperty(value = "ファイル名（ファイルパス/ファイル名）")
	private String[] file_name;

	@ApiModelProperty(value = "MD5")
	private String[] hash;

	@ApiModelProperty(value = "送信元デバイスID")
	private String[] sender_device_id;

	@ApiModelProperty(value = "送信通知時刻")
	private String[] notice_time;

	@ApiModelProperty(value = "予備1")
	private String[] reserve1;

	@ApiModelProperty(value = "予備2")
	private String[] reserve2;

	@ApiModelProperty(value = "予備3")
	private String[] reserve3;

	@ApiModelProperty(value = "予備4")
	private String[] reserve4;

	@ApiModelProperty(value = "予備5")
	private String[] reserve5;

	@ApiModelProperty(value = "その他メタデータ")
	private String[] other_metadata;

	@ApiModelProperty(value = "アップロードユーザID")
	private String[] upload_user_id;

	@ApiModelProperty(value = "任意並び順条件(カンマ区切り)")
	private String sort;

	@ApiModelProperty(value = "取得フィールド(カンマ区切り)")
	private String fields;

	@ApiModelProperty(value = "表示対象ページ番号")
	private String page;

	@ApiModelProperty(value = "1度に返すItem数")
	private String limit;

	public String buildUrlParameter() {
		StringJoiner sj = new StringJoiner("&", "?", "");
		sj.setEmptyValue("");
		try {
			if (id != null) for (String s : id) sj.add("id=" + URLEncoder.encode(s, ENCODING));
			if (measure_time != null) for (String s : measure_time) sj.add("measure_time=" + URLEncoder.encode(s, ENCODING));
			if (upload_time != null) for (String s : upload_time) sj.add("upload_time=" + URLEncoder.encode(s, ENCODING));
			if (zip_flg != null) for (String s : zip_flg) sj.add("zip_flg=" + URLEncoder.encode(s, ENCODING));
			if (file_name != null) for (String s : file_name) sj.add("file_name=" + URLEncoder.encode(s, ENCODING));
			if (hash != null) for (String s : hash) sj.add("hash=" + URLEncoder.encode(s, ENCODING));
			if (sender_device_id != null) for (String s : sender_device_id) sj.add("sender_device_id=" + URLEncoder.encode(s, ENCODING));
			if (notice_time != null) for (String s : notice_time) sj.add("notice_time=" + URLEncoder.encode(s, ENCODING));
			if (reserve1 != null) for (String s : reserve1) sj.add("reserve1=" + URLEncoder.encode(s, ENCODING));
			if (reserve2 != null) for (String s : reserve2) sj.add("reserve2=" + URLEncoder.encode(s, ENCODING));
			if (reserve3 != null) for (String s : reserve3) sj.add("reserve3=" + URLEncoder.encode(s, ENCODING));
			if (reserve4 != null) for (String s : reserve4) sj.add("reserve4=" + URLEncoder.encode(s, ENCODING));
			if (reserve5 != null) for (String s : reserve5) sj.add("reserve5=" + URLEncoder.encode(s, ENCODING));
			if (other_metadata != null) for (String s : other_metadata) sj.add("other_metadata=" + URLEncoder.encode(s, ENCODING));
			if (upload_user_id != null) for (String s : upload_user_id) sj.add("upload_user_id=" + URLEncoder.encode(s, ENCODING));
			if (sort != null) sj.add("sort=" + URLEncoder.encode(sort, ENCODING));
			if (fields != null) sj.add("fields=" + URLEncoder.encode(fields, ENCODING));
			if (page != null) sj.add("page=" + URLEncoder.encode(page, ENCODING));
			if (limit != null) sj.add("limit=" + URLEncoder.encode(limit, ENCODING));

		} catch (UnsupportedEncodingException e) {
		}
		return sj.toString();
	}
}
