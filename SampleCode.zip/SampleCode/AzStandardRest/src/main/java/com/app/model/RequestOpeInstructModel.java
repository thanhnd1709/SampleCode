package com.app.model;
import java.io.Serializable;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.app.common.Consts;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * GWへのコマンド実行依頼モデル
 * @author 810
 *
 */
@Data
public class RequestOpeInstructModel implements Serializable {

	private static final long serialVersionUID = 1L;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@ApiModelProperty(value = "GW機種ID", required = true)
	private String gw_model_id;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@ApiModelProperty(value = "GWシリアルNo", required = true)
	private String gw_serial_no;

	@ApiModelProperty(value = "機種ID")
	private String model_id;

	@ApiModelProperty(value = "シリアルNo")
	private String serial_no;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@Size(max = 50, message = "{" + Consts.MESSAGE_E000021 + "}")
	@ApiModelProperty(value = "操作", required = true)
	private String operation;

	@ApiModelProperty(value = "引数")
	private Object argument;

	@DecimalMax(value = "300", message = "{" + Consts.MESSAGE_E000022 + "}")
	@DecimalMin(value = "5", message = "{" + Consts.MESSAGE_E000023 + "}")
	@ApiModelProperty(value = "待ち時間(秒)")
	private Integer wait_time;

	@ApiModelProperty(value = "実行時刻 ※(yyyyMMddHHmmssまたはHHmmss)")
	private String exec_time;

	@ApiModelProperty(value = "引数(文字列形式)", hidden = true)
	private String argumentString;

	@ApiModelProperty(value = "依頼ユーザID", hidden = true)
	private String request_user_id;

	@ApiModelProperty(value = "接続元IPアドレス", hidden = true)
	private String remote_addr;

	@ApiModelProperty(value = "クライアントIPアドレス", hidden = true)
	private String client_addr;

	@ApiModelProperty(value = "HTTPリファラ―", hidden = true)
	private String http_referer;

	@ApiModelProperty(value = "CORSオリジン", hidden = true)
	private String cors_origin;
}
