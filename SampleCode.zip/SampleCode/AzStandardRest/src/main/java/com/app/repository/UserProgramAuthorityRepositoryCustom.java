package com.app.repository;

import java.util.List;

import com.app.entity.UserProgramAuthorityEntity;
import com.app.model.UserProgramAuthorityQueryModel;

/**
 * ユーザ・プログラム権限情報取得リポジトリカスタム
 * @author 9571
 *
 */
public interface UserProgramAuthorityRepositoryCustom {

	/**
	 * ユーザ・プログラム権限情報取得
	 */
	List<UserProgramAuthorityEntity> getUserProgramAuthority(UserProgramAuthorityQueryModel query, List<String> sort, Integer limit, Integer offset);

	/**
	 * ユーザ・プログラム権限情報取得
	 * @param query 検索条件オブジェクト
	 * @return 件数
	 */
	Long countAll(UserProgramAuthorityQueryModel query);




}