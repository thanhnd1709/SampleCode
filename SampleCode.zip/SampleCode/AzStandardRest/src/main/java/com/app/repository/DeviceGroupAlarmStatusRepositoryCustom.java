package com.app.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.app.entity.DeviceGroupAlarmStatusEntity;
import com.app.model.DeviceGroupAlarmStatusModel;

/**
 * デバイスグループアラーム状態取得リポジトリクラス
 * @author（TOSCO）エヒー
 */
@Repository
public interface DeviceGroupAlarmStatusRepositoryCustom {

	/**
	 *①	取得情報区分が１(直下最大イベントレベル) の時デバイスグループ直下のデバイスのイベントレベル最大値を取得する
	 */
	List<DeviceGroupAlarmStatusEntity> getParentEventLevel(DeviceGroupAlarmStatusModel query,String sort, Integer limit, Integer offset);

	/**
	 *②	取得情報区分が2(配下最大イベントレベル) の時
	 *      デバイスグループ、デバイスを親子関係で展開して、配下のデバイスグループやデバイスも含めた
	 *      ベントレベル最大値 を取得する
	 */
	List<DeviceGroupAlarmStatusEntity> getChildEventLevel(DeviceGroupAlarmStatusModel query,String sort, Integer limit, Integer offset);

}
