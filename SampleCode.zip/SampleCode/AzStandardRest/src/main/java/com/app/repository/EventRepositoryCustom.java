package com.app.repository;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.app.entity.MstEventEntity;
import com.app.model.EventQueryModel;

public interface EventRepositoryCustom {
	List<MstEventEntity> findAll(EventQueryModel query, List<String> sort, Integer limit, Integer offset);
	Long countAll(EventQueryModel query);

    MstEventEntity findOneForUpdate(@Param("id") int id);
}