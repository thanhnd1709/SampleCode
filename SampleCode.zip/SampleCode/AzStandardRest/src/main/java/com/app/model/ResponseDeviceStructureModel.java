package com.app.model;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * デバイス階層情報取得モデル
 */
@Data
public class ResponseDeviceStructureModel {

	@ApiModelProperty(value = "デバイス階層（指定デバイス(機種ID+”&”+S/N) ～ 親デバイス(機種ID+”&”+S/N) までを タブ区切りで連結）")
	private String device_structure;

	@ApiModelProperty(value = "階層数")
	private Integer level;

	@ApiModelProperty(value = "機種ID")
	private String model_id;

	@ApiModelProperty(value = "シリアルNo")
	private String serial_no;

	@ApiModelProperty(value = "デバイスモード")
	private String device_mode;

}