package com.app.exception;

/**
 * 例外クラス
 * @author（TOSCO）ウェイ
 */
public class IoTSQLException   extends RuntimeException {

	private static final long serialVersionUID = 4943447961378179730L;

	public IoTSQLException(Exception e){
		super(e);
	}
}
