package com.app.controller;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;
import org.springframework.web.util.UriComponents;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.exception.BadRequestException;
import com.app.model.DeviceAlarmStatusModel;
import com.app.model.DeviceListModel;
import com.app.model.ResponseDeviceAlarmStatusModel;
import com.app.model.SubResponseModel;
import com.app.service.DeviceAlarmStatusService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * デバイスアラーム状態取得コントローラクラス
 */
@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_ALARM_EVENT_MGT)
@Api(tags= {Consts.TAGS_ALARM_EVENT_MGT,}, description = Consts.MSG_ALARM_EVENT_MGT)
public class GetDeviceAlarmStatusAPIController {

	public static final Logger logger = LoggerFactory.getLogger(GetDeviceAlarmStatusAPIController.class);

	/**
	 * デバイスアラーム状態取得
	 * @param locale
	 * @param reqModel
	 * @param errors
	 * @return
	 * @throws Exception
	 */
	@Autowired private DeviceAlarmStatusService deviceAlarmStatusService;
	@Autowired private MessageSource _msgSource;

	@ApiOperation(value = Consts.MSG_GET_DEVICE_ALARM_STATUS, notes = Consts.MSG_GET_DEVICE_ALARM_STATUS_01, nickname = Consts.OPERATIONID_GET_DEVICE_ALARM_STATUS_INDEX)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = ResponseDeviceAlarmStatusModel.class, responseContainer = "List"),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_DEVICE_ALARM_STATUS, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<List<ResponseDeviceAlarmStatusModel>> index(Locale locale, @ModelAttribute @Valid DeviceAlarmStatusModel reqModel, BindingResult errors) throws Exception {

		logger.info("Get開始");

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, reqModel, lstError);
		if(!lstError.isEmpty()){
			BadRequestException exp = new BadRequestException("");
			exp.setArgs(lstError);
			throw exp;
		}

		// ページング処理
        HttpHeaders headers = new HttpHeaders();
		if (reqModel.getPage() != null && reqModel.getLimit() != null) {
			Integer page = Integer.parseInt(reqModel.getPage());
			Integer limit = Integer.parseInt(reqModel.getLimit());
			Integer next = null;
			Integer prev = null;

			Long count = deviceAlarmStatusService.countAll(reqModel);
			if (count == 0) {
				return new ResponseEntity<List<ResponseDeviceAlarmStatusModel>>(new ArrayList<ResponseDeviceAlarmStatusModel>(), HttpStatus.OK);
			}
			int countpage = count.intValue() / limit;
			countpage += (count.intValue() % limit > 0) ? 1 : 0;

			if (countpage <= page) page = countpage;
			if (page > 1) prev = page - 1;
			if (page < countpage) next = page + 1;

			reqModel.setPage(String.valueOf(page));
	        UriComponents uriComponents = MvcUriComponentsBuilder.fromMethodName(
	        		GetDeviceAlarmStatusAPIController.class, "index", locale, reqModel, errors).build();
	        URI location = uriComponents.toUri();
	        StringBuffer sb = new StringBuffer();
	        if (next != null) {
	        	reqModel.setPage(String.valueOf(next));
	        	sb.append("<" + location.toString() + reqModel.buildUrlParameter() + ">;rel=\"next\",");

	        	reqModel.setPage(String.valueOf(countpage));
	        	sb.append("<" + location.toString() + reqModel.buildUrlParameter() + ">;rel=\"last\"");
	        }
	        if (prev != null) {
	        	if (sb.length() > 0) sb.append(",");

	        	reqModel.setPage("1");
	        	sb.append("<" + location.toString() + reqModel.buildUrlParameter() + ">;rel=\"first\",");

	        	reqModel.setPage(String.valueOf(prev));
	        	sb.append("<" + location.toString() + reqModel.buildUrlParameter() + ">;rel=\"prev\"");
	        }
	        if (sb.length() > 0) headers.add("Link", sb.toString());

	        reqModel.setPage(String.valueOf(page));
		}

		List<ResponseDeviceAlarmStatusModel> result = deviceAlarmStatusService.getDeviceAlarmStatus(reqModel);

        return new ResponseEntity<List<ResponseDeviceAlarmStatusModel>>(result, headers, HttpStatus.OK);
	}

	/**
	 * 入力チェック処理
	 * @param locale          ロケール
	 * @param reqModel        デバイスアラーム状態モデル
	 * @return List<SubResponseModel> エラーリスト
	 */
	private List<SubResponseModel> Validation(Locale locale
												, DeviceAlarmStatusModel reqModel
												, List<SubResponseModel> lstError){

		// リクエスト．検出区分が null、又は 空白（""）の場合
		if (reqModel.getGet_class() == null || reqModel.getGet_class().length == 0) {
			lstError.add(new SubResponseModel("get_class"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));

		} else {
			// リクエスト．検出区分が 1/2/3/4/5 以外の場合
			for (String getClass : reqModel.getGet_class()) {
				if (StringUtil.IsValidNum(getClass)) {
					lstError.add(new SubResponseModel("get_class",
									_msgSource.getMessage(Consts.MESSAGE_E000046, null, locale)));
				}
			}
		}

		// リクエスト．発生復帰区分が入力されている場合
		if(StringUtil.IsNullOrEmpty(reqModel.getIncident_class()) || StringUtil.IsBlank(reqModel.getIncident_class())){
			reqModel.setIncident_class("1");
		} else {
			// リクエスト．発生復帰区分が 1/2/3 以外の場合
			if(!StringUtil.IsChar2(reqModel.getIncident_class())){
				lstError.add(new SubResponseModel("getIncident_class"
						, _msgSource.getMessage(Consts.MESSAGE_E000045, null, locale)));
			}
		}

		// リクエスト．取得情報区分が null、又は 空白（""）の場合
		if(StringUtil.IsNullOrEmpty(reqModel.getGet_info_class())
				|| StringUtil.IsBlank(reqModel.getGet_info_class())){
			lstError.add(new SubResponseModel("get_info_class"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));

		}else{
			// リクエスト．取得情報区分が 1/2 以外の場合
			if(!StringUtil.IsChar1(reqModel.getGet_info_class())){
				lstError.add(new SubResponseModel("get_info_class"
						, _msgSource.getMessage(Consts.MESSAGE_E000044, null, locale)));
			}
		}

		int idx = 0;
		// リクエスト．デバイスリストが null、又は 空リストの場合
		if(reqModel.getDevice_list() == null || reqModel.getDevice_list().size() <= 0){
			lstError.add(new SubResponseModel("device_list"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}else{
			for(DeviceListModel dlModel : reqModel.getDevice_list()){

				boolean isNull = false;

				// リクエスト．[配列]デバイスリスト．機種IDが nullの場合
				if(StringUtil.IsNullOrEmpty(dlModel.getModel_id())){
					lstError.add(new SubResponseModel("[" + idx + "]:model_id"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
					isNull = true;
				}

				// リクエスト．[配列]デバイスリスト．シリアルNoが nullの場合
				if(StringUtil.IsNullOrEmpty(dlModel.getSerial_no())){
					lstError.add(new SubResponseModel("[" + idx + "]:serial_no"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
					isNull = true;
				}

				if(isNull == false){
					// リクエスト．[配列]デバイスリスト．機種ID、且つ リクエスト．[配列]デバイスリスト．シリアルNo が 空白（""）の場合
					if(StringUtil.IsBlank(dlModel.getModel_id()) && StringUtil.IsBlank(dlModel.getSerial_no())){
						lstError.add(new SubResponseModel("[" + idx + "]:model_id, serial_no"
								, _msgSource.getMessage(Consts.MESSAGE_E000031, null, locale)));
					}
				}
				idx += 1;
			}
		}

		// リクエスト．比較区分が null、又は 空白（""）の場合
		if(StringUtil.IsNullOrEmpty(reqModel.getCompare_class())
				|| StringUtil.IsBlank(reqModel.getCompare_class())){
			reqModel.setCompare_class("1");
		}else{
			// リクエスト．比較区分が 1/2 以外の場合
			if(!StringUtil.IsChar1(reqModel.getCompare_class())){
				lstError.add(new SubResponseModel("compare_class"
						, _msgSource.getMessage(Consts.MESSAGE_E000044, null, locale)));
			}
		}

		// 取得フィールドの指定が不正な場合
		if(reqModel.getFields() != null){
			List<String> fieldsParams = new ArrayList<String>();
			for (String item : reqModel.getFields().split(",")) {
				fieldsParams.add(item.toLowerCase());
			}

	        if(StringUtil.hasDuplicate(fieldsParams)
	        		|| !StringUtil.hasProperty(new ResponseDeviceAlarmStatusModel(), fieldsParams)){
	        	lstError.add(new SubResponseModel("fields",
	        			_msgSource.getMessage(Consts.MESSAGE_E000050, null, locale)));
	        }
		}

		//Pageの指定が不正な場合
		try{
			if (reqModel.getPage() != null && Integer.parseInt(reqModel.getPage()) < 1){
				lstError.add(new SubResponseModel("page",
						_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		}catch (NumberFormatException e) {
			lstError.add(new SubResponseModel("page",
					_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}

		//limitの指定が不正な場合
		try{
			if (reqModel.getLimit() != null && Integer.parseInt(reqModel.getLimit()) < 1){
				lstError.add(new SubResponseModel("limit",
						_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		}catch (NumberFormatException e) {
			lstError.add(new SubResponseModel("limit",
					_msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}

		// ソートの指定が不正な場合
		if(reqModel.getSort() != null){
			List<String> sortParams = new ArrayList<String>();
			for (String item : reqModel.getSort().split(",")) {
				sortParams.add(item.toLowerCase().replace("-", ""));
			}

	        if(StringUtil.hasDuplicate(sortParams)
	        		|| !StringUtil.hasProperty(new ResponseDeviceAlarmStatusModel(), sortParams)){
	        	lstError.add(new SubResponseModel("sort",
	        			_msgSource.getMessage(Consts.MESSAGE_E000049, null, locale)));
	        }
		}

		return lstError;
	}
}

