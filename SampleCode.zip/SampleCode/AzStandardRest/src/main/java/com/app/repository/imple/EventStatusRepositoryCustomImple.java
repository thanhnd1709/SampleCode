package com.app.repository.imple;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.common.Consts;
import com.app.entity.DeviceAlarmStatusEntity;
import com.app.entity.EventStatusEntity;
import com.app.filter.AuthUserInfoComponent;
import com.app.model.DeviceAlarmStatusModel;
import com.app.model.DeviceListModel;
import com.app.model.EventListModel2;
import com.app.model.EventStatusModel;
import com.app.repository.EventStatusRepositoryCustom;

/**
 * イベント・アラーム状態取得リポジトリ実装クラス
 * @author（TOSCO）エヒー
 */
@Component
public class EventStatusRepositoryCustomImple implements EventStatusRepositoryCustom {

	private static final String SELECT_STR = " SELECT";

	private static final String SELECT_FIELDS_STR  =" ei.model_id"
			  											+",ei.serial_no"
			  											+",ei.detection_class"
			  											+",ei.id"
			  											+",ei.event_time"
			  											+",ei.event_id"
			  											+",ei.event_status"
			  											+",ei.incident_class"
			  											+",ei.event_level"
			  											+",ei.cope_status"
			  											+",ei.incident_time"
			  											+",ei.return_time"
			  											+",ei.version"
			  											+",me.event_type"
			  											+",me.sensor_id"
			  											+",me.name_locale1"
			  											+",me.name_locale2"
			  											+",me.name_locale3"
			  											+",me.description_locale1"
			  											+",me.description_locale2"
			  											+",me.description_locale3"
			  											+",me.chk_app_name"
			  											+",me.chk_app_parameter"
			  											+",me.check_timing"
			  											+",me.note";

	private static final String FROM_STR = " FROM std_event_incidence ei,"
											+ " mst_event me";

	private static final String WHERE_STR = " ei.model_id = me.model_id"
			  								+"	AND ei.serial_no = me.serial_no"
			  								+"	AND ei.event_id = me.event_id"
			  								+"	AND dbo.fn_EventAuthChk(me.model_id, me.serial_no, me.event_id, (:userId), default, default) = 1";

	private String selectSql = null;
	private String fromSql = null;
	private String whereSql = null;

	@Autowired EntityManager em;
	@Autowired AuthUserInfoComponent authUserInfo;

	/**
	 * ①デバイスグループID指定時 かつ 親子展開フラグがtrueの時、
	 * デバイスグループを親子展開し展開後のデバイスグループ群で対象のイベントIDを求めイベント状態管理を検索する
	 */
	@Override
	public List<EventStatusEntity> searchDeviceGroupIdTrue(EventStatusModel query, String sort, Integer limit,
			Integer offset) {

	String withSql = " WITH all_structure_group (device_group_id, level) AS ("
				+ " Select device_group_id,"
				+ " 0 as level "
				+ " FROM mst_device_group mg"
				+ " WHERE device_group_id = :device_group_id"
				+ " UNION ALL"
				+ " SELECT mg.device_group_id,"
				+ " ag.level+1 as level "
				+ " FROM all_structure_group ag"
				+ " INNER JOIN mst_device_group mg"
				+ " ON ag.device_group_id = mg.parent_device_group_id"
				+ " WHERE level<10)";

		selectSql = SELECT_STR;

		//FROM設定
		fromSql = FROM_STR + ", (SELECT DISTINCT mgd.model_id, mgd.serial_no "
				+ "  FROM all_structure_group ag,"
				+ "  mst_group_composition_device mgd"
				+ "  WHERE ag.device_group_id = mgd.device_group_id) el";

		//WHERE検索条件設定
		whereSql = " WHERE ei.model_id = el.model_id"
				+ "  AND ei.serial_no = el.serial_no AND" + WHERE_STR;

		selectSql = selectSql + SELECT_FIELDS_STR + fromSql + whereSql;

		//WHERE句用検索条件追加
		selectSql = addCondition(selectSql, query);

		//ORDER BY句を作成する
		selectSql = orderBy(selectSql, sort, limit, offset);

		//WITHと結合
		selectSql = withSql + selectSql;

		Query qry = em.createNativeQuery(selectSql, EventStatusEntity.class);

		//デバイスグルップIDの設定
		qry.setParameter("device_group_id", query.getDevice_group_id());

		//各バインド変数にパラメータを設定する。
		qry = setParameters(qry, query, limit, offset);

		@SuppressWarnings("unchecked")
		List<EventStatusEntity> list = qry.getResultList();

		return list;
	}

	/**
	 * ②デバイスグループID指定時 かつ 親子展開フラグがfalseの時、
	 * 指定されたデバイスグループで対象のイベントIDを求めイベント状態管理を検索する
	 */
	@Override
	public List<EventStatusEntity> searchDeviceGroupIdFalse(EventStatusModel query, String sort, Integer limit,
			Integer offset) {

		selectSql = SELECT_STR;

		//FROM設定
		fromSql = FROM_STR +", mst_group_composition_device mgd";

		//WHERE検索条件設定
		whereSql = " WHERE mgd.device_group_id = :device_group_id"
				+ " AND ei.model_id = mgd.model_id"
				+ " AND ei.serial_no = mgd.serial_no AND" + WHERE_STR;

		selectSql = selectSql + SELECT_FIELDS_STR + fromSql + whereSql;

		//WHERE句用検索条件追加
		selectSql = addCondition(selectSql, query);

		//ORDER BY句を作成する
		selectSql = orderBy(selectSql, sort, limit, offset);

		Query qry = em.createNativeQuery(selectSql, EventStatusEntity.class);

		//デバイスグルップIDの設定
		qry.setParameter("device_group_id", query.getDevice_group_id());

		//各バインド変数にパラメータを設定する。
		qry = setParameters(qry, query, limit, offset);

		@SuppressWarnings("unchecked")
		List<EventStatusEntity> list = qry.getResultList();

		return list;
	}

	/**
	 * ③[配列]デバイスリスト指定時 かつ 親子展開フラグがtrueの時、
	 * デバイスを親子展開し展開後のデバイス群で対象のイベントIDを求めイベント状態管理を検索する
	 */
	@Override
	public List<EventStatusEntity> searchDeviceListTrue(EventStatusModel query, String sort, Integer limit,
			Integer offset) {

		String withSql = "WITH all_structure_device (model_id, serial_no, level) AS ("
					+ " SELECT model_id, serial_no, 0 as level"
					+ "   FROM mst_device md";

		// [配列]デバイスリスト処理
		boolean deviceListFlg = false;
		withSql += " WHERE (";
		for (DeviceListModel device : query.getDevice_list()) {
			if (deviceListFlg) withSql += " OR ";
			withSql += " (model_id = '" + device.getModel_id() + "' AND serial_no = '" + device.getSerial_no() + "')";
			deviceListFlg = true;
		}
		withSql += ")";


		withSql += " UNION ALL"
				+ " SELECT md.model_id, md.serial_no,  ad.level+1 as level"
				+ " FROM all_structure_device ad "
				+ "  INNER JOIN mst_device md"
				+ "    ON (ad.model_id = md.parent_model_id "
				+ "    AND ad.serial_no = md.parent_serial_no)"
				+ "  WHERE level < 10)";

		selectSql = SELECT_STR;


		//FROM設定
		fromSql = FROM_STR + ", (SELECT DISTINCT me.model_id, me.serial_no, me.event_id"
				+ " FROM all_structure_device ad, mst_event me"
				+ " WHERE ad.model_id = me.model_id"
				+ " AND ad.serial_no = me.serial_no) el";

		//WHERE検索条件設定
		whereSql = " WHERE ei.model_id = el.model_id"
				+ "  AND ei.serial_no = el.serial_no"
				+ "  AND ei.event_id = el.event_id AND" + WHERE_STR;

		selectSql = selectSql + SELECT_FIELDS_STR + fromSql + whereSql;

		//WHERE句用検索条件追加
		selectSql = addCondition(selectSql, query);

		//ORDER BY句を作成する
		selectSql = orderBy(selectSql, sort, limit, offset);

		//WITHと結合
		selectSql = withSql + selectSql;

		Query qry = em.createNativeQuery(selectSql, EventStatusEntity.class);

		//各バインド変数にパラメータを設定する。
		qry = setParameters(qry, query, limit, offset);

		@SuppressWarnings("unchecked")
		List<EventStatusEntity> list = qry.getResultList();

		return list;

	}

	/**
	 *④[配列]デバイスリスト指定時 かつ 親子展開フラグがfalseの時、
	 *指定されたデバイスで対象のイベントIDを求めイベント状態管理を検索する
	 */
	@Override
	public List<EventStatusEntity> searchDeviceListFalse(EventStatusModel query, String sort, Integer limit,
			Integer offset) {

		selectSql = SELECT_STR;


		//WHERE検索条件設定
		whereSql = " WHERE" + WHERE_STR;

		selectSql = selectSql + SELECT_FIELDS_STR + FROM_STR + whereSql;

		//WHERE句用検索条件追加
		selectSql = addCondition(selectSql, query);

		// [配列]デバイスリスト処理
		boolean deviceListFlg = false;
		selectSql += " AND (";
		for (DeviceListModel device : query.getDevice_list()) {
			if (deviceListFlg) selectSql += " OR ";
			selectSql += " (me.model_id = '" + device.getModel_id()
					+  "' AND me.serial_no = '" + device.getSerial_no() + "')";
			deviceListFlg = true;
		}
		selectSql += ")";

		//ORDER BY句を作成する
		selectSql = orderBy(selectSql, sort, limit, offset);

		Query qry = em.createNativeQuery(selectSql, EventStatusEntity.class);

		//デバイスグルップIDの設定
		qry = setParameters(qry, query, limit, offset);

		@SuppressWarnings("unchecked")
		List<EventStatusEntity> entityList = qry.getResultList();

		return entityList;
	}

	/**
	 * ⑤デバイスグループID、[配列]デバイスリスト未指定時、
	 */
	@Override
	public List<EventStatusEntity> search(EventStatusModel query, String sort, Integer limit, Integer offset) {

		selectSql = SELECT_STR;


		//WHERE検索条件設定
		whereSql = " WHERE" + WHERE_STR;

		selectSql = selectSql + SELECT_FIELDS_STR + FROM_STR + whereSql;

		//WHERE句用検索条件追加
		selectSql = addCondition(selectSql, query);

		// [配列]イベントリストが指定されている場合
		if (query.getEvent_list() != null) {
			boolean eventListFlg = false;
			selectSql += " AND (";
			for (EventListModel2 event : query.getEvent_list()) {
				if (eventListFlg) selectSql += " OR ";
				selectSql += "(me.model_id = '" + event.getModel_id()
						  + "' AND me.serial_no = '" + event.getSerial_no()
						  + "' AND me.event_id = '" + event.getEvent_id() + "')";
				eventListFlg = true;
			}
			selectSql += ")";
		}

		//ORDER BY句を作成する
		selectSql = orderBy(selectSql, sort, limit, offset);

		Query qry = em.createNativeQuery(selectSql, EventStatusEntity.class);

		//デバイスグルップIDの設定
		qry = setParameters(qry, query, limit, offset);

		@SuppressWarnings("unchecked")
		List<EventStatusEntity> entityList = qry.getResultList();

		return entityList;
	}

	/**
	 * WHERE句用検索条件追加
	 *
	 * @param selectSql
	 * @param query
	 */
	private String addCondition(String selectSql, EventStatusModel query){

		// 検出区分
		selectSql += " AND ei.detection_class IN (";
		boolean flg = false;
		for (String getClass : query.getGet_class()) {
			if (flg) selectSql += ",";
			selectSql += "'" + getClass + "'";
			flg = true;
		}
		selectSql += ")";

		//発生復帰区分が指定されている場合かつ発生復帰区分が指定された値が3ではないの場合、
		if (query.getIncident_class() != null && !query.getIncident_class().equals(Consts.INCIDENT_CLASS_3)) {
			selectSql += " AND ei.incident_class = :incident_class";
		}

		// イベント時刻が指定されている場合
		if (query.getEvent_time() != null) {
			selectSql += " AND ei.event_time = :event_time";
		}

		boolean hasVal= false;
		// イベント状態が指定されている場合
		if (query.getEvent_status() != null) {
			selectSql += " AND ei.event_status IN ('";
			for(String eventStatus: query.getEvent_status()){
				if(hasVal) selectSql +="','";
				selectSql += eventStatus;
				hasVal = true;
			}
			selectSql += "')";
		}

		// イベントレベルが指定されている場合
		if (query.getEvent_level() != null) {
			hasVal = false;
			selectSql += " AND ei.event_level IN ('";
			for(String eventLevel : query.getEvent_level()){
				if(hasVal) selectSql += "','";
				selectSql += eventLevel;
				hasVal = true;
			}
			selectSql += "')";
		}

		// 対応状況が指定されている場合
		if (query.getCope_status() != null) {
			hasVal = false;
			selectSql += " AND ei.cope_status IN ('";
			for(String copeStatus : query.getCope_status()){
				if(hasVal) selectSql += "','";
				selectSql += copeStatus;
				hasVal = true;
			}
			selectSql += "')";
		}

		// 発生時刻が指定されている場合
		if (query.getIncident_time() != null) {
			selectSql += " AND ei.incident_time = :incident_time";
		}

		// 復帰時刻が指定されている場合
		if (query.getReturn_time() != null) {
			selectSql += " AND ei.return_time = :return_time";
		}
		return selectSql;
	}

	/**
	 * ORDER BY句を作成する
	 *
	 * @param selectSql
	 * @param sort
	 * @param limit
	 * @param offset
	 */

	private String orderBy(String baseSql, String sort, Integer limit, Integer offset){

		// ソート順が指定されている場合
		if(sort != null){
			baseSql = baseSql + " ORDER BY " + sort;
		}

		// ページングが指定されている場合
		if(limit != null && offset != null){
			// ソート順が指定されていない場合
			if(sort == null){
				baseSql = baseSql + " ORDER BY model_id, serial_no, detection_class, event_id, event_time ";
			}
			baseSql =  baseSql + " OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY";
		}
		return baseSql;
	}

	/**
	 * 各バインド変数にパラメータを設定する。
	 * @param qry
	 * @param qyary
	 * @param limit
	 * @param offset
	 */
	private Query setParameters(Query qry, EventStatusModel query, Integer limit, Integer offset) {

		// バインド文字列に対し値をバインド
		//if (query.getMax_number() != null) {
		//	qry.setParameter("max_number", query.getMax_number());
		//}

		// ユーザID取得
		qry.setParameter("userId", authUserInfo.getPrincipalName());

		// 発生復帰区分文字列に対し値をバインド
		if (query.getIncident_class() != null && !query.getIncident_class().equals(Consts.INCIDENT_CLASS_3)) {
			qry.setParameter("incident_class", query.getIncident_class());
		}

		//イベント時刻文字列に対し値をバインド
		if (query.getEvent_time() != null) {
			qry.setParameter("event_time", query.getEvent_time());
		}

		//発生時刻文字列に対し値をバインド
		if (query.getIncident_time() != null) {
			qry.setParameter("incident_time", query.getIncident_time());
		}

		//復帰時刻文字列に対し値をバインド
		if(query.getReturn_time() != null){
			qry.setParameter("return_time",query.getReturn_time() );
		}

		if (limit != null && offset != null) {
			qry.setParameter("offset", offset);
			qry.setParameter("limit", limit);
		}
		return qry;
	}

	/**
	 * デバイスアラーム状態を取得する。（指定デバイスのみ）
	 */
	@Override
	public List<DeviceAlarmStatusEntity> searchDeviceAlarmStatus(DeviceAlarmStatusModel model, List<String> sort, Integer limit, Integer offset) {

		String select = buildQuery(model);
		String orderBy = buildOrderBy(sort, limit, offset);
		Query query = em.createNativeQuery(select + orderBy, DeviceAlarmStatusEntity.class);
		setParameters(query, model);

		@SuppressWarnings("unchecked")
		List<DeviceAlarmStatusEntity> entityList = query.getResultList();
		return entityList;
	}

	/**
	 * デバイスアラーム状態の件数を取得する。（指定デバイスのみ）
	 */
	@Override
	public Long countDeviceAlarmStatus(DeviceAlarmStatusModel model) {
		String select = buildQuery(model);
		Query query = em.createNativeQuery("SELECT count(*) FROM (" + select + ") as tmp");
		setParameters(query, model);
		return ((Integer)query.getSingleResult()).longValue();
	}

	/**
	 * デバイスアラーム状態取得のSELECT文を作成する。（指定デバイスのみ）
	 */
	private String buildQuery(DeviceAlarmStatusModel model) {
		// SQL SELECT句以降作成
		String select = " SELECT"
				+  " e.model_id,"
				+  " e.serial_no,"
				+  " e.detection_class,"
				+  " :max_event_level as max_event_level"
				+  " FROM std_event_incidence AS e"
				+  " WHERE"
				+  "   :devices AND"
				+  "   :detection_classes AND"
				+  "   :incident_classes"
				+  "   ((e.detection_class IN ('4', '5') AND dbo.fn_EventAuthChk(e.model_id, e.serial_no, e.event_id, :user_id, default, default) = 1) OR"
				+  "   (e.detection_class NOT IN ('4', '5') AND dbo.fn_DeviceAuthChk(e.model_id, e.serial_no, :user_id, default, default) = 1))"
				+  " GROUP BY e.model_id, e.serial_no, e.detection_class";

		StringBuffer sb = new StringBuffer();

		// 比較区分
		if ("2".equals(model.getCompare_class())) {
			sb.append("max(try_convert(float, e.event_level))");
		} else {
			sb.append("max(e.event_level)");
		}
		select = select.replaceAll(":max_event_level", sb.toString());

		// デバイス条件作成
		List<DeviceListModel> deviceList = model.getDevice_list();
		sb = new StringBuffer();
		for (int i = 0; i < deviceList.size(); i++) {
			if (sb.length() > 0) sb.append(" OR ");
			sb.append("(e.model_id = :model_id_" + i + " AND e.serial_no = :serial_no_" + i + ")");
		}
		select = select.replaceAll(":devices", "(" + sb.toString() + ")");

		// 検出区分条件作成
		String[] detectionClasses = model.getGet_class();
		sb = new StringBuffer();
		for (int i = 0; i < detectionClasses.length; i++) {
			if (sb.length() > 0) sb.append(", ");
			sb.append(":detection_class_" + i);
		}
		select = select.replaceAll(":detection_classes", "e.detection_class IN (" + sb.toString() + ")");

		// 発生復帰区分条件作成
		String incidentClass = model.getIncident_class();
		if (Consts.INCIDENT_CLASS_3.equals(incidentClass)) {
			select = select.replaceAll(":incident_classes", "");
		} else {
			select = select.replaceAll(":incident_classes", "e.incident_class = :incident_class AND ");
		}

		return select;
	}

	/**
	 * デバイスアラーム状態を取得する。（指定デバイスの配下のデバイスを含む）
	 */
	@Override
	public List<DeviceAlarmStatusEntity> searchDeviceAlarmStatusRecursive(DeviceAlarmStatusModel model, List<String> sort, Integer limit, Integer offset) {

		String with = buildQueryRecursiveWith(model);
		String select = buildQueryRecursive(model);
		String orderBy = buildOrderBy(sort, limit, offset);
		Query query = em.createNativeQuery(with + select + orderBy, DeviceAlarmStatusEntity.class);
		setParameters(query, model);

		@SuppressWarnings("unchecked")
		List<DeviceAlarmStatusEntity> entityList = query.getResultList();
		return entityList;
	}

	/**
	 * デバイスアラーム状態の件数を取得する。（指定デバイスの配下のデバイスを含む）
	 */
	@Override
	public Long countDeviceAlarmStatusRecursive(DeviceAlarmStatusModel model) {
		String with = buildQueryRecursiveWith(model);
		String select = buildQueryRecursive(model);
		Query query = em.createNativeQuery(with + " SELECT count(*) FROM (" + select + ") as tmp");
		setParameters(query, model);
		return ((Integer)query.getSingleResult()).longValue();
	}

	/**
	 * 指定デバイスの配下のデバイスを取得する場合のWITH句を作成する。
	 * @param model
	 * @return
	 */
	private String buildQueryRecursiveWith(DeviceAlarmStatusModel model) {
		// SQL With句作成
		String with = " WITH nodes(model_id, serial_no, level) AS ("
				+ "  SELECT model_id, serial_no, 0 as level"
				+ "    FROM mst_device WHERE :devices"
				+ "  UNION ALL"
				+ "  SELECT d.model_id, d.serial_no, level + 1"
				+ "    FROM mst_device AS d INNER JOIN nodes AS n ON"
				+ "    d.parent_model_id = n.model_id AND d.parent_serial_no = n.serial_no"
				+ ")";

		// デバイス用バインド変数作成
		List<DeviceListModel> deviceList = model.getDevice_list();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < deviceList.size(); i++) {
			if (sb.length() > 0) sb.append(" OR ");
			sb.append("(model_id = :model_id_" + i + " AND serial_no = :serial_no_" + i + ")");
		}
		with = with.replaceAll(":devices", sb.toString());

		return with;
	}

	/**
	 * 指定デバイスの配下のデバイスを取得する場合のSELECT文を作成する。
	 * @param model
	 * @return
	 */
	private String buildQueryRecursive(DeviceAlarmStatusModel model) {
		StringBuffer sb = new StringBuffer();

		// SQL SELECT句以降作成
		String select = " SELECT ";
		select  += " e.model_id,"
				+  " e.serial_no,"
				+  " e.detection_class,"
				+  " :max_event_level as max_event_level"
				+  " FROM nodes n"
				+  " INNER JOIN std_event_incidence AS e ON"
				+  "   e.model_id = n.model_id AND e.serial_no = n.serial_no"
				+  " WHERE"
				+  "   :detection_classes AND"
				+  "   :incident_classes"
				+  "   ((e.detection_class IN ('4', '5') AND dbo.fn_EventAuthChk(e.model_id, e.serial_no, e.event_id, :user_id, default, default) = 1) OR"
				+  "   (e.detection_class NOT IN ('4', '5') AND dbo.fn_DeviceAuthChk(e.model_id, e.serial_no, :user_id, default, default) = 1))"
				+  " GROUP BY e.model_id, e.serial_no, e.detection_class";

		// 比較区分
		sb = new StringBuffer();
		if ("2".equals(model.getCompare_class())) {
			sb.append("max(try_convert(float, e.event_level))");
		} else {
			sb.append("max(e.event_level)");
		}
		select = select.replaceAll(":max_event_level", sb.toString());

		// 検出区分条件作成
		String[] detectionClasses = model.getGet_class();
		sb = new StringBuffer();
		for (int i = 0; i < detectionClasses.length; i++) {
			if (sb.length() > 0) sb.append(", ");
			sb.append(":detection_class_" + i);
		}
		select = select.replaceAll(":detection_classes", "e.detection_class IN (" + sb.toString() + ")");

		// 発生復帰区分条件作成
		String incidentClass = model.getIncident_class();
		if (Consts.INCIDENT_CLASS_3.equals(incidentClass)) {
			select = select.replaceAll(":incident_classes", "");
		} else {
			select = select.replaceAll(":incident_classes", "e.incident_class = :incident_class AND ");
		}

		return select;
	}

	/**
	 * ORDER BY句を作成する。
	 * @param sort
	 * @param limit
	 * @param offset
	 * @return
	 */
	private String buildOrderBy(List<String> sort, Integer limit, Integer offset) {
		StringBuffer orderBy = new StringBuffer();
		if (sort.size() > 0) {
			orderBy.append(" ORDER BY ");
			for (String col : sort) {
				if (col.startsWith("-")) {
					orderBy.append(col.substring(1) + " desc,");
				} else {
					orderBy.append(col + " asc,");
				}
			}
			orderBy.deleteCharAt(orderBy.length()-1);
		} else {
			orderBy.append(" ORDER BY e.model_id, e.serial_no, e.detection_class asc");
		}
		if (limit != null && offset != null) {
			orderBy.append(" OFFSET " + offset + " ROWS FETCH NEXT " + limit + " ROWS ONLY");
		}
		return orderBy.toString();
	}

	/**
	 * 各バインド変数にパラメータを設定する。
	 * @param query
	 * @param model
	 */
	private void setParameters(Query query, DeviceAlarmStatusModel model) {
		// デバイス用バインド変数にパラメータを設定
		List<DeviceListModel> deviceList = model.getDevice_list();
		for (int i = 0; i < deviceList.size(); i++) {
			query.setParameter("model_id_" + i, deviceList.get(i).getModel_id());
			query.setParameter("serial_no_" + i, deviceList.get(i).getSerial_no());
		}

		// 検出区分用バインド変数にパラメータを設定
		String[] detectionClasses = model.getGet_class();
		for (int i = 0; i < detectionClasses.length; i++) {
			query.setParameter("detection_class_" + i, detectionClasses[i]);
		}

		// 発生復帰区分にパラメータを設定
		String incidentClass = model.getIncident_class();
		if (!Consts.INCIDENT_CLASS_3.equals(incidentClass)) {
			query.setParameter("incident_class", incidentClass);
		}

		// ユーザID
		query.setParameter("user_id", authUserInfo.getPrincipalName());
	}

}
