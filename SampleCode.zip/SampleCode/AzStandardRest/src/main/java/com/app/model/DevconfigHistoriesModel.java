package com.app.model;
import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class DevconfigHistoriesModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "ID")
	private Integer id;

	@ApiModelProperty(value = "機種ID")
	private String model_id;

	@ApiModelProperty(value = "シリアルNo")
	private String serial_no;

	@ApiModelProperty(value = "コンフィグID")
	private String config_id;

	@ApiModelProperty(value = "コンフィグファイル名")
	private String config_file;

	@ApiModelProperty(value = "GWアップロード時刻")
	private String gw_upload_time;

	@ApiModelProperty(value = "フォーマットバージョン")
	private String format_version;

	@ApiModelProperty(value = "コンフィグバージョン")
	private String config_version;

	@ApiModelProperty(value = "設定ファイル通知キー")
	private String file_notification_key;

	@ApiModelProperty(value = "マスタ登録結果")
	private Boolean regist_flg;

	@ApiModelProperty(value = "結果通知送信ID")
	private Long result_send_id;

	@ApiModelProperty(value = "バージョン")
	private Long version;

	@ApiModelProperty(value = "登録時刻")
	private String insert_time;

	@ApiModelProperty(value = "更新時刻")
	private String update_time;

}
