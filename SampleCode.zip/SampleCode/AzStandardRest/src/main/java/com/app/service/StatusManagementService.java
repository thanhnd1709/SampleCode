package com.app.service;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.common.utils.DateTimeUtil;
import com.app.entity.StdEventIncidenceEntity;
import com.app.exception.DataNotFoundException;
import com.app.exception.LockingFailureException;
import com.app.model.StatusManagementModel;
import com.app.model.StatusManagementQueryModel;
import com.app.repository.StatusManagementRepository;

@Service
@Transactional(readOnly = true)
public class StatusManagementService {

	@Autowired
	private StatusManagementRepository updateEventStatusRepository;


	@Transactional(readOnly = false)
	public StatusManagementModel update(Locale locale,int id, StatusManagementQueryModel model) throws Exception{
		StdEventIncidenceEntity rec = updateEventStatusRepository.findOneForUpdate(id);
		if(rec == null) {
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.statusManagementInfo")});
			throw exp;
		}

		rec.setCope_status(model.getCope_status());
		if (model.getVersion() == null || model.getVersion() != rec.getVersion()) {
			LockingFailureException exp = new LockingFailureException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.statusManagementInfo")});
			throw exp;
		}

		updateEventStatusRepository.saveAndFlush(rec);
		StdEventIncidenceEntity updateRec = updateEventStatusRepository.findOne(id);
		StatusManagementModel newModel = new StatusManagementModel();
		newModel.setId(updateRec.getId());
		newModel.setModel_id(updateRec.getModel_id());
		newModel.setSerial_no(updateRec.getSerial_no());
		newModel.setDetection_class(updateRec.getDetection_class());
		newModel.setEvent_id(updateRec.getEvent_id());

		if(updateRec.getEvent_time() != null){
			newModel.setEvent_time(DateTimeUtil.formatTimestamp(updateRec.getEvent_time()));
		}

		newModel.setEvent_status(updateRec.getEvent_status());
		newModel.setIncident_class(updateRec.getIncident_class());
		newModel.setEvent_level(updateRec.getEvent_level());
		newModel.setCope_status(updateRec.getCope_status());

		if(updateRec.getIncident_time() != null){
			newModel.setIncident_time(DateTimeUtil.formatTimestamp(updateRec.getIncident_time()));
		}

		if(updateRec.getReturn_time() != null)
		{
			newModel.setReturn_time(DateTimeUtil.formatTimestamp(updateRec.getReturn_time()));
		}

		newModel.setVersion(updateRec.getVersion());

		if(updateRec.getInsert_time() != null){
			newModel.setInsert_time(DateTimeUtil.formatTimestamp(updateRec.getInsert_time()));
		}

		if(updateRec.getUpdate_time() != null){
		newModel.setUpdate_time(DateTimeUtil.formatTimestamp(updateRec.getUpdate_time()));
		}

		return newModel;
	}

	@Transactional(readOnly = false)
	public void delete(int uuid) throws Exception {
		StdEventIncidenceEntity rec = updateEventStatusRepository.findOne(uuid);
		if(rec == null) {
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.statusManagementInfo")});
			throw exp;
		}
		updateEventStatusRepository.delete(rec);
	}

	class ModelFilter {
		public ModelFilter(boolean b) {
			cope_status = b;
			version = b;
		}
		public boolean cope_status = true;
		public boolean version = true;
	}
}

