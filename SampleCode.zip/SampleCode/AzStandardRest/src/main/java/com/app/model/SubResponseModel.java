package com.app.model;

/**
 * サブエラー情報モデルクラス
 * @author（TOSCO）ウェイ
 */
public class SubResponseModel {

    // フィールドID
    public String fieldId;
    // エラーメッセージ
    public String message;

    public SubResponseModel(String fieldId
    						, String message) {
        this.fieldId = fieldId;
        this.message = message;
    }
}
