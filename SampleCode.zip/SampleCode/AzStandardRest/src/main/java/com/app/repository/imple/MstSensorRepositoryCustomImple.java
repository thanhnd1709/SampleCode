package com.app.repository.imple;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.entity.MstSensorEntity;
import com.app.filter.AuthUserInfoComponent;
import com.app.repository.MstSensorRepositoryCustom;

/**
 * センサー情報リポジトリ実装クラス
 * @author（TOSCO）ウェイ
 */
@Component
public class MstSensorRepositoryCustomImple implements MstSensorRepositoryCustom {

	@Autowired EntityManager em;
	@Autowired AuthUserInfoComponent authUserInfo;

	@Override
	public List<MstSensorEntity> find(String modelId, String serialNo, String sensorId, char measureType) {
		String sensorIds = "";
		String strSql = "SELECT"
						+ " ss.id"
						+ " ,ss.model_id"
						+ " ,ss.serial_no"
						+ " ,ss.sensor_id"
						+ " ,ss.sensor_type"
						+ " ,ss.name_locale1"
						+ " ,ss.name_locale2"
						+ " ,ss.name_locale3"
						+ " ,ss.unit_locale1"
						+ " ,ss.unit_locale2"
						+ " ,ss.unit_locale3"
						+ " ,ss.transform_locale1"
						+ " ,ss.transform_locale2"
						+ " ,ss.transform_locale3"
						+ " ,ss.decimal_num_locale1"
						+ " ,ss.decimal_num_locale2"
						+ " ,ss.decimal_num_locale3"
						+ " ,ss.max_value_locale1"
						+ " ,ss.max_value_locale2"
						+ " ,ss.max_value_locale3"
						+ " ,ss.min_value_locale1"
						+ " ,ss.min_value_locale2"
						+ " ,ss.min_value_locale3"
						+ " ,ss.description_locale1"
						+ " ,ss.description_locale2"
						+ " ,ss.description_locale3"
						+ " ,ss.measure_type"
						+ " ,ss.data_type"
						+ " ,ss.fixed_length"
						+ " ,ss.time_data_create_flg"
						+ " ,ss.short_term_minutes"
						+ " ,ss.note"
						+ " ,ss.version"
						+ " ,ss.inserted"
						+ " ,ss.insert_time"
						+ " ,ss.updated"
						+ " ,ss.update_time"
						+ " FROM mst_sensor ss"
						+ " WHERE"
						+ " dbo.fn_SensorAuthChk(ss.model_id, ss.serial_no, ss.sensor_id, (:userId), default, default) = 1";

		// 機種ID
		if(modelId != null) strSql += " AND ss.model_id = :model_id";
		// シリアルNo
		if(serialNo != null) strSql += " AND ss.serial_no = :serial_no";
		// センサーID
		if (sensorId != null) {

			String [] ids = sensorId.split(",");
			sensorIds = String.join("','", ids);
			strSql += " AND ss.sensor_id IN( '"+ sensorIds + "')";
		}




		// 計測タイプ
		strSql += " AND ss.measure_type = :measure_type";

		Query q = em.createNativeQuery(strSql, MstSensorEntity.class);
		// ユーザId
		q.setParameter("userId", authUserInfo.getPrincipalName());
		// 機種ID
		if(modelId != null) q.setParameter("model_id", modelId);
		// シリアルNo
		if(serialNo != null) q.setParameter("serial_no", serialNo);

		// センサーID
		//if(sensorId != null) q.setParameter("sensor_id", sensorIds);
		// 計測タイプ
		q.setParameter("measure_type", measureType);

		@SuppressWarnings("unchecked")
		List<MstSensorEntity> lstResult = q.getResultList();
		return lstResult;
	}
}
