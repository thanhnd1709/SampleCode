package com.app.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Version;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 */
@Entity
@Table(name="mst_role_root_group")
@Data
@EntityListeners(AuditingEntityListener.class)
@AllArgsConstructor
@NoArgsConstructor
public class MstRoleRootGroupEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column
	private Integer id;

	@Column
	private String role_id;
	@Column
	private String root_group_id;
	@Version
	@Column
	private Long version;

	@CreatedBy
    @Column
	private String inserted;

	@Column
	private Timestamp insert_time;

	@PrePersist
    public void onPrePersist() {
        setInsert_time(new Timestamp(System.currentTimeMillis()));
        setUpdate_time(new Timestamp(System.currentTimeMillis()));
    }

	@LastModifiedBy
    @Column
	private String updated;

	@Column
	private Timestamp update_time;

	@PreUpdate
    public void onPreUpdate() {
        setUpdate_time(new Timestamp(System.currentTimeMillis()));
    }

}

