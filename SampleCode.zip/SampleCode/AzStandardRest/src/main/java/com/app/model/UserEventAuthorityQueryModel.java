package com.app.model;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.StringJoiner;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * ユーザ・イベント権限情報クエリモデル
 *
 * @author 1625
 *
 */
@Data
public class UserEventAuthorityQueryModel implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String ENCODING = "UTF-8";

	@ApiModelProperty(value = "機種ID")
	private String[] model_id;

	@ApiModelProperty(value = "シリアルNo")
	private String[] serial_no;

	@ApiModelProperty(value = "イベントID")
	private String[] event_id;

	@ApiModelProperty(value = "イベント種別")
	private String[] event_type;

	@ApiModelProperty(value = "イベントレベル")
	private String[] event_level;

	@ApiModelProperty(value = "センサーID")
	private String[] sensor_id;

	@ApiModelProperty(value = "名称(ロケール１)")
	private String[] name_locale1;

	@ApiModelProperty(value = "名称(ロケール２)")
	private String[] name_locale2;

	@ApiModelProperty(value = "名称(ロケール３)")
	private String[] name_locale3;

	@ApiModelProperty(value = "説明(ロケール１)")
	private String[] description_locale1;

	@ApiModelProperty(value = "説明(ロケール２)")
	private String[] description_locale2;

	@ApiModelProperty(value = "説明(ロケール３)")
	private String[] description_locale3;

	@ApiModelProperty(value = "アラーム検出アプリ名")
	private String[] chk_app_name;

	@ApiModelProperty(value = "アラーム検出パラメータ")
	private String[] chk_app_parameter;

	@ApiModelProperty(value = "チェックタイミング")
	private String[] check_timing;

	@ApiModelProperty(value = "備考")
	private String[] note;

	@ApiModelProperty(value = "デバイスグループID")
	private String[] device_group_id;

	@ApiModelProperty(value = "デバイスグループ種別")
	private String[] device_group_type;

	@ApiModelProperty(value = "デバイスグループサブ種別")
	private String[] device_group_subtype;

	@ApiModelProperty(value = "デバイスグループ名称(ロケール1)")
	private String[] device_group_name_locale1;

	@ApiModelProperty(value = "デバイスグループ名称(ロケール2)")
	private String[] device_group_name_locale2;

	@ApiModelProperty(value = "デバイスグループ名称(ロケール3)")
	private String[] device_group_name_locale3;

	@ApiModelProperty(value = "デバイスグループ説明(ロケール1)")
	private String[] device_group_description_locale1;

	@ApiModelProperty(value = "デバイスグループ説明(ロケール2)")
	private String[] device_group_description_locale2;

	@ApiModelProperty(value = "デバイスグループ説明(ロケール3)")
	private String[] device_group_description_locale3;

	@ApiModelProperty(value = "親デバイスグループID")
	private String[] parent_device_group_id;

	@ApiModelProperty(value = "設置場所")
	private String[] setup_place;

	@ApiModelProperty(value = "設置状態")
	private String[] setup_status;

	@ApiModelProperty(value = "緯度")
	private String[] latitude;

	@ApiModelProperty(value = "経度")
	private String[] longitude;

	@ApiModelProperty(value = "デバイスグループ備考")
	private String[] device_group_note;

	@ApiModelProperty(value = "ロールID")
	private String[] role_id;

	@ApiModelProperty(value = "ルートグループID")
	private String[] root_group_id;

	/* API内で値を設定するため、非公開とする。 */
	@ApiModelProperty(value = "ユーザID", hidden = true)
	private String user_id;

	@ApiModelProperty(value = "ロール情報名称(ロケール1)")
	private String[] role_name_locale1;

	@ApiModelProperty(value = "ロール情報名称(ロケール2)")
	private String[] role_name_locale2;

	@ApiModelProperty(value = "ロール情報名称(ロケール3)")
	private String[] role_name_locale3;

	@ApiModelProperty(value = "ロール情報説明(ロケール1)")
	private String[] role_description_locale1;

	@ApiModelProperty(value = "ロール情報説明(ロケール2)")
	private String[] role_description_locale2;

	@ApiModelProperty(value = "ロール情報説明(ロケール3)")
	private String[] role_description_locale3;

	@ApiModelProperty(value = "ロール情報備考")
	private String[] role_note;

	@ApiModelProperty(value = "デバイスグループ階層")
	private String[] hierarchy;

	@ApiModelProperty(value = "URL ※メソッド入力時は必須")
	private String url;

	@ApiModelProperty(value = "メソッド ※URL入力時は必須")
	private String method;

	@ApiModelProperty(value = "任意並び順条件")
	private String sort;

	@ApiModelProperty(value = "取得フィールド")
	private String fields;

	@ApiModelProperty(value = "表示対象ページ番号")
	private String page;

	@ApiModelProperty(value = "1度に返すItem数")
	private String limit;

	public String buildUrlParameter() {
		StringJoiner sj = new StringJoiner("&", "?", "");
		sj.setEmptyValue("");
		try {
			if (model_id != null)
				for (String s : model_id)
					sj.add("model_id=" + URLEncoder.encode(s, ENCODING));

			if (serial_no != null)
				for (String s : serial_no)
					sj.add("serial_no=" + URLEncoder.encode(s, ENCODING));

			if (event_id != null)
				for (String s : event_id)
					sj.add("event_id=" + URLEncoder.encode(s, ENCODING));

			if (event_type != null)
				for (String s : event_type)
					sj.add("event_type=" + URLEncoder.encode(s, ENCODING));

			if (event_level != null)
				for (String s : event_level)
					sj.add("event_level=" + URLEncoder.encode(s, ENCODING));

			if (sensor_id != null)
				for (String s : sensor_id)
					sj.add("sensor_id=" + URLEncoder.encode(s, ENCODING));

			if (name_locale1 != null)
				for (String s : name_locale1)
					sj.add("name_locale1=" + URLEncoder.encode(s, ENCODING));

			if (name_locale2 != null)
				for (String s : name_locale2)
					sj.add("name_locale2=" + URLEncoder.encode(s, ENCODING));

			if (name_locale3 != null)
				for (String s : name_locale3)
					sj.add("name_locale3=" + URLEncoder.encode(s, ENCODING));

			if (description_locale1 != null)
				for (String s : description_locale1)
					sj.add("description_locale1=" + URLEncoder.encode(s, ENCODING));

			if (description_locale2 != null)
				for (String s : description_locale2)
					sj.add("description_locale2=" + URLEncoder.encode(s, ENCODING));

			if (description_locale3 != null)
				for (String s : description_locale3)
					sj.add("description_locale3=" + URLEncoder.encode(s, ENCODING));

			if (chk_app_name != null)
				for (String s : chk_app_name)
					sj.add("chk_app_name=" + URLEncoder.encode(s, ENCODING));

			if (chk_app_parameter != null)
				for (String s : chk_app_parameter)
					sj.add("chk_app_parameter=" + URLEncoder.encode(s, ENCODING));

			if (check_timing != null)
				for (String s : check_timing)
					sj.add("check_timing=" + URLEncoder.encode(s, ENCODING));

			if (note != null)
				for (String s : note)
					sj.add("note=" + URLEncoder.encode(s, ENCODING));

			if (device_group_id != null)
				for (String s : device_group_id)
					sj.add("device_group_id=" + URLEncoder.encode(s, ENCODING));

			if (device_group_type != null)
				for (String s : device_group_type)
					sj.add("device_group_type=" + URLEncoder.encode(s, ENCODING));

			if (device_group_subtype != null)
				for (String s : device_group_subtype)
					sj.add("device_group_subtype=" + URLEncoder.encode(s, ENCODING));

			if (device_group_name_locale1 != null)
				for (String s : device_group_name_locale1)
					sj.add("device_group_name_locale1=" + URLEncoder.encode(s, ENCODING));

			if (device_group_name_locale2 != null)
				for (String s : device_group_name_locale2)
					sj.add("device_group_name_locale2=" + URLEncoder.encode(s, ENCODING));

			if (device_group_name_locale3 != null)
				for (String s : device_group_name_locale3)
					sj.add("device_group_name_locale3=" + URLEncoder.encode(s, ENCODING));

			if (device_group_description_locale1 != null)
				for (String s : device_group_description_locale1)
					sj.add("device_group_description_locale1=" + URLEncoder.encode(s, ENCODING));

			if (device_group_description_locale2 != null)
				for (String s : device_group_description_locale2)
					sj.add("device_group_description_locale2=" + URLEncoder.encode(s, ENCODING));

			if (device_group_description_locale3 != null)
				for (String s : device_group_description_locale3)
					sj.add("device_group_description_locale3=" + URLEncoder.encode(s, ENCODING));

			if (parent_device_group_id != null)
				for (String s : parent_device_group_id)
					sj.add("parent_device_group_id=" + URLEncoder.encode(s, ENCODING));

			if (setup_place != null)
				for (String s : setup_place)
					sj.add("setup_place=" + URLEncoder.encode(s, ENCODING));

			if (setup_status != null)
				for (String s : setup_status)
					sj.add("setup_status=" + URLEncoder.encode(s, ENCODING));

			if (latitude != null)
				for (String s : latitude)
					sj.add("latitude=" + URLEncoder.encode(s, ENCODING));

			if (longitude != null)
				for (String s : longitude)
					sj.add("longitude=" + URLEncoder.encode(s, ENCODING));

			if (device_group_note != null)
				for (String s : device_group_note)
					sj.add("device_group_note=" + URLEncoder.encode(s, ENCODING));

			if (role_id != null)
				for (String s : role_id)
					sj.add("role_id=" + URLEncoder.encode(s, ENCODING));

			if (root_group_id != null)
				for (String s : root_group_id)
					sj.add("root_group_id=" + URLEncoder.encode(s, ENCODING));

			if (hierarchy != null)
				for (String s : hierarchy)
					sj.add("hierarchy=" + URLEncoder.encode(s, ENCODING));

			if (role_name_locale1 != null)
				for (String s : role_name_locale1)
					sj.add("role_name_locale1=" + URLEncoder.encode(s, ENCODING));

			if (role_name_locale2 != null)
				for (String s : role_name_locale2)
					sj.add("role_name_locale2=" + URLEncoder.encode(s, ENCODING));

			if (role_name_locale3 != null)
				for (String s : role_name_locale3)
					sj.add("role_name_locale3=" + URLEncoder.encode(s, ENCODING));

			if (role_description_locale1 != null)
				for (String s : role_description_locale1)
					sj.add("role_description_locale1=" + URLEncoder.encode(s, ENCODING));

			if (role_description_locale2 != null)
				for (String s : role_description_locale2)
					sj.add("role_description_locale2=" + URLEncoder.encode(s, ENCODING));

			if (role_description_locale3 != null)
				for (String s : role_description_locale3)
					sj.add("role_description_locale3=" + URLEncoder.encode(s, ENCODING));

			if (role_note != null)
				for (String s : role_note)
					sj.add("role_note=" + URLEncoder.encode(s, ENCODING));

			if (sort != null)
				sj.add("sort=" + URLEncoder.encode(sort, ENCODING));

			if (fields != null)
				sj.add("fields=" + URLEncoder.encode(fields, ENCODING));

			if (page != null)
				sj.add("page=" + URLEncoder.encode(page, ENCODING));

			if (limit != null)
				sj.add("limit=" + URLEncoder.encode(limit, ENCODING));

		} catch (UnsupportedEncodingException e) {
		}
		return sj.toString();
	}
}
