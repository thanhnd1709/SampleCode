package com.app.controller;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.RequestEntity.BodyBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;
import org.springframework.web.util.UriComponents;

import com.app.common.Consts;
import com.app.exception.BadRequestException;
import com.app.model.FileInfoNotificationModel;
import com.app.model.FileInfoNotificationQueryModel;
import com.app.model.PostFileModel;
import com.app.model.RequestOpeInstructModel;
import com.app.model.ResponseFileModel2;
import com.app.model.ResponseModel;
import com.app.model.ResponseOpeInstructModel;
import com.app.model.SubResponseModel;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * GWへのファイル情報通知APIコントローラクラス
 * @author（TOSCO）
 */
@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_DEVICE)
@Api(tags ={Consts.TAGS_DEVICE_OPERATIONS,}, description = Consts.MSG_DEVICE_OPERATIONS)
public class FileInfoNotificationAPIController {

	public static final Logger logger = LoggerFactory.getLogger(FileInfoNotificationAPIController.class);

	/**
	 * GWへのファイル情報通知
	 */
	@ApiOperation(value = Consts.MSG_POST_FILE_INFO_NOTIFICATION, notes = Consts.MSG_POST_FILE_INFO_NOTIFICATION_01, nickname = Consts.OPERATIONID_FILE_INFO_NOTIFICATION_POST)
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Created", response = FileInfoNotificationModel.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_FILE_INFO_NOTIFICATION, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<Object> create(HttpServletRequest request, Locale locale, @Valid @RequestBody FileInfoNotificationQueryModel model, Errors errors) throws Exception {
		logger.info("[/v1/device/fileInfoNotification POST] start request：" + model);

		//入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		if (errors.hasErrors()) {
			BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			for(FieldError err :  errors.getFieldErrors()) {
				lstError.add(new SubResponseModel(err.getField(), err.getDefaultMessage()));
			}
			exp.setArgs(lstError);
			throw exp;
		}

		// リクエストヘッダ取得
		Enumeration<String> e = request.getHeaderNames();
		Map<String, String> headers = new HashMap<String, String>();


		while (e.hasMoreElements()) {
			String header = e.nextElement();
			headers.put(header, request.getHeader(header));
			if (header.equalsIgnoreCase("authorization")) {
				headers = new HashMap<String, String>();
				String auth = request.getHeader(header);
				headers.put(header, auth);
				String principle = request.getHeader("X-MS-CLIENT-PRINCIPAL-NAME");
				headers.put("X-REPLACE-USER-ID", principle);
				break;
			}
		}

		// originヘッダの変更を許可する。
		System.setProperty("sun.net.http.allowRestrictedHeaders", "true");

		 // ファイル登録API実行
		ResponseFileModel2 postFileResponse = null;
		try {
			postFileResponse = postFile(headers, locale, model, errors);
		} catch (HttpClientErrorException ce) {
			logger.warn("[/v1/sensor-data-file-mgt/file POST]" + ce.getStatusCode() + " " + ce.getResponseBodyAsString());
			return getResponseEntity(ce.getResponseBodyAsString(), "[File Regist API]");
		} catch (HttpServerErrorException se) {
			logger.warn("[/v1/sensor-data-file-mgt/file POST]" + se.getStatusCode() + " " + se.getResponseBodyAsString());
			return getResponseEntity(se.getResponseBodyAsString(), "[File Regist API]");
		}

		// GWへのコマンド実行依頼API実行
		ResponseOpeInstructModel opeInstructResponse = null;
		try {
			opeInstructResponse = opeInstruct(headers, locale, model, errors, postFileResponse);
		} catch (HttpClientErrorException ce) {
			logger.warn("[/v1/device/opeInstructions  POST] " + ce.getStatusCode() + " " + ce.getResponseBodyAsString());
			return getResponseEntity(ce.getResponseBodyAsString(), "[Direct Method API]");
		} catch (HttpServerErrorException se) {
			logger.warn("[/v1/device/opeInstructions  POST] " + se.getStatusCode() + " " + se.getResponseBodyAsString());
			return getResponseEntity(se.getResponseBodyAsString(), "[Direct Method API]");
		}

		// APIレスポンス作成
		FileInfoNotificationModel response = new FileInfoNotificationModel();
		response.setFile_name(postFileResponse.file_name);
		response.setSend_id(opeInstructResponse.getSend_id());
		response.setResult_detail_code(opeInstructResponse.getResult_detail_code());
		response.setResult_message(opeInstructResponse.getResult_message());
		response.setData(opeInstructResponse.getData());
		HttpStatus resultCode = HttpStatus.valueOf(Integer.parseInt(opeInstructResponse.getResult_code()));

		logger.info("[/v1/device/fileInfoNotification POST] end response：" + response);
		return new ResponseEntity<Object>(response, resultCode);
	}

	/**
	 * ファイル登録API実行
	 * @param headers リクエストヘッダ
	 * @param locale ロケール
	 * @param querymodel リクエストボディ
	 * @param errors バリデーションエラー情報
	 * @return ファイル登録APIレスポンス
	 * @throws Exception
	 */
	private ResponseFileModel2 postFile(Map<String, String> headers, Locale locale, FileInfoNotificationQueryModel querymodel, Errors errors) throws Exception {
		PostFileModel model = new PostFileModel();
		model.setFile_type(Consts.FILE_TYPE_9);
		model.setContainer(querymodel.getContainer());
		model.setFile_name(querymodel.getFile_name());
		model.setZip_flg(querymodel.getZip_flg());
		model.setFile_data(querymodel.getFile_data());
		model.setBase64_flg(querymodel.getBase64_flg());
		model.setReserve1(querymodel.getReserve1());
		model.setReserve2(querymodel.getReserve2());
		model.setReserve3(querymodel.getReserve3());
		model.setReserve4(querymodel.getReserve4());
		model.setReserve5(querymodel.getReserve5());

		UriComponents uriComponents = MvcUriComponentsBuilder
				.fromMethodName(PostFileAPIController.class, "PostFile", locale, model).build();
        URI uri = uriComponents.toUri();
        BodyBuilder body = RequestEntity.post(uri).contentType(MediaType.APPLICATION_JSON);
        for (String key : headers.keySet()) {
        	body = body.header(key, headers.get(key));
        }
        RequestEntity<PostFileModel> request = body.body(model);

		// POST実行
        logger.info("[/v1/sensor-data-file-mgt/file POST] request=" + request.toString());
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setRequestFactory(new HttpComponentsClientHttpRequestFactory());
		ResponseEntity<ResponseFileModel2> responseEntity = restTemplate.exchange(request, ResponseFileModel2.class);
        logger.info("[/v1/sensor-data-file-mgt/file POST] response=" + responseEntity.toString());

		return responseEntity.getBody();
	}

	/**
	 * GWへのコマンド実行依頼API実行
	 * @param headers リクエストヘッダ
	 * @param locale ロケール
	 * @param querymodel リクエストボディ
	 * @param errors バリデーションエラー情報
	 * @return GWへのコマンド実行依頼APIレスポンス
	 */
	private ResponseOpeInstructModel opeInstruct(Map<String, String> headers, Locale locale, FileInfoNotificationQueryModel querymodel, Errors errors, ResponseFileModel2 fileinfo) {
		String remoteAddr = headers.get("RemoteAddr");
		String clientAddr = headers.get("x-forwarded-for");
		String referer = headers.get("referer");
		String origin = headers.get("origin");
		String userAgent = headers.get("user-agent");

		RequestOpeInstructModel model = new RequestOpeInstructModel();
		model.setGw_model_id(querymodel.getGw_model_id());
		model.setGw_serial_no(querymodel.getGw_serial_no());
		model.setOperation("FileNotice");
		Map<String, Object> argument = new HashMap<String, Object>();
		argument.put("container", querymodel.getContainer());
		argument.put("fileName", fileinfo.file_name);
		argument.put("fileType", querymodel.getFile_type());
		argument.put("noticeInfo", querymodel.getNotice_info());
		model.setArgument(argument);

		UriComponents uriComponents = MvcUriComponentsBuilder
				.fromMethodName(OpeInstructAPIController.class, "post", locale, model, errors,
						remoteAddr, clientAddr, referer, origin, userAgent).build();
		URI uri = uriComponents.toUri();
		BodyBuilder body = RequestEntity.post(uri).contentType(MediaType.APPLICATION_JSON);
		for (String key : headers.keySet()) {
			body = body.header(key, headers.get(key));
		}
		RequestEntity<RequestOpeInstructModel> request = body.body(model);

		// POST実行
		logger.info("[/v1/device/opeInstructions  POST] request=" + request.toString());
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setRequestFactory(new HttpComponentsClientHttpRequestFactory());
		ResponseEntity<ResponseOpeInstructModel> responseEntity = restTemplate.exchange(request, ResponseOpeInstructModel.class);
		logger.info("[/v1/device/opeInstructions  POST] response=" + responseEntity.toString());

		ResponseOpeInstructModel response = responseEntity.getBody();
		response.setResult_code(responseEntity.getStatusCode().toString());
		return response;
	}

	/**
	 * API実行エラー時のレスポンスを作成
	 * @param json APIレスポンスボディ
	 * @param messagePrefix 実行API識別用文字列
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	@SuppressWarnings("unchecked")
	private ResponseEntity<Object> getResponseEntity(String json, String messagePrefix) throws JsonParseException, JsonMappingException, IOException {
		ResponseModel model = null;
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> resultMap = mapper.readValue(json, new TypeReference<LinkedHashMap<String,Object>>(){});
		int code = (Integer)resultMap.get("code");
		String message = messagePrefix + " " + (String)resultMap.get("message");
		if (resultMap.get("detail") instanceof String) {
			model = new ResponseModel(code, message, (String)resultMap.get("detail"));
		} else if (resultMap.get("details") instanceof List) {
			List<SubResponseModel> list = new ArrayList<>();
			for (Map<String, Object> obj : (List<Map<String, Object>>)resultMap.get("details")) {
				list.add(new SubResponseModel((String)obj.get("fieldId"), (String)obj.get("message")));
			}
			model = new ResponseModel(code, message, list);
		}
		return new ResponseEntity<Object>(model, HttpStatus.valueOf(code));
	}
}
