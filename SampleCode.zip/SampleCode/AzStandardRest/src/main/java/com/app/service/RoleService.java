package com.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.common.utils.DateTimeUtil;
import com.app.entity.MstRollEntity;
import com.app.exception.DataNotFoundException;
import com.app.exception.LockingFailureException;
import com.app.model.RollModel;
import com.app.model.RollQueryModel;
import com.app.repository.RoleRepository;
import com.app.repository.RoleRepositoryCustom;

@Service
@Transactional(readOnly = true)
public class RoleService {
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	private RoleRepositoryCustom roleRepositoryCustom;

	public RollModel findOne(int uuid, String fields, String user_id) throws Exception{
		ModelFilter mf = makeModelFilter(fields);

		MstRollEntity entity = roleRepository.findOne(uuid);
		RollModel newModel = null;
		if (entity != null) {
			if (!roleRepositoryCustom.hasAuthorityByRoleId(user_id, entity.getRole_id())) return newModel;
			newModel = new RollModel();
			if (mf.id) newModel.setId(entity.getId());
			if (mf.role_id) newModel.setRole_id(entity.getRole_id());
			if (mf.base_role_flg) newModel.setBase_role_flg(entity.getBase_role_flg());
			if (mf.authority_role_id) newModel.setAuthority_role_id(entity.getAuthority_role_id());
			if (mf.name_locale1) newModel.setName_locale1(entity.getName_locale1());
			if (mf.name_locale2) newModel.setName_locale2(entity.getName_locale2());
			if (mf.name_locale3) newModel.setName_locale3(entity.getName_locale3());
			if (mf.description_locale1) newModel.setDescription_locale1(entity.getDescription_locale1());
			if (mf.description_locale2) newModel.setDescription_locale2(entity.getDescription_locale2());
			if (mf.description_locale3) newModel.setDescription_locale3(entity.getDescription_locale3());
			if (mf.note) newModel.setNote(entity.getNote());
			if (mf.version) newModel.setVersion(entity.getVersion());
			if (mf.inserted) newModel.setInserted(entity.getInserted());
			if (mf.insert_time) newModel.setInsert_time(DateTimeUtil.formatTimestamp(entity.getInsert_time()));
			if (mf.updated) newModel.setUpdated(entity.getUpdated());
			if (mf.update_time) newModel.setUpdate_time(DateTimeUtil.formatTimestamp(entity.getUpdate_time()));
		}
		return  newModel;
	}

	public List<RollModel> findAll(RollQueryModel filter) throws Exception{

		ModelFilter mf = makeModelFilter(filter.getFields());

		List<String> sort = new ArrayList<String>();
		if (filter.getSort() != null) {
			for (String item : filter.getSort().split(",")) {
				sort.add(item.trim().toLowerCase());
			}
		}

		Integer limit = null;
		Integer offset = null;
		if (filter.getPage() != null && filter.getLimit() != null) {
			limit = Integer.parseInt(filter.getLimit());
			offset = (Integer.parseInt(filter.getPage()) - 1) * limit;
		}

		List<MstRollEntity> entList = roleRepositoryCustom.findAll(filter, sort, limit, offset);
		List<RollModel> modelList = new ArrayList<RollModel>();
		for (MstRollEntity entity : entList) {
			RollModel newModel = new RollModel();
			if (mf.id) newModel.setId(entity.getId());
			if (mf.role_id) newModel.setRole_id(entity.getRole_id());
			if (mf.base_role_flg) newModel.setBase_role_flg(entity.getBase_role_flg());
			if (mf.authority_role_id) newModel.setAuthority_role_id(entity.getAuthority_role_id());
			if (mf.name_locale1) newModel.setName_locale1(entity.getName_locale1());
			if (mf.name_locale2) newModel.setName_locale2(entity.getName_locale2());
			if (mf.name_locale3) newModel.setName_locale3(entity.getName_locale3());
			if (mf.description_locale1) newModel.setDescription_locale1(entity.getDescription_locale1());
			if (mf.description_locale2) newModel.setDescription_locale2(entity.getDescription_locale2());
			if (mf.description_locale3) newModel.setDescription_locale3(entity.getDescription_locale3());
			if (mf.note) newModel.setNote(entity.getNote());
			if (mf.version) newModel.setVersion(entity.getVersion());
			if (mf.inserted) newModel.setInserted(entity.getInserted());
			if (mf.insert_time) newModel.setInsert_time(DateTimeUtil.formatTimestamp(entity.getInsert_time()));
			if (mf.updated) newModel.setUpdated(entity.getUpdated());
			if (mf.update_time) newModel.setUpdate_time(DateTimeUtil.formatTimestamp(entity.getUpdate_time()));
			modelList.add(newModel);
		}
		return modelList;
	}

	public Long countAll(RollQueryModel filter) throws Exception{
		return roleRepositoryCustom.countAll(filter);
	}

	public Boolean isRoleExist(String roleId) throws Exception{
		return roleRepositoryCustom.isRoleExist(roleId);
	}

	public Boolean hasAuthorityByRoleId(String userId, String roleId) {
		return roleRepositoryCustom.hasAuthorityByRoleId(userId, roleId);
	}

	public Boolean isSystemAdmin(String userId) throws Exception{
		return roleRepositoryCustom.isSystemAdmin(userId);
	}

	@Transactional(readOnly = false)
	public RollModel save(RollModel model) throws Exception{

		MstRollEntity newRec = new MstRollEntity();

		if (model.getRole_id() != null) newRec.setRole_id(model.getRole_id());
		if (model.getBase_role_flg() != null) newRec.setBase_role_flg(model.getBase_role_flg());
		if (model.getAuthority_role_id() != null) newRec.setAuthority_role_id(model.getAuthority_role_id());
		if (model.getName_locale1() != null) newRec.setName_locale1(model.getName_locale1());
		if (model.getName_locale2() != null) newRec.setName_locale2(model.getName_locale2());
		if (model.getName_locale3() != null) newRec.setName_locale3(model.getName_locale3());
		if (model.getDescription_locale1() != null) newRec.setDescription_locale1(model.getDescription_locale1());
		if (model.getDescription_locale2() != null) newRec.setDescription_locale2(model.getDescription_locale2());
		if (model.getDescription_locale3() != null) newRec.setDescription_locale3(model.getDescription_locale3());
		if (model.getNote() != null) newRec.setNote(model.getNote());
		newRec.setVersion(0L);

		newRec = roleRepository.save(newRec);

		RollModel newModel = new RollModel();
		newModel.setId(newRec.getId());
		newModel.setRole_id(newRec.getRole_id());
		newModel.setBase_role_flg(newRec.getBase_role_flg());
		newModel.setAuthority_role_id(newRec.getAuthority_role_id());
		newModel.setName_locale1(newRec.getName_locale1());
		newModel.setName_locale2(newRec.getName_locale2());
		newModel.setName_locale3(newRec.getName_locale3());
		newModel.setDescription_locale1(newRec.getDescription_locale1());
		newModel.setDescription_locale2(newRec.getDescription_locale2());
		newModel.setDescription_locale3(newRec.getDescription_locale3());
		newModel.setNote(newRec.getNote());
		newModel.setVersion(newRec.getVersion());
		newModel.setInserted(newRec.getInserted());
		newModel.setInsert_time(DateTimeUtil.formatTimestamp(newRec.getInsert_time()));
		newModel.setUpdated(newRec.getUpdated());
		newModel.setUpdate_time(DateTimeUtil.formatTimestamp(newRec.getUpdate_time()));
		return newModel;
	}

	@Transactional(readOnly = false)
	public RollModel update(Locale locale,int id, RollModel model) throws Exception{
		MstRollEntity rec = roleRepositoryCustom.findOneForUpdate(id);
		if(rec == null) {
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.roleInfo")});
			throw exp;
		}

		rec.setRole_id(model.getRole_id());
		rec.setBase_role_flg(model.getBase_role_flg());
		rec.setAuthority_role_id(model.getAuthority_role_id());
		rec.setName_locale1(model.getName_locale1());
		rec.setName_locale2(model.getName_locale2());
		rec.setName_locale3(model.getName_locale3());
		rec.setDescription_locale1(model.getDescription_locale1());
		rec.setDescription_locale2(model.getDescription_locale2());
		rec.setDescription_locale3(model.getDescription_locale3());
		rec.setNote(model.getNote());
		if (model.getVersion() == null || model.getVersion() != rec.getVersion()) {
			LockingFailureException exp = new LockingFailureException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.roleInfo")});
			throw exp;
		}

		roleRepository.saveAndFlush(rec);
		MstRollEntity updateRec = roleRepository.findOne(id);
		RollModel newModel = new RollModel();
		newModel.setId(updateRec.getId());
		newModel.setRole_id(updateRec.getRole_id());
		newModel.setBase_role_flg(updateRec.getBase_role_flg());
		newModel.setAuthority_role_id(updateRec.getAuthority_role_id());
		newModel.setName_locale1(updateRec.getName_locale1());
		newModel.setName_locale2(updateRec.getName_locale2());
		newModel.setName_locale3(updateRec.getName_locale3());
		newModel.setDescription_locale1(updateRec.getDescription_locale1());
		newModel.setDescription_locale2(updateRec.getDescription_locale2());
		newModel.setDescription_locale3(updateRec.getDescription_locale3());
		newModel.setNote(updateRec.getNote());
		newModel.setVersion(updateRec.getVersion());
		newModel.setInserted(updateRec.getInserted());
		newModel.setInsert_time(DateTimeUtil.formatTimestamp(updateRec.getInsert_time()));
		newModel.setUpdated(updateRec.getUpdated());
		newModel.setUpdate_time(DateTimeUtil.formatTimestamp(updateRec.getUpdate_time()));
		return newModel;
	}

	@Transactional(readOnly = false)
	public void delete(int uuid) throws Exception {
		MstRollEntity rec = roleRepository.findOne(uuid);
		if(rec == null) {
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.roleInfo")});
			throw exp;
		}
		roleRepository.delete(rec);
	}

	private ModelFilter makeModelFilter(String fields) {
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if ("id".equals(str)) mf.id = true;
				if ("role_id".equals(str)) mf.role_id = true;
				if ("base_role_flg".equals(str)) mf.base_role_flg = true;
				if ("authority_role_id".equals(str)) mf.authority_role_id = true;
				if ("name_locale1".equals(str)) mf.name_locale1 = true;
				if ("name_locale2".equals(str)) mf.name_locale2 = true;
				if ("name_locale3".equals(str)) mf.name_locale3 = true;
				if ("description_locale1".equals(str)) mf.description_locale1 = true;
				if ("description_locale2".equals(str)) mf.description_locale2 = true;
				if ("description_locale3".equals(str)) mf.description_locale3 = true;
				if ("note".equals(str)) mf.note = true;
				if ("version".equals(str)) mf.version = true;
				if ("inserted".equals(str)) mf.inserted = true;
				if ("insert_time".equals(str)) mf.insert_time = true;
				if ("updated".equals(str)) mf.updated = true;
				if ("update_time".equals(str)) mf.update_time = true;
			}
		}
		return mf;
	}

	class ModelFilter {
		public ModelFilter(boolean b) {
			id = b;
			role_id = b;
			base_role_flg = b;
			authority_role_id = b;
			name_locale1 = b;
			name_locale2 = b;
			name_locale3 = b;
			description_locale1 = b;
			description_locale2 = b;
			description_locale3 = b;
			note = b;
			version = b;
			inserted = b;
			insert_time = b;
			updated = b;
			update_time = b;
		}
		public boolean id = true;
		public boolean role_id = true;
		public boolean base_role_flg= true;
		public boolean authority_role_id= true;
		public boolean name_locale1 = true;
		public boolean name_locale2 = true;
		public boolean name_locale3 = true;
		public boolean description_locale1 = true;
		public boolean description_locale2 = true;
		public boolean description_locale3 = true;
		public boolean note = true;
		public boolean version = true;
		public boolean inserted = true;
		public boolean insert_time = true;
		public boolean updated = true;
		public boolean update_time = true;
	}
}
