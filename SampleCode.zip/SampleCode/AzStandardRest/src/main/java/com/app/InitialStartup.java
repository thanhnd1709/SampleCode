package com.app;

import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import com.app.common.utils.CustomTelemetryThreadLocal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.app.common.Consts;
import com.app.entity.MstSystemInfoEntity;
import com.app.model.SystemInfoModel;
import com.app.repository.MstSystemInfoRepositoryCustom;

/**
 * APIの初回起動時、実行する
 *
 * @author（TOSCO）ウェイ
 */
@EnableJpaRepositories
@Configuration
public class InitialStartup {

	@Autowired
	private MstSystemInfoRepositoryCustom repoCustom;
	@Autowired
	private MessageSource messageSource;
	private Logger logger = LoggerFactory.getLogger(InitialStartup.class);

	public static SystemInfoModel systemInfoModel = new SystemInfoModel();
	public static String[] timeSeriesAPIRangeSearch;
	public static String[] timeSeriesAPI1Search;

	/**
	 * 初期化設定処理
	 */
	@Bean
	public String execStartup() {
		logger.info("InitialStartup.execStartup()");

		// HTTPSプロキシ設定
		ResourceBundle _bundle = ResourceBundle.getBundle("application");
		System.setProperty("http.proxySet", _bundle.getString("http.proxy.set"));
		System.setProperty("http.proxyHost", _bundle.getString("http.proxy.host"));
		System.setProperty("http.proxyPort", _bundle.getString("http.proxy.port"));
		System.setProperty("https.proxySet", _bundle.getString("https.proxy.set"));
		System.setProperty("https.proxyHost", _bundle.getString("https.proxy.host"));
		System.setProperty("https.proxyPort", _bundle.getString("https.proxy.port"));

		timeSeriesAPIRangeSearch = new String []{Consts.PARAMETER_KBN_RAW,
				Consts.PARAMETER_KBN_HOUR,
				Consts.PARAMETER_KBN_MONTH};


		try {
			// システムの設定情報を取得する
			List<MstSystemInfoEntity> lstResult = repoCustom.search();
			for (MstSystemInfoEntity result : lstResult) {
				switch (result.getKey()) {
				// 時間別移行待機時間
				case Consts.KEY_DATA_HOUR_WAIT:
					systemInfoModel.setDataHourMigrateWaite(result.getValue_int());
					logger.info("mst_system_info（DataHourMigrateWaite）：" + systemInfoModel.getDataHourMigrateWaite());
					break;

				// 日別Blob移行待機日数
				case Consts.KEY_DATA_BLOB_WAIT:
					systemInfoModel.setDataBlobMigrateWaite(result.getValue_int());
					logger.info(
							"mst_system_info（DataBlobMigrateWaite）：" + systemInfoModel.getDataBlobMigrateWaite());
					break;

				// 日別Blob移行待機日数２
				case Consts.KEY_DATA_BLOB_WAIT2:
					systemInfoModel.setDataBlobMigrateWaite2(result.getValue_int());
					logger.info("mst_system_info(DataBlobMigrateWaite2）："
							+ systemInfoModel.getDataBlobMigrateWaite2());
					break;

				}
			}

			// 下記の何れかが取得できない、又は Null、又は 空白の場合、0を設定して
			// 処理を続行する
			checkSystemValues();

		} catch (Exception e) {
			CustomTelemetryThreadLocal.setErrorCode(Integer.toString(Consts.HTTP_CODE_500));
			CustomTelemetryThreadLocal.setErrorMsg(Consts.HTTP_MESSAGE_500);
			checkSystemValues();
			logger.warn(e.getMessage());
		}
		return "";
	}

	private void checkSystemValues() {
		// システムマスタで取得できない場合のデフォルト値
		Long defaultVal = new Long(0);

		// 時間別移行待機時間
		if (systemInfoModel.getDataHourMigrateWaite() == null) {

			systemInfoModel.setDataHourMigrateWaite(defaultVal);
			logger.warn(
					messageSource.getMessage(Consts.MESSAGE_E000106, new String[] { "mst_system_info(key="+ Consts.KEY_DATA_HOUR_WAIT+")"},
							Locale.getDefault()));

			// 日別Blob移行待機日数
		}
		if (systemInfoModel.getDataBlobMigrateWaite() == null) {
			systemInfoModel.setDataBlobMigrateWaite(defaultVal);
			logger.warn(
					messageSource.getMessage(Consts.MESSAGE_E000106, new String[] { "mst_system_info(key="+ Consts.KEY_DATA_BLOB_WAIT +")" },
							Locale.getDefault()));

			// 日別Blob移行待機日数２
		}
		if (systemInfoModel.getDataBlobMigrateWaite2() == null) {
			systemInfoModel.setDataBlobMigrateWaite2(defaultVal);
			logger.warn(messageSource.getMessage(Consts.MESSAGE_E000106, new String[] {  "mst_system_info(key="+ Consts.KEY_DATA_BLOB_WAIT2 +")" },
					 Locale.getDefault()));
		}
	}
}
