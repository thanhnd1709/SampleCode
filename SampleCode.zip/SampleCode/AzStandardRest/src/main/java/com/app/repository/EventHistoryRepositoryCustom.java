package com.app.repository;
import java.sql.Timestamp;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.app.entity.EventHistoryEntity;
import com.app.model.EventHistoryModel;

/**
 * イベント・アラーム履歴検索リポジトリクラス
 * @author（TOSCO）小川
 */
@Repository
public interface EventHistoryRepositoryCustom {

	/**
	 * ①デバイスグループID指定時 かつ 親子展開フラグがtrueの時、デバイスグループを親子展開し展開後のデバイスグループ群で対象のイベントIDを求めイベント履歴を検索する
	 */
	List<EventHistoryEntity> searchDeviceGroupIdTrue(EventHistoryModel query, Timestamp dateFrom, Timestamp dateTo, String sort, Integer limit, Integer offset);

	/**
	 * ②デバイスグループID指定時 かつ 親子展開フラグがfalseの時、指定されたデバイスグループで対象のイベントIDを求めイベント履歴を検索する
	 */
	List<EventHistoryEntity> searchDeviceGroupIdFalse(EventHistoryModel query, Timestamp dateFrom, Timestamp dateTo, String sort, Integer limit, Integer offset);

	/**
	 * ③[配列]デバイスリスト指定時 かつ 親子展開フラグがtrueの時、デバイスを親子展開し展開後のデバイス群で対象のイベントIDを求めイベント履歴を検索する
	 */
	List<EventHistoryEntity> searchDeviceLitsTrue(EventHistoryModel query, Timestamp dateFrom, Timestamp dateTo, String sort, Integer limit, Integer offset);

	/**
	 * ④[配列]デバイスリスト指定時 かつ 親子展開フラグがfalseの時、指定されたデバイスで対象のイベントIDを求めイベント履歴を検索する
	 */
	List<EventHistoryEntity> searchDeviceListFalse(EventHistoryModel query, Timestamp dateFrom, Timestamp dateTo, String sort, Integer limit, Integer offset);

	/**
	 * ⑤デバイスグループID、[配列]デバイスリスト未指定時、イベント時刻(From-To)等でイベント履歴を検索する
	 */
	List<EventHistoryEntity> searchEventTime(EventHistoryModel query, Timestamp dateFrom, Timestamp dateTo, String sort, Integer limit, Integer offset);


}