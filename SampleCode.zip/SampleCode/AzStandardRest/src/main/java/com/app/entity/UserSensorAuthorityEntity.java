package com.app.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * ユーザ・センサー権限情報取得エンティティ
 * ※ユーザ・センサー権限情報は実テーブルではなく、
 * センサー情報、グループ構成デバイス、
 * DB Functionユーザ・デバイスグループ取得(fn_UserDeviceGroup)から
 * 返却されるテーブル値。
 */
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserSensorAuthorityEntity {

	@Id
	private Integer id;
	@Column
	private String model_id;
	@Column
	private String serial_no;
	@Column
	private String sensor_id;
	@Column
	private String sensor_type;
	@Column
	private String sensor_name_locale1;
	@Column
	private String sensor_name_locale2;
	@Column
	private String sensor_name_locale3;
	@Column
	private String unit_locale1;
	@Column
	private String unit_locale2;
	@Column
	private String unit_locale3;
	@Column
	private String transform_locale1;
	@Column
	private String transform_locale2;
	@Column
	private String transform_locale3;
	@Column
	private Integer decimal_num_locale1;
	@Column
	private Integer decimal_num_locale2;
	@Column
	private Integer decimal_num_locale3;
	@Column
	private Double max_value_locale1;
	@Column
	private Double max_value_locale2;
	@Column
	private Double max_value_locale3;
	@Column
	private Double min_value_locale1;
	@Column
	private Double min_value_locale2;
	@Column
	private Double min_value_locale3;
	@Column
	private String sensor_description_locale1;
	@Column
	private String sensor_description_locale2;
	@Column
	private String sensor_description_locale3;
	@Column
	private String measure_type;
	@Column
	private String data_type;
	@Column
	private Integer fixed_length;
	@Column
	private Boolean time_data_create_flg;
	@Column
	private Integer short_term_minutes;
	@Column
	private String sensor_note;
	@Column
	private String device_group_id;
	@Column
	private String device_group_type;
	@Column
	private String device_group_subtype;
	@Column
	private String device_group_name_locale1;
	@Column
	private String device_group_name_locale2;
	@Column
	private String device_group_name_locale3;
	@Column
	private String device_group_description_locale1;
	@Column
	private String device_group_description_locale2;
	@Column
	private String device_group_description_locale3;
	@Column
	private String parent_device_group_id;
	@Column
	private String setup_place;
	@Column
	private String setup_status;
	@Column
	private BigDecimal latitude;
	@Column
	private BigDecimal longitude;
	@Column
	private String device_group_note;
	@Column
	private String role_id;
	@Column
	private String root_group_id;
	@Column
	private String role_name_locale1;
	@Column
	private String role_name_locale2;
	@Column
	private String role_name_locale3;
	@Column
	private String role_description_locale1;
	@Column
	private String role_description_locale2;
	@Column
	private String role_description_locale3;
	@Column
	private String role_note;
	@Column
	private Integer hierarchy;
}

