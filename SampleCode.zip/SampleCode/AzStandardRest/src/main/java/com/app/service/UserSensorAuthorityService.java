package com.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.entity.UserSensorAuthorityEntity;
import com.app.model.UserSensorAuthorityModel;
import com.app.model.UserSensorAuthorityQueryModel;
import com.app.repository.UserSensorAuthorityRepository;

/**
 * ユーザ・センサー権限情報取得サービスクラス
 * @author 9571
 *
 */
@Service
@Transactional(readOnly = true)
public class UserSensorAuthorityService {

	@Autowired
	private UserSensorAuthorityRepository userSensorAuthorityRepository;

	/**
	 * ユーザ・センサー権限情報一覧取得
	 * @param filter 検索条件オブジェクト
	 * @return ユーザ・センサー権限情報リスト
	 * @throws Exception
	 */

	public List<UserSensorAuthorityModel> findAll(UserSensorAuthorityQueryModel filter) throws Exception{

		ModelFilter mf = makeModelFilter(filter.getFields());

		List<String> sort = new ArrayList<String>();
		if(filter.getSort() != null){
			for(String item : filter.getSort().split(",")){
				sort.add(item.trim().toLowerCase());
			}
		}

		Integer limit = null;
		Integer offset = null;
		if (filter.getLimit() != null && filter.getPage() != null) {
			limit = Integer.parseInt(filter.getLimit());
			offset = (Integer.parseInt(filter.getPage()) - 1) * limit;
		}

		List<UserSensorAuthorityEntity> entList = userSensorAuthorityRepository.findAll(filter, sort, limit, offset);

		List<UserSensorAuthorityModel> modelList = new ArrayList<UserSensorAuthorityModel>();
		for(UserSensorAuthorityEntity entity : entList){
			UserSensorAuthorityModel model = new UserSensorAuthorityModel();
			if(mf.model_id)model.setModel_id(entity.getModel_id());
			if(mf.serial_no)model.setSerial_no(entity.getSerial_no());
			if(mf.sensor_id)model.setSensor_id(entity.getSensor_id());
			if(mf.sensor_type)model.setSensor_type(entity.getSensor_type());
			if(mf.sensor_name_locale1)model.setSensor_name_locale1(entity.getSensor_name_locale1());
			if(mf.sensor_name_locale2)model.setSensor_name_locale2(entity.getSensor_name_locale2());
			if(mf.sensor_name_locale3)model.setSensor_name_locale3(entity.getSensor_name_locale3());
			if(mf.unit_locale1)model.setUnit_locale1(entity.getUnit_locale1());
			if(mf.unit_locale2)model.setUnit_locale2(entity.getUnit_locale2());
			if(mf.unit_locale3)model.setUnit_locale3(entity.getUnit_locale3());
			if(mf.transform_locale1)model.setTransform_locale1(entity.getTransform_locale1());
			if(mf.transform_locale2)model.setTransform_locale2(entity.getTransform_locale2());
			if(mf.transform_locale3)model.setTransform_locale3(entity.getTransform_locale3());
			if(mf.decimal_num_locale1)model.setDecimal_num_locale1(entity.getDecimal_num_locale1());
			if(mf.decimal_num_locale2)model.setDecimal_num_locale2(entity.getDecimal_num_locale2());
			if(mf.decimal_num_locale3)model.setDecimal_num_locale3(entity.getDecimal_num_locale3());
			if(mf.max_value_locale1)model.setMax_value_locale1(entity.getMax_value_locale1());
			if(mf.max_value_locale2)model.setMax_value_locale2(entity.getMax_value_locale2());
			if(mf.max_value_locale3)model.setMax_value_locale3(entity.getMax_value_locale3());
			if(mf.min_value_locale1)model.setMin_value_locale1(entity.getMin_value_locale1());
			if(mf.min_value_locale2)model.setMin_value_locale2(entity.getMin_value_locale2());
			if(mf.min_value_locale3)model.setMin_value_locale3(entity.getMin_value_locale3());
			if(mf.sensor_description_locale1)model.setSensor_description_locale1(entity.getSensor_description_locale1());
			if(mf.sensor_description_locale2)model.setSensor_description_locale2(entity.getSensor_description_locale2());
			if(mf.sensor_description_locale3)model.setSensor_description_locale3(entity.getSensor_description_locale3());
			if(mf.measure_type)model.setMeasure_type(entity.getMeasure_type());
			if(mf.data_type)model.setData_type(entity.getData_type());
			if(mf.fixed_length)model.setFixed_length(entity.getFixed_length());
			if(mf.time_data_create_flg)model.setTime_data_create_flg(entity.getTime_data_create_flg());
			if(mf.short_term_minutes)model.setShort_term_minutes(entity.getShort_term_minutes());
			if(mf.sensor_note)model.setSensor_note(entity.getSensor_note());
			if(mf.device_group_id)model.setDevice_group_id(entity.getDevice_group_id());
			if(mf.device_group_type)model.setDevice_group_type(entity.getDevice_group_type());
			if(mf.device_group_subtype)model.setDevice_group_subtype(entity.getDevice_group_subtype());
			if(mf.device_group_name_locale1)model.setDevice_group_name_locale1(entity.getDevice_group_name_locale1());
			if(mf.device_group_name_locale2)model.setDevice_group_name_locale2(entity.getDevice_group_name_locale2());
			if(mf.device_group_name_locale3)model.setDevice_group_name_locale3(entity.getDevice_group_name_locale3());
			if(mf.device_group_description_locale1)model.setDevice_group_description_locale1(entity.getDevice_group_description_locale1());
			if(mf.device_group_description_locale2)model.setDevice_group_description_locale2(entity.getDevice_group_description_locale2());
			if(mf.device_group_description_locale3)model.setDevice_group_description_locale3(entity.getDevice_group_description_locale3());
			if(mf.parent_device_group_id)model.setParent_device_group_id(entity.getParent_device_group_id());
			if(mf.setup_place)model.setSetup_place(entity.getSetup_place());
			if(mf.setup_status)model.setSetup_status(entity.getSetup_status());
			if(mf.latitude)model.setLatitude(entity.getLatitude());
			if(mf.longitude)model.setLongitude(entity.getLongitude());
			if(mf.device_group_note)model.setDevice_group_note(entity.getDevice_group_note());
			if(mf.role_id)model.setRole_id(entity.getRole_id());
			if(mf.root_group_id)model.setRoot_group_id(entity.getRoot_group_id());
			if(mf.role_name_locale1)model.setRole_name_locale1(entity.getRole_name_locale1());
			if(mf.role_name_locale2)model.setRole_name_locale2(entity.getRole_name_locale2());
			if(mf.role_name_locale3)model.setRole_name_locale3(entity.getRole_name_locale3());
			if(mf.role_description_locale1)model.setRole_description_locale1(entity.getRole_description_locale1());
			if(mf.role_description_locale2)model.setRole_description_locale2(entity.getRole_description_locale2());
			if(mf.role_description_locale3)model.setRole_description_locale3(entity.getRole_description_locale3());
			if(mf.role_note)model.setRole_note(entity.getRole_note());
			if(mf.hierarchy)model.setHierarchy(entity.getHierarchy());
			modelList.add(model);
		}
		return modelList;
	}

	/**
	 * ユーザ・センサー権限情報一覧件数取得
	 * @param filter 検索条件オブジェクト
	 * @return 検索結果件数
	 * @throws Exception
	 */
	public Long countAll(UserSensorAuthorityQueryModel filter) throws Exception{
		return userSensorAuthorityRepository.countAll(filter);
	}

	/**
	 * 返却項目フィルター作成
	 * @param fields 取得対象項目名リスト（カンマ区切り）
	 * @return フィルターオブジェクト
	 */
	private ModelFilter makeModelFilter(String fields) {
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if ("model_id".equals(str)) mf.model_id = true;
				if ("serial_no".equals(str)) mf.serial_no = true;
				if ("sensor_id".equals(str)) mf.sensor_id = true;
				if ("sensor_type".equals(str)) mf.sensor_type = true;
				if ("sensor_name_locale1".equals(str)) mf.sensor_name_locale1 = true;
				if ("sensor_name_locale2".equals(str)) mf.sensor_name_locale2 = true;
				if ("sensor_name_locale3".equals(str)) mf.sensor_name_locale3 = true;
				if ("unit_locale1".equals(str)) mf.unit_locale1 = true;
				if ("unit_locale2".equals(str)) mf.unit_locale2 = true;
				if ("unit_locale3".equals(str)) mf.unit_locale3 = true;
				if ("transform_locale1".equals(str)) mf.transform_locale1 = true;
				if ("transform_locale1".equals(str)) mf.transform_locale1 = true;
				if ("transform_locale3".equals(str)) mf.transform_locale3 = true;
				if ("decimal_num_locale1".equals(str)) mf.decimal_num_locale1 = true;
				if ("decimal_num_locale2".equals(str)) mf.decimal_num_locale2 = true;
				if ("decimal_num_locale3".equals(str)) mf.decimal_num_locale3 = true;
				if ("max_value_locale1".equals(str)) mf.max_value_locale1 = true;
				if ("max_value_locale2".equals(str)) mf.max_value_locale2 = true;
				if ("max_value_locale3".equals(str)) mf.max_value_locale3 = true;
				if ("min_value_locale1".equals(str)) mf.min_value_locale1 = true;
				if ("min_value_locale2".equals(str)) mf.min_value_locale2 = true;
				if ("min_value_locale3".equals(str)) mf.min_value_locale3 = true;
				if ("sensor_description_locale1".equals(str)) mf.sensor_description_locale1 = true;
				if ("sensor_description_locale2".equals(str)) mf.sensor_description_locale2 = true;
				if ("sensor_description_locale3".equals(str)) mf.sensor_description_locale3 = true;
				if ("measure_type".equals(str)) mf.measure_type = true;
				if ("data_type".equals(str)) mf.data_type = true;
				if ("fixed_length".equals(str)) mf.fixed_length = true;
				if ("time_data_create_flg".equals(str)) mf.time_data_create_flg = true;
				if ("short_term_minutes".equals(str)) mf.short_term_minutes = true;
				if ("sensor_note".equals(str)) mf.sensor_note = true;
				if ("device_group_id".equals(str)) mf.device_group_id = true;
				if ("device_group_type".equals(str)) mf.device_group_type = true;
				if ("device_group_subtype".equals(str)) mf.device_group_subtype = true;
				if ("device_group_name_locale1".equals(str)) mf.device_group_name_locale1 = true;
				if ("device_group_name_locale2".equals(str)) mf.device_group_name_locale2 = true;
				if ("device_group_name_locale3".equals(str)) mf.device_group_name_locale3 = true;
				if ("device_group_description_locale1".equals(str)) mf.device_group_description_locale1 = true;
				if ("device_group_description_locale2".equals(str)) mf.device_group_description_locale2 = true;
				if ("device_group_description_locale3".equals(str)) mf.device_group_description_locale3 = true;
				if ("parent_device_group_id".equals(str)) mf.parent_device_group_id = true;
				if ("setup_place".equals(str)) mf.setup_place = true;
				if ("setup_status".equals(str)) mf.setup_status = true;
				if ("latitude".equals(str)) mf.latitude = true;
				if ("longitude".equals(str)) mf.longitude = true;
				if ("device_group_note".equals(str)) mf.device_group_note = true;
				if ("role_id".equals(str)) mf.role_id = true;
				if ("root_group_id".equals(str)) mf.root_group_id = true;
				if ("role_name_locale1".equals(str)) mf.role_name_locale1 = true;
				if ("role_name_locale2".equals(str)) mf.role_name_locale2 = true;
				if ("role_name_locale3".equals(str)) mf.role_name_locale3 = true;
				if ("role_description_locale1".equals(str)) mf.role_description_locale1 = true;
				if ("role_description_locale2".equals(str)) mf.role_description_locale2 = true;
				if ("role_description_locale3".equals(str)) mf.role_description_locale3 = true;
				if ("role_note".equals(str)) mf.role_note = true;
				if ("hierarchy".equals(str)) mf.hierarchy = true;

			}
		}
		return mf;
	}

	/**
	 * 返却項目フィルタークラス
	 * true=返却する。false=返却しない。
	 *
	 */
	class ModelFilter {
		public ModelFilter(boolean b) {
			model_id = b;
			serial_no = b;
			sensor_id = b;
			sensor_type = b;
			sensor_name_locale1 = b;
			sensor_name_locale2 = b;
			sensor_name_locale3 = b;
			unit_locale1 = b;
			unit_locale2 = b;
			unit_locale3 = b;
			transform_locale1 = b;
			transform_locale2 = b;
			transform_locale3 = b;
			decimal_num_locale1 = b;
			decimal_num_locale2 = b;
			decimal_num_locale3 = b;
			max_value_locale1 = b;
			max_value_locale2 = b;
			max_value_locale3 = b;
			min_value_locale1 = b;
			min_value_locale2 = b;
			min_value_locale3 = b;
			sensor_description_locale1 = b;
			sensor_description_locale2 = b;
			sensor_description_locale3 = b;
			measure_type = b;
			data_type = b;
			fixed_length = b;
			time_data_create_flg = b;
			short_term_minutes = b;
			sensor_note = b;
			device_group_id = b;
			device_group_type = b;
			device_group_subtype = b;
			device_group_name_locale1 = b;
			device_group_name_locale2 = b;
			device_group_name_locale3 = b;
			device_group_description_locale1 = b;
			device_group_description_locale2 = b;
			device_group_description_locale3 = b;
			parent_device_group_id = b;
			setup_place = b;
			setup_status = b;
			latitude = b;
			longitude = b;
			device_group_note = b;
			role_id = b;
			root_group_id = b;
			role_name_locale1 = b;
			role_name_locale2 = b;
			role_name_locale3 = b;
			role_description_locale1 = b;
			role_description_locale2 = b;
			role_description_locale3 = b;
			role_note = b;
			hierarchy = b;

		}
		public boolean model_id = true;
		public boolean serial_no = true;
		public boolean sensor_id = true;
		public boolean sensor_type = true;
		public boolean sensor_name_locale1 = true;
		public boolean sensor_name_locale2 = true;
		public boolean sensor_name_locale3 = true;
		public boolean unit_locale1 = true;
		public boolean unit_locale2 = true;
		public boolean unit_locale3 = true;
		public boolean transform_locale1 = true;
		public boolean transform_locale2 = true;
		public boolean transform_locale3 = true;
		public boolean decimal_num_locale1 = true;
		public boolean decimal_num_locale2 = true;
		public boolean decimal_num_locale3 = true;
		public boolean max_value_locale1 = true;
		public boolean max_value_locale2 = true;
		public boolean max_value_locale3 = true;
		public boolean min_value_locale1 = true;
		public boolean min_value_locale2 = true;
		public boolean min_value_locale3 = true;
		public boolean sensor_description_locale1 = true;
		public boolean sensor_description_locale2 = true;
		public boolean sensor_description_locale3 = true;
		public boolean measure_type = true;
		public boolean data_type = true;
		public boolean fixed_length = true;
		public boolean time_data_create_flg = true;
		public boolean short_term_minutes = true;
		public boolean sensor_note = true;
		public boolean device_group_id = true;
		public boolean device_group_type = true;
		public boolean device_group_subtype = true;
		public boolean device_group_name_locale1 = true;
		public boolean device_group_name_locale2 = true;
		public boolean device_group_name_locale3 = true;
		public boolean device_group_description_locale1 = true;
		public boolean device_group_description_locale2 = true;
		public boolean device_group_description_locale3 = true;
		public boolean parent_device_group_id = true;
		public boolean setup_place = true;
		public boolean setup_status = true;
		public boolean latitude = true;
		public boolean longitude = true;
		public boolean device_group_note = true;
		public boolean role_id = true;
		public boolean root_group_id = true;
		public boolean role_name_locale1 = true;
		public boolean role_name_locale2 = true;
		public boolean role_name_locale3 = true;
		public boolean role_description_locale1 = true;
		public boolean role_description_locale2 = true;
		public boolean role_description_locale3 = true;
		public boolean role_note = true;
		public boolean hierarchy = true;

	}
}

