package com.app.common;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.stereotype.Component;

import com.app.exception.DataNotFoundException;

@Component
@Aspect
public class FindOneAspect {

	/**
	 * 各ServiceのfindOneメソッドが0件だった場合、DataNotFoundExceptionを
	 * スローするインターセプタ
	 * @param jp
	 * @param ret
	 * @throws DataNotFoundException
	 */
	@AfterReturning(value = "execution(* *..*Service.findOne(..))", returning = "ret")
	public void checkResult(JoinPoint jp, Object ret) throws DataNotFoundException {
		if(ret == null) {
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.info")});
			throw exp;
		}
	}
}