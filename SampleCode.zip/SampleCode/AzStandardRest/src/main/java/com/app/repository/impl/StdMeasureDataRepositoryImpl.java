package com.app.repository.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.common.Consts;
import com.app.common.utils.DateTimeUtil;
import com.app.entity.StdMeasureDataEntity;
import com.app.model.DataSend1Message;
import com.app.model.DataSend2Message;
import com.app.model.DataSend3Message;
import com.app.model.DevMeasureDataEntity;
import com.app.model.MeasureDataEntity;
import com.app.repository.StdMeasureDataRepositoryCustom;
import com.google.gson.Gson;
import com.microsoft.azure.storage.table.CloudTable;
import com.microsoft.azure.storage.table.TableQuery;
import com.microsoft.azure.storage.table.TableQuery.Operators;
import com.microsoft.azure.storage.table.TableQuery.QueryComparisons;

/**
 * 計測データリポジトリ実装クラス
 * 
 * @author（TOSCO）ウェイ
 */
@Component
public class StdMeasureDataRepositoryImpl implements StdMeasureDataRepositoryCustom {

	@Autowired
	EntityManager em;

	@Override
	public List<StdMeasureDataEntity> searchAll(String modelId, String serialNo, String sensorId, Timestamp dateFrom,
			Timestamp dateTo) throws Exception {

		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<StdMeasureDataEntity> query = builder.createQuery(StdMeasureDataEntity.class);
		Root<StdMeasureDataEntity> root = query.from(StdMeasureDataEntity.class);

		List<Predicate> where = new ArrayList<>();
		// 機種ID
		if (modelId != null)
			where.add(builder.equal(root.get("model_id"), modelId));
		// シリアルNo
		if (serialNo != null)
			where.add(builder.equal(root.get("serial_no"), serialNo));
		// センサーID
		if (sensorId != null)
			where.add(builder.equal(root.get("sensor_id"), sensorId));
		// 計測時間
		if (dateFrom.compareTo(dateTo) == 0) {
			where.add(builder.equal(root.get("measure_time"), dateFrom));
		} else {
			where.add(builder.greaterThanOrEqualTo(root.get("measure_time"), dateFrom));
			where.add(builder.lessThan(root.get("measure_time"), dateTo));
		}
		if (where.size() > 0)
			query.where(where.toArray(new Predicate[where.size()]));

		// 計測時間（昇順）
		query.orderBy(builder.asc(root.get("measure_time")));

		return em.createQuery(query).getResultList();
	}

	@Override
	public List<StdMeasureDataEntity> searchAllExcluceE(String modelId, String serialNo, String sensorId,
			Timestamp dateFrom, Timestamp dateTo) throws Exception {

		char chrE = 'E';
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<StdMeasureDataEntity> query = builder.createQuery(StdMeasureDataEntity.class);
		Root<StdMeasureDataEntity> root = query.from(StdMeasureDataEntity.class);

		List<Predicate> where = new ArrayList<>();
		// 機種ID
		if (modelId != null)
			where.add(builder.equal(root.get("model_id"), modelId));
		// シリアルNo
		if (serialNo != null)
			where.add(builder.equal(root.get("serial_no"), serialNo));
		// センサーID
		if (sensorId != null)
			where.add(builder.equal(root.get("sensor_id"), sensorId));
		// 計測時間
		if (dateFrom.compareTo(dateTo) == 0) {
			where.add(builder.equal(root.get("measure_time"), dateFrom));
		} else {
			where.add(builder.greaterThanOrEqualTo(root.get("measure_time"), dateFrom));
			where.add(builder.lessThan(root.get("measure_time"), dateTo));
		}

		// データ移行区分
		where.add(builder.notEqual(root.get("data_migrate_class"), chrE));
		if (where.size() > 0)
			query.where(where.toArray(new Predicate[where.size()]));

		// 計測時間（昇順）
		query.orderBy(builder.asc(root.get("measure_time")));

		return em.createQuery(query).getResultList();
	}

	@Override
	public List<StdMeasureDataEntity> searchFirst(String modelId, String serialNo, String sensorId, Timestamp dateFrom,
			Timestamp dateTo) throws Exception {

		char chrE = 'E';
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<StdMeasureDataEntity> query = builder.createQuery(StdMeasureDataEntity.class);
		Root<StdMeasureDataEntity> root = query.from(StdMeasureDataEntity.class);

		List<Predicate> where = new ArrayList<>();
		// 機種ID
		if (modelId != null)
			where.add(builder.equal(root.get("model_id"), modelId));
		// シリアルNo
		if (serialNo != null)
			where.add(builder.equal(root.get("serial_no"), serialNo));
		// センサーID
		if (sensorId != null)
			where.add(builder.equal(root.get("sensor_id"), sensorId));
		// 計測時間
		if (dateFrom.compareTo(dateTo) == 0) {
			where.add(builder.equal(root.get("measure_time"), dateFrom));
		} else {
			where.add(builder.greaterThanOrEqualTo(root.get("measure_time"), dateFrom));
			where.add(builder.lessThan(root.get("measure_time"), dateTo));
		}
		// データ移行区分
		where.add(builder.notEqual(root.get("data_migrate_class"), chrE));
		if (where.size() > 0)
			query.where(where.toArray(new Predicate[where.size()]));

		// 計測時間（昇順）
		query.orderBy(builder.asc(root.get("measure_time")));

		return em.createQuery(query).setMaxResults(1).getResultList();
	}

	@Override
	public List<StdMeasureDataEntity> searchLast(String modelId, String serialNo, String sensorId) throws Exception {

		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<StdMeasureDataEntity> query = builder.createQuery(StdMeasureDataEntity.class);
		Root<StdMeasureDataEntity> root = query.from(StdMeasureDataEntity.class);

		List<Predicate> where = new ArrayList<>();
		// 機種ID
		if (modelId != null)
			where.add(builder.equal(root.get("model_id"), modelId));
		// シリアルNo
		if (serialNo != null)
			where.add(builder.equal(root.get("serial_no"), serialNo));
		// センサーID
		if (sensorId != null)
			where.add(builder.equal(root.get("sensor_id"), sensorId));
		if (where.size() > 0)
			query.where(where.toArray(new Predicate[where.size()]));

		// 計測時間（降順）
		query.orderBy(builder.desc(root.get("measure_time")));

		return em.createQuery(query).setMaxResults(1).getResultList();
	}

	@Override
	public List<MeasureDataEntity> searchMeasureFromTableStorage(String modelId, String serialNo, String sensorId,
			String dateFrom, String dateTo, CloudTable cloudTable) throws Exception {
		List<MeasureDataEntity> lstEntity= new ArrayList<>();
		String partitionKey = modelId + "$" + serialNo;
		String partitionKeyFilter =  TableQuery.generateFilterCondition(Consts.PARTITION_KEY, QueryComparisons.EQUAL, partitionKey);
		
		String filter1 = TableQuery.generateFilterCondition(Consts.ROW_KEY,
				QueryComparisons.GREATER_THAN_OR_EQUAL, dateFrom);
		String filter2;
		if( dateFrom.equals(dateTo)){
			filter2 = TableQuery.generateFilterCondition(Consts.ROW_KEY,
					QueryComparisons.LESS_THAN_OR_EQUAL, dateTo);
		}else{
			filter2 = TableQuery.generateFilterCondition(Consts.ROW_KEY,
					QueryComparisons.LESS_THAN, dateTo);
		}
		String rowFilter = TableQuery.combineFilters(filter1, Operators.AND, filter2);
		String combinedFilter = TableQuery.combineFilters(partitionKeyFilter, Operators.AND, rowFilter);
		
		TableQuery<DevMeasureDataEntity> rangeQuery =
		        TableQuery.from(DevMeasureDataEntity.class)
		        .where(combinedFilter);
		
//		String partitionKey = "TEST-TDSL-PLC" + "$" + "PLCEMU0100";
//		String partitionKeyFilter =  TableQuery.generateFilterCondition("PartitionKey", QueryComparisons.EQUAL, partitionKey);
//		String rowKey = "201810151022160000000";
//		String rowKeyFilter =  TableQuery.generateFilterCondition("RowKey", QueryComparisons.EQUAL, rowKey);
//		TableQuery<DevMeasureDataEntity> rangeQuery =
//		        TableQuery.from(DevMeasureDataEntity.class)
//		        .where(TableQuery.combineFilters(partitionKeyFilter,
//		
//		        		Operators.AND, rowKeyFilter));
		for (DevMeasureDataEntity entity : cloudTable.execute(rangeQuery)) {
			Gson g = new Gson();
//	        System.out.println(entity.getPartitionKey() +
//            " " + entity.getRowKey() +
//            "\t" + entity.getData() +
//            "\t" + entity.getMessageClass());
			if(entity.getMessageClass().compareTo("Data Send1") == 0) {
		        DataSend1Message msg = g.fromJson(entity.getData(), DataSend1Message.class);
		        for (DataSend1Message.DataSend1TimeData timeData : msg.timeList) {
		        	for (DataSend1Message.DataSend1MeasureData measureData : timeData.dataList){
		        		if(measureData.getSensorId().equals(sensorId)) {
		        			MeasureDataEntity measureDataEntity = new MeasureDataEntity();
			        		measureDataEntity.setModelId(msg.getModelId()); 
			        		measureDataEntity.setSerialNo(msg.getSerialNo());
			        		measureDataEntity.setSensorId(measureData.getSensorId()); 
							measureDataEntity.setMeasureTime(DateTimeUtil.toTimestamp(timeData.getMeasureTime()));
			        		measureDataEntity.setMeasureData(measureData.getData());
			        		measureDataEntity.setDataMigrateClass('1');
			        		lstEntity.add(measureDataEntity);
		        		}
		        		//System.out.println(measureDataEntity);
		        	}
				}
		        //System.out.println(msg);
			}else if(entity.getMessageClass().compareTo("Data Send2") == 0) {
				DataSend2Message msg2 = g.fromJson(entity.getData(), DataSend2Message.class);
				for (DataSend2Message.DataSend2TimeData timeData : msg2.timeList) {
		        	for (DataSend2Message.DataSend2MeasureData measureData : timeData.dataList){
		        		if(timeData.getSensorId().equals(sensorId)) {
		        			MeasureDataEntity measureDataEntity = new MeasureDataEntity();
			        		measureDataEntity.setModelId(msg2.getModelId()); 
			        		measureDataEntity.setSerialNo(msg2.getSerialNo());
			        		measureDataEntity.setSensorId(timeData.getSensorId()); 
							measureDataEntity.setMeasureTime(DateTimeUtil.toTimestamp(measureData.getMeasureTime()));
			        		measureDataEntity.setMeasureData(measureData.getData());
			        		measureDataEntity.setDataMigrateClass('1');
			        		lstEntity.add(measureDataEntity);
			        		//System.out.println(measureDataEntity);
		        		}
		        	}
				}
			}else if(entity.getMessageClass().compareTo("Data Send3") == 0) {
				DataSend3Message msg3 = g.fromJson(entity.getData(), DataSend3Message.class);
				for (DataSend3Message.DataSend3TimeData timeData : msg3.timeList) {
					for(String d : timeData.dataList) {
						if(timeData.getSensorId().equals(sensorId)) {
							MeasureDataEntity measureDataEntity = new MeasureDataEntity();
			        		measureDataEntity.setModelId(msg3.getModelId()); 
			        		measureDataEntity.setSerialNo(msg3.getSerialNo());
			        		measureDataEntity.setSensorId(timeData.getSensorId()); 
							measureDataEntity.setMeasureTime(DateTimeUtil.toTimestamp(timeData.getMeasureStartTime()));
			        		measureDataEntity.setMeasureData(d);
			        		measureDataEntity.setDataMigrateClass('1');
			        		lstEntity.add(measureDataEntity);
						}
					}
				}
			}
	    }
		return lstEntity;
	}
}
