package com.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.common.utils.DateTimeUtil;
import com.app.entity.MstEventEntity;
import com.app.exception.DataNotFoundException;
import com.app.exception.LockingFailureException;
import com.app.model.EventModel;
import com.app.model.EventQueryModel;
import com.app.repository.EventRepository;
import com.app.repository.EventRepositoryCustom;

@Service
@Transactional(readOnly = true)
public class EventService {
	@Autowired
	private EventRepository eventRepository;
	@Autowired
	private EventRepositoryCustom eventRepositoryCustom;

	public EventModel findOne(int uuid, String fields) throws Exception{
		ModelFilter mf = makeModelFilter(fields);

		MstEventEntity entity = eventRepository.findOne(uuid);
		EventModel newModel = null;
		if (entity != null) {
			newModel = new EventModel();
			if (mf.id) newModel.setId(entity.getId());
			if (mf.model_id) newModel.setModel_id(entity.getModel_id());
			if (mf.serial_no) newModel.setSerial_no(entity.getSerial_no());
			if (mf.event_id) newModel.setEvent_id(entity.getEvent_id());
			if (mf.event_type) newModel.setEvent_type(entity.getEvent_type());
			if (mf.event_level) newModel.setEvent_level(entity.getEvent_level());
			if (mf.sensor_id) newModel.setSensor_id(entity.getSensor_id());
			if (mf.name_locale1) newModel.setName_locale1(entity.getName_locale1());
			if (mf.name_locale2) newModel.setName_locale2(entity.getName_locale2());
			if (mf.name_locale3) newModel.setName_locale3(entity.getName_locale3());
			if (mf.description_locale1) newModel.setDescription_locale1(entity.getDescription_locale1());
			if (mf.description_locale2) newModel.setDescription_locale2(entity.getDescription_locale2());
			if (mf.description_locale3) newModel.setDescription_locale3(entity.getDescription_locale3());
			if (mf.chk_app_name) newModel.setChk_app_name(entity.getChk_app_name());
			if (mf.chk_app_parameter) newModel.setChk_app_parameter(entity.getChk_app_parameter());
			if (mf.check_timing) newModel.setCheck_timing(entity.getCheck_timing());
			if (mf.note) newModel.setNote(entity.getNote());
			if (mf.version) newModel.setVersion(entity.getVersion());
			if (mf.inserted) newModel.setInserted(entity.getInserted());
			if (mf.insert_time) newModel.setInsert_time(DateTimeUtil.formatTimestamp(entity.getInsert_time()));
			if (mf.updated) newModel.setUpdated(entity.getUpdated());
			if (mf.update_time) newModel.setUpdate_time(DateTimeUtil.formatTimestamp(entity.getUpdate_time()));
		}
		return  newModel;
	}

	public List<EventModel> findAll(EventQueryModel filter) throws Exception{

		ModelFilter mf = makeModelFilter(filter.getFields());

		List<String> sort = new ArrayList<String>();
		if (filter.getSort() != null) {
			for (String item : filter.getSort().split(",")) {
				sort.add(item.trim().toLowerCase());
			}
		}

		Integer limit = null;
		Integer offset = null;
		if (filter.getPage() != null && filter.getLimit() != null) {
			limit = Integer.parseInt(filter.getLimit());
			offset = (Integer.parseInt(filter.getPage()) - 1) * limit;
		}

		List<MstEventEntity> entList = eventRepositoryCustom.findAll(filter, sort, limit, offset);
		List<EventModel> modelList = new ArrayList<EventModel>();
		for (MstEventEntity entity : entList) {
			EventModel newModel = new EventModel();
			if (mf.id) newModel.setId(entity.getId());
			if (mf.model_id) newModel.setModel_id(entity.getModel_id());
			if (mf.serial_no) newModel.setSerial_no(entity.getSerial_no());
			if (mf.event_id) newModel.setEvent_id(entity.getEvent_id());
			if (mf.event_type) newModel.setEvent_type(entity.getEvent_type());
			if (mf.event_level) newModel.setEvent_level(entity.getEvent_level());
			if (mf.sensor_id) newModel.setSensor_id(entity.getSensor_id());
			if (mf.name_locale1) newModel.setName_locale1(entity.getName_locale1());
			if (mf.name_locale2) newModel.setName_locale2(entity.getName_locale2());
			if (mf.name_locale3) newModel.setName_locale3(entity.getName_locale3());
			if (mf.description_locale1) newModel.setDescription_locale1(entity.getDescription_locale1());
			if (mf.description_locale2) newModel.setDescription_locale2(entity.getDescription_locale2());
			if (mf.description_locale3) newModel.setDescription_locale3(entity.getDescription_locale3());
			if (mf.chk_app_name) newModel.setChk_app_name(entity.getChk_app_name());
			if (mf.chk_app_parameter) newModel.setChk_app_parameter(entity.getChk_app_parameter());
			if (mf.check_timing) newModel.setCheck_timing(entity.getCheck_timing());
			if (mf.note) newModel.setNote(entity.getNote());
			if (mf.version) newModel.setVersion(entity.getVersion());
			if (mf.inserted) newModel.setInserted(entity.getInserted());
			if (mf.insert_time) newModel.setInsert_time(DateTimeUtil.formatTimestamp(entity.getInsert_time()));
			if (mf.updated) newModel.setUpdated(entity.getUpdated());
			if (mf.update_time) newModel.setUpdate_time(DateTimeUtil.formatTimestamp(entity.getUpdate_time()));
			modelList.add(newModel);
		}
		return modelList;
	}

	public Long countAll(EventQueryModel filter) throws Exception{
		return eventRepositoryCustom.countAll(filter);
	}

	@Transactional(readOnly = false)
	public EventModel save(EventModel model) throws Exception{

		MstEventEntity newRec = new MstEventEntity();

		if (model.getModel_id() != null) newRec.setModel_id(model.getModel_id());
		if (model.getSerial_no() != null) newRec.setSerial_no(model.getSerial_no());
		if (model.getEvent_id() != null) newRec.setEvent_id(model.getEvent_id());
		if (model.getEvent_type() != null) newRec.setEvent_type(model.getEvent_type());
		if (model.getEvent_level() != null) newRec.setEvent_level(model.getEvent_level());
		if (model.getSensor_id() != null) newRec.setSensor_id(model.getSensor_id());
		if (model.getName_locale1() != null) newRec.setName_locale1(model.getName_locale1());
		if (model.getName_locale2() != null) newRec.setName_locale2(model.getName_locale2());
		if (model.getName_locale3() != null) newRec.setName_locale3(model.getName_locale3());
		if (model.getDescription_locale1() != null) newRec.setDescription_locale1(model.getDescription_locale1());
		if (model.getDescription_locale2() != null) newRec.setDescription_locale2(model.getDescription_locale2());
		if (model.getDescription_locale3() != null) newRec.setDescription_locale3(model.getDescription_locale3());
		if (model.getChk_app_name() != null) newRec.setChk_app_name(model.getChk_app_name());
		if (model.getChk_app_parameter() != null) newRec.setChk_app_parameter(model.getChk_app_parameter());
		if (model.getCheck_timing() != null) newRec.setCheck_timing(model.getCheck_timing());
		if (model.getNote() != null) newRec.setNote(model.getNote());
		newRec.setVersion(0L);

		newRec = eventRepository.save(newRec);

		EventModel newModel = new EventModel();
		newModel.setId(newRec.getId());
		newModel.setModel_id(newRec.getModel_id());
		newModel.setSerial_no(newRec.getSerial_no());
		newModel.setEvent_id(newRec.getEvent_id());
		newModel.setEvent_type(newRec.getEvent_type());
		newModel.setEvent_level(newRec.getEvent_level());
		newModel.setSensor_id(newRec.getSensor_id());
		newModel.setName_locale1(newRec.getName_locale1());
		newModel.setName_locale2(newRec.getName_locale2());
		newModel.setName_locale3(newRec.getName_locale3());
		newModel.setDescription_locale1(newRec.getDescription_locale1());
		newModel.setDescription_locale2(newRec.getDescription_locale2());
		newModel.setDescription_locale3(newRec.getDescription_locale3());
		newModel.setChk_app_name(newRec.getChk_app_name());
		newModel.setChk_app_parameter(newRec.getChk_app_parameter());
		newModel.setCheck_timing(newRec.getCheck_timing());
		newModel.setNote(newRec.getNote());
		newModel.setVersion(newRec.getVersion());
		newModel.setInserted(newRec.getInserted());
		newModel.setInsert_time(DateTimeUtil.formatTimestamp(newRec.getInsert_time()));
		newModel.setUpdated(newRec.getUpdated());
		newModel.setUpdate_time(DateTimeUtil.formatTimestamp(newRec.getUpdate_time()));
		return newModel;
	}

	@Transactional(readOnly = false)
	public EventModel update(Locale locale,int id, EventModel model) throws Exception{
		MstEventEntity rec = eventRepositoryCustom.findOneForUpdate(id);
		if(rec == null) {
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.eventInfo")});
			throw exp;
		}

		rec.setModel_id(model.getModel_id());
		rec.setSerial_no(model.getSerial_no());
		rec.setEvent_id(model.getEvent_id());
		rec.setEvent_type(model.getEvent_type());
		rec.setEvent_level(model.getEvent_level());
		rec.setSensor_id(model.getSensor_id());
		rec.setName_locale1(model.getName_locale1());
		rec.setName_locale2(model.getName_locale2());
		rec.setName_locale3(model.getName_locale3());
		rec.setDescription_locale1(model.getDescription_locale1());
		rec.setDescription_locale2(model.getDescription_locale2());
		rec.setDescription_locale3(model.getDescription_locale3());
		rec.setChk_app_name(model.getChk_app_name());
		rec.setChk_app_parameter(model.getChk_app_parameter());
		rec.setCheck_timing(model.getCheck_timing());
		rec.setNote(model.getNote());
		if (model.getVersion() == null || model.getVersion() != rec.getVersion()) {
			LockingFailureException exp = new LockingFailureException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.eventInfo")});
			throw exp;
		}





		eventRepository.saveAndFlush(rec);
		MstEventEntity updateRec = eventRepository.findOne(id);
		EventModel newModel = new EventModel();
		newModel.setId(updateRec.getId());
		newModel.setModel_id(updateRec.getModel_id());
		newModel.setSerial_no(updateRec.getSerial_no());
		newModel.setEvent_id(updateRec.getEvent_id());
		newModel.setEvent_type(updateRec.getEvent_type());
		newModel.setEvent_level(updateRec.getEvent_level());
		newModel.setSensor_id(updateRec.getSensor_id());
		newModel.setName_locale1(updateRec.getName_locale1());
		newModel.setName_locale2(updateRec.getName_locale2());
		newModel.setName_locale3(updateRec.getName_locale3());
		newModel.setDescription_locale1(updateRec.getDescription_locale1());
		newModel.setDescription_locale2(updateRec.getDescription_locale2());
		newModel.setDescription_locale3(updateRec.getDescription_locale3());
		newModel.setChk_app_name(updateRec.getChk_app_name());
		newModel.setChk_app_parameter(updateRec.getChk_app_parameter());
		newModel.setCheck_timing(updateRec.getCheck_timing());
		newModel.setNote(updateRec.getNote());
		newModel.setVersion(updateRec.getVersion());
		newModel.setInserted(updateRec.getInserted());
		newModel.setInsert_time(DateTimeUtil.formatTimestamp(updateRec.getInsert_time()));
		newModel.setUpdated(updateRec.getUpdated());
		newModel.setUpdate_time(DateTimeUtil.formatTimestamp(updateRec.getUpdate_time()));
		return newModel;
	}


	@Transactional(readOnly = false)
	public void delete(int uuid) throws Exception {
		MstEventEntity rec = eventRepository.findOne(uuid);
		if(rec == null) {
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.eventInfo")});
			throw exp;
		}
		eventRepository.delete(rec);
	}

	private ModelFilter makeModelFilter(String fields) {
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if ("id".equals(str)) mf.id = true;
				if ("model_id".equals(str)) mf.model_id = true;
				if ("serial_no".equals(str)) mf.serial_no = true;
				if ("event_id".equals(str)) mf.event_id = true;
				if ("event_type".equals(str)) mf.event_type = true;
				if ("event_level".equals(str)) mf.event_level = true;
				if ("sensor_id".equals(str)) mf.sensor_id = true;
				if ("name_locale1".equals(str)) mf.name_locale1 = true;
				if ("name_locale2".equals(str)) mf.name_locale2 = true;
				if ("name_locale3".equals(str)) mf.name_locale3 = true;
				if ("description_locale1".equals(str)) mf.description_locale1 = true;
				if ("description_locale2".equals(str)) mf.description_locale2 = true;
				if ("description_locale3".equals(str)) mf.description_locale3 = true;
				if ("chk_app_name".equals(str)) mf.chk_app_name = true;
				if ("chk_app_parameter".equals(str)) mf.chk_app_parameter = true;
				if ("check_timing".equals(str)) mf.check_timing = true;
				if ("note".equals(str)) mf.note = true;
				if ("version".equals(str)) mf.version = true;
				if ("inserted".equals(str)) mf.inserted = true;
				if ("insert_time".equals(str)) mf.insert_time = true;
				if ("updated".equals(str)) mf.updated = true;
				if ("update_time".equals(str)) mf.update_time = true;
			}
		}
		return mf;
	}

	class ModelFilter {
		public ModelFilter(boolean b) {
			id = b;
			model_id = b;
			serial_no = b;
			event_id = b;
			event_type = b;
			event_level = b;
			sensor_id = b;
			name_locale1 = b;
			name_locale2 = b;
			name_locale3 = b;
			description_locale1 = b;
			description_locale2 = b;
			description_locale3 = b;
			chk_app_name = b;
			chk_app_parameter = b;
			check_timing = b;
			note = b;
			version = b;
			inserted = b;
			insert_time = b;
			updated = b;
			update_time = b;
		}
		public boolean id = true;
		public boolean model_id = true;
		public boolean serial_no = true;
		public boolean event_id = true;
		public boolean event_type = true;
		public boolean event_level = true;
		public boolean sensor_id = true;
		public boolean name_locale1 = true;
		public boolean name_locale2 = true;
		public boolean name_locale3 = true;
		public boolean description_locale1 = true;
		public boolean description_locale2 = true;
		public boolean description_locale3 = true;
		public boolean chk_app_name = true;
		public boolean chk_app_parameter = true;
		public boolean check_timing = true;
		public boolean note = true;
		public boolean version = true;
		public boolean inserted = true;
		public boolean insert_time = true;
		public boolean updated = true;
		public boolean update_time = true;
	}
}

