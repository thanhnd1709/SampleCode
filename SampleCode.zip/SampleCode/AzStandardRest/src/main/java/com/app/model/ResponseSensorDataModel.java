package com.app.model;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * センサーデータモデルクラス
 * @author（TOSCO）ウェイ
 */
@Data
public class ResponseSensorDataModel {

	@ApiModelProperty(value = "機種ID")
	private String modelId;
	@ApiModelProperty(value = "シリアルNo")
	private String serialNo;
	@ApiModelProperty(value = "センサーデータリスト")
	private List<ResponseSensorModel> timeList;

	public ResponseSensorDataModel(String modelId, String serialNo, List<ResponseSensorModel> timeList){
		this.modelId = modelId;
		this.serialNo = serialNo;
		this.timeList = timeList;
	}
}