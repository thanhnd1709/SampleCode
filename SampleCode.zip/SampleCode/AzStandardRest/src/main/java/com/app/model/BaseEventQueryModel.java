package com.app.model;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.StringJoiner;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class BaseEventQueryModel implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String ENCODING = "UTF-8";

	@ApiModelProperty(value = "ID")
	private String[] id;

	@ApiModelProperty(value = "機種ID")
	private String[] model_id;

	@ApiModelProperty(value = "イベントID")
	private String[] event_id;

	@ApiModelProperty(value = "イベント種別")
	private String[] event_type;

	@ApiModelProperty(value = "イベントレベル")
	private String[] event_level;

	@ApiModelProperty(value = "センサーID")
	private String[] sensor_id;

	@ApiModelProperty(value = "名称(ロケール1)")
	private String[] name_locale1;

	@ApiModelProperty(value = "名称(ロケール2)")
	private String[] name_locale2;

	@ApiModelProperty(value = "名称(ロケール3)")
	private String[] name_locale3;

	@ApiModelProperty(value = "説明(ロケール1)")
	private String[] description_locale1;

	@ApiModelProperty(value = "説明(ロケール2)")
	private String[] description_locale2;

	@ApiModelProperty(value = "説明(ロケール3)")
	private String[] description_locale3;

	@ApiModelProperty(value = "アラーム検出アプリ名")
	private String[] chk_app_name;

	@ApiModelProperty(value = "アラーム検出パラメータ")
	private String[] chk_app_parameter;

	@ApiModelProperty(value = "チェックタイミング")
	private String[] check_timing;

	@ApiModelProperty(value = "備考")
	private String[] note;

	@ApiModelProperty(value = "個別属性同期フラグ（true：当マスタ登録・更新時、センサー情報(Sql Database) も合わせて更新する / false）")
	private String[] attribute_sync_flg;

	@ApiModelProperty(value = "バージョン")
	private String[] version;

	@ApiModelProperty(value = "登録者")
	private String[] inserted;

	@ApiModelProperty(value = "登録時刻")
	private String[] insert_time;

	@ApiModelProperty(value = "更新者")
	private String[] updated;

	@ApiModelProperty(value = "更新時刻")
	private String[] update_time;

	@ApiModelProperty(value = "任意並び順条件(カンマ区切り)")
	private String sort;

	@ApiModelProperty(value = "取得フィールド(カンマ区切り)")
	private String fields;

	@ApiModelProperty(value = "表示対象ページ番号")
	private String page;

	@ApiModelProperty(value = "1度に返すItem数")
	private String limit;

	public String buildUrlParameter() {
		StringJoiner sj = new StringJoiner("&", "?", "");
		sj.setEmptyValue("");
		try {
			if (id != null) for (String s : id) sj.add("id=" + URLEncoder.encode(s, ENCODING));

			if (model_id != null) for (String s : model_id) sj.add("model_id=" + URLEncoder.encode(s, ENCODING));

			if (event_id != null) for (String s : event_id) sj.add("event_id=" + URLEncoder.encode(s, ENCODING));

			if (event_type != null) for (String s : event_type) sj.add("event_type=" + URLEncoder.encode(s, ENCODING));

			if (event_level != null) for (String s : event_level) sj.add("event_level=" + URLEncoder.encode(s, ENCODING));

			if (sensor_id != null) for (String s : sensor_id) sj.add("sensor_id=" + URLEncoder.encode(s, ENCODING));

			if (name_locale1 != null) for (String s : name_locale1) sj.add("name_locale1=" + URLEncoder.encode(s, ENCODING));

			if (name_locale2 != null) for (String s : name_locale2) sj.add("name_locale2=" + URLEncoder.encode(s, ENCODING));

			if (name_locale3 != null) for (String s : name_locale3) sj.add("name_locale3=" + URLEncoder.encode(s, ENCODING));

			if (description_locale1 != null) for (String s : description_locale1) sj.add("description_locale1=" + URLEncoder.encode(s, ENCODING));

			if (description_locale2 != null) for (String s : description_locale2) sj.add("description_locale2=" + URLEncoder.encode(s, ENCODING));

			if (description_locale3 != null) for (String s : description_locale3) sj.add("description_locale3=" + URLEncoder.encode(s, ENCODING));

			if (chk_app_name != null) for (String s : chk_app_name) sj.add("chk_app_name=" + URLEncoder.encode(s, ENCODING));

			if (chk_app_parameter != null) for (String s : chk_app_parameter) sj.add("chk_app_parameter=" + URLEncoder.encode(s, ENCODING));

			if (check_timing != null) for (String s : check_timing) sj.add("check_timing=" + URLEncoder.encode(s, ENCODING));

			if (note != null) for (String s : note) sj.add("note=" + URLEncoder.encode(s, ENCODING));

			if (attribute_sync_flg != null) for (String s : attribute_sync_flg) sj.add("attribute_sync_flg=" + URLEncoder.encode(s, ENCODING));

			if (version != null) for (String s : version) sj.add("version=" + URLEncoder.encode(s, ENCODING));

			if (inserted != null) for (String s : inserted) sj.add("inserted=" + URLEncoder.encode(s, ENCODING));

			if (insert_time != null) for (String s : insert_time) sj.add("insert_time=" + URLEncoder.encode(s, ENCODING));

			if (updated != null) for (String s : updated) sj.add("updated=" + URLEncoder.encode(s, ENCODING));

			if (update_time != null) for (String s : update_time) sj.add("update_time=" + URLEncoder.encode(s, ENCODING));

			if (sort != null) sj.add("sort=" + URLEncoder.encode(sort, ENCODING));

			if (fields != null) sj.add("fields=" + URLEncoder.encode(fields, ENCODING));

			if (page != null) sj.add("page=" + URLEncoder.encode(page, ENCODING));

			if (limit != null) sj.add("limit=" + URLEncoder.encode(limit, ENCODING));

		} catch (UnsupportedEncodingException e) {
		}
		return sj.toString();
	}
}
