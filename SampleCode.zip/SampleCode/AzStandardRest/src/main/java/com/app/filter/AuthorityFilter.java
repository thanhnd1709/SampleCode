/**
 *
 */
package com.app.filter;

import java.io.IOException;
import java.util.Locale;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.GenericFilterBean;

import com.app.common.Consts;

/**
 * 認可チェックフィルター
 */
@Component
public class AuthorityFilter extends GenericFilterBean {
	@Autowired
	private EntityManager em;
	@Autowired
	private AuthUserInfoComponent authUserInfoComponent;

	private Logger logger = LoggerFactory.getLogger(AuthorityFilter.class);

	private static final String HEADER_PRINCIPAL_ID = "X-MS-CLIENT-PRINCIPAL-ID";
	private static final String HEADER_PRINCIPAL_NAME = "X-MS-CLIENT-PRINCIPAL-NAME";
	private static final String HEADER_REPLACE_USER_ID = "X-REPLACE-USER-ID";
	private static final String HEADER_USER_AGENT = "user-agent";
	private static final String REGEX_FUNCTION_USER_ID = "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}";


	private static final String QUERY_STR = "SELECT 1 WHERE EXISTS(" +
			" SELECT 1 FROM mst_program_authority pa, mst_role_program_authority rpa, mst_user_role ur" +
			" WHERE pa.authority_id = rpa.authority_id" +
			" AND ur.role_id = rpa.role_id" +
			" AND (:url = pa.url OR :url like pa.url + '/%')" +
			" AND pa.method = :method" +
			" AND ur.user_id = :user_id" +
			")";

	/* (非 Javadoc)
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest httpRequest = (HttpServletRequest)request;


		String userId = httpRequest.getHeader(HEADER_PRINCIPAL_NAME);
		String replaceUserId = httpRequest.getHeader(HEADER_REPLACE_USER_ID);
		boolean isFunction = false;


		if (userId == null && replaceUserId == null) {
			logger.info("認可されていません。(ユーザID無し)");
			((HttpServletResponse)response).setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
			return;
		}

		if (userId == null) {
		    userId = replaceUserId;
		    replaceUserId = null;
		    isFunction = true;
		}


		String url = httpRequest.getServletPath();
		String method = httpRequest.getMethod();
		String userAgent = httpRequest.getHeader(HEADER_USER_AGENT);
		logger.info("認可チェック実行。 (URL={}, メソッド={}, ユーザID={}, ユーザエージェント={}, 代替ユーザID={})",
				url, method, userId, userAgent, replaceUserId);

		try {
			boolean isFunctionUser = false;
			if (isFunctionUser(userId, userAgent, isFunction)) {
				if (replaceUserId == null) {
					logger.info("Function用ユーザID");
					isFunctionUser = true;
					authUserInfoComponent.setPrincipalName(Consts.FUNCTION_USER_ID);
				} else {
					logger.info("代替ユーザID使用");
					userId = replaceUserId;
				}
			}
			if (!isFunctionUser) {
				Query q = em.createNativeQuery(QUERY_STR);
				q.setParameter("url", url);
				q.setParameter("method", method);
				q.setParameter("user_id", userId);
				q.getSingleResult();

				authUserInfoComponent.setPrincipalID(httpRequest.getHeader(HEADER_PRINCIPAL_ID));
				authUserInfoComponent.setPrincipalName(userId);
			}
		} catch (NoResultException e) {
			logger.info("認可されていません。(URL={}, メソッド={}, ユーザID={})", url, method, userId);
			((HttpServletResponse)response).setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
			return;
		} catch (Exception e) {
			ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
			messageSource.setBasename("messages");
			messageSource.setDefaultEncoding("UTF-8");
			String detail = messageSource.getMessage(Consts.MESSAGE_E000116, null, Locale.getDefault());
			RuntimeException ex = new RuntimeException(detail, e);
			//logger.error(detail, e);
			throw ex;
		}

		logger.info("[AuthorityFilter] authUserInfoComponent設定 " +
				"principalID=" + authUserInfoComponent.getPrincipalID() +
				", principalName=" + authUserInfoComponent.getPrincipalName());

		chain.doFilter(request, response);
	}

	/**
	 * Azure Function向けユーザIDチェック
	 * @param userId ユーザID
	 * @param userAgent ユーザエージェント
	 * @return true=OK, false=NG
	 */
	public static boolean isFunctionUser(String userId, String userAgent, boolean isFunction) {
		return (userId.toLowerCase().matches(REGEX_FUNCTION_USER_ID) && (userAgent == null || isFunction));
	}
}
