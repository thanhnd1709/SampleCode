package com.app.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * イベント履歴リストモデル
 * @author（TOSCO）小川
 */
@Data
public class EventHistoryListModel {

	@ApiModelProperty(value = "機種ID")
	private String model_id;

	@ApiModelProperty(value = "シリアルNo")
	private String serial_no;

	@ApiModelProperty(value = "検出区分")
	private String detection_class;

	@ApiModelProperty(value = "イベントID")
	private String event_id;

	@ApiModelProperty(value = "イベント時刻")
	private String event_time;

	@ApiModelProperty(value = "イベント状態")
	private String event_status;

	@ApiModelProperty(value = "発生復帰区分")
	private String incident_class;

	@ApiModelProperty(value = "イベントレベル")
	private String event_level;

	@ApiModelProperty(value = "検出情報")
	private String detection_info;

	@ApiModelProperty(value = "イベント種別")
	private String event_type;

	@ApiModelProperty(value = "センサーID")
	private String sensor_id;

	@ApiModelProperty(value = "名称(ロケール1)")
	private String name_locale1;

	@ApiModelProperty(value = "名称(ロケール2)")
	private String name_locale2;

	@ApiModelProperty(value = "名称(ロケール3)")
	private String name_locale3;

	@ApiModelProperty(value = "説明(ロケール1)")
	private String description_locale1;

	@ApiModelProperty(value = "説明(ロケール2)")
	private String description_locale2;

	@ApiModelProperty(value = "説明(ロケール3)")
	private String description_locale3;

	@ApiModelProperty(value = "アラーム検出アプリ名")
	private String chk_app_name;

	@ApiModelProperty(value = "アラーム検出パラメータ")
	private String chk_app_parameter;

	@ApiModelProperty(value = "チェックタイミング")
	private String check_timing;

	@ApiModelProperty(value = "備考")
	private String note;

}
