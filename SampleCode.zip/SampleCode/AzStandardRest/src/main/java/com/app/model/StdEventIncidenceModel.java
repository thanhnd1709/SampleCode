package com.app.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * イベント・アラーム状態管理モデルクラス
 * @author（TOSCO）ウェイ
 */
@Data
public class StdEventIncidenceModel {

	@ApiModelProperty(value = "ID")
	private String id;

	@ApiModelProperty(value = "機種ID")
	private String model_id;

	@ApiModelProperty(value = "シリアルNo")
	private String serial_no;

	@ApiModelProperty(value = "検出区分")
	private String detection_class;

	@ApiModelProperty(value = "イベントID")
	private String event_id;

	@ApiModelProperty(value = "イベント時刻")
	private String event_time;

	@ApiModelProperty(value = "イベント状態")
	private String event_status;

	@ApiModelProperty(value = "発生復帰区分")
	private String incident_class;

	@ApiModelProperty(value = "イベントレベル")
	private String event_level;

	@ApiModelProperty(value = "対応状況")
	private String cope_status;

	@ApiModelProperty(value = "発生時刻")
	private String incident_time;

	@ApiModelProperty(value = "復帰時刻")
	private String return_time;

	@ApiModelProperty(value = "バージョン")
	private String version;

	@ApiModelProperty(value = "登録時刻")
	private String insert_time;

	@ApiModelProperty(value = "更新時刻")
	private String update_time;
}
