package com.app.controller;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;
import org.springframework.web.util.UriComponents;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.exception.BadRequestException;
import com.app.filter.AuthUserInfoComponent;
import com.app.model.ResponseModel;
import com.app.model.RollModel;
import com.app.model.RollQueryModel;
import com.app.model.SubResponseModel;
import com.app.service.RoleService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * ロール情報コントローラクラス
 *
 */
@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_MST)
@Api(tags = { Consts.TAGS_ROLE, }, description = Consts.MSG_ROLE)
public class RollAPIController {

	public static final Logger logger = LoggerFactory.getLogger(RollAPIController.class);
	@Autowired
	private AuthUserInfoComponent authUserInfoComponent;
	@Autowired
	private RoleService roleService;
	@Autowired
	private MessageSource messageSource;

	@ApiOperation(value = Consts.MSG_GET_ROLE, notes = Consts.MSG_GET_ROLE_01, nickname = Consts.OPERATIONID_ROLE_INDEX)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = RollModel.class, responseContainer = "List"),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_ROLE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<List<RollModel>> index(Locale locale
			, @ModelAttribute @Valid RollQueryModel querymodel, BindingResult errors) throws Exception {

		logger.info("Get開始");

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, querymodel, querymodel.getFields(), lstError);
		if (!lstError.isEmpty()) {
			BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			exp.setArgs(lstError);
			throw exp;
		}
		//ログインユーザIDをセットする
		querymodel.setUser_id(authUserInfoComponent.getPrincipalName());
		// ページング処理
		HttpHeaders headers = new HttpHeaders();
		if (querymodel.getPage() != null && querymodel.getLimit() != null) {
			Integer page = Integer.parseInt(querymodel.getPage());
			Integer limit = Integer.parseInt(querymodel.getLimit());
			Integer next = null;
			Integer prev = null;

			Long count = roleService.countAll(querymodel);
			if (count == 0) {
				return new ResponseEntity<List<RollModel>>(new ArrayList<RollModel>(), HttpStatus.OK);
			}
			int countpage = count.intValue() / limit;
			countpage += (count.intValue() % limit > 0) ? 1 : 0;

			if (countpage <= page) page = countpage;
			if (page > 1) prev = page - 1;
			if (page < countpage) next = page + 1;

			querymodel.setPage(String.valueOf(page));
			UriComponents uriComponents = MvcUriComponentsBuilder
					.fromMethodName(RollAPIController.class, "index",locale, querymodel, errors).build();
			URI location = uriComponents.toUri();
			StringBuffer sb = new StringBuffer();
			if (next != null) {
				querymodel.setPage(String.valueOf(next));
				sb.append("<" + location.toString() + querymodel.buildUrlParameter() + ">;rel=\"next\",");

				querymodel.setPage(String.valueOf(countpage));
				sb.append("<" + location.toString() + querymodel.buildUrlParameter() + ">;rel=\"last\"");
			}
			if (prev != null) {
				if (sb.length() > 0) sb.append(",");

				querymodel.setPage("1");
				sb.append("<" + location.toString() + querymodel.buildUrlParameter() + ">;rel=\"first\",");

				querymodel.setPage(String.valueOf(prev));
				sb.append("<" + location.toString() + querymodel.buildUrlParameter() + ">;rel=\"prev\"");
			}
			if (sb.length() > 0)
				headers.add("Link", sb.toString());

			querymodel.setPage(String.valueOf(page));
		}

		List<RollModel> result = roleService.findAll(querymodel);

		return new ResponseEntity<List<RollModel>>(result, headers, HttpStatus.OK);
	}

	@ApiOperation(value = Consts.MSG_GET_ROLE_ID, notes = Consts.MSG_GET_ROLE_ID_01, nickname = Consts.OPERATIONID_ROLE_SHOW)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = RollModel.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 404, message = Consts.HTTP_MESSAGE_404),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_ROLE_ID, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public RollModel show(Locale locale, @PathVariable("id") String idStr,
			@RequestParam(name = Consts.REQUEST_URL_FIELDS_KEY, required = false) String fields) throws Exception {

		logger.info("GetByID開始");

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, null, fields, lstError);

		Integer id = null;
		try {
			id = Integer.parseInt(idStr);
		} catch (Exception e) {
			String message = messageSource.getMessage(Consts.MESSAGE_E000112, null, locale);
			lstError.add(new SubResponseModel("", message));
		}

		// 入力エラーがある場合、
		if (!lstError.isEmpty()) {
			BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			exp.setArgs(lstError);
			throw exp;
		}
		//ログインユーザIDをセットする
		//querymodel.setUser_id(authUserInfoComponent.getPrincipalName());
		RollModel result = roleService.findOne(id, fields, authUserInfoComponent.getPrincipalName());
		return result;
	}

	@ApiOperation(value = Consts.MSG_POST_ROLE, notes = Consts.MSG_POST_ROLE_01, nickname = Consts.OPERATIONID_ROLE_CREATE)
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Created", response = RollModel.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 409, message = Consts.HTTP_MESSAGE_409),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_ROLE, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<RollModel> create(Locale locale, @Valid @RequestBody RollModel model, Errors errors)throws Exception {
		logger.info("POST開始");
		List<SubResponseModel> lstError = new ArrayList<>();
		// 入力チェック
		if (errors.hasErrors()) {
			BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);

			for (FieldError err : errors.getFieldErrors()) {
				lstError.add(new SubResponseModel(err.getField(), err.getDefaultMessage()));
			}
			exp.setArgs(lstError);
			throw exp;
		}
		ValidationForCreateNew(locale, model, authUserInfoComponent.getPrincipalName(), lstError) ;

		if (!lstError.isEmpty()) {
			BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			exp.setArgs(lstError);
			throw exp;
		}

		return new ResponseEntity<RollModel>(roleService.save(model), HttpStatus.CREATED);
	}

	@ApiOperation(value = Consts.MSG_PUT_ROLE, notes = Consts.MSG_PUT_ROLE_01, nickname = Consts.OPERATIONID_ROLE_PUT)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = RollModel.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 404, message = Consts.HTTP_MESSAGE_404),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 409, message = Consts.HTTP_MESSAGE_409),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_ROLE_ID, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.PUT)
	public RollModel put(Locale locale, @PathVariable(value = "id") String idStr, @Valid @RequestBody RollModel model,
			Errors errors) throws Exception {
		logger.info("PUT開始");
		Integer id = null;
		try {
			id = Integer.parseInt(idStr);
		} catch (Exception e) {
			BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			List<SubResponseModel> lstError = new ArrayList<>();
			String message = messageSource.getMessage(Consts.MESSAGE_E000112, null, locale);
			lstError.add(new SubResponseModel("", message));
			exp.setArgs(lstError);
			throw exp;
		}

		// 入力チェック
		if (errors.hasErrors()) {
			BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			List<SubResponseModel> lstError = new ArrayList<>();
			for (FieldError err : errors.getFieldErrors()) {
				lstError.add(new SubResponseModel(err.getField(), err.getDefaultMessage()));
			}
			exp.setArgs(lstError);
			throw exp;
		}
		List<SubResponseModel> lstError = new ArrayList<>();
		ValidationForUpdate(locale, model, authUserInfoComponent.getPrincipalName(), lstError) ;

		if (!lstError.isEmpty()) {
			BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			exp.setArgs(lstError);
			throw exp;
		}
		return roleService.update(locale, id, model);
	}

	@ApiOperation(value = Consts.MSG_DELETE_ROLE, notes = Consts.MSG_DELETE_ROLE_01, nickname = Consts.OPERATIONID_ROLE_DELETE)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = ResponseModel.class),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 404, message = Consts.HTTP_MESSAGE_404),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_ROLE_ID, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.DELETE)
	public ResponseEntity<Object> delete(Locale locale, @PathVariable(value = "id") String idStr) throws Exception {
		logger.info("delete開始");
		Integer id = null;
		try {
			id = Integer.parseInt(idStr);
		} catch (Exception e) {
			BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			List<SubResponseModel> lstError = new ArrayList<>();
			String message = messageSource.getMessage(Consts.MESSAGE_E000112, null, locale);
			lstError.add(new SubResponseModel("", message));
			exp.setArgs(lstError);
			throw exp;
		}
		List<SubResponseModel> lstError = new ArrayList<>();
		ValidationForDelete(locale, id, authUserInfoComponent.getPrincipalName(), lstError) ;

		if (!lstError.isEmpty()) {
			BadRequestException exp = new BadRequestException(Consts.HTTP_MESSAGE_400);
			exp.setArgs(lstError);
			throw exp;
		}
		// デバイス情報削除処理を行う
		roleService.delete(id);
		// 正常
		ResponseModel returnInfoModel = new ResponseModel(HttpStatus.OK.value(), HttpStatus.OK.getReasonPhrase(), "");
		return new ResponseEntity<Object>(returnInfoModel, HttpStatus.OK);
	}

	private void ValidationForCreateNew(Locale locale, RollModel model, String userId, List<SubResponseModel> lstError) throws Exception {
		String authorityRoleId = model == null?null:model.getAuthority_role_id();
		String roleId = model == null?null:model.getRole_id();
		Boolean baseRoleFlg = model == null?null:model.getBase_role_flg();

		if (authorityRoleId != null){

			if (!roleService.isRoleExist(authorityRoleId)){
				lstError.add(new SubResponseModel("authority_role_id",
						messageSource.getMessage(Consts.MESSAGE_E000122, null, locale)));
			}else if(roleId != null){

				if (!roleService.hasAuthorityByRoleId(userId, authorityRoleId)){
					lstError.add(new SubResponseModel("authorityRoleId",
							messageSource.getMessage(Consts.MESSAGE_E000131, new String[]{authorityRoleId}, locale)));
				}
			}
		}

		if (baseRoleFlg != null && baseRoleFlg){

			if (!roleService.isSystemAdmin(userId)){
				lstError.add(new SubResponseModel("base_role_flg",
						messageSource.getMessage(Consts.MESSAGE_E000130, null, locale)));
			}
		}
	}

	private void ValidationForUpdate(Locale locale, RollModel model, String userId, List<SubResponseModel> lstError)throws Exception {
		String roleId = model == null?null:model.getRole_id();

		//更新可能のロール
		if (roleId != null){
			RollQueryModel query = new RollQueryModel();
			query.setRole_id(new String[]{roleId});
			query.setUser_id(userId);

			if (!roleService.hasAuthorityByRoleId(userId, roleId)){
				lstError.add(new SubResponseModel("role_id",
						messageSource.getMessage(Consts.MESSAGE_E000105, null, locale)));
				return;
			}
		}
		ValidationForCreateNew(locale, model, userId, lstError);
	}
	private void ValidationForDelete(Locale locale, Integer id , String userId, List<SubResponseModel> lstError) throws Exception {
		//idで取得する
		RollModel result = roleService.findOne(id, null, userId);

		String roleId = result == null?null:result.getRole_id();
		Boolean baseRoleFlg = result == null?null:result.getBase_role_flg();


		if (roleId != null){

			if (!roleService.hasAuthorityByRoleId(userId, roleId)){
				lstError.add(new SubResponseModel("",
						messageSource.getMessage(Consts.MESSAGE_E000105, null, locale)));
			}
		}

		if (baseRoleFlg != null && baseRoleFlg){

			if (!roleService.isSystemAdmin(userId)){
				lstError.add(new SubResponseModel("",
						messageSource.getMessage(Consts.MESSAGE_E000105, null, locale)));
			}
		}
	}

	/**
	 * 入力チェック処理
	 * @param locale   ロケール
	 * @param queryModel    検索条件
	 * @param fields   フィールド
	 * @return List<SubResponseModel> エラーリスト
	 */
	private List<SubResponseModel> Validation(Locale locale, RollQueryModel queryModel, String fields, List<SubResponseModel> lstError) {

		String sorts = queryModel == null?null:queryModel.getSort();
		String page = queryModel == null?null:queryModel.getPage();
		String limit = queryModel == null?null:queryModel.getLimit();

		try{
			if (page != null && Integer.parseInt(page) < 1){
				lstError.add(new SubResponseModel("page",
						messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		}catch (NumberFormatException e) {
			lstError.add(new SubResponseModel("page",
					messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}

		//limit指定あり不正の場合
		try{
			if (limit != null && Integer.parseInt(limit) < 1){
				lstError.add(new SubResponseModel("limit",
						messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		}catch (NumberFormatException e) {
			lstError.add(new SubResponseModel("limit",
					messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}

		// ソートの指定が不正な場合
		if(sorts != null){
			List<String> sortParams = new ArrayList<String>();
			for (String item : sorts.split(",")) {
				sortParams.add(item.toLowerCase().replace("-", ""));
			}

	        if(StringUtil.hasDuplicate(sortParams)
	        		|| !StringUtil.hasProperty(new RollModel(), sortParams)){
	        	lstError.add(new SubResponseModel("sort",
	        			messageSource.getMessage(Consts.MESSAGE_E000049, null, locale)));
	        }
		}

		// フィールドの指定が不正な場合
		if(fields != null){
			List<String> fieldParams = new ArrayList<String>();
			for (String item : fields.split(",")) {
				fieldParams.add(item.toLowerCase().replace("-", ""));
			}

	        if(StringUtil.hasDuplicate(fieldParams)
	        		|| !StringUtil.hasProperty(new RollModel(), fieldParams)){
	        	lstError.add(new SubResponseModel("fields",
	        			messageSource.getMessage(Consts.MESSAGE_E000049, null, locale)));
	        }
		}

		return lstError;
	}
}
