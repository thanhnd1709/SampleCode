package com.app.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * センサーファイル情報モデルクラス
 * @author（TOSCO）ウェイ
 */
@Data
public class ResponseFileModel {

	@ApiModelProperty(value = "ID")
	private String id;
	@ApiModelProperty(value = "機種ID")
	private String model_id;
	@ApiModelProperty(value = "シリアルNo")
	private String serial_no;
	@ApiModelProperty(value = "センサーID")
	private String sensor_id;
	@ApiModelProperty(value = "計測時刻")
	private String measure_time;
	@ApiModelProperty(value = "UpLoad時刻")
	private String upload_time;
	@ApiModelProperty(value = "圧縮有無")
	private String zip_flg;
	@ApiModelProperty(value = "ファイル名")
	private String file_name;
	@ApiModelProperty(value = "MD5")
	private String hash;
	@ApiModelProperty(value = "送信元デバイスID")
	private String sender_device_id;
	@ApiModelProperty(value = "送信通知時刻")
	private String notice_time;
	@ApiModelProperty(value = "予備1")
	private String reserve1;
	@ApiModelProperty(value = "予備2")
	private String reserve2;
	@ApiModelProperty(value = "予備3")
	private String reserve3;
	@ApiModelProperty(value = "予備4")
	private String reserve4;
	@ApiModelProperty(value = "予備5")
	private String reserve5;
	@ApiModelProperty(value = "その他メタデータ")
	private String other_metadata;
	@ApiModelProperty(value = "アップロードユーザID")
	private String upload_user_id;
}
