package com.app.entity;

import com.microsoft.azure.storage.table.TableServiceEntity;

/**
 * 日別計測データエンティティクラス
 * @author（TOSCO）ウェイ
 */
public class DevDayDataEntity extends TableServiceEntity{

	// データ型
	private String dataType;
	// 固定長サイズ
	private int fixedLength;
	// データ移行区分
	private String dataMigrateClass;
	// データ１
	private byte[] data1;
	// データ２
	private byte[] data2;
	// データ３
	private byte[] data3;
	// データ４
	private byte[] data4;
	// データ５
	private byte[] data5;
	// データ６
	private byte[] data6;
	// データ７
	private byte[] data7;
	// データ８
	private byte[] data8;
	// データ９
	private byte[] data9;
	// データ１０
	private byte[] data10;
	// データ１１
	private byte[] data11;
	// データ１２
	private byte[] data12;
	// データ１３
	private byte[] data13;
	// データ１４
	private byte[] data14;
	// データ１５
	private byte[] data15;
	// バージョン
	private long version;

	/**
	 * @return dataType
	 */
	public String getdataType() {
		return dataType;
	}
	/**
	 * @param dataType セットする dataType
	 */
	public void setdataType(String dataType) {
		this.dataType = dataType;
	}
	/**
	 * @return fixedLength
	 */
	public int getfixedLength() {
		return fixedLength;
	}
	/**
	 * @param fixedLength セットする fixedLength
	 */
	public void setfixedLength(int fixedLength) {
		this.fixedLength = fixedLength;
	}
	/**
	 * @return dataMigrateClass
	 */
	public String getdataMigrateClass() {
		return dataMigrateClass;
	}
	/**
	 * @param dataMigrateClass セットする dataMigrateClass
	 */
	public void setdataMigrateClass(String dataMigrateClass) {
		this.dataMigrateClass = dataMigrateClass;
	}
	/**
	 * @return data1
	 */
	public byte[] getdata1() {
		return data1;
	}
	/**
	 * @param data1 セットする data1
	 */
	public void setdata1(byte[] data1) {
		this.data1 = data1;
	}
	/**
	 * @return data2
	 */
	public byte[] getdata2() {
		return data2;
	}
	/**
	 * @param data2 セットする data2
	 */
	public void setdata2(byte[] data2) {
		this.data2 = data2;
	}
	/**
	 * @return data3
	 */
	public byte[] getdata3() {
		return data3;
	}
	/**
	 * @param data3 セットする data3
	 */
	public void setdata3(byte[] data3) {
		this.data3 = data3;
	}
	/**
	 * @return data4
	 */
	public byte[] getdata4() {
		return data4;
	}
	/**
	 * @param data4 セットする data4
	 */
	public void setdata4(byte[] data4) {
		this.data4 = data4;
	}
	/**
	 * @return data5
	 */
	public byte[] getdata5() {
		return data5;
	}
	/**
	 * @param data5 セットする data5
	 */
	public void setdata5(byte[] data5) {
		this.data5 = data5;
	}
	/**
	 * @return data6
	 */
	public byte[] getdata6() {
		return data6;
	}
	/**
	 * @param data6 セットする data6
	 */
	public void setdata6(byte[] data6) {
		this.data6 = data6;
	}
	/**
	 * @return data7
	 */
	public byte[] getdata7() {
		return data7;
	}
	/**
	 * @param data7 セットする data7
	 */
	public void setdata7(byte[] data7) {
		this.data7 = data7;
	}
	/**
	 * @return data8
	 */
	public byte[] getdata8() {
		return data8;
	}
	/**
	 * @param data8 セットする data8
	 */
	public void setdata8(byte[] data8) {
		this.data8 = data8;
	}
	/**
	 * @return data9
	 */
	public byte[] getdata9() {
		return data9;
	}
	/**
	 * @param data9 セットする data9
	 */
	public void setdata9(byte[] data9) {
		this.data9 = data9;
	}
	/**
	 * @return data10
	 */
	public byte[] getdata10() {
		return data10;
	}
	/**
	 * @param data10 セットする data10
	 */
	public void setdata10(byte[] data10) {
		this.data10 = data10;
	}
	/**
	 * @return data11
	 */
	public byte[] getdata11() {
		return data11;
	}
	/**
	 * @param data11 セットする data11
	 */
	public void setdata11(byte[] data11) {
		this.data11 = data11;
	}
	/**
	 * @return data12
	 */
	public byte[] getdata12() {
		return data12;
	}
	/**
	 * @param data12 セットする data12
	 */
	public void setdata12(byte[] data12) {
		this.data12 = data12;
	}
	/**
	 * @return data13
	 */
	public byte[] getdata13() {
		return data13;
	}
	/**
	 * @param data13 セットする data13
	 */
	public void setdata13(byte[] data13) {
		this.data13 = data13;
	}
	/**
	 * @return data14
	 */
	public byte[] getdata14() {
		return data14;
	}
	/**
	 * @param data14 セットする data14
	 */
	public void setdata14(byte[] data14) {
		this.data14 = data14;
	}
	/**
	 * @return data15
	 */
	public byte[] getdata15() {
		return data15;
	}
	/**
	 * @param data15 セットする data15
	 */
	public void setdata15(byte[] data15) {
		this.data15 = data15;
	}
	/**
	 * @return version
	 */
	public long getversion() {
		return version;
	}
	/**
	 * @param version セットする version
	 */
	public void setversion(long version) {
		this.version = version;
	}
}
