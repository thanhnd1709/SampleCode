package com.app.controller;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;
import org.springframework.web.util.UriComponents;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.exception.BadRequestException;
import com.app.filter.AuthUserInfoComponent;
import com.app.model.SubResponseModel;
import com.app.model.UserDeviceGroupAuthorityModel;
import com.app.model.UserDeviceGroupAuthorityQueryModel;
import com.app.service.UserDeviceGroupAuthorityService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * ユーザ・デバイスグループ権限情報取得APIコントローラクラス
 * @author 810
 *
 */
@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_MST)
@Api(tags ={Consts.TAGS_USER_DEVICE_GROUP_AUTHORITY,}, description = Consts.MSG_GET_USER_DEVICE_GROUP_AUTHORITY)
public class GetUserDeviceGroupAuthorityAPIController {

	public static final Logger logger = LoggerFactory.getLogger(GetUserDeviceGroupAuthorityAPIController.class);

	@Autowired
	private UserDeviceGroupAuthorityService userDeviceGroupAuthorityService;
	@Autowired
	private MessageSource messageSource;
	@Autowired
	private AuthUserInfoComponent authUserInfoComponent;

	/**
	 * ユーザ・デバイスグループ権限情報取得
	 * @param locale ロケール
	 * @param querymodel 検索モデル
	 * @param errors エラーリスト
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = Consts.REQUEST_URL_USER_DEVICE_GROUP_AUTHORITY, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	@ApiOperation(value = Consts.MSG_GET_USER_DEVICE_GROUP_AUTHORITY, notes = Consts.MSG_GET_USER_DEVICE_GROUP_AUTHORITY_01, nickname = Consts.OPERATIONID_USER_DEVICE_GROUP_AUTHORITY_INDEX)
	@ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK", response = UserDeviceGroupAuthorityModel.class, responseContainer = "List"),
            @ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
            @ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
            @ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
    })	public ResponseEntity<List<UserDeviceGroupAuthorityModel>> index(Locale locale, @ModelAttribute @Valid UserDeviceGroupAuthorityQueryModel querymodel, BindingResult errors) throws Exception {

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, querymodel, lstError);
		if (!lstError.isEmpty()) {
			BadRequestException exp = new BadRequestException("");
			exp.setArgs(lstError);
			throw exp;
		}

		// 認証されたユーザIDを検索条件に設定
		String userId = authUserInfoComponent.getPrincipalName();
		querymodel.setUser_id(userId);

		// ページング処理
        HttpHeaders headers = new HttpHeaders();
		if (querymodel.getPage() != null && querymodel.getLimit() != null) {
			Integer page = Integer.parseInt(querymodel.getPage());
			Integer limit = Integer.parseInt(querymodel.getLimit());
			Integer next = null;
			Integer prev = null;

			Long count = userDeviceGroupAuthorityService.countAll(querymodel);
			if (count == 0) {
				return new ResponseEntity<List<UserDeviceGroupAuthorityModel>>(new ArrayList<UserDeviceGroupAuthorityModel>(), HttpStatus.OK);
			}
			int countpage = count.intValue() / limit;
			countpage += (count.intValue() % limit > 0) ? 1 : 0;

			if (countpage <= page) page = countpage;
			if (page > 1) prev = page - 1;
			if (page < countpage) next = page + 1;

			querymodel.setPage(String.valueOf(page));
	        UriComponents uriComponents = MvcUriComponentsBuilder.fromMethodName(
	        					GetUserDeviceGroupAuthorityAPIController.class, "index", locale, querymodel, errors).build();
	        URI location = uriComponents.toUri();
	        StringBuffer sb = new StringBuffer();
	        if (next != null) {
	        	querymodel.setPage(String.valueOf(next));
	        	sb.append("<" + location.toString() + querymodel.buildUrlParameter() + ">;rel=\"next\",");

	        	querymodel.setPage(String.valueOf(countpage));
	        	sb.append("<" + location.toString() + querymodel.buildUrlParameter() + ">;rel=\"last\"");
	        }
	        if (prev != null) {
	        	if (sb.length() > 0) sb.append(",");

	        	querymodel.setPage("1");
	        	sb.append("<" + location.toString() + querymodel.buildUrlParameter() + ">;rel=\"first\",");

	        	querymodel.setPage(String.valueOf(prev));
	        	sb.append("<" + location.toString() + querymodel.buildUrlParameter() + ">;rel=\"prev\"");
	        }
	        if (sb.length() > 0) headers.add("Link", sb.toString());

	        querymodel.setPage(String.valueOf(page));
		}

		// 検索実行
		List<UserDeviceGroupAuthorityModel> result = userDeviceGroupAuthorityService.findAll(querymodel);

        return new ResponseEntity<List<UserDeviceGroupAuthorityModel>>(result, headers, HttpStatus.OK);
	}

	/**
	 * 入力チェック処理
	 * @param locale ロケール
	 * @param req 検索モデル
	 * @param lstError エラーリスト
	 * @return List<SubResponseModel> エラーリスト
	 */
	private List<SubResponseModel> Validation(Locale locale, UserDeviceGroupAuthorityQueryModel req, List<SubResponseModel> lstError) {

		// URL,メソッド（一方のみ入力はNG）
		if (StringUtil.IsNullOrEmpty(req.getUrl()) ^ StringUtil.IsNullOrEmpty(req.getMethod())) {
			String item = StringUtil.IsNullOrEmpty(req.getUrl()) ? "url" : "method";
        	lstError.add(new SubResponseModel(item,
        			messageSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}

		// 取得フィールドの指定が不正な場合
		if(req.getFields() != null){
			List<String> fieldsParams = new ArrayList<String>();
			for (String item : req.getFields().split(",")) {
				fieldsParams.add(item.toLowerCase());
			}

	        if(StringUtil.hasDuplicate(fieldsParams)
	        		|| !StringUtil.hasProperty(new UserDeviceGroupAuthorityModel(), fieldsParams)){
	        	lstError.add(new SubResponseModel("fields",
	        			messageSource.getMessage(Consts.MESSAGE_E000050, null, locale)));
	        }
		}

		//Pageの指定が不正な場合
		try{
			if (req.getPage() != null && Integer.parseInt(req.getPage()) < 1){
				lstError.add(new SubResponseModel("page",
						messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		}catch (NumberFormatException e) {
			lstError.add(new SubResponseModel("page",
					messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}

		//limitの指定が不正な場合
		try{
			if (req.getLimit() != null && Integer.parseInt(req.getLimit()) < 1){
				lstError.add(new SubResponseModel("limit",
						messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		}catch (NumberFormatException e) {
			lstError.add(new SubResponseModel("limit",
					messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}

		// ソートの指定が不正な場合
		if(req.getSort() != null){
			List<String> sortParams = new ArrayList<String>();
			for (String item : req.getSort().split(",")) {
				sortParams.add(item.toLowerCase().replace("-", ""));
			}

	        if(StringUtil.hasDuplicate(sortParams)
	        		|| !StringUtil.hasProperty(new UserDeviceGroupAuthorityModel(), sortParams)){
	        	lstError.add(new SubResponseModel("sort",
	        			messageSource.getMessage(Consts.MESSAGE_E000049, null, locale)));
	        }
		}

		return lstError;
	}
}
