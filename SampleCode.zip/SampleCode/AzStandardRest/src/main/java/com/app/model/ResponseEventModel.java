package com.app.model;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * イベント・アラームモデル
 */
@Data
public class ResponseEventModel {

	@ApiModelProperty(value = "機種ID")
	private String modelId;

	@ApiModelProperty(value = "シリアルNo")
	private String serialNo;

	@ApiModelProperty(value = "検出区分")
	private String detectionClass;

	@ApiModelProperty(value = "イベントリスト")
	private List<EventListModel> eventList;


	public ResponseEventModel(String modelId, String serialNo, String detectionClass, List<EventListModel> eventList){
		this.modelId = modelId;
		this.serialNo = serialNo;
		this.detectionClass =  detectionClass;
		this.eventList = eventList;
	}

}
