package com.app.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * ユーザモデルクラス
 * @author（TOSCO）ウェイ
 */
@Data
public class UserModel {

	@ApiModelProperty(value = "ユーザID")
	private String userId;

	public UserModel(String userId){
		this.userId = userId;
	}
}
