package com.app.repository.impl;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.entity.UserProgramAuthorityEntity;
import com.app.model.UserProgramAuthorityQueryModel;
import com.app.repository.UserProgramAuthorityRepositoryCustom;

/**
 * ユーザ・プログラム権限情報取得リポジトリクラス
 * @author 9571
 *
 */
@Component
public class UserProgramAuthorityRepositoryImpl implements UserProgramAuthorityRepositoryCustom {

	private static final String SELECT_STAR = "SELECT COUNT(*) FROM ";

	private static final String SELECT_SQL = "SELECT DISTINCT ";

	private static final String SELECT_STR = "SELECT row_number() over(ORDER BY (SELECT NULL) ASC) as id, tmp.* FROM ";

	private static final String SELECT_ALL_SQL = "SELECT DISTINCT"
											+ " pa.id as id,"
											+ " pa.authority_id as authority_id,"
											+ " pa.authority_type as authority_type,"
											+ " pa.name_locale1 as program_name_locale1,"
											+ " pa.name_locale2 as program_name_locale2,"
											+ " pa.name_locale3 as program_name_locale3,"
											+ " pa.description_locale1 as program_description_locale1,"
											+ " pa.description_locale2 as program_description_locale2,"
											+ " pa.description_locale3 as program_description_locale3,"
											+ " pa.program_id as program_id,"
											+ " pa.url as url,"
											+ " pa.method as method,"
											+ " pa.note as program_note,"
											+ " r.role_id as role_id,"
											+ " r.name_locale1 as role_name_locale1,"
											+ " r.name_locale2 as role_name_locale2,"
											+ " r.name_locale3 as role_name_locale3,"
											+ " r.description_locale1 as role_description_locale1,"
											+ " r.description_locale2 as role_description_locale2,"
											+ " r.description_locale3 as role_description_locale3,"
											+ " r.note as role_note";

	private static final String FROM_SQL  = " FROM mst_program_authority pa"
											+ "  INNER JOIN mst_role_program_authority rpa ON pa.authority_id = rpa.authority_id"
											+ "  INNER JOIN mst_user_role ur ON ur.role_id = rpa.role_id"
											+ "  INNER JOIN mst_role r ON r.role_id = rpa.role_id";

	private static final String WHERE_SQL = " WHERE ";


	@Autowired EntityManager em;
	@SuppressWarnings("unchecked")
	@Override
	public List<UserProgramAuthorityEntity> getUserProgramAuthority(UserProgramAuthorityQueryModel query,
			List<String> sort, Integer limit, Integer offset) {

		StringBuffer orderBy = new StringBuffer();
		boolean isValue = false;
		// ORDER BY句作成
		if (sort.size() > 0) {
			isValue = true;
			orderBy.append(" ORDER BY ");
			for (String col : sort) {
				if (col.startsWith("-")) {
					orderBy.append(col.substring(1) + " desc,");
				} else {
					orderBy.append(col + " asc,");
				}
			}
			orderBy.deleteCharAt(orderBy.length()-1);
		}

		Map<String, Object> params = new HashMap<String, Object>();
		String sql = SELECT_STR +"("+ buildSubQuery(query, params) + orderBy.toString() + ") as tmp" ;
		if(limit == null && offset == null){
			sql = SELECT_STR +"("+ buildSubQuery(query, params) + ") as tmp " + orderBy.toString() ;
		}else{
			if (isValue){
				orderBy.append(" OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY ");
			}else{
				orderBy.append(" ORDER BY authority_id,role_id asc OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY ");
			}
			sql = SELECT_STR + "(" + buildSubQuery(query, params) + orderBy.toString() + ") as tmp";
		}

		// クエリ作成
		Query q = em.createNativeQuery(sql, UserProgramAuthorityEntity.class);
		Set<String> keys = params.keySet();
		for (String key : keys) {
			q.setParameter(key, params.get(key));
		}

		// ページング設定
		if (limit != null && offset != null) {
			q.setParameter("offset", offset);
			q.setParameter("limit", limit);
		}

		return q.getResultList();
	}

	/**
	 * ユーザ・プログラム権限情報件数取得
	 * @param query 検索条件オブジェクト
	 * @return 件数
	 */
	@Override
	public Long countAll(UserProgramAuthorityQueryModel query) {

		Map<String, Object> params = new HashMap<String, Object>();
		String sql = SELECT_STAR +"("+ buildSubQuery (query, params) + ") as tmp" ;
		// クエリ作成
		Query q = em.createNativeQuery(sql);
		Set<String> keys = params.keySet();
		for (String key : keys) {
			q.setParameter(key, params.get(key));
		}
		// クエリ実行
		return ((Integer)q.getSingleResult()).longValue();
	}

	/**
	 * サブクエリ作成
	 * @param query
	 * @param params
	 * @return
	 */
	private String buildSubQuery(UserProgramAuthorityQueryModel query, Map<String, Object> params) {
		StringBuffer sql = new StringBuffer();

		if(query.getFields() == null){
			sql.append(SELECT_ALL_SQL);
		} else {
			sql.append(SELECT_SQL);

			// INパラメータのfieldsで指定された項目以外のカラムはnull固定値を取得する
			List<String> list = Arrays.asList(query.getFields().split(","));
			Field[] fields = UserProgramAuthorityEntity.class.getDeclaredFields();
			int idx = 0;
			for (Field f : fields) {
				if ("id".equals(f.getName())) {
					// idは親クエリのrow_numberで取得するため除外する。
					continue;
				}
				String item = list.contains(f.getName()) ? f.getName() : "null";

				if (!item.equals("null")) {
					item = buildSelect(item);
					if (idx <= 11) {
						sql.append("pa." + item + " as " + f.getName() + ",");
					} else if (idx > 11) {
						sql.append("r." + item + " as " + f.getName() + ",");
					}
				} else {
					sql.append(item + " as " + f.getName() + ",");
				}
				idx++;
			}
			sql.deleteCharAt(sql.length()-1);	// 末端の,を削除
		}
		sql.append(FROM_SQL);
		// WHERE句作成
		String where = buildCondition(query, params);
		sql.append(where);

		return sql.toString();
	}

	/**
	 * SELLECT変数を作成する。
	 * @param item 変数
	 * @return item 変数
	 */
	private String buildSelect(String item) {
		if (item.equalsIgnoreCase("program_note") || item.equalsIgnoreCase("role_note"))
			item = "note";
		if (item.equalsIgnoreCase("program_name_locale1") || item.equalsIgnoreCase("role_name_locale1"))
			item = "name_locale1";
		if (item.equalsIgnoreCase("program_name_locale2") || item.equalsIgnoreCase("role_name_locale2"))
			item = "name_locale2";
		if (item.equalsIgnoreCase("program_name_locale3") || item.equalsIgnoreCase("role_name_locale3"))
			item = "name_locale3";
		if (item.equalsIgnoreCase("program_description_locale1")
				|| item.equalsIgnoreCase("role_description_locale1"))
			item = "description_locale1";
		if (item.equalsIgnoreCase("program_description_locale2")
				|| item.equalsIgnoreCase("role_description_locale2"))
			item = "description_locale2";
		if (item.equalsIgnoreCase("program_description_locale3")
				|| item.equalsIgnoreCase("role_description_locale3"))
			item = "description_locale3";

		return item;
	}

	/**
	 * WHERE句文字列と、バインド変数KVオブジェクトを作成する。
	 * @param query 検索条件オブジェクト
	 * @param params バインド変数KVオブジェクト（返却用）
	 * @return WHERE句文字列
	 */
	private String buildCondition(UserProgramAuthorityQueryModel query, Map<String, Object> params) {
		StringBuffer where = new StringBuffer(WHERE_SQL);
		where.append("ur.user_id=:ur.user_id");
		params.put("ur.user_id", query.getUser_id());
		addCondition(where, params, "r.role_id", query.getRole_id());
		addCondition(where, params, "pa.authority_id", query.getAuthority_id());
		addCondition(where, params, "pa.authority_type", query.getAuthority_type());
		addCondition(where, params, "pa.name_locale1", query.getProgram_name_locale1());
		addCondition(where, params, "pa.name_locale2", query.getProgram_name_locale2());
		addCondition(where, params, "pa.name_locale3", query.getProgram_name_locale3());
		addCondition(where, params, "pa.description_locale1", query.getProgram_description_locale1());
		addCondition(where, params, "pa.description_locale2", query.getProgram_description_locale2());
		addCondition(where, params, "pa.description_locale3", query.getProgram_description_locale3());
		addCondition(where, params, "pa.program_id", query.getProgram_id());
		addCondition(where, params, "pa.url", query.getUrl());
		addCondition(where, params, "pa.method", query.getMethod());
		addCondition(where, params, "pa.note", query.getProgram_note());
		addCondition(where, params, "r.name_locale1", query.getRole_name_locale1());
		addCondition(where, params, "r.name_locale2", query.getRole_name_locale2());
		addCondition(where, params, "r.name_locale3", query.getRole_name_locale3());
		addCondition(where, params, "r.description_locale1", query.getRole_description_locale1());
		addCondition(where, params, "r.description_locale2", query.getRole_description_locale2());
		addCondition(where, params, "r.description_locale3", query.getRole_description_locale3());
		addCondition(where, params, "r.note", query.getRole_note());
		String ret = where.toString();
		return (ret.equals(WHERE_SQL) ? "" : ret);
	}

	/**
	 * WHERE句用検索条件追加
	 * 引数のwhere句文字列にAND 列名 IN (バインド変数,...)の形式で検索条件を追加する。
	 * バインド変数名は"列名_配列インデックス"の形式とする。
	 * paramsには、キーにバインド変数名、値にvaluesの値を設定する。
	 * @param where WHERE句文字列
	 * @param params バインド変数KVオブジェクト（返却用）
	 * @param col 検索条件列名
	 * @param values 検索条件値配列
	 */
	private void addCondition(StringBuffer where, Map<String, Object> params, String col, Object[] values) {
		if (values == null || values.length == 0) return;
		if (where.length() > WHERE_SQL.length()) where.append(" AND ");
		where.append(col + " in (");
		for (int i = 0; i < values.length; i++) {
			String name = col + "_" + i;
			where.append(":").append(name).append(",");
			params.put(name, values[i]);
		}
		where.deleteCharAt(where.length()-1);
		where.append(")");
	}
}