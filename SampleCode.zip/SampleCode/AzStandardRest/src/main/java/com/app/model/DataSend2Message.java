package com.app.model;

import java.util.List;

public class DataSend2Message extends DataSendMessage{
	public List<DataSend2TimeData> timeList;
	public class DataSend2TimeData
    {
        //計測時間
        public String sensorId;
        //[配列]データ
        public List<DataSend2MeasureData> dataList ;
        
		public String getSensorId() {
			return sensorId;
		}
		public void setSensorId(String sensorId) {
			this.sensorId = sensorId;
		}
		public List<DataSend2MeasureData> getDataList() {
			return dataList;
		}
		public void setDataList(List<DataSend2MeasureData> dataList) {
			this.dataList = dataList;
		}
    }
	public class DataSend2MeasureData
    {
        public String measureTime ;
        public String data ;
        
		public String getMeasureTime() {
			return measureTime;
		}
		public void setMeasureTime(String measureTime) {
			this.measureTime = measureTime;
		}
		public String getData() {
			return data;
		}
		public void setData(String data) {
			this.data = data;
		}
    }
	public List<DataSend2TimeData> getTimeList() {
		return timeList;
	}

	public void setTimeList(List<DataSend2TimeData> timeList) {
		this.timeList = timeList;
	}
}
