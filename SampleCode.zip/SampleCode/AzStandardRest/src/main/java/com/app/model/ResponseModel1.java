package com.app.model;


import io.swagger.annotations.ApiModelProperty;

/**
 * レスポンスモデルクラス
 * @author（TOSCO）ウェイ
 */
public class ResponseModel1 {

	@ApiModelProperty(value = "エラーコードの値")
    public int code;
	@ApiModelProperty(value = "エラーコードの理由フレーズ")
    public String message;

    public ResponseModel1(int code, String message) {
        this.code = code;
        this.message = message;
    }
}
