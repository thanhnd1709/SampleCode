package com.app.model;
import java.io.Serializable;
import java.math.BigDecimal;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * ユーザ・デバイスグループ権限情報モデル
 * @author 810
 *
 */
@Data
public class UserDeviceGroupAuthorityModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "デバイスグループID")
	private String device_group_id;

	@ApiModelProperty(value = "デバイスグループ種別")
	private String device_group_type;

	@ApiModelProperty(value = "デバイスグループサブ種別")
	private String device_group_subtype;

	@ApiModelProperty(value = "デバイスグループ名称(ロケール1)")
	private String device_group_name_locale1;

	@ApiModelProperty(value = "デバイスグループ名称(ロケール2)")
	private String device_group_name_locale2;

	@ApiModelProperty(value = "デバイスグループ名称(ロケール3)")
	private String device_group_name_locale3;

	@ApiModelProperty(value = "デバイスグループ説明(ロケール1)")
	private String device_group_description_locale1;

	@ApiModelProperty(value = "デバイスグループ説明(ロケール2)")
	private String device_group_description_locale2;

	@ApiModelProperty(value = "デバイスグループ説明(ロケール3)")
	private String device_group_description_locale3;

	@ApiModelProperty(value = "親デバイスグループID")
	private String parent_device_group_id;

	@ApiModelProperty(value = "設置場所")
	private String setup_place;

	@ApiModelProperty(value = "設置状態")
	private String setup_status;

	@ApiModelProperty(value = "緯度")
	private BigDecimal latitude;

	@ApiModelProperty(value = "経度")
	private BigDecimal longitude;

	@ApiModelProperty(value = "デバイスグループ備考")
	private String device_group_note;

	@ApiModelProperty(value = "ロールID")
	private String role_id;

	@ApiModelProperty(value = "ルートグループID")
	private String root_group_id;

	@ApiModelProperty(value = "ロール名称(ロケール1)")
	private String role_name_locale1;

	@ApiModelProperty(value = "ロール名称(ロケール2)")
	private String role_name_locale2;

	@ApiModelProperty(value = "ロール名称(ロケール3)")
	private String role_name_locale3;

	@ApiModelProperty(value = "ロール説明(ロケール1)")
	private String role_description_locale1;

	@ApiModelProperty(value = "ロール説明(ロケール2)")
	private String role_description_locale2;

	@ApiModelProperty(value = "ロール説明(ロケール3)")
	private String role_description_locale3;

	@ApiModelProperty(value = "ロール備考")
	private String role_note;

	@ApiModelProperty(value = "デバイスグループ階層")
	private Integer hierarchy;

}
