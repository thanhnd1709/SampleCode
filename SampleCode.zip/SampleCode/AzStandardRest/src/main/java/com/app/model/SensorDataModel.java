package com.app.model;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * センサーデータモデルクラス
 * @author（TOSCO）ウェイ
 */
@Data
public class SensorDataModel {

	@ApiModelProperty(value = "検索区分（1：対象期間内の全データ取得 / 2：センサ毎に、対象期間内の最初のデータを１件取得）", required = true)
	private String get_class;

	@ApiModelProperty(value = "対象期間(From) ※yyyy-MM-dd HH:mm:ss.SSSSSSS", required = true)
	private String measure_time_from;

	@ApiModelProperty(value = "対象期間(To) ※yyyy-MM-dd HH:mm:ss.SSSSSSS 未指定時はシステム時刻とする")
	private String measure_time_to;

	@ApiModelProperty(value = "データ丸め区分")
	private String round_kbn;

	@ApiModelProperty(value = "最大件数")
	private Integer max_number;

	@ApiModelProperty(value = "ソート順（measureTime：(デフォルト値)計測時刻の昇順 / -measureTime：計測時刻の降順）")
	private String sort;

	@ApiModelProperty(value = "センサリスト", required = true)
	private List<SensorModel1> sensor_list;
}
