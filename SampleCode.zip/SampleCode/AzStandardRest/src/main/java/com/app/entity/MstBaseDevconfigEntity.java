package com.app.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Version;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 */
@Entity
@Table(name="mst_base_devconfig")
@Data
@EntityListeners(AuditingEntityListener.class)
@AllArgsConstructor
@NoArgsConstructor
public class MstBaseDevconfigEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column
	private Integer id;

	@Column
	private String model_id;
	@Column
	private String config_id;
	@Column
	private String config_type;
	@Column
	private String required_class;
	@Column
	private String name_locale1;
	@Column
	private String name_locale2;
	@Column
	private String name_locale3;
	@Column
	private String description_locale1;
	@Column
	private String description_locale2;
	@Column
	private String description_locale3;
	@Column
	private String data_type;
	@Column
	private String data;
	@Column
	private String template_file_name;
	@Column
	private String tool_address;
	@Column
	private String tool_class;
	@Column
	private String apply_command;
	@Column
	private String inventory_command;
	@Column
	private String note;
	@Version
	@Column
	private Long version;

	@CreatedBy
    @Column
	private String inserted;

	@Column
	private Timestamp insert_time;

	@PrePersist
    public void onPrePersist() {
        setInsert_time(new Timestamp(System.currentTimeMillis()));
        setUpdate_time(new Timestamp(System.currentTimeMillis()));
    }

	@LastModifiedBy
    @Column
	private String updated;

	@Column
	private Timestamp update_time;

	@PreUpdate
    public void onPreUpdate() {
        setUpdate_time(new Timestamp(System.currentTimeMillis()));
    }

}

