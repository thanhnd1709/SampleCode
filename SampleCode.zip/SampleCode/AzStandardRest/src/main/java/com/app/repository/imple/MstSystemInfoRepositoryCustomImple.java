package com.app.repository.imple;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.common.Consts;
import com.app.entity.MstSystemInfoEntity;
import com.app.repository.MstSystemInfoRepositoryCustom;

/**
 * システムの設定情報リポジトリ実装クラス
 * @author（TOSCO）ウェイ
 */
@Component
public class MstSystemInfoRepositoryCustomImple implements MstSystemInfoRepositoryCustom {

	@Autowired EntityManager em;

	@Override
	public List<MstSystemInfoEntity> search() throws Exception {

		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<MstSystemInfoEntity> query = builder.createQuery(MstSystemInfoEntity.class);
		Root<MstSystemInfoEntity> root = query.from(MstSystemInfoEntity.class);

		List<Predicate> where = new ArrayList<>();

		where.add(builder.or(
			builder.equal(root.get("key"), Consts.KEY_DATA_HOUR_WAIT)
			, builder.equal(root.get("key"), Consts.KEY_DATA_BLOB_WAIT)
			, builder.equal(root.get("key"), Consts.KEY_DATA_BLOB_WAIT2)
			));

		query.where(where.toArray(new Predicate[where.size()]));

		return em.createQuery(query).getResultList();
	}
}
