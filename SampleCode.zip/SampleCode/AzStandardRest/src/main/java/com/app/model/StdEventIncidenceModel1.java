package com.app.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * イベント・アラーム状態管理モデルクラス
 * @author（TOSCO）ウェイ
 */
@Data
public class StdEventIncidenceModel1 {

	@ApiModelProperty(value = "対応状況", required = true)
	private String cope_status;

	@ApiModelProperty(value = "バージョン", required = true)
	private String version;
}
