package com.app.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * センサーモデルクラス
 * @author（TOSCO）ウェイ
 */
@Data
public class ResponseSensorModel {

	@ApiModelProperty(value = "センサーID")
	private String sensorId;

	@ApiModelProperty(value = "丸め実施フラグ")
	@JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
	private Boolean roundFlg;

	@ApiModelProperty(value = "計測データリスト")
	@JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
	private List<ResponseMeasureDataModel> dataList;

	@ApiModelProperty(value = "ステータス")
    @JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY)
    public String status;

	public ResponseSensorModel(String sensorId, Boolean roundFlg, List<ResponseMeasureDataModel> dataList, String status){
		this.sensorId = sensorId;
		this.roundFlg = roundFlg;
		this.dataList = dataList;
		this.status = status;
	}

	public ResponseSensorModel(String sensorId, Boolean roundFlg, List<ResponseMeasureDataModel> dataList){
		this.sensorId = sensorId;
		this.roundFlg = roundFlg;
		this.dataList = dataList;
		this.status = "";
	}
}