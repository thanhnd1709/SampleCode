package com.app.model;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * イベント・アラーム履歴検索モデル
 * @author（TOSCO）小川
 */
@Data
public class ResponseEventHistoryModel {

	@ApiModelProperty(value = "トータル件数")
	private Integer total;

	@ApiModelProperty(value = "イベント履歴")
	private List<EventHistoryListModel> event_history_list;

}
