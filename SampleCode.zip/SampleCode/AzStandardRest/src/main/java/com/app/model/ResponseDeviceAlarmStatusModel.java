package com.app.model;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * デバイスアラーム状態モデル
 */
@Data
public class ResponseDeviceAlarmStatusModel {

	@ApiModelProperty(value = "機種ID")
	private String model_id;

	@ApiModelProperty(value = "シリアルNo")
	private String serial_no;

	@ApiModelProperty(value = "検出区分")
	private String detection_class;
private String event_id;
	@ApiModelProperty(value = "最大イベントレベル")
	private String max_event_level;

}
