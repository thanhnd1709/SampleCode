package com.app.model;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * センサーモデル
 * @author（TOSCO）ウェイ
 */
@Data
public class SensorModel2 {

	@ApiModelProperty(value = "機種ID")
	private String model_id;

	@ApiModelProperty(value = "シリアルNo")
	private String serial_no;

	@ApiModelProperty(value = "センサーIDリスト")
	private List<String> sensor_id_list;

	public SensorModel2(String model_id, String serial_no, List<String> sensor_id_list){
		this.model_id = model_id;
		this.serial_no = serial_no;
		this.sensor_id_list = sensor_id_list;
	}
}
