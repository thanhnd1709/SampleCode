package com.app.entity;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 */
@Entity
@Data
@AllArgsConstructor
@IdClass(DeviceGroupDeviceEntity.PK.class)
@NoArgsConstructor
public class DeviceGroupDeviceEntity {

	@Id
	private String device_group_list;
	@Id
	private String level;
	@Id
	private String model_id;
	@Id
	private String serial_no;
	
	@Embeddable
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	static class PK implements Serializable {
		private String device_group_list;
		private String level;
		private String model_id;
		private String serial_no;
	}
}