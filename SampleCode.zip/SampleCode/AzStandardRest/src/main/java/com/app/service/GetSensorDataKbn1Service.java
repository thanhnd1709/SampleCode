package com.app.service;

import java.io.FileInputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.io.Decoder;
import org.apache.avro.io.DecoderFactory;
import org.apache.avro.util.Utf8;
import org.apache.commons.beanutils.BeanComparator;
import org.apache.commons.collections.comparators.ReverseComparator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.InitialStartup;
import com.app.common.Consts;
import com.app.common.utils.BitConverter;
import com.app.common.utils.DateTimeUtil;
import com.app.common.utils.StringUtil;
import com.app.entity.DevHHDataEntity;
import com.app.entity.DevHourlyDataEntity;
import com.app.entity.MstSensorEntity;
import com.app.entity.StdMeasureDataEntity;
import com.app.model.HourlySensorData;
import com.app.model.MeasureDataEntity;
import com.app.model.ResponseMeasureDataModel;
import com.app.model.ResponseSensorDataModel;
import com.app.model.ResponseSensorModel;
import com.app.model.SensorModel2;
import com.app.repository.BlobDataRepositoryCustom;
import com.app.repository.DevHHDataRepositoryCustom;
import com.app.repository.MstSensorRepositoryCustom;
import com.app.repository.StdMeasureDataRepository;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.table.CloudTable;

/**
 * センサーデータ取得サービスクラス
 * 
 * @author（TOSCO）ウェイ
 */
@Service
public class GetSensorDataKbn1Service {

	// private Logger logger =
	// LoggerFactory.getLogger(GetSensorDataKbn1Service.class);

	@Autowired
	private MstSensorRepositoryCustom _sensorRepoCustom;
	@Autowired
	private StdMeasureDataRepository _stdmdRepoCustom;
	@Autowired
	private DevHHDataRepositoryCustom _hhRepoCustom;
	@Autowired
	private BlobDataRepositoryCustom _blobRepoCustom;

	private HashSet<String> hs = new HashSet<String>();

	private long oneDay = 1 * 24 * 60 * 60 * 1000;

	/**
	 * センサーデータ取得処理
	 * 
	 * @return センサーデータリスト
	 */
	public List<ResponseSensorDataModel> getSensorDataKbn1(Timestamp reqMeasureTimeFrom, Timestamp reqMeasureTimeTo,
			String reqRoundKbn, Integer reqMaxNumber, String reqSort, List<SensorModel2> ssModelList,
			HashMap<String, Date> paramSystemInfo, CloudTable cloudTable1, CloudTable cloudTable2,
			CloudBlobContainer container) throws Exception {

		List<ResponseMeasureDataModel> lstMeasureData = new ArrayList<>();
		List<ResponseSensorModel> lstSensor = new ArrayList<>();
		List<ResponseSensorDataModel> lstSensorData = new ArrayList<>();

		String modelId = "";
		String serialNo = "";

		Boolean roundFlg = null;
		Boolean isExculeE = false;

		// データ丸め区分が1の場合
		if ("1".equals(reqRoundKbn)) {
			roundFlg = false;
			isExculeE = true;
		}

		// センサーデータ取得処理
		for (SensorModel2 ssModel : ssModelList) {

			// 機種ID
			modelId = ssModel.getModel_id();
			// シリアルNo
			serialNo = ssModel.getSerial_no();
			// センサーID
			List<String> ssIdList = ssModel.getSensor_id_list();

			for (String ssId : ssIdList) {

				// センサー情報取得
				List<MstSensorEntity> lstSensorEntity = _sensorRepoCustom.find(modelId, serialNo, ssId,
						Consts.MEASURE_TYPE_1);

				// 該当センサー情報が存在しない場合、
				// レスポンスの対象センサーに空リストを設定し、次のセンサー情報の取得処理に進む
				if (lstSensorEntity == null || lstSensorEntity.size() <= 0) {
					if (ssId != null) {

						if (ssId.contains(",")) {
							String[] ssids = ssId.split(",");
							for (String id : ssids) {
								lstSensor.add(new ResponseSensorModel(id, null, new ArrayList<>()));
							}

						} else {
							lstSensor.add(new ResponseSensorModel(ssId, null, new ArrayList<>()));
						}
					}
					continue;
				}

				// 検索用パラメータリスト
				 String[] searchTSParamList = InitialStartup.timeSeriesAPIRangeSearch;
//				 dummy to testing
//				String[] searchTSParamList = new String[] { "1" };

				// 該当センサー情報が存在する場合
				for (MstSensorEntity sensorEntity : lstSensorEntity) {

					// 計測データ取得処理を行う
					List<ResponseMeasureDataModel> lstResult = this.getSensorData(modelId, serialNo,
							sensorEntity.getSensor_id(), DateTimeUtil.formatTs(reqMeasureTimeFrom),
							DateTimeUtil.formatTs(reqMeasureTimeTo), searchTSParamList, cloudTable1, cloudTable2,
							container, sensorEntity.getData_type(), sensorEntity.getFixed_length(), isExculeE,
							paramSystemInfo);
					for (ResponseMeasureDataModel result : lstResult) {
						lstMeasureData.add(result);
					}

					// logger.info("【計測データ】" + lstMeasureData.size() + "件：" + lstMeasureData);

					String status = "";
					if (lstMeasureData != null && lstMeasureData.size() > 0) {
						// ソート順が "DESC"「降順」の場合
						if (reqSort != null && Consts.SORT_SS_DATA_DESC.equals(reqSort)) {
							Collections.sort(lstMeasureData, new BeanComparator<ResponseMeasureDataModel>("measureTime",
									new ReverseComparator()));
						} else {
							Collections.sort(lstMeasureData,
									new BeanComparator<ResponseMeasureDataModel>("measureTime"));
						}

						// データ丸め区分が "1"「平均値」の場合
						if ("1".equals(reqRoundKbn)) {
							if (sensorEntity.getData_type().equals(Consts.DATA_TYPE_INT)
									|| sensorEntity.getData_type().equals(Consts.DATA_TYPE_LONG)
									|| sensorEntity.getData_type().equals(Consts.DATA_TYPE_REAL)
									|| sensorEntity.getData_type().equals(Consts.DATA_TYPE_FLOAT)
									|| sensorEntity.getData_type().equals(Consts.DATA_TYPE_STAT)) {

								// ソート順が "DESC"「降順」の場合

								if (reqSort != null && Consts.SORT_SS_DATA_DESC.equals(reqSort)) {
									lstMeasureData = this.AverageForDESC(lstMeasureData,
											DateTimeUtil.formatTs(reqMeasureTimeFrom),
											DateTimeUtil.formatTs(reqMeasureTimeTo), reqMaxNumber);
								} else {
									lstMeasureData = this.AverageForASC(lstMeasureData,
											DateTimeUtil.formatTs(reqMeasureTimeFrom),
											DateTimeUtil.formatTs(reqMeasureTimeTo), reqMaxNumber);
								}

								// 丸め処理を実施する場合のみ
								roundFlg = true;
							} else {
								roundFlg = false;
								lstMeasureData = null;
								status = "NG";
							}
						} else {
							// 最大件数を指定した場合
							if (reqMaxNumber != null && lstMeasureData.size() > reqMaxNumber) {
								lstMeasureData.subList(reqMaxNumber, lstMeasureData.size()).clear();
							}
						}
					}

					// 該当センサーに取得された計測データを格納する
					lstSensor.add(
							new ResponseSensorModel(sensorEntity.getSensor_id(), roundFlg, lstMeasureData, status));
					lstMeasureData = new ArrayList<>();
				}
			}
			// センサーデータを格納する
			lstSensorData.add(new ResponseSensorDataModel(modelId, serialNo, lstSensor));
			lstSensor = new ArrayList<>();
		}
		return lstSensorData;
	}

	/**
	 * センサーデータ取得処理
	 * 
	 * @return センサーデータリスト
	 */
	private List<ResponseMeasureDataModel> getSensorData(String paramModelId, String paramSerialNo,
			String paramSensorId, String paramDateFrom, String paramDateTo, String[] paramLstSearch,
			CloudTable paramCloudTable1, CloudTable paramCloudTable2, CloudBlobContainer paramCloudBlob,
			String paramDataType, Integer paramFixedLen, boolean roundFlg, HashMap<String, Date> paramSystemInfo)
			throws Exception {

		List<ResponseMeasureDataModel> lstResult = new ArrayList<>();
		List<ResponseMeasureDataModel> lstResultRet = new ArrayList<>();
		Timestamp dateFrom = DateTimeUtil.toTimestamp(paramDateFrom);

		for (String searchParam : paramLstSearch) {
			switch (searchParam) {
			case Consts.PARAMETER_KBN_RAW:
				// 引数．対象期間（To） < ４.(2)で求めた計測データの期間（From）以外の場合のみ、
				// 計測データ（raw）取得処理を行う
				lstResult = this.getRawMeasureData(paramModelId, paramSerialNo, paramSensorId, paramDateFrom,
						paramDateTo, paramDataType, roundFlg, paramCloudTable2);

				break;

			case Consts.PARAMETER_KBN_HOUR:
				if (dateFrom.compareTo(new Timestamp(paramSystemInfo.get(Consts.PARAMETER_KBN_HOUR).getTime())) > 0) {
					continue;
				} else {
					lstResult = this.getHourMeasureData(paramModelId, paramSerialNo, paramSensorId, paramDateFrom,
							paramDateTo, paramCloudTable1);
				}
				break;

			case Consts.PARAMETER_KBN_MONTH:
				if (dateFrom.compareTo(new Timestamp(paramSystemInfo.get(Consts.PARAMETER_KBN_MONTH).getTime())) > 0) {
					continue;
				} else {

					lstResult = this.getBlobMeasureDataMonthly(paramModelId, paramSerialNo, paramSensorId,
							paramDateFrom, paramDateTo, paramDataType, paramCloudBlob, roundFlg);
				}
				break;
			default:
				continue;
			}
			// 検索結果をマージする
			lstResultRet = mergeList(lstResult, lstResultRet);
		}
		return lstResultRet;
	}

	/**
	 * 取得した計測データのリストを返却用のリストとマージする。 すてに返却用リストに同じ計測時間のデータあった場合は、マージしない（返却用の優先する）
	 * 
	 * @return 計測データリスト
	 */
	private List<ResponseMeasureDataModel> mergeList(List<ResponseMeasureDataModel> source,
			List<ResponseMeasureDataModel> des) {
		if (des.size() == 0) {
			hs = new HashSet<String>();
			source.addAll(des);
			source.forEach(x -> hs.add(x.getMeasureTime()));
			return source;
		} else {
			source.forEach(x -> {
				if (!hs.contains(x.getMeasureTime())) {
					hs.add(x.getMeasureTime());
					des.add(x);
				}
			});
		}
		return des;
	}

	/**
	 * 計測データ（raw）取得処理
	 * 
	 * @return 計測データリスト
	 */
	private List<ResponseMeasureDataModel> getRawMeasureData(String paramModelId, String paramSerialNo,
			String paramSensorId, String paramDateFrom, String paramDateTo, String paramDataType, Boolean roundFlg,
			CloudTable paramCloudTable2) throws Exception {
		// logger.debug("計測データ取得処理 Start:");

		List<ResponseMeasureDataModel> lstResult = new ArrayList<>();
		// TSDV comment old source code
		// List<StdMeasureDataEntity> lstEntity= new ArrayList<>();
		// if (roundFlg){
		// lstEntity = _stdmdRepoCustom.searchAllExcluceE(paramModelId, paramSerialNo,
		// paramSensorId
		// , DateTimeUtil.toTimestamp(paramDateFrom),
		// DateTimeUtil.toTimestamp(paramDateTo));
		// }else{
		// lstEntity = _stdmdRepoCustom.searchAll(paramModelId, paramSerialNo,
		// paramSensorId
		// , DateTimeUtil.toTimestamp(paramDateFrom),
		// DateTimeUtil.toTimestamp(paramDateTo));
		//
		// }
		// for(StdMeasureDataEntity entity : lstEntity){
		// if (roundFlg){
		// if((paramDataType.equals(Consts.DATA_TYPE_INT)
		// || paramDataType.equals(Consts.DATA_TYPE_LONG)
		// || paramDataType.equals(Consts.DATA_TYPE_REAL)
		// || paramDataType.equals(Consts.DATA_TYPE_FLOAT)
		// || paramDataType.equals(Consts.DATA_TYPE_STAT))
		// && !StringUtil.IsHalfNumberDbl(entity.getMeasure_data())){
		// continue;
		// }
		// }
		// lstResult.add(new
		// ResponseMeasureDataModel(DateTimeUtil.formatTs(entity.getMeasure_time())
		// ,
		// StringUtil.IsNullOrEmpty(entity.getMeasure_data())?"":entity.getMeasure_data().trim()));
		// }
		// TSDV comment old source code
		// TSDV get measure from table storage
		List<MeasureDataEntity> lstEntity = new ArrayList<>();
		lstEntity = _stdmdRepoCustom.searchMeasureFromTableStorage(paramModelId, paramSerialNo, paramSensorId,
				paramDateFrom, paramDateTo, paramCloudTable2);
		for (MeasureDataEntity entity : lstEntity) {
			if (roundFlg) {
				if ((paramDataType.equals(Consts.DATA_TYPE_INT) || paramDataType.equals(Consts.DATA_TYPE_LONG)
						|| paramDataType.equals(Consts.DATA_TYPE_REAL) || paramDataType.equals(Consts.DATA_TYPE_FLOAT)
						|| paramDataType.equals(Consts.DATA_TYPE_STAT))
						&& !StringUtil.IsHalfNumberDbl(entity.getMeasureData())) {
					continue;
				}
			}
			lstResult.add(new ResponseMeasureDataModel(DateTimeUtil.formatTs(entity.getMeasureTime()),
					StringUtil.IsNullOrEmpty(entity.getMeasureData()) ? "" : entity.getMeasureData().trim()));
		}
		// TSDV get measure from table storage
		return lstResult;
	}

	/**
	 * 時間別計測データ（hour）取得処理
	 * 
	 * @return 計測データリスト
	 */
	private List<ResponseMeasureDataModel> getHourMeasureData(String paramModelId, String paramSerialNo,
			String paramSensorId, String paramDateFrom, String paramDateTo, CloudTable paramCloudTable1)
			throws Exception {
		// logger.debug("時間別計測データ取得処理 Start:");

		List<ResponseMeasureDataModel> lstResult = new ArrayList<>();
		// String partitionKey = paramModelId + Consts.AND + paramSerialNo + Consts.AND
		// + paramSensorId;
		String partitionKey = paramModelId + Consts.DEVICE_SEPARATOR + paramSerialNo;
		int startIdx = 0;
		int millisecIdx = 17;
		int minIdx = 10;

		String strDateFrom = StringUtil.subString(paramDateFrom, startIdx, minIdx);
		String strDateTo = StringUtil.subString(paramDateTo, startIdx, minIdx);
		long timeFrom = Integer.valueOf(StringUtil.subString(paramDateFrom, minIdx, millisecIdx));
		long timeTo = Integer.valueOf(StringUtil.subString(paramDateTo, minIdx, millisecIdx));

		boolean hasMinSec = false;
		//
		Iterable<DevHourlyDataEntity> hourlyDataList;
		hourlyDataList = _hhRepoCustom.searchAllHourlyData(partitionKey, strDateFrom, strDateTo, hasMinSec,
				paramCloudTable1);

		DateTimeFormatter inFormat = DateTimeFormatter.ofPattern("yyyyMMdd HHmmssSSS");
		DateTimeFormatter outFormat = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSSSSSS");

		for (DevHourlyDataEntity inEntity : hourlyDataList) {
			for (int no = 0; no < DevHourlyDataEntity.MAX_SENSOR_COUNT; no++) {
				String sensorId = inEntity.GetSensorId(no);
				byte[] hourlySensorData = inEntity.GetSensorData(no);

				if (sensorId == null)
					break;

				for (int pos = 0; pos < hourlySensorData.length;) {
					HourlySensorData sensorData = decode(hourlySensorData, pos);
					if (sensorData != null) {
						pos += sensorData.getSize();

						int time = sensorData.getTime();
						String yyyyMMddHHmmssSSS = inEntity.getRowKey() + String.format("%07d", time);
						yyyyMMddHHmmssSSS = yyyyMMddHHmmssSSS.substring(0, 8)+" "+yyyyMMddHHmmssSSS.substring(8, yyyyMMddHHmmssSSS.length());
						LocalDateTime dateTime = LocalDateTime.parse(yyyyMMddHHmmssSSS, inFormat);
						String measureTime = dateTime.format(outFormat);

						ResponseMeasureDataModel res = new ResponseMeasureDataModel(measureTime, sensorData.getData());

						lstResult.add(res);
					} else {
						// do nothing
					}
				}
			}
		}

		// Iterable<DevHHDataEntity> lstHHData;
		// lstHHData = _hhRepoCustom.searchAll(partitionKey
		// , strDateFrom
		// , strDateTo
		// , hasMinSec
		// , paramCloudTable1);
		//
		// for(DevHHDataEntity hhData : lstHHData){
		// List<byte[]> lstByte = new ArrayList<>();
		// if(hhData.getdata1() != null) lstByte.add(hhData.getdata1());
		// if(hhData.getdata2() != null) lstByte.add(hhData.getdata2());
		// if(hhData.getdata3() != null) lstByte.add(hhData.getdata3());
		// if(hhData.getdata4() != null) lstByte.add(hhData.getdata4());
		// if(hhData.getdata5() != null) lstByte.add(hhData.getdata5());
		// if(hhData.getdata6() != null) lstByte.add(hhData.getdata6());
		// if(hhData.getdata7() != null) lstByte.add(hhData.getdata7());
		// if(hhData.getdata8() != null) lstByte.add(hhData.getdata8());
		// if(hhData.getdata9() != null) lstByte.add(hhData.getdata9());
		// if(hhData.getdata10() != null) lstByte.add(hhData.getdata10());
		// if(hhData.getdata11() != null) lstByte.add(hhData.getdata11());
		// if(hhData.getdata12() != null) lstByte.add(hhData.getdata12());
		// if(hhData.getdata13() != null) lstByte.add(hhData.getdata13());
		// if(hhData.getdata14() != null) lstByte.add(hhData.getdata14());
		// if(hhData.getdata15() != null) lstByte.add(hhData.getdata15());
		//
		// int targetRow = this.getTargetRow(lstByte, hhData.getdataType(),
		// hhData.getfixedLength()
		// , timeFrom, timeTo, 7);
		// for (int row = targetRow; row < lstByte.size(); row ++){
		//
		// List<ResponseMeasureDataModel> lstRes;
		// if(strDateFrom.equals(hhData.getRowKey()) &&
		// strDateTo.equals(hhData.getRowKey())){
		// lstRes = this.getTargetData(lstByte, targetRow, hhData.getdataType(),
		// hhData.getfixedLength()
		// , timeFrom, timeTo, hhData.getRowKey());
		//
		// }else if(strDateFrom.equals(hhData.getRowKey()) &&
		// !strDateTo.equals(hhData.getRowKey())){
		// lstRes = this.getTargetData(lstByte, targetRow, hhData.getdataType(),
		// hhData.getfixedLength()
		// , timeFrom, null, hhData.getRowKey());
		//
		// }else if(!strDateFrom.equals(hhData.getRowKey()) &&
		// strDateTo.equals(hhData.getRowKey())){
		// lstRes = this.getTargetData(lstByte, targetRow, hhData.getdataType(),
		// hhData.getfixedLength()
		// , null, timeTo, hhData.getRowKey());
		// }else{
		// lstRes = this.getTargetDataAll(lstByte, targetRow, hhData.getdataType(),
		// hhData.getfixedLength()
		// , hhData.getRowKey());
		// }
		//
		// for(ResponseMeasureDataModel res : lstRes){
		// lstResult.add(res);
		// }
		// }
		// }

		return lstResult;
	}

	public HourlySensorData decode(byte[] buf, int startPos) {
		HourlySensorData entity = new HourlySensorData();
		int time = 0;
		String data = "";

		if (startPos > buf.length) {
			return null;
		}

		int readSize = 0;

		time = BitConverter.toInt32(buf, startPos + readSize);
		readSize += (Integer.SIZE / 8);
		entity.setTime(time);

		int dataLen = BitConverter.toInt32(buf, startPos + readSize);
		readSize += (Integer.SIZE / 8);

		byte[] arr2 = Arrays.copyOfRange(buf, startPos + readSize, startPos + readSize + dataLen);
		data = new String(arr2, StandardCharsets.UTF_8);
		readSize += dataLen;
		entity.setData(data);

		entity.setSize(readSize);
		return entity;
	}

	/**
	 * 月別計測データ（blob）取得処理
	 * 
	 * @return 計測データリスト
	 */
	private List<ResponseMeasureDataModel> getBlobMeasureDataMonthly(String paramModelId, String paramSerialNo,
			String paramSensorId, String paramDateFrom, String paramDateTo, String paramDataType,
			CloudBlobContainer paramCloudBlob, Boolean roundFlg) throws Exception {
		// logger.debug("月別Blobファイルデータ取得処理 Start:");

		List<ResponseMeasureDataModel> lstResult = new ArrayList<>();
		String schemaDescription = Consts.MONTH_BLOB_SCHEMA;
		;

		int startDayIdx = 0;
		int endDayIdx = 0;
		int startIdx = 0;
		int endIdx = 21;
		int dayIdx = 6;
		int hourIdx = 8;
		int numOfTime = 13;

		long timeFrom = Long.valueOf(StringUtil.subString(paramDateFrom, hourIdx, endIdx));
		long timeTo = Long.valueOf(StringUtil.subString(paramDateTo, hourIdx, endIdx));

		String strStartDate = StringUtil.subString(paramDateFrom, startIdx, hourIdx);
		String strEndDate = StringUtil.subString(paramDateTo, startIdx, hourIdx);
		Timestamp tsFrom = DateTimeUtil.toTimestamp(paramDateFrom);
		Timestamp tsTo = DateTimeUtil.toTimestamp(paramDateTo);
		Timestamp tsMeasureData = DateTimeUtil.toTimestamp(paramDateFrom);
		String strTargetTime = "";

		if ("".equals(paramModelId.trim()))
			paramModelId = "#";
		if ("".equals(paramSerialNo.trim()))
			paramSerialNo = "#";
		if ("".equals(paramSensorId.trim()))
			paramSensorId = "#";
		String prjDir = System.getProperty("user.dir");

		boolean bNumber = false;
		if (paramDataType.equals(Consts.DATA_TYPE_INT) || paramDataType.equals(Consts.DATA_TYPE_LONG)
				|| paramDataType.equals(Consts.DATA_TYPE_REAL) || paramDataType.equals(Consts.DATA_TYPE_FLOAT)
				|| paramDataType.equals(Consts.DATA_TYPE_STAT)) {
			bNumber = true;
		}

		while (tsFrom.compareTo(tsTo) <= 0) {

			List<String> targetDays = new ArrayList<String>();

			String targetDate = DateTimeUtil.formatTs(tsFrom);
			String measureDataDate = DateTimeUtil.formatTs(tsFrom);
			String filePath = StringUtil.getFilePath(StringUtil.subString(targetDate, startIdx, dayIdx), null,
					paramModelId, paramSerialNo, null);
			String result = _blobRepoCustom.download(paramCloudBlob, paramSensorId + Consts.EXTENSION_AVRO, filePath,
					prjDir + Consts.DELIMITER + Consts.FOLDER_MEASURE_DATA);
			if (!"".equals(result)) {
				String strTargetDate = StringUtil.subString(targetDate, startIdx, hourIdx);
				String strMeasureDataDate = StringUtil.subString(targetDate, startIdx, hourIdx);
				Schema schema = new Schema.Parser().parse(schemaDescription);

				GenericDatumReader<List<Utf8>> datumReader = new GenericDatumReader<List<Utf8>>(schema);
				InputStream in = new FileInputStream(result);
				Decoder decoder = DecoderFactory.get().directBinaryDecoder(in, null);
				List<Utf8> list = datumReader.read(null, decoder);

				String searchStartMonth = strStartDate.substring(4, 6);
				String searchEndMonth = strEndDate.substring(4, 6);
				String currentTargetMonth = strTargetDate.substring(4, 6);

				// 読み取ったAvroファイルの検索開始位置と終了位置を求める
				if (searchStartMonth.equals(searchEndMonth)) {
					startDayIdx = Integer.parseInt(StringUtil.subString(strStartDate, dayIdx, hourIdx));
					endDayIdx = Integer.parseInt(StringUtil.subString(strEndDate, dayIdx, hourIdx));
				} else if (currentTargetMonth.equals(searchStartMonth)) {
					startDayIdx = Integer.parseInt(StringUtil.subString(strStartDate, dayIdx, hourIdx));
					endDayIdx = Consts.BLOB_LINE;
				} else if (currentTargetMonth.equals(searchEndMonth)) {
					startDayIdx = 1;
					endDayIdx = Integer.parseInt(StringUtil.subString(strEndDate, dayIdx, hourIdx));
					tsMeasureData.setTime(tsFrom.getTime() + (oneDay * (startDayIdx - 1)));

				} else {
					startDayIdx = 1;
					endDayIdx = Consts.BLOB_LINE;
					tsMeasureData.setTime(tsFrom.getTime() + (oneDay * (startDayIdx - 1)));
				}

				for (Utf8 str : list.subList(startDayIdx - 1, endDayIdx)) {
					measureDataDate = DateTimeUtil.formatTs(tsMeasureData);
					strMeasureDataDate = StringUtil.subString(measureDataDate, startIdx, hourIdx);

					if (str.length() == 0) {
						tsMeasureData.setTime(tsMeasureData.getTime() + oneDay);
						continue;
					}
					String[] lineData = StringUtil.split(str.toString().trim(), Consts.LINE_SEPARATOR, -1);
					targetDays = Arrays.asList(lineData);

					if (strStartDate.equals(measureDataDate) && strEndDate.equals(measureDataDate)) {
						for (String lineDay : targetDays) {
							String[] data = StringUtil.split(lineDay, Consts.COMMA, -1);
							strTargetTime = StringUtil.getFormat(data[0], numOfTime);
							long time = Long.valueOf(strTargetTime);

							if ((timeFrom <= time && timeTo > time) || (timeFrom == timeTo && timeFrom == time)) {
								// データタイプが数値(int等）の時、計測値が数値以外場合は、スキップする
								if (roundFlg && bNumber == true && !StringUtil.IsValidType(paramDataType, data[1])) {
									continue;
								}
								lstResult.add(new ResponseMeasureDataModel(strMeasureDataDate + strTargetTime,
										data[1].trim()));
							}
						}
					} else if (strStartDate.equals(strMeasureDataDate)) {
						for (String lineDay : targetDays) {
							String[] data = StringUtil.split(lineDay, Consts.COMMA, -1);
							strTargetTime = StringUtil.getFormat(data[0], numOfTime);
							long time = Long.valueOf(strTargetTime);

							if (timeFrom <= time) {
								// データタイプが数値(int等）の時、計測値が数値以外場合は、スキップする
								if (roundFlg && bNumber == true && !StringUtil.IsValidType(paramDataType, data[1])) {
									continue;
								}
								lstResult.add(new ResponseMeasureDataModel(strMeasureDataDate + strTargetTime,
										data[1].trim()));
							}
						}
					} else if (strEndDate.equals(strMeasureDataDate)) {
						for (String lineDay : targetDays) {
							String[] data = StringUtil.split(lineDay, Consts.COMMA, -1);
							strTargetTime = StringUtil.getFormat(data[0], numOfTime);
							long time = Long.valueOf(strTargetTime);

							if (timeTo <= time)
								break;

							// データタイプが数値(int等）の時、計測値が数値以外場合は、スキップする
							if (roundFlg && bNumber == true && !StringUtil.IsValidType(paramDataType, data[1])) {
								continue;
							}
							lstResult.add(
									new ResponseMeasureDataModel(strMeasureDataDate + strTargetTime, data[1].trim()));
						}
					} else {
						for (String lineDay : targetDays) {
							String[] data = StringUtil.split(lineDay, Consts.COMMA, -1);

							// データタイプが数値(int等）の時、計測値が数値以外場合は、スキップする
							if (roundFlg && bNumber == true && !StringUtil.IsValidType(paramDataType, data[1])) {
								continue;
							}
							lstResult.add(new ResponseMeasureDataModel(
									strMeasureDataDate + StringUtil.getFormat(data[0], numOfTime), data[1].trim()));
						}
					}
					// br.close();
					tsMeasureData.setTime(tsMeasureData.getTime() + oneDay);
				}
			}
			Calendar cal = Calendar.getInstance();
			cal.setTime(tsFrom);
			cal.set(Calendar.DAY_OF_MONTH, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
			cal.add(Calendar.MONTH, 1);
			// 翌月の１日に検索の開始日とする
			tsFrom.setTime(cal.getTimeInMillis());
		}
		return lstResult;
	}

	/**
	 * 計測データ取得対象列番号取得処理
	 * 
	 * @param paramSearchKbn
	 *            検索区分
	 * @param lstByte
	 *            バイト配列リスト
	 * @param dataType
	 *            データタイプ
	 * @param fixLength
	 *            固定長サイズ
	 * @param timeFrom
	 *            対象期間（From）
	 * @param timeTo
	 *            対象期間（To）
	 * @param endIdx
	 * @return 計測データ取得対象列番号
	 */
	private int getTargetRow(List<byte[]> lstByte, String dataType, int fixLength, long timeFrom, long timeTo,
			int endIdx) throws Exception {

		int targetRow = 0;
		for (int i = 0; i < lstByte.size(); i++) {

			long time = 0;
			byte[] b = lstByte.get(i);
			ByteBuffer buffer = ByteBuffer.wrap(b);
			buffer.order(ByteOrder.LITTLE_ENDIAN);

			// データ型が int 、real、stat、long、float、bit、又は 固定長サイズがある場合、
			if (Consts.DATA_TYPE_INT.equals(dataType) || Consts.DATA_TYPE_REAL.equals(dataType)
					|| Consts.DATA_TYPE_STAT.equals(dataType) || Consts.DATA_TYPE_LONG.equals(dataType)
					|| Consts.DATA_TYPE_FLOAT.equals(dataType) || Consts.DATA_TYPE_BIT.equals(dataType)
					|| fixLength > 0) {
				time = buffer.getInt();

				// 上記以外の場合、
			} else {
				String data = new String(b);
				time = Long.valueOf(StringUtil.subString(data, 0, endIdx));
			}

			if ((timeFrom == timeTo && timeFrom == time) || timeFrom <= time && timeTo > time) {
				targetRow = targetRow == 0 ? targetRow : targetRow - 1;
				return targetRow;
			}
		}
		return targetRow;
	}

	/**
	 * 計測データ取得処理
	 * 
	 * @param lstByte
	 *            バイト配列リスト
	 * @param targetRow
	 *            取得対象列番号
	 * @param dataType
	 *            データタイプ
	 * @param fixLength
	 *            固定長サイズ
	 * @param rowKey
	 *            列キー
	 * @return 計測データ
	 */
	private List<ResponseMeasureDataModel> getTargetDataAll(List<byte[]> lstByte, int targetRow, String dataType,
			int fixLength, String rowKey) throws Exception {

		List<ResponseMeasureDataModel> lstResult = new ArrayList<>();

		String formatter;
		if (rowKey.length() == 10) {
			formatter = Consts.MEASURE_TIME_FORMAT_HOUR;
		} else {
			formatter = Consts.MEASURE_TIME_FORMAT_DAY;
		}

		byte[] b = lstByte.get(targetRow);
		ByteBuffer buffer = ByteBuffer.wrap(b);
		buffer.order(ByteOrder.LITTLE_ENDIAN);

		int byteTime = 4;
		int byteData = 0;
		int i = 0;

		// データ型が int 、又は stat の場合、
		if (Consts.DATA_TYPE_INT.equals(dataType) || Consts.DATA_TYPE_STAT.equals(dataType)) {

			byteData = 4;
			while (i <= b.length - (byteTime + byteData - 1)) {
				String measureTime = rowKey + String.format(formatter, buffer.getInt());
				String measureData = String.valueOf(buffer.getInt());
				lstResult.add(new ResponseMeasureDataModel(StringUtil.getFormat(measureTime, 21), measureData));
				i = i + byteTime + byteData;
			}

			// データ型が real の場合、
		} else if (Consts.DATA_TYPE_REAL.equals(dataType)) {

			byteData = 4;
			while (i <= b.length - (byteTime + byteData - 1)) {
				String measureTime = rowKey + String.format(formatter, buffer.getInt());
				String measureData = String.valueOf(buffer.getFloat());
				lstResult.add(new ResponseMeasureDataModel(StringUtil.getFormat(measureTime, 21), measureData));
				i = i + byteTime + byteData;
			}

			// データ型が long の場合、
		} else if (Consts.DATA_TYPE_LONG.equals(dataType)) {

			byteData = 8;
			while (i <= b.length - (byteTime + byteData - 1)) {
				String measureTime = rowKey + String.format(formatter, buffer.getInt());
				String measureData = String.valueOf(buffer.getLong());
				lstResult.add(new ResponseMeasureDataModel(StringUtil.getFormat(measureTime, 21), measureData));
				i = i + byteTime + byteData;
			}

			// データ型が float の場合、
		} else if (Consts.DATA_TYPE_FLOAT.equals(dataType)) {

			byteData = 8;
			while (i <= b.length - (byteTime + byteData - 1)) {
				String measureTime = rowKey + String.format(formatter, buffer.getInt());
				String measureData = String.valueOf(buffer.getDouble());
				lstResult.add(new ResponseMeasureDataModel(StringUtil.getFormat(measureTime, 21), measureData));
				i = i + byteTime + byteData;
			}

			// データ型が bit 、かつ 固定長サイズがあるの場合、
		} else if (Consts.DATA_TYPE_BIT.equals(dataType) && fixLength > 0) {

			BigDecimal bd = BigDecimal.valueOf(fixLength);
			BigDecimal divisor = new BigDecimal("8.00");
			byteData = bd.divide(divisor, BigDecimal.ROUND_UP).intValue();

			while (i <= b.length - (byteTime + byteData - 1)) {

				String measureTime = rowKey + String.format(formatter, buffer.getInt(i));

				String strData = "";
				for (int k = i + byteTime; k < i + byteTime + byteData; k++)
					strData = String.format("%02x", b[k]) + strData;

				lstResult.add(new ResponseMeasureDataModel(StringUtil.getFormat(measureTime, 21),
						StringUtil.getBitData(strData, fixLength)));
				i = i + byteTime + byteData;
			}

			// 上記以外の場合、
		} else {
			// 固定長サイズがあるの場合、
			if (fixLength > 0) {

				byteData = fixLength;
				while (i <= b.length - (byteTime + byteData - 1)) {

					String measureTime = rowKey + String.format(formatter, buffer.getInt(i));

					byte[] data = new byte[byteData];
					int j = -1;
					for (int k = i + byteTime; k < i + byteTime + byteData; k++) {
						j += 1;
						data[j] = b[k];
					}
					lstResult.add(new ResponseMeasureDataModel(StringUtil.getFormat(measureTime, 21),
							new String(data).trim()));
					i = i + byteTime + byteData;
				}

				// 上記以外の場合、
			} else {
				String arrData[] = StringUtil.split(new String(b), Consts.LINE_SEPARATOR, 0);
				for (String data : arrData) {
					String measure[] = StringUtil.split(data, Consts.COMMA, -1);
					lstResult.add(new ResponseMeasureDataModel(StringUtil.getFormat(rowKey + measure[0], 21),
							measure[1].trim()));
				}
			}
		}
		return lstResult;
	}

	/**
	 * 計測データ取得処理
	 * 
	 * @param lstByte
	 *            バイト配列リスト
	 * @param targetRow
	 *            取得対象列番号
	 * @param dataType
	 *            データタイプ
	 * @param fixLength
	 *            固定長サイズ
	 * @param timeFrom
	 *            対象期間（From）
	 * @param timeTo
	 *            対象期間（To）
	 * @param rowKey
	 *            列キー
	 * @return 計測データ
	 */
	private List<ResponseMeasureDataModel> getTargetData(List<byte[]> lstByte, int targetRow, String dataType,
			int fixLength, Long timeFrom, Long timeTo, String rowKey) throws Exception {

		List<ResponseMeasureDataModel> lstResult = new ArrayList<>();

		String formatter;
		if (rowKey.length() == 10) {
			formatter = Consts.MEASURE_TIME_FORMAT_HOUR;
		} else {
			formatter = Consts.MEASURE_TIME_FORMAT_DAY;
		}

		byte[] b = lstByte.get(targetRow);
		ByteBuffer buffer = ByteBuffer.wrap(b);
		buffer.order(ByteOrder.LITTLE_ENDIAN);

		int byteTime = 4;
		int byteData = 0;
		int i = 0;

		// データ型が int 、又は stat の場合、
		if (Consts.DATA_TYPE_INT.equals(dataType) || Consts.DATA_TYPE_STAT.equals(dataType)) {

			byteData = 4;
			while (i <= b.length - (byteTime + byteData - 1)) {

				int time = buffer.getInt();
				String measureData = String.valueOf(buffer.getInt());

				if ((timeFrom != null && timeTo != null
						&& ((timeFrom.equals(timeTo) && timeFrom == time) || (timeFrom <= time && timeTo > time)))
						|| (timeFrom != null && timeTo == null && timeFrom <= time)
						|| (timeFrom == null && timeTo != null && timeTo > time)) {

					String measureTime = rowKey + String.format(formatter, time);
					lstResult.add(new ResponseMeasureDataModel(StringUtil.getFormat(measureTime, 21), measureData));
				}
				i = i + byteTime + byteData;
			}

			// データ型が real の場合、
		} else if (Consts.DATA_TYPE_REAL.equals(dataType)) {

			byteData = 4;
			while (i <= b.length - (byteTime + byteData - 1)) {

				int time = buffer.getInt();
				String measureData = String.valueOf(buffer.getFloat());

				if ((timeFrom != null && timeTo != null
						&& ((timeFrom.equals(timeTo) && timeFrom == time) || (timeFrom <= time && timeTo > time)))
						|| (timeFrom != null && timeTo == null && timeFrom <= time)
						|| (timeFrom == null && timeTo != null && timeTo > time)) {

					String measureTime = rowKey + String.format(formatter, time);
					lstResult.add(new ResponseMeasureDataModel(StringUtil.getFormat(measureTime, 21), measureData));
				}
				i = i + byteTime + byteData;
			}

			// データ型が long の場合、
		} else if (Consts.DATA_TYPE_LONG.equals(dataType)) {

			byteData = 8;
			while (i <= b.length - (byteTime + byteData - 1)) {

				int time = buffer.getInt();
				String measureData = String.valueOf(buffer.getLong());

				if ((timeFrom != null && timeTo != null
						&& ((timeFrom.equals(timeTo) && timeFrom == time) || (timeFrom <= time && timeTo > time)))
						|| (timeFrom != null && timeTo == null && timeFrom <= time)
						|| (timeFrom == null && timeTo != null && timeTo > time)) {

					String measureTime = rowKey + String.format(formatter, time);
					lstResult.add(new ResponseMeasureDataModel(StringUtil.getFormat(measureTime, 21), measureData));
				}
				i = i + byteTime + byteData;
			}

			// データ型が float の場合、
		} else if (Consts.DATA_TYPE_FLOAT.equals(dataType)) {

			byteData = 8;
			while (i <= b.length - (byteTime + byteData - 1)) {

				int time = buffer.getInt();
				String measureData = String.valueOf(buffer.getDouble());

				if ((timeFrom != null && timeTo != null
						&& ((timeFrom.equals(timeTo) && timeFrom == time) || (timeFrom <= time && timeTo > time)))
						|| (timeFrom != null && timeTo == null && timeFrom <= time)
						|| (timeFrom == null && timeTo != null && timeTo > time)) {

					String measureTime = rowKey + String.format(formatter, time);
					lstResult.add(new ResponseMeasureDataModel(StringUtil.getFormat(measureTime, 21), measureData));
				}
				i = i + byteTime + byteData;
			}

			// データ型が bit 、かつ 固定長サイズがあるの場合、StringUtil.getFormat(measureTime, 21)
		} else if (Consts.DATA_TYPE_BIT.equals(dataType) && fixLength > 0) {

			BigDecimal bd = BigDecimal.valueOf(fixLength);
			BigDecimal divisor = new BigDecimal("8.00");
			byteData = bd.divide(divisor, BigDecimal.ROUND_UP).intValue();

			while (i <= b.length - (byteTime + byteData - 1)) {

				int time = buffer.getInt(i);

				String strData = "";
				if ((timeFrom != null && timeTo != null
						&& ((timeFrom.equals(timeTo) && timeFrom == time) || (timeFrom <= time && timeTo > time)))
						|| (timeFrom != null && timeTo == null && timeFrom <= time)
						|| (timeFrom == null && timeTo != null && timeTo > time)) {

					for (int k = i + byteTime; k < i + byteTime + byteData; k++)
						strData = String.format("%02x", b[k]) + strData;

					String measureTime = rowKey + String.format(formatter, time);
					lstResult.add(new ResponseMeasureDataModel(StringUtil.getFormat(measureTime, 21),
							StringUtil.getBitData(strData, fixLength)));
				}
				i = i + byteTime + byteData;
			}

			// 上記以外の場合、
		} else {
			// 固定長サイズがあるの場合、
			if (fixLength > 0) {

				byteData = fixLength;
				while (i <= b.length - (byteTime + byteData - 1)) {

					int time = buffer.getInt(i);

					byte[] data = new byte[byteData];
					if ((timeFrom != null && timeTo != null
							&& ((timeFrom.equals(timeTo) && timeFrom == time) || (timeFrom <= time && timeTo > time)))
							|| (timeFrom != null && timeTo == null && timeFrom <= time)
							|| (timeFrom == null && timeTo != null && timeTo > time)) {

						int j = -1;
						for (int k = i + byteTime; k < i + byteTime + byteData; k++) {
							j += 1;
							data[j] = b[k];
						}
						String measureTime = rowKey + String.format(formatter, time);
						lstResult.add(new ResponseMeasureDataModel(StringUtil.getFormat(measureTime, 21),
								new String(data).trim()));
					}
					i = i + byteTime + byteData;
				}

				// 上記以外の場合、
			} else {
				String arrData[] = StringUtil.split(new String(b), Consts.LINE_SEPARATOR, 0);
				for (String data : arrData) {
					String measure[] = StringUtil.split(data, Consts.COMMA, -1);

					int time = Integer.parseInt(measure[0]);
					if ((timeFrom != null && timeTo != null
							&& ((timeFrom.equals(timeTo) && timeFrom == time) || (timeFrom <= time && timeTo > time)))
							|| (timeFrom != null && timeTo == null && timeFrom <= time)
							|| (timeFrom == null && timeTo != null && timeTo > time)) {

						lstResult.add(new ResponseMeasureDataModel(StringUtil.getFormat(rowKey + measure[0], 21),
								measure[1].trim()));
					}
				}
			}
		}
		return lstResult;
	}

	private List<ResponseMeasureDataModel> AverageForASC(List<ResponseMeasureDataModel> lstMeasureData,
			String paramTimeFrom, String paramTimeTo, int maxNum) throws Exception {

		List<ResponseMeasureDataModel> lstAvgData = new ArrayList<>();
		Timestamp timeFrom = DateTimeUtil.toTimestamp(paramTimeFrom);
		Timestamp timeTo = DateTimeUtil.toTimestamp(paramTimeTo);

		// (From～Toの期間を最大件数で分割し各期間の平均値を取る
		// 対象期間（From - To）取得
		long timeDiff = (timeTo.getTime() - timeFrom.getTime()) / maxNum;
		double nanoDiff = (timeTo.getNanos() - timeFrom.getNanos()) / maxNum;

		Timestamp startTs = timeFrom;
		Timestamp endTs;
		Timestamp averageTime;
		double averageVal;
		double totalVal;
		long totalTime;
		long totalNano;
		int dataCnt;
		int maxNumCnt = 1;
		int idx = 0;

		while (maxNumCnt <= maxNum) {

			if (maxNumCnt == maxNum) {
				endTs = timeTo;
				endTs.setNanos(endTs.getNanos() + 1);
			} else {
				endTs = new Timestamp(startTs.getTime() + timeDiff);

				int nanoSecs = endTs.getNanos() + ((int) Math.round(nanoDiff) * maxNumCnt);
				int maxVal = 999999999;
				if (nanoSecs > maxVal) {
					nanoSecs = nanoSecs - maxVal;
					long durationInMs = TimeUnit.MILLISECONDS.convert(nanoSecs, TimeUnit.NANOSECONDS);

					endTs = new Timestamp(endTs.getTime() + durationInMs);
					endTs.setNanos(maxVal);
				} else {
					endTs.setNanos(nanoSecs);
				}
			}

			totalTime = 0;
			totalNano = 0;
			totalVal = 0;
			dataCnt = 0;
			int doubleValLength = 0;

			for (int i = idx; i < lstMeasureData.size(); i++) {
				idx = i;
				ResponseMeasureDataModel model = lstMeasureData.get(idx);
				Timestamp ts = DateTimeUtil.toTimestamp(model.getMeasureTime());

				// To以上の場合
				if (endTs.compareTo(ts) <= 0) {
					break;
				}

				// From以上 To未満の場合、
				if (startTs.compareTo(ts) <= 0 && endTs.compareTo(ts) > 0) {
					totalTime += ts.getTime();
					totalNano += ts.getNanos();
					totalVal += Double.parseDouble(model.getData());

					int length = model.getData().contains(".") ? (model.getData().split(Pattern.quote("."))[1]).length()
							: 0;
					if (doubleValLength < length) {
						doubleValLength = length;
					}
					dataCnt++;
				}
			}

			if (dataCnt > 0) {
				averageTime = new Timestamp(totalTime / dataCnt);
				Long average = totalNano / dataCnt;
				averageTime.setNanos(average.intValue());
				averageVal = totalVal / dataCnt;
				// logger.info(totalVal + "/" + dataCnt + "=" + averageVal);

				lstAvgData.add(new ResponseMeasureDataModel(DateTimeUtil.formatTs(averageTime),
						StringUtil.getFormat1(averageVal, doubleValLength)));
			}
			startTs = endTs;
			maxNumCnt += 1;
		}
		return lstAvgData;
	}

	private List<ResponseMeasureDataModel> AverageForDESC(List<ResponseMeasureDataModel> lstMeasureData,
			String paramTimeFrom, String paramTimeTo, int maxNum) throws Exception {

		List<ResponseMeasureDataModel> lstAvgData = new ArrayList<>();
		Timestamp timeFrom = DateTimeUtil.toTimestamp(paramTimeFrom);
		Timestamp timeTo = DateTimeUtil.toTimestamp(paramTimeTo);

		// (From～Toの期間を最大件数で分割し各期間の平均値を取る
		// 対象期間（From - To）取得
		long timeDiff = (timeTo.getTime() - timeFrom.getTime()) / maxNum;
		double nanoDiff = (timeTo.getNanos() - timeFrom.getNanos()) / maxNum;

		Timestamp startTs;
		Timestamp endTs = timeTo;
		Timestamp averageTime;
		double averageVal;
		double totalVal;
		long totalTime;
		long totalNano;
		int dataCnt;
		int maxNumCnt = 1;
		int idx = 0;

		endTs.setNanos(endTs.getNanos() + 1);
		while (maxNumCnt <= maxNum) {

			if (maxNumCnt == maxNum) {
				startTs = timeFrom;
			} else {
				startTs = new Timestamp(endTs.getTime() - timeDiff);

				int nanoSecs = startTs.getNanos() - ((int) Math.round(nanoDiff) * maxNumCnt);
				int minVal = 0;
				if (nanoSecs < minVal) {

					nanoSecs = minVal - nanoSecs;
					long durationInMs = TimeUnit.MILLISECONDS.convert(nanoSecs, TimeUnit.NANOSECONDS);

					startTs = new Timestamp(startTs.getTime() - durationInMs);
				} else {
					startTs.setNanos(nanoSecs);
				}
			}

			totalTime = 0;
			totalNano = 0;
			totalVal = 0;
			dataCnt = 0;
			int doubleValLength = 0;

			for (int i = idx; i < lstMeasureData.size(); i++) {
				idx = i;
				ResponseMeasureDataModel model = lstMeasureData.get(idx);
				Timestamp ts = DateTimeUtil.toTimestamp(model.getMeasureTime());

				// To以上の場合
				if (startTs.compareTo(ts) == 1) {
					break;
				}

				// From以上 To未満の場合、
				if (startTs.compareTo(ts) <= 0 && endTs.compareTo(ts) > 0) {
					totalTime += ts.getTime();
					totalNano += ts.getNanos();
					totalVal += Double.parseDouble(model.getData());

					int length = model.getData().contains(".") ? (model.getData().split(Pattern.quote("."))[1]).length()
							: 0;
					if (doubleValLength < length) {
						doubleValLength = length;
					}
					dataCnt++;
				}
			}
			if (dataCnt > 0) {
				averageTime = new Timestamp(totalTime / dataCnt);
				Long average = totalNano / dataCnt;
				averageTime.setNanos(average.intValue());
				averageVal = totalVal / dataCnt;

				lstAvgData.add(new ResponseMeasureDataModel(DateTimeUtil.formatTs(averageTime),
						StringUtil.getFormat1(averageVal, doubleValLength)));
			}
			endTs = startTs;
			maxNumCnt += 1;
		}
		return lstAvgData;
	}
}
