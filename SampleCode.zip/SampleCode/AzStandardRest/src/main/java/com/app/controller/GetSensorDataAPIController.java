package com.app.controller;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.exception.BadRequestException;
import com.app.model.ResponseSensorDataModel;
import com.app.model.SensorDataModel;
import com.app.model.SensorModel1;
import com.app.model.SubResponseModel;
import com.app.service.GetSensorDataService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * センサーデータ取得コントローラクラス
 * @author（TOSCO）ウェイ
 */
@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_DATA_FILE_MGT)
@Api(tags ={Consts.TAGS_SENSOR_DATA_FILE_MGT,}, description = Consts.MSG_SENSOR_DATA_FILE_MGT)
public class GetSensorDataAPIController {

	@Autowired private GetSensorDataService _service;
	@Autowired private MessageSource _msgSource;

	public static final Logger logger = LoggerFactory.getLogger(GetSensorDataAPIController.class);

	/**
	 * センサーデータ取得処理
	 */
	@ApiOperation(value = Consts.MSG_SENSOR_DATA, notes = Consts.MSG_SENSOR_DATA_01, nickname = Consts.OPERATIONID_SENSOR_DATA_INDEX)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = ResponseSensorDataModel.class, responseContainer = "List"),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 404, message = Consts.HTTP_MESSAGE_404),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_SENSOR_DATA, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
    public ResponseEntity<List<ResponseSensorDataModel>> GetSensorData(Locale locale, SensorDataModel reqModel,BindingResult result)
    																							throws Exception {
		logger.info("【センサーデータ取得】Request：" + reqModel);
		//Data Bind時のエラー

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, reqModel, result, lstError);
		if(!lstError.isEmpty()){
			BadRequestException exp = new BadRequestException("");
			exp.setArgs(lstError);
			throw exp;
		}

		// センサーデータを取得する
		List<ResponseSensorDataModel> lstResult =_service.getSensorData(reqModel);
		//logger.debug("【センサーデータ取得】Response：" + lstResult);
		return new ResponseEntity<List<ResponseSensorDataModel>>(lstResult, HttpStatus.OK);
	}

	/**
	 * 入力チェック処理
	 * @return List<SubResponseModel> エラーリスト
	 */
	private List<SubResponseModel> Validation(Locale locale
												, SensorDataModel req
												, BindingResult bindResult
												, List<SubResponseModel> lstError){

		// リクエスト．検索区分が null、又は 空白（""）の場合
		if(StringUtil.IsNullOrEmpty(req.getGet_class()) || StringUtil.IsBlank(req.getGet_class())){
			lstError.add(new SubResponseModel("get_class"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));

		}else{
			// リクエスト．検索区分が 「1、2」以外の場合
			if(!StringUtil.IsChar1(req.getGet_class())){
				lstError.add(new SubResponseModel("get_class"
						, _msgSource.getMessage(Consts.MESSAGE_E000044, null, locale)));
			}
		}

		Date mTimeTo = null;
		Date mTimeFrom = null;

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.");
		formatter.setLenient(false);

		// 対象期間(From)が null、又は 空白（""）の場合
		if(StringUtil.IsNullOrEmpty(req.getMeasure_time_from()) || StringUtil.IsBlank(req.getMeasure_time_from())){
			lstError.add(new SubResponseModel("measure_time_from"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));

		}else{
			if(!StringUtil.chkLength(req.getMeasure_time_from(), 27)){
				lstError.add(new SubResponseModel("measure_time_from",
						_msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{Consts.DATETIME_FORMAT_NANO}, locale)));

			}else{
				try{
					Timestamp tsFrom = new Timestamp(formatter.parse(req.getMeasure_time_from().substring(0, 20)).getTime());
					tsFrom.setNanos(Integer.parseInt(req.getMeasure_time_from().substring(20, 27)) * 100);
					mTimeFrom = new Date(tsFrom.getTime());

					// 対象期間(From)が現在日時より未来の場合
					/*if(date.compareTo(mTimeFrom) < 0){
						lstError.add(new SubResponseModel("measure_time_from"
								, _msgSource.getMessage(Consts.MESSAGE_E000014
										, new String[]{_msgSource.getMessage(Consts.MESSAGE_SYSTEM_DATETIME, null, locale)
												,_msgSource.getMessage(Consts.MESSAGE_TARGET_PERIOD_FROM, null, locale)}
								, locale)));
					}*/
				} catch (Exception e) {
					// 対象期間(From)のフォーマットが不正、又は 不正な日付の場合
					lstError.add(new SubResponseModel("measure_time_from"
							, _msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{Consts.DATETIME_FORMAT_NANO}, locale)));
				}
			}
		}

		if(!StringUtil.IsNullOrEmpty(req.getMeasure_time_to()) && !StringUtil.IsBlank(req.getMeasure_time_to())){

			if(!StringUtil.chkLength(req.getMeasure_time_to(), 27)){
				lstError.add(new SubResponseModel("measure_time_to"
						, _msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{Consts.DATETIME_FORMAT_NANO}, null, locale)));

			}else{
				try{
					Timestamp tsTo = new Timestamp(formatter.parse(req.getMeasure_time_to().substring(0, 20)).getTime());
					tsTo.setNanos(Integer.parseInt(req.getMeasure_time_to().substring(20, 27)) * 100);
					mTimeTo = new Date(tsTo.getTime());

					// 対象期間(To)が現在日時より未来の場合未入力と同じ扱いにする
					/*if(mTimeTo.compareTo(date) > 0){
						req.setMeasure_time_to(null);
					}else{*/
						// 対象期間(From)が対象期間(To)より未来の場合
						if(mTimeFrom != null && mTimeTo.compareTo(mTimeFrom) < 0){
							lstError.add(new SubResponseModel("measure_time_from, measure_time_to"
									, _msgSource.getMessage(Consts.MESSAGE_E000014
											, new String[]{_msgSource.getMessage(Consts.MESSAGE_TARGET_PERIOD_TO, null, locale)
													, _msgSource.getMessage(Consts.MESSAGE_TARGET_PERIOD_FROM, null, locale)}
									, locale)));
						}
					//}
				} catch (Exception e) {
					// 対象期間(To)のフォーマットが不正、又は 不正な日付の場合
					lstError.add(new SubResponseModel("measure_time_to",
							_msgSource.getMessage(Consts.MESSAGE_E000129, new String[]{Consts.DATETIME_FORMAT_NANO}, locale)));
				}
			}
		}

		int idx = 0;
		// リクエスト．センサーリストが null、又は 空リストの場合
		if (req.getSensor_list() == null || req.getSensor_list().size() <= 0){
			lstError.add(new SubResponseModel("sensor_list"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}else{
			for(SensorModel1 ssModel : req.getSensor_list()){

				boolean isNull = false;
				if(StringUtil.IsNullOrEmpty(ssModel.getModel_id())){
					lstError.add(new SubResponseModel("[" + idx + "]model_id"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
					isNull = true;
				}

				if(StringUtil.IsNullOrEmpty(ssModel.getSerial_no())){
					lstError.add(new SubResponseModel("[" + idx + "]serial_no"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
					isNull = true;
				}

				if(isNull == false){
					if(StringUtil.IsBlank(ssModel.getModel_id()) && StringUtil.IsBlank(ssModel.getSerial_no())){
						lstError.add(new SubResponseModel("[" + idx + "]model_id, serial_no"
								, _msgSource.getMessage(Consts.MESSAGE_E000031, null, locale)));
					}
				}
				idx += 1;
			}
		}

		// リクエスト．検索区分が 1の場合
		if(Consts.KBN_SEARCH_1.equals(req.getGet_class())){

			// リクエスト．データ丸め区分が指定の場合
			if(!StringUtil.IsNullOrEmpty(req.getRound_kbn()) && !StringUtil.IsBlank(req.getRound_kbn())){

				// リクエスト．データ丸め区分が 1以外 の場合
				if(!"1".equals(req.getRound_kbn())){
					lstError.add(new SubResponseModel("round_kbn"
							, _msgSource.getMessage(Consts.MESSAGE_E000047, null, locale)));

				// リクエスト．データ丸め区分が 1 、かつ リクエスト．最大件数が未指定、又は 0を指定した場合
				}else if("1".equals(req.getRound_kbn()) && (req.getMax_number() == null || req.getMax_number() <= 0)){
					lstError.add(new SubResponseModel("max_number"
							, _msgSource.getMessage(Consts.MESSAGE_E000018, null, locale)));
				}
			}else{
				if(req.getMax_number() != null && req.getMax_number() <= 0){
					lstError.add(new SubResponseModel("max_number"
							, _msgSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
				}
			}
		// リクエスト．検索区分が 2の場合
		}else if(Consts.KBN_SEARCH_2.equals(req.getGet_class())){

			// リクエスト．データ丸め区分が指定の場合
			if(!StringUtil.IsNullOrEmpty(req.getRound_kbn()) && !StringUtil.IsBlank(req.getRound_kbn())){
				lstError.add(new SubResponseModel("round_kbn"
						, _msgSource.getMessage(Consts.MESSAGE_E000017, null, locale)));
			}

			// リクエスト．最大件数が指定した場合
			if(req.getMax_number() != null){
				lstError.add(new SubResponseModel("max_number"
						, _msgSource.getMessage(Consts.MESSAGE_E000017, null, locale)));
			}

			// リクエスト．ソート順が指定した場合
			if(!StringUtil.IsNullOrEmpty(req.getSort()) && !StringUtil.IsBlank(req.getSort())){
				lstError.add(new SubResponseModel("sort"
						, _msgSource.getMessage(Consts.MESSAGE_E000017, null, locale)));
			}
		}

		return lstError;
	}
}
