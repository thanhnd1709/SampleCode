package com.app.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.entity.UserSensorAuthorityEntity;

/**
 * ユーザ・センサー権限情報取得リポジトリ
 * @author 9571
 *
 */
@Repository
public interface UserSensorAuthorityRepository extends JpaRepository<UserSensorAuthorityEntity, Integer>, UserSensorAuthorityRepositoryCustom {
}