package com.app.repository.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.entity.DeviceStructureEntity;
import com.app.filter.AuthUserInfoComponent;
import com.app.model.DeviceStructureModel;
import com.app.repository.DeviceStructureRepositoryCustom;

/**
 * デバイス階層情報取得リポジトリ実装クラス
 * @author（TOSCO）9571
 */
@Component
public class DeviceStructureRepositoryImpl implements DeviceStructureRepositoryCustom{

	/**
	 * デバイス階層情報取得
	 * @return デバイス階層情報取得エンティティクラスリスト
	 *
	 */
	@Autowired EntityManager em;
	@Autowired AuthUserInfoComponent authUserInfo;

	@Override
	public List<DeviceStructureEntity> getDeviceStructure(DeviceStructureModel reqModel,String sort,Integer limit,Integer offset) {

		String withSql = "WITH device_structure (parent_device_list, level, model_id, serial_no,  device_mode) AS ("
				        + " SELECT"
				        + "  CONVERT(nvarchar(2000), '') AS parent_device_list,"
				        + "  1 AS Level,"
				        + "  model_id,"
				        + "  serial_no ,"
				        + "  device_mode"
				        + " FROM mst_device md"
				        + " WHERE ";

		boolean hasValue = false;
		if(!StringUtil.IsNullOrEmpty(reqModel.getModel_id())){
			withSql     += " model_id  = :model_id";
			hasValue 	= true;
		}
		if(!StringUtil.IsNullOrEmpty(reqModel.getSerial_no())){
			if(hasValue) withSql += " AND";
			withSql	    += " serial_no  = :serial_no";
		}
			withSql     +=" UNION ALL"
				        + " SELECT"
				        + "   CONVERT(nvarchar(2000), ds.parent_device_list + (CASE level WHEN 1 THEN '' ELSE char(9) END) + ds.model_id + char(38) +ds.serial_no) AS parent_device_list,"
				        + "   level + 1 AS level,"
				        + "   md.model_id,"
				        + "   md.serial_no,"
				        + "   md.device_mode"
				        + " FROM device_structure ds"
				        + " INNER JOIN mst_device md"
				        + "   ON ds.model_id  = md.parent_model_id"
				        + "   AND ds.serial_no = md.parent_serial_no"
				        + "   AND ds.level < :level "
				        + "   AND dbo.fn_DeviceAuthChk(md.model_id, md.serial_no, (:userId), default, default) = 1)";

		String selectSql = " SELECT ROW_NUMBER() OVER(ORDER BY level) AS id, parent_device_list, level, model_id, serial_no,  device_mode from device_structure ds";

		if(reqModel.getGet_class().equals(Consts.KBN_SEARCH_2)){
			selectSql += " WHERE ds.level = :level"
					  + "  OR NOT EXISTS "
					  + "  (SELECT 1 FROM mst_device md WHERE ds.model_id = md.parent_model_id AND ds.serial_no = md.parent_serial_no) ";
		}

		selectSql = withSql + selectSql;

		boolean isNull = false;
		if(sort != null){
			selectSql = selectSql + " ORDER BY " + sort;
			isNull = true;
		}
		if(limit!= null && offset!= null){
			if(isNull == false){
				selectSql =  selectSql + " ORDER BY parent_device_list, level, model_id, serial_no, device_mode";
			}
			selectSql += " OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY";
		}

		Query query = em.createNativeQuery(selectSql,DeviceStructureEntity.class);

		//機種IDの設定
		if(!StringUtil.IsNullOrEmpty(reqModel.getModel_id())){
			query.setParameter("model_id", reqModel.getModel_id());
		}

		//S/Nの設定
		if(!StringUtil.IsNullOrEmpty(reqModel.getSerial_no())){
			query.setParameter("serial_no", reqModel.getSerial_no());
		}

		//階層数の設定
		query.setParameter("level", reqModel.getLevel());

		//トークンのユーザIDの設定
		query.setParameter("userId",authUserInfo.getPrincipalName() );

		//limitとoffsetの設定
		if (limit != null && offset != null) {
			query.setParameter("limit", limit);
			query.setParameter("offset", offset);
		}

		@SuppressWarnings("unchecked")
		List<DeviceStructureEntity> list = query.getResultList();

		return list;
	}

}