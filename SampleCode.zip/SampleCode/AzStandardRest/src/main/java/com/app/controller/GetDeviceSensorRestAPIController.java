package com.app.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.exception.BadRequestException;
import com.app.model.DeviceListModel;
import com.app.model.DeviceSensorModel;
import com.app.model.SensorModel;
import com.app.model.SubResponseModel;
import com.app.service.DeviceSensorService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * デバイス下センサ情報取得コントローラクラス
 */
@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_DEVICE_GROUP_STRUCTURE_GET)
@Api(tags= {Consts.TAGS_DEVICE_GROUP_STRUCTURE_GET,}, description = Consts.MSG_DEVICE_GROUP_STRUCTURE_GET)
public class GetDeviceSensorRestAPIController {

	public static final Logger logger = LoggerFactory.getLogger(GetDeviceSensorRestAPIController.class);

	@Autowired private DeviceSensorService deviceSensorService;
	@Autowired private MessageSource _msgSource;

	@ApiOperation(value = Consts.MSG_GET_DEVICE_SENSOR, notes = Consts.MSG_GET_DEVICE_SENSOR_01, nickname = Consts.OPERATIONID_DEVICE_SENSOR_INDEX)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = SensorModel.class, responseContainer = "List"),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500)
	})
	@RequestMapping(value = Consts.REQUEST_URL_DEVICE_SENSOR, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<List<SensorModel>> index(Locale locale, @ModelAttribute @Valid DeviceSensorModel reqModel, BindingResult errors) throws Exception {

		logger.info("Get開始");

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, reqModel, lstError);
		if(!lstError.isEmpty()){
			BadRequestException exp = new BadRequestException("");
			exp.setArgs(lstError);
			throw exp;
		}

		List<SensorModel> result = deviceSensorService.getDeviceSensor(reqModel.getDevice_list());

        return new ResponseEntity<List<SensorModel>>(result, HttpStatus.OK);
	}

	/**
	 * 入力チェック処理
	 * @param locale          ロケール
	 * @param reqModel        デバイス下センサ情報取得モデル
	 * @return List<SubResponseModel> エラーリスト
	 */
	private List<SubResponseModel> Validation(Locale locale
												, DeviceSensorModel reqModel
												, List<SubResponseModel> lstError){

		int idx = 0;
		// リクエスト．デバイスリストが null、又は 空リストの場合
		if(reqModel.getDevice_list() == null || reqModel.getDevice_list().size() <= 0){
			lstError.add(new SubResponseModel("sensor_list"
					, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}else{
			for(DeviceListModel dlModel : reqModel.getDevice_list()){

				boolean isNull = false;

				// リクエスト．[配列]デバイスリスト．機種IDが nullの場合
				if(StringUtil.IsNullOrEmpty(dlModel.getModel_id())){
					lstError.add(new SubResponseModel("[" + idx + "]:model_id"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
					isNull = true;
				}

				// リクエスト．[配列]デバイスリスト．シリアルNoが nullの場合
				if(StringUtil.IsNullOrEmpty(dlModel.getSerial_no())){
					lstError.add(new SubResponseModel("[" + idx + "]:serial_no"
							, _msgSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
					isNull = true;
				}

				if(isNull == false){
					// リクエスト．[配列]デバイスリスト．機種ID、且つ リクエスト．[配列]デバイスリスト．シリアルNo が 空白（""）の場合
					if(StringUtil.IsBlank(dlModel.getModel_id()) && StringUtil.IsBlank(dlModel.getSerial_no())){
						lstError.add(new SubResponseModel("[" + idx + "]:model_id, serial_no"
								, _msgSource.getMessage(Consts.MESSAGE_E000031, null, locale)));
					}
				}
				idx += 1;
			}
		}

		return lstError;
	}
}
