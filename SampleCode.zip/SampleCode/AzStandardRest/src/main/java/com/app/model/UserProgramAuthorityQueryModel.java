package com.app.model;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.StringJoiner;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * ユーザ・プログラム権限情報取得モデル
 * @author 9571
 *
 */
@Data
public class UserProgramAuthorityQueryModel implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String ENCODING = "UTF-8";

	@ApiModelProperty(value = "ID")
	private String[] id;

	@ApiModelProperty(value = "ロールID")
	private String[] role_id;

	@ApiModelProperty(value = "権限ID")
	private String[] authority_id;

	@ApiModelProperty(value = "権限種別")
	private String[] authority_type;

	@ApiModelProperty(value = "プログラム名称(ロケール1)")
	private String[] program_name_locale1;

	@ApiModelProperty(value = "プログラム名称(ロケール2)")
	private String[] program_name_locale2;

	@ApiModelProperty(value = "プログラム名称(ロケール3)")
	private String[] program_name_locale3;

	@ApiModelProperty(value = "プログラム説明(ロケール1)")
	private String[] program_description_locale1;

	@ApiModelProperty(value = "プログラム説明(ロケール2)")
	private String[] program_description_locale2;

	@ApiModelProperty(value = "プログラム説明(ロケール3)")
	private String[] program_description_locale3;

	@ApiModelProperty(value = "プログラムID")
	private String[] program_id;

	@ApiModelProperty(value = "URL")
	private String[] url;

	@ApiModelProperty(value = "メソッド")
	private String[] method;

	@ApiModelProperty(value = "プログラム備考")
	private String[] program_note;

	@ApiModelProperty(value = "ロール名称(ロケール1)")
	private String[] role_name_locale1;

	@ApiModelProperty(value = "ロール名称(ロケール2)")
	private String[] role_name_locale2;

	@ApiModelProperty(value = "ロール名称(ロケール3)")
	private String[] role_name_locale3;

	@ApiModelProperty(value = "ロール説明(ロケール1)")
	private String[] role_description_locale1;

	@ApiModelProperty(value = "ロール説明(ロケール2)")
	private String[] role_description_locale2;

	@ApiModelProperty(value = "ロール説明(ロケール3)")
	private String[] role_description_locale3;

	@ApiModelProperty(value = "ロール備考")
	private String[] role_note;

	@ApiModelProperty(value = "ユーザID",hidden = true)
	private String user_id;

	@ApiModelProperty(value = "任意並び順条件")
	private String sort;

	@ApiModelProperty(value = "取得フィールド")
	private String fields;

	@ApiModelProperty(value = "表示対象ページ番号")
	private String page;

	@ApiModelProperty(value = "1度に返すItem数")
	private String limit;

	public String buildUrlParameter() {
		StringJoiner sj = new StringJoiner("&", "?", "");
		sj.setEmptyValue("");
		try {
			if (role_id != null)
				for (String s : role_id)
					sj.add("role_id=" + URLEncoder.encode(s, ENCODING));

			if (user_id != null)
					sj.add("user_id=" + URLEncoder.encode(user_id, ENCODING));

			if (role_name_locale1 != null)
				for (String s : role_name_locale1)
					sj.add("role_name_locale1=" + URLEncoder.encode(s, ENCODING));

			if (role_name_locale2 != null)
				for (String s : role_name_locale2)
					sj.add("role_name_locale2=" + URLEncoder.encode(s, ENCODING));

			if (role_name_locale3 != null)
				for (String s : role_name_locale3)
					sj.add("role_name_locale3=" + URLEncoder.encode(s, ENCODING));

			if (role_description_locale1 != null)
				for (String s : role_description_locale1)
					sj.add("role_description_locale1=" + URLEncoder.encode(s, ENCODING));

			if (role_description_locale2 != null)
				for (String s : role_description_locale2)
					sj.add("role_description_locale2=" + URLEncoder.encode(s, ENCODING));

			if (role_description_locale3 != null)
				for (String s : role_description_locale3)
					sj.add("role_description_locale3=" + URLEncoder.encode(s, ENCODING));

			if (role_note != null)
				for (String s : role_note)
					sj.add("role_note=" + URLEncoder.encode(s, ENCODING));

			if (authority_id != null)
				for (String s : authority_id)
					sj.add("authority_id=" + URLEncoder.encode(s, ENCODING));

			if (authority_type != null)
				for (String s : authority_type)
					sj.add("authority_type=" + URLEncoder.encode(s, ENCODING));

			if (program_name_locale1 != null)
				for (String s : program_name_locale1)
					sj.add("program_name_locale1=" + URLEncoder.encode(s, ENCODING));

			if (program_name_locale2 != null)
				for (String s : program_name_locale2)
					sj.add("program_name_locale2=" + URLEncoder.encode(s, ENCODING));

			if (program_name_locale2 != null)
				for (String s : program_name_locale2)
					sj.add("program_name_locale2=" + URLEncoder.encode(s, ENCODING));

			if (program_description_locale1 != null)
				for (String s : program_description_locale1)
					sj.add("program_description_locale1=" + URLEncoder.encode(s, ENCODING));

			if (program_description_locale2 != null)
				for (String s : program_description_locale2)
					sj.add("program_description_locale2=" + URLEncoder.encode(s, ENCODING));

			if (program_description_locale3 != null)
				for (String s : program_description_locale3)
					sj.add("program_description_locale3=" + URLEncoder.encode(s, ENCODING));

			if (program_id != null)
				for (String s : program_id)
					sj.add("program_id=" + URLEncoder.encode(s, ENCODING));

			if (url != null)
				for (String s : url)
					sj.add("url=" + URLEncoder.encode(s, ENCODING));

			if (method != null)
				for (String s : method)
					sj.add("method=" + URLEncoder.encode(s, ENCODING));

			if (program_note != null)
				for (String s : program_note)
					sj.add("program_note=" + URLEncoder.encode(s, ENCODING));

			if (sort != null)
				sj.add("sort=" + URLEncoder.encode(sort, ENCODING));

			if (fields != null)
				sj.add("fields=" + URLEncoder.encode(fields, ENCODING));

			if (page != null)
				sj.add("page=" + URLEncoder.encode(page, ENCODING));

			if (limit != null)
				sj.add("limit=" + URLEncoder.encode(limit, ENCODING));

		} catch (UnsupportedEncodingException e) {
		}
		return sj.toString();
	}

}
