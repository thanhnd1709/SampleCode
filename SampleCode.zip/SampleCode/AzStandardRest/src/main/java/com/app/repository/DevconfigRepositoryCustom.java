package com.app.repository;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.app.entity.MstDevconfigEntity;
import com.app.model.DevconfigQueryModel;

public interface DevconfigRepositoryCustom {
	List<MstDevconfigEntity> findAll(DevconfigQueryModel query, List<String> sort, Integer limit, Integer offset);
	Long countAll(DevconfigQueryModel query);

    MstDevconfigEntity findOneForUpdate(@Param("id") int id);
}