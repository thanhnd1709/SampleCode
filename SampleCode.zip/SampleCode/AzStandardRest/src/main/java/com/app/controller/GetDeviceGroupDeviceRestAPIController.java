package com.app.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.common.Consts;
import com.app.common.utils.StringUtil;
import com.app.exception.BadRequestException;
import com.app.filter.AuthUserInfoComponent;
import com.app.model.DeviceGroupDeviceModel;
import com.app.model.DeviceGroupDeviceQueryModel;
import com.app.model.SubResponseModel;
import com.app.service.DeviceGroupDeviceService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * 指定デバイスグループ下デバイス取得コントローラクラス
 * 
 * @auther 1572
 */

@RestController
@RequestMapping(Consts.REQUEST_URL_MAPPING_VER + Consts.REQUEST_URL_MAPPING_DEVICE_GROUP_STRUCTURE_GET)
@Api(tags = { Consts.TAGS_DEVICE_GROUP_STRUCTURE_GET, }, description = Consts.MSG_DEVICE_GROUP_STRUCTURE_GET)
public class GetDeviceGroupDeviceRestAPIController {

	public static final Logger logger = LoggerFactory.getLogger(GetDeviceGroupDeviceRestAPIController.class);

	@Autowired
	private DeviceGroupDeviceService deviceGroupDeviceService;
	@Autowired
	private MessageSource messageSource;
	@Autowired
	private AuthUserInfoComponent authUserInfoComponent;

	@ApiOperation(value = Consts.MSG_GET_DEVICE_GROUP_DEVICE, notes = Consts.MSG_GET_DEVICE_GROUP_DEVICE_01, nickname = Consts.OPERATIONID_DEVICE_GROUP_DEVICE_INDEX)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = DeviceGroupDeviceModel.class, responseContainer = "List"),
			@ApiResponse(code = 400, message = Consts.HTTP_MESSAGE_400),
			@ApiResponse(code = 405, message = Consts.HTTP_MESSAGE_405),
			@ApiResponse(code = 500, message = Consts.HTTP_MESSAGE_500) })
	@RequestMapping(value = Consts.REQUEST_URL_DEVICE_GROUP_DEVICE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<List<DeviceGroupDeviceModel>> index(Locale locale,
			@ModelAttribute @Valid DeviceGroupDeviceQueryModel querymodel, BindingResult errors) throws Exception {

		logger.info("Get開始");

		// 入力チェック
		List<SubResponseModel> lstError = new ArrayList<>();
		lstError = Validation(locale, querymodel, lstError);
		if (!lstError.isEmpty()) {
			BadRequestException exp = new BadRequestException("");
			exp.setArgs(lstError);
			throw exp;
		}

		// 認証されたユーザIDを検索条件に設定
		String userId = authUserInfoComponent.getPrincipalName();
		querymodel.setUser_id(userId);

		List<DeviceGroupDeviceModel> result = deviceGroupDeviceService.findAll(querymodel);

		return new ResponseEntity<List<DeviceGroupDeviceModel>>(result, HttpStatus.OK);
	}

	/**
	 * 入力チェック処理
	 * 
	 * @param locale
	 *            ロケール
	 * @param reqModel
	 *            デバイスグループ階層情報取得モデル
	 * @return List<SubResponseModel> エラーリスト
	 */
	private List<SubResponseModel> Validation(Locale locale, DeviceGroupDeviceQueryModel reqModel,
			List<SubResponseModel> lstError) {
		
		// 取得フィールドの指定が不正な場合
		if(reqModel.getFields() != null){
			List<String> fieldsParams = new ArrayList<String>();
			for (String item : reqModel.getFields().split(",")) {
				fieldsParams.add(item.toLowerCase());
			}

	        if(StringUtil.hasDuplicate(fieldsParams)
	        		|| !StringUtil.hasProperty(new DeviceGroupDeviceModel(), fieldsParams)){
	        	lstError.add(new SubResponseModel("fields",
	        			messageSource.getMessage(Consts.MESSAGE_E000050, null, locale)));
	        }
		}

		// リクエスト．階層数が null、又は 空白（""）の場合
		if (StringUtil.IsNullOrEmpty(reqModel.getLevel()) || StringUtil.IsBlank(reqModel.getLevel())) {
			reqModel.setLevel("40");
		} else {
			// リクエスト．階層数が1～40以外の場合
			if (!StringUtil.IsHalfNumber(reqModel.getLevel())) {
				lstError.add(
						new SubResponseModel("level", messageSource.getMessage(Consts.MESSAGE_E000011, null, locale)));
			} else if (!StringUtil.IsMaxMin2(Double.parseDouble(reqModel.getLevel()), 40.0, 1.0)) {
				lstError.add(new SubResponseModel("level",
						messageSource.getMessage(Consts.MESSAGE_E000024, new String[] { "1", "40" }, locale)));
			}
		}

		// リクエスト．デバイスグループIDが null、又は 空白（""）の場合
		if (reqModel.getDevice_group_id() == null){
			lstError.add(new SubResponseModel("device_group_id",
					messageSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}
		else if(reqModel.getDevice_group_id().length==0
				|| StringUtil.IsBlank(reqModel.getDevice_group_id()[0] ))
		{
			lstError.add(new SubResponseModel("device_group_id",
					messageSource.getMessage(Consts.MESSAGE_E000001, null, locale)));
		}

		// Pageの指定が不正な場合
		try {
			if (reqModel.getPage() != null && Integer.parseInt(reqModel.getPage()) < 1) {
				lstError.add(
						new SubResponseModel("page", messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		} catch (NumberFormatException e) {
			lstError.add(new SubResponseModel("page", messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}

		// limitの指定が不正な場合
		try {
			if (reqModel.getLimit() != null && Integer.parseInt(reqModel.getLimit()) < 1) {
				lstError.add(
						new SubResponseModel("limit", messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
			}
		} catch (NumberFormatException e) {
			lstError.add(new SubResponseModel("limit", messageSource.getMessage(Consts.MESSAGE_E000019, null, locale)));
		}

		// ソートの指定が不正な場合
		if (reqModel.getSort() != null) {
			List<String> sortParams = new ArrayList<String>();
			for (String item : reqModel.getSort().split(",")) {
				sortParams.add(item.toLowerCase().replace("-", ""));
			}

			if (StringUtil.hasDuplicate(sortParams)
					|| !StringUtil.hasProperty(new DeviceGroupDeviceModel(), sortParams)) {
				lstError.add(
						new SubResponseModel("sort", messageSource.getMessage(Consts.MESSAGE_E000049, null, locale)));
			}
		}
		return lstError;
	}
}
