package com.app.common;

/**
 * 定数クラス
 * @author（TOSCO）ウェイ
 */
public class Consts {

	/****************************
	 * Url
	 ****************************/
	public static final String REQUEST_URL_MAPPING_VER = "/v1";
	public static final String REQUEST_URL_MAPPING_MST = "/master-info";
	public static final String REQUEST_URL_MAPPING_DEVICE_GROUP_STRUCTURE_GET = "/device-group-structure-get";
	public static final String REQUEST_URL_MAPPING_DATA_FILE_MGT = "/sensor-data-file-mgt";
	public static final String REQUEST_URL_MAPPING_ALARM_EVENT_MGT = "/alarm-event-mgt";
	public static final String REQUEST_URL_MAPPING_DEVICE = "/device";

	public static final String REQUEST_URL_DEVICE = "/devices";
	public static final String REQUEST_URL_DEVICE_ID = "/devices/{id}";
	public static final String REQUEST_URL_USER_ROLE = "/userRoles";
	public static final String REQUEST_URL_USER_ROLE_ID = "/userRoles/{id}";
	public static final String REQUEST_URL_GROUP_COMPOSITION_SENSOR = "/groupCompositionSensors";
	public static final String REQUEST_URL_GROUP_COMPOSITION_SENSOR_ID = "/groupCompositionSensors/{id}";
	public static final String REQUEST_URL_SENSOR = "/sensors";
	public static final String REQUEST_URL_SENSOR_ID = "/sensors/{id}";
	public static final String REQUEST_URL_EVENT = "events";
	public static final String REQUEST_URL_EVENT_ID = "/events/{id}";
	public static final String REQUEST_URL_DEVICE_GROUP = "/deviceGroups";
	public static final String REQUEST_URL_DEVICE_GROUP_ID = "/deviceGroups/{id}";
	public static final String REQUEST_URL_GROUP_COMPOSITION_DEVICE = "/groupCompositionDevices";
	public static final String REQUEST_URL_GROUP_COMPOSITION_DEVICE_ID = "/groupCompositionDevices/{id}";
	public static final String REQUEST_URL_BASE_DEVICE = "/baseDevices";
	public static final String REQUEST_URL_BASE_DEVICE_ID = "/baseDevices/{id}";
	public static final String REQUEST_URL_BASE_SENSOR = "/baseSensors";
	public static final String REQUEST_URL_BASE_SENSOR_ID = "/baseSensors/{id}";
	public static final String REQUEST_URL_BASE_EVENT = "baseEvents";
	public static final String REQUEST_URL_BASE_EVENT_ID = "/baseEvents/{id}";
	public static final String REQUEST_URL_BASE_DEVCONFIG = "baseDevconfigs";
	public static final String REQUEST_URL_BASE_DEVCONFIG_ID = "/baseDevconfigs/{id}";
	public static final String REQUEST_URL_DEVCONFIG = "devconfigs";
	public static final String REQUEST_URL_DEVCONFIG_ID = "/devconfigs/{id}";
	public static final String REQUEST_URL_DEVCONFIG_HISTORIES = "/devconfigHistories";
	public static final String REQUEST_URL_DEVCONFIG_HISTORIES_ID = "/devconfigHistories/{id}";

	public static final String REQUEST_URL_ROLE_ROOT_GROUP = "/roleRootGroups";
	public static final String REQUEST_URL_ROLE_ROOT_GROUP_ID = "/roleRootGroups/{id}";
	public static final String REQUEST_URL_ROLE_DEVICE_GROUP = "/roleDeviceGroups";
	public static final String REQUEST_URL_ROLE_DEVICE_GROUP_ID = "/roleDeviceGroups/{id}";

	public static final String REQUEST_URL_DEVICE_GROUP_STRUCTURE = "/deviceGroupStructure";
	public static final String REQUEST_URL_DEVICE_GROUP_DEVICE = "/deviceGroupDevice";
	public static final String REQUEST_URL_DEVICE_STRUCTURE = "/deviceStructure";
	public static final String REQUEST_URL_DEVICE_SENSOR = "deviceSensor";

	public static final String REQUEST_URL_SENSOR_DATA = "/sensorData";
	public static final String REQUEST_URL_LATEST_SENSOR_DATA = "/latestSensorData";
	public static final String REQUEST_URL_SENSOR_FILE = "/sensorFile";
	public static final String REQUEST_URL_LATEST_SENSOR_FILE = "/latestSensorFile";
	public static final String REQUEST_URL_FILE = "/file";
	public static final String REQUEST_URL_MEASURE_FILE = "/measureFile";
	public static final String REQUEST_URL_EXPANSION_FILE = "/expansionFile";

	public static final String REQUEST_URL_EVENT_HISTORY = "/eventHistory";
	public static final String REQUEST_URL_EVENT_STATUS = "/eventStatus";
	public static final String REQUEST_URL_DEVICE_GROUP_ALARM_STATUS = "/deviceGroupAlarmStatus";
	public static final String REQUEST_URL_DEVICE_ALARM_STATUS = "/deviceAlarmStatus";
	public static final String REQUEST_URL_POST_EVENT = "/event";
	public static final String REQUEST_URL_STATUS_MGT = "/statusMgt/{id}";

	public static final String REQUEST_URL_ROLE = "/roles";
	public static final String REQUEST_URL_ROLE_ID = "/roles/{id}";

	public static final String REQUEST_URL_USER_DEVICE_GROUP_AUTHORITY = "/userDeviceGroupAuthorities";
	public static final String REQUEST_URL_USER_DEVICE_AUTHORITY = "/userDeviceAuthorities";
	public static final String REQUEST_URL_USER_DEVICE_AUTHORITY_ID = "/userDeviceAuthorities/{id}";
	public static final String REQUEST_URL_USER_BASE_DEVICE_AUTHORITY = "/userBaseDeviceAuthorities";
	public static final String REQUEST_URL_USER_BASE_DEVICE_AUTHORITY_ID = "/userBaseDeviceAuthorities/{id}";
	public static final String REQUEST_URL_USER_SENSOR_AUTHORITY = "/userSensorAuthorities";
	public static final String REQUEST_URL_USER_PROGRAM_AUTHORITY = "/userProgramAuthorities";
	public static final String REQUEST_URL_USER_EVENT_AUTHORITY = "/userEventAuthorities";

	public static final String REQUEST_URL_OPE_INSTRUCTIONS = "/opeInstructions";
	public static final String REQUEST_URL_FILE_INFO_NOTIFICATION = "/fileInfoNotification";

	public static final String REQUEST_URL_GROUP_COMPOSITION_EVENT = "/groupCompositionEvents";
	public static final String REQUEST_URL_GROUP_COMPOSITION_EVENT_ID = "/groupCompositionEvents/{id}";

	/****************************
	 * アノテーション
	 ****************************/
	// tags
	public static final String TAGS_DEVICE = "DEVICE";
	public static final String TAGS_USER_ROLE = "USER_ROLE";
	public static final String TAGS_SENSOR = "SENSOR";
	public static final String TAGS_EVENT = "EVENT";
	public static final String TAGS_DEVICE_GROUP = "DEVICE_GROUP";
	public static final String TAGS_GROUP_COMPOSITION_DEVICE = "GROUP_COMPOSITION_DEVICE";
	public static final String TAGS_BASE_DEVICE = "BASE_DEVICE";
	public static final String TAGS_BASE_SENSOR = "BASE_SENSOR";
	public static final String TAGS_BASE_EVENT = "BASE_EVENT";
	public static final String TAGS_BASE_DEVCONFIG = "BASE_DEVCONFIG";
	public static final String TAGS_DEVCONFIG = "DEVCONFIG";
	public static final String TAGS_DEVCONFIG_HISTORY = "DEVCONFIG_HISTORIES";

	public static final String TAGS_DEVICE_GROUP_STRUCTURE_GET = "DEVICE_GROUP_STRUCTURE_GET";
	public static final String TAGS_SENSOR_DATA_FILE_MGT = "SENSOR_DATA_FILE_MGT";
	public static final String TAGS_ALARM_EVENT_MGT = "ALARM_EVENT_MGT";


	public static final String TAGS_ROLE_ROOT_GROUP = "ROLE_ROOT_GROUP";
	public static final String TAGS_ROLE_DEVICE_GROUP = "ROLE_DEVICE_GROUP";

	public static final String TAGS_ROLE = "ROLE";
	public static final String TAGS_USER_DEVICE_GROUP_AUTHORITY = "USER_DEVICE_GROUP_AUTHORITY";
	public static final String TAGS_USER_DEVICE_AUTHORITY = "USER_DEVICE_AUTHORITY";
	public static final String TAGS_USER_BASE_DEVICE_AUTHORITY = "USER_BASE_DEVICE_AUTHORITY";
	public static final String TAGS_USER_SENSOR_AUTHORITY = "USER_SENSOR_AUTHORITY";
	public static final String TAGS_USER_PROGRAM_AUTHORITY = "USER_PROGRAM_AUTHORITY";
	public static final String TAGS_USER_EVENT_AUTHORITY = "USER_EVENT_AUTHORITY";

	public static final String TAGS_DEVICE_OPERATIONS = "DEVICE_OPERATIONS";

	public static final String TAGS_GROUP_COMPOSITION_EVENTS = "GROUP_COMPOSITION_EVENTS";

	// operationId
	public static final String OPERATIONID_DEVICE_INDEX = "deviceIndex";
	public static final String OPERATIONID_DEVICE_SHOW = "deviceShow";
	public static final String OPERATIONID_DEVICE_CREATE = "deviceCreate";
	public static final String OPERATIONID_DEVICE_PUT = "devicePut";
	public static final String OPERATIONID_DEVICE_DELETE = "deviceDelete";

	public static final String OPERATIONID_USER_ROLE_INDEX = "userRoleIndex";
	public static final String OPERATIONID_USER_ROLE_SHOW = "userRoleShow";
	public static final String OPERATIONID_USER_ROLE_CREATE = "userRoleCreate";
	public static final String OPERATIONID_USER_ROLE_PUT = "userRolePut";
	public static final String OPERATIONID_USER_ROLE_DELETE = "userRoleDelete";

	public static final String OPERATIONID_GROUP_COMPOSITION_SENSOR_INDEX = "groupCompositionSensorIndex";
	public static final String OPERATIONID_GROUP_COMPOSITION_SENSOR_SHOW = "groupCompositionSensorShow";
	public static final String OPERATIONID_GROUP_COMPOSITION_SENSOR_CREATE = "groupCompositionSensorCreate";
	public static final String OPERATIONID_GROUP_COMPOSITION_SENSOR_PUT = "groupCompositionSensorPut";
	public static final String OPERATIONID_GROUP_COMPOSITION_SENSOR_DELETE = "groupCompositionSensorDelete";

	public static final String OPERATIONID_SENSOR_INDEX = "sensorIndex";
	public static final String OPERATIONID_SENSOR_SHOW = "sensorShow";
	public static final String OPERATIONID_SENSOR_CREATE = "sensorCreate";
	public static final String OPERATIONID_SENSOR_PUT = "sensorPut";
	public static final String OPERATIONID_SENSOR_DELETE = "sensorDelete";

	public static final String OPERATIONID_EVENT_INDEX = "eventIndex";
	public static final String OPERATIONID_EVENT_SHOW = "eventShow";
	public static final String OPERATIONID_EVENT_CREATE = "eventCreate";
	public static final String OPERATIONID_EVENT_PUT = "eventPut";
	public static final String OPERATIONID_EVENT_DELETE = "eventDelete";

	public static final String OPERATIONID_DEVICE_GROUP_INDEX = "deviceGroupIndex";
	public static final String OPERATIONID_DEVICE_GROUP_SHOW = "deviceGroupShow";
	public static final String OPERATIONID_DEVICE_GROUP_CREATE = "deviceGroupCreate";
	public static final String OPERATIONID_DEVICE_GROUP_PUT = "deviceGroupPut";
	public static final String OPERATIONID_DEVICE_GROUP_DELETE = "deviceGroupDelete";

	public static final String OPERATIONID_GROUP_COMPOSITION_DEVICE_INDEX = "groupCompositionDeviceIndex";
	public static final String OPERATIONID_GROUP_COMPOSITION_DEVICE_SHOW = "groupCompositionDeviceShow";
	public static final String OPERATIONID_GROUP_COMPOSITION_DEVICE_CREATE = "groupCompositionDeviceCreate";
	public static final String OPERATIONID_GROUP_COMPOSITION_DEVICE_PUT = "groupCompositionDevicePut";
	public static final String OPERATIONID_GROUP_COMPOSITION_DEVICE_DELETE = "groupCompositionDeviceDelete";

	public static final String OPERATIONID_GROUP_COMPOSITION_EVENT_INDEX = "groupCompositionEventIndex";
	public static final String OPERATIONID_GROUP_COMPOSITION_EVENT_SHOW = "groupCompositionEventShow";
	public static final String OPERATIONID_GROUP_COMPOSITION_EVENT_CREATE = "groupCompositionEventCreate";
	public static final String OPERATIONID_GROUP_COMPOSITION_EVENT_PUT = "groupCompositionEventPut";
	public static final String OPERATIONID_GROUP_COMPOSITION_EVENT_DELETE = "groupCompositionEventDelete";

	public static final String OPERATIONID_BASE_DEVICE_INDEX = "baseDeviceIndex";
	public static final String OPERATIONID_BASE_DEVICE_SHOW = "baseDeviceShow";
	public static final String OPERATIONID_BASE_DEVICE_CREATE = "baseDeviceCreate";
	public static final String OPERATIONID_BASE_DEVICE_PUT = "baseDevicePut";
	public static final String OPERATIONID_BASE_DEVICE_DELETE = "baseDeviceDelete";

	public static final String OPERATIONID_BASE_SENSOR_INDEX = "baseSensorIndex";
	public static final String OPERATIONID_BASE_SENSOR_SHOW = "baseSensorShow";
	public static final String OPERATIONID_BASE_SENSOR_CREATE = "baseSensorCreate";
	public static final String OPERATIONID_BASE_SENSOR_PUT = "baseSensorPut";
	public static final String OPERATIONID_BASE_SENSOR_DELETE = "baseSensorDelete";

	public static final String OPERATIONID_BASE_EVENT_INDEX = "baseEventIndex";
	public static final String OPERATIONID_BASE_EVENT_SHOW = "baseEventShow";
	public static final String OPERATIONID_BASE_EVENT_CREATE = "baseEventCreate";
	public static final String OPERATIONID_BASE_EVENT_PUT = "baseEventPut";
	public static final String OPERATIONID_BASE_EVENT_DELETE = "baseEventDelete";

	public static final String OPERATIONID_DEVCONFIG_INDEX = "devconfigIndex";
	public static final String OPERATIONID_DEVCONFIG_SHOW = "devconfigShow";
	public static final String OPERATIONID_DEVCONFIG_CREATE = "devconfigCreate";
	public static final String OPERATIONID_DEVCONFIG_PUT = "devconfigPut";

	public static final String OPERATIONID_BASE_DEVCONFIG_INDEX = "baseDevconfigIndex";
	public static final String OPERATIONID_BASE_DEVCONFIG_SHOW = "baseDevconfigShow";
	public static final String OPERATIONID_BASE_DEVCONFIG_CREATE = "baseDevconfigCreate";
	public static final String OPERATIONID_BASE_DEVCONFIG_PUT = "baseDevconfigPut";

	public static final String OPERATIONID_DEVICE_GROUP_STRUCTURE_INDEX = "deviceGroupStructureIndex";
	public static final String OPERATIONID_DEVICE_GROUP_DEVICE_INDEX = "deviceGroupDeviceIndex";
	public static final String OPERATIONID_DEVICE_STRUCTURE_INDEX = "deviceStructureIndex";
	public static final String OPERATIONID_DEVICE_SENSOR_INDEX = "deviceSensorIndex";

	public static final String OPERATIONID_ROLE_ROOT_GROUP_INDEX = "roleRootGroupIndex";
	public static final String OPERATIONID_ROLE_ROOT_GROUP_SHOW = "roleRootGroupShow";
	public static final String OPERATIONID_ROLE_ROOT_GROUP_CREATE = "roleRootGroupCreate";
	public static final String OPERATIONID_ROLE_ROOT_GROUP_PUT = "roleRootGroupPut";
	public static final String OPERATIONID_ROLE_ROOT_GROUP_DELETE = "roleRootGroupDelete";

	public static final String OPERATIONID_ROLE_DEVICE_GROUP_INDEX = "roleDeviceGroupIndex";
	public static final String OPERATIONID_ROLE_DEVICE_GROUP_SHOW = "roleDeviceGroupShow";
	public static final String OPERATIONID_ROLE_DEVICE_GROUP_CREATE = "roleDeviceGroupCreate";
	public static final String OPERATIONID_ROLE_DEVICE_GROUP_PUT = "roleDeviceGroupPut";
	public static final String OPERATIONID_ROLE_DEVICE_GROUP_DELETE = "roleDeviceGroupDelete";

	public static final String OPERATIONID_SENSOR_DATA_INDEX = "sensorDataIndex";
	public static final String OPERATIONID_LATEST_SENSOR_DATA_INDEX = "latestSensorDataIndex";
	public static final String OPERATIONID_SENSOR_FILE_INDEX = "sensorFileIndex";
	public static final String OPERATIONID_LATEST_SENSOR_FILE_INDEX = "latestSensorFileIndex";
	public static final String OPERATIONID_GET_FILE_INDEX = "getFileIndex";
	public static final String OPERATIONID_POST_FILE_CREATE = "postFileCreate";
	public static final String OPERATIONID_POST_MEASURE_FILE_CREATE = "postMeasureFileCreate";
	public static final String OPERATIONID_POST_EXPANSION_FILE_CREATE = "postExpansionFileCreate";
	public static final String OPERATIONID_SENSOR_DATA_DELETE = "sensorDataDelete";

	public static final String OPERATIONID_SEARCH_EVENT_HISTORY_INDEX  = "searchEventHistoryIndex";
	public static final String OPERATIONID_GET_EVENT_STATUS_INDEX  = "eventStatusIndex";
	public static final String OPERATIONID_GET_DEVICE_GROUP_ALARM_STATUS_INDEX  = "getDeviceGroupAlarmStatusIndex";
	public static final String OPERATIONID_GET_DEVICE_ALARM_STATUS_INDEX  = "getDeviceAlarmStatusIndex";
	public static final String OPERATIONID_POST_EVENT_CREATE = "postEventCreate";
	public static final String OPERATIONID_STATUS_MANAGEMENT_PUT = "statusManagementPut";

	public static final String OPERATIONID_ROLE_INDEX = "roleIndex";
	public static final String OPERATIONID_ROLE_SHOW = "roleShow";
	public static final String OPERATIONID_ROLE_CREATE = "roleCreate";
	public static final String OPERATIONID_ROLE_PUT = "rolePut";
	public static final String OPERATIONID_ROLE_DELETE = "roleDelete";

	public static final String OPERATIONID_USER_DEVICE_GROUP_AUTHORITY_INDEX  = "userDeviceGroupAuthorityIndex";

	public static final String OPERATIONID_USER_DEVICE_AUTHORITY_INDEX  = "userDeviceAuthorityIndex";
	public static final String OPERATIONID_USER_DEVICE_AUTHORITY_POST  = "userDeviceAuthorityCreate";
	public static final String OPERATIONID_USER_DEVICE_AUTHORITY_PUT  = "userDeviceAuthorityPut";

	public static final String OPERATIONID_USER_BASE_DEVICE_AUTHORITY_INDEX  = "userBaseDeviceAuthorityIndex";

	public static final String OPERATIONID_USER_BASE_DEVICE_AUTHORITY_CREATE  = "userBaseDeviceAuthorityCreate";

	public static final String OPERATIONID_USER_BASE_DEVICE_AUTHORITY_UPDATE  = "userBaseDeviceAuthorityUpdate";

	public static final String OPERATIONID_USER_SENSOR_AUTHORITY_INDEX  = "userSensorAuthorityIndex";

	public static final String OPERATIONID_USER_EVENT_AUTHORITY_INDEX  = "userEventAuthorityIndex";

	public static final String OPERATIONID_USER_PROGRAM_AUTHORITY_INDEX  = "userProgramAuthorityIndex";

	public static final String OPERATIONID_OPE_INSTRUCTIONS_POST = "opeInstructionsPost";
	public static final String OPERATIONID_FILE_INFO_NOTIFICATION_POST = "fileInfoNotification";

	public static final String OPERATIONID_GET_DEVCONFIG_HISTORIES_INDEX = "devconfigHistoriesIndex";
	public static final String OPERATIONID_GET_DEVCONFIG_HISTORIES_SHOW = "devconfigHistoriesShow";
	// value
	public static final String MSG_DEVICE = "デバイス情報(DB)";
	public static final String MSG_USER_ROLE = "ユーザ・ロール";
	public static final String MSG_SENSOR = "センサー情報";
	public static final String MSG_EVENT = "イベント・アラーム情報";
	public static final String MSG_DEVICE_GROUP = "デバイスグループ情報";
	public static final String MSG_GROUP_COMPOSITION_DEVICE = "グループ構成デバイス";
	public static final String MSG_BASE_DEVICE = "デバイスマスタ";
	public static final String MSG_BASE_SENSOR = "センサーマスタ";
	public static final String MSG_BASE_EVENT = "イベント・アラームマスタ";
	public static final String MSG_BASE_DEVCONFIG = "デバイスコンフィグマスタ";
	public static final String MSG_DEVCONFIG = "デバイスコンフィグ情報";
	public static final String MSG_DEVCONFIG_HISTORIES = "デバイスコンフィグ履歴情報";
	public static final String MSG_DEVCONFIG_HISTORIES_01 = "デバイスコンフィグ履歴情報を取得します。";

	public static final String MSG_ROLE = "ロール情報";
	public static final String MSG_ROLE_01 = "ロール情報を取得します。";

	public static final String MSG_DEVICE_GROUP_STRUCTURE_GET = "デバイスグループ階層構造取得";
	public static final String MSG_SENSOR_DATA_FILE_MGT = "センサーデータ・ファイル管理";
	public static final String MSG_ALARM_EVENT_MGT = "アラーム・イベント・予兆管理";

	public static final String MSG_ROLE_ROOT_GROUP = "ロール・ルートグループ";
	public static final String MSG_ROLE_DEVICE_GROUP = "ロール・デバイスグループ権限";
	public static final String MSG_GROUP_COMPOSITION_EVENTS = "グループ構成イベント";


	public static final String MSG_GET_DEVICE = "デバイス情報(DB)取得";
	public static final String MSG_GET_DEVICE_01 = "デバイス情報(DB)を取得します。";
	public static final String MSG_GET_DEVICE_ID = "デバイス情報(DB)取得 (ID指定)";
	public static final String MSG_GET_DEVICE_ID_01 = "デバイス情報(DB)を取得します。 (ID指定)";
	public static final String MSG_POST_DEVICE = "デバイス情報(DB)登録";
	public static final String MSG_POST_DEVICE_01 = "デバイス情報(DB)を登録します。";
	public static final String MSG_PUT_DEVICE = "デバイス情報(DB)更新";
	public static final String MSG_PUT_DEVICE_01 = "デバイス情報(DB)を更新します。(PUT時 versionは必須項目です。更新前の値をセットして下さい。)";
	public static final String MSG_DELETE_DEVICE = "デバイス情報(DB)削除";
	public static final String MSG_DELETE_DEVICE_01 = "デバイス情報(DB)を削除します。";


	public static final String MSG_GET_GROUP_COMPOSITION_SENSOR = "グループ構成センサー取得";
	public static final String MSG_GET_GROUP_COMPOSITION_SENSOR_01 = "グループ構成センサーを取得します。";
	public static final String MSG_GET_GROUP_COMPOSITION_SENSOR_ID = "グループ構成センサー取得 (ID指定)";
	public static final String MSG_GET_GROUP_COMPOSITION_SENSOR_ID_01 = "グループ構成センサーを取得します。 (ID指定)";
	public static final String MSG_POST_GROUP_COMPOSITION_SENSOR = "グループ構成センサー登録";
	public static final String MSG_POST_GROUP_COMPOSITION_SENSOR_01 = "グループ構成センサーを登録します。";
	public static final String MSG_PUT_GROUP_COMPOSITION_SENSOR = "グループ構成センサー更新";
	public static final String MSG_PUT_GROUP_COMPOSITION_SENSOR_01 = "グループ構成センサーを更新します。(PUT時 versionは必須項目です。更新前の値をセットして下さい。)";
	public static final String MSG_DELETE_GROUP_COMPOSITION_SENSOR = "グループ構成センサー削除";
	public static final String MSG_DELETE_GROUP_COMPOSITION_SENSOR_01 = "グループ構成センサーを削除します。";

	public static final String MSG_GET_USER_ROLE = "ユーザ・ロール取得";
	public static final String MSG_GET_USER_ROLE_01 = "ログインユーザがアクセス可能なロールについて、ユーザ・ロール情報を取得します。";
	public static final String MSG_GET_USER_ROLE_ID = "ユーザ・ロール取得 (ID指定)";
	public static final String MSG_GET_USER_ROLE_ID_01 = "ユーザ・ロールを取得します。 (ID指定)";
	public static final String MSG_POST_USER_ROLE = "ユーザ・ロール登録";
	public static final String MSG_POST_USER_ROLE_01 = "ユーザ・ロールを登録します。（ログインユーザがアクセス可能なロールについてのみ、ユーザを登録できます。）";
	public static final String MSG_PUT_USER_ROLE = "ユーザ・ロール更新";
	public static final String MSG_PUT_USER_ROLE_01 = "ユーザ・ロールを更新します。(ログインユーザがアクセス可能なロールについてのみ、ユーザを更新できます。PUT時 versionは必須項目です。更新前の値をセットして下さい。)";
	public static final String MSG_DELETE_USER_ROLE = "ユーザ・ロール削除";
	public static final String MSG_DELETE_USER_ROLE_01 = "ユーザ・ロールを削除します。（ログインユーザがアクセス可能なロールについてのみ、ユーザを削除できます。）";

	public static final String MSG_GET_SENSOR = "センサー情報取得";
	public static final String MSG_GET_SENSOR_01 = "センサー情報を取得します。";
	public static final String MSG_GET_SENSOR_ID = "センサー情報取得 (ID指定)";
	public static final String MSG_GET_SENSOR_ID_01 = "センサー情報を取得します。 (ID指定)";
	public static final String MSG_POST_SENSOR = "センサー情報登録";
	public static final String MSG_POST_SENSOR_01 = "センサー情報を登録します。";
	public static final String MSG_PUT_SENSOR = "センサー情報更新";
	public static final String MSG_PUT_SENSOR_01 = "センサー情報を更新します。(PUT時 versionは必須項目です。更新前の値をセットして下さい。)";
	public static final String MSG_DELETE_SENSOR = "センサー情報削除";
	public static final String MSG_DELETE_SENSOR_01 = "センサー情報を削除します。";

	public static final String MSG_GET_EVENT = "イベント・アラーム情報取得";
	public static final String MSG_GET_EVENT_01 = "イベント・アラーム情報を取得します。";
	public static final String MSG_GET_EVENT_ID = "イベント・アラーム情報取得 (ID指定)";
	public static final String MSG_GET_EVENT_ID_01 = "イベント・アラーム情報を取得します。 (ID指定)";
	public static final String MSG_POST_EVENT = "イベント・アラーム情報登録";
	public static final String MSG_POST_EVENT_01 = "イベント・アラーム情報を登録します。";
	public static final String MSG_PUT_EVENT = "イベント・アラーム情報更新";
	public static final String MSG_PUT_EVENT_01 = "イベント・アラーム情報を更新します。(PUT時 versionは必須項目です。更新前の値をセットして下さい。)";
	public static final String MSG_DELETE_EVENT = "イベント・アラーム情報削除";
	public static final String MSG_DELETE_EVENT_01 = "イベント・アラーム情報を削除します。";

	public static final String MSG_GET_ROLE = "ロール情報取得";
	public static final String MSG_GET_ROLE_01 = "ロール情報を取得します。";
	public static final String MSG_GET_ROLE_ID = "ロール情報取得 (ID指定)";
	public static final String MSG_GET_ROLE_ID_01 = "ロール情報を取得します。(ID指定)";
	public static final String MSG_POST_ROLE = "ロール情報登録";
	public static final String MSG_POST_ROLE_01 = "ロール情報を登録します。";
	public static final String MSG_PUT_ROLE = "ロール情報更新";
	public static final String MSG_PUT_ROLE_01 = "ロール情報を更新します。(PUT時 versionは必須項目です。更新前の値をセットして下さい。)";
	public static final String MSG_DELETE_ROLE = "ロール情報削除";
	public static final String MSG_DELETE_ROLE_01 = "ロール情報を削除します。";


	public static final String MSG_GET_DEVICE_GROUP = "デバイスグループ情報取得";
	public static final String MSG_GET_DEVICE_GROUP_01 = "デバイスグループ情報を取得します。";
	public static final String MSG_GET_DEVICE_GROUP_ID = "デバイスグループ情報取得 (ID指定)";
	public static final String MSG_GET_DEVICE_GROUP_ID_01 = "デバイスグループ情報を取得します。 (ID指定)";
	public static final String MSG_POST_DEVICE_GROUP = "デバイスグループ情報登録";
	public static final String MSG_POST_DEVICE_GROUP_01 = "デバイスグループ情報を登録します。";
	public static final String MSG_PUT_DEVICE_GROUP = "デバイスグループ情報更新";
	public static final String MSG_PUT_DEVICE_GROUP_01 = "デバイスグループ情報を更新します。(PUT時 versionは必須項目です。更新前の値をセットして下さい。)";
	public static final String MSG_DELETE_DEVICE_GROUP = "デバイスグループ情報削除";
	public static final String MSG_DELETE_DEVICE_GROUP_01 = "デバイスグループ情報を削除します。";

	public static final String MSG_GET_GROUP_COMPOSITION_DEVICE = "グループ構成デバイス取得";
	public static final String MSG_GET_GROUP_COMPOSITION_DEVICE_01 = "グループ構成デバイスを取得します。";
	public static final String MSG_GET_GROUP_COMPOSITION_DEVICE_ID = "グループ構成デバイス取得 (ID指定)";
	public static final String MSG_GET_GROUP_COMPOSITION_DEVICE_ID_01 = "グループ構成デバイスを取得します。 (ID指定)";
	public static final String MSG_POST_GROUP_COMPOSITION_DEVICE = "グループ構成デバイス登録";
	public static final String MSG_POST_GROUP_COMPOSITION_DEVICE_01 = "グループ構成デバイスを登録します。";
	public static final String MSG_PUT_GROUP_COMPOSITION_DEVICE = "グループ構成デバイス更新";
	public static final String MSG_PUT_GROUP_COMPOSITION_DEVICE_01 = "グループ構成デバイスを更新します。(PUT時 versionは必須項目です。更新前の値をセットして下さい。)";
	public static final String MSG_DELETE_GROUP_COMPOSITION_DEVICE = "グループ構成デバイス削除";
	public static final String MSG_DELETE_GROUP_COMPOSITION_DEVICE_01 = "グループ構成デバイスを削除します。";

	public static final String MSG_GET_GROUP_COMPOSITION_EVENT = "グループ構成イベント取得";
	public static final String MSG_GET_GROUP_COMPOSITION_EVENT_01 = "グループ構成イベントを取得します。";
	public static final String MSG_GET_GROUP_COMPOSITION_EVENT_ID = "グループ構成イベント取得 (ID指定)";
	public static final String MSG_GET_GROUP_COMPOSITION_EVENT_ID_01 = "グループ構成イベントを取得します。 (ID指定)";
	public static final String MSG_POST_GROUP_COMPOSITION_EVENT = "グループ構成イベント登録";
	public static final String MSG_POST_GROUP_COMPOSITION_EVENT_01 = "グループ構成イベントを登録します。";
	public static final String MSG_PUT_GROUP_COMPOSITION_EVENT = "グループ構成イベント更新";
	public static final String MSG_PUT_GROUP_COMPOSITION_EVENT_01 = "グループ構成イベントを更新します。(PUT時 versionは必須項目です。更新前の値をセットして下さい。)";
	public static final String MSG_DELETE_GROUP_COMPOSITION_EVENT = "グループ構成イベント削除";
	public static final String MSG_DELETE_GROUP_COMPOSITION_EVENT_01 = "グループ構成イベントを削除します。";

	public static final String MSG_GET_BASE_DEVICE = "デバイスマスタ取得";
	public static final String MSG_GET_BASE_DEVICE_01 = "デバイスマスタを取得します。";
	public static final String MSG_GET_BASE_DEVICE_ID = "デバイスマスタ取得 (ID指定)";
	public static final String MSG_GET_BASE_DEVICE_ID_01 = "デバイスマスタを取得します。 (ID指定)";
	public static final String MSG_POST_BASE_DEVICE = "デバイスマスタ登録";
	public static final String MSG_POST_BASE_DEVICE_01 = "デバイスマスタを登録します。";
	public static final String MSG_PUT_BASE_DEVICE = "デバイスマスタ更新";
	public static final String MSG_PUT_BASE_DEVICE_01 = "デバイスマスタを更新します。(PUT時 versionは必須項目です。更新前の値をセットして下さい。)";
	public static final String MSG_DELETE_BASE_DEVICE = "デバイスマスタ削除";
	public static final String MSG_DELETE_BASE_DEVICE_01 = "デバイスマスタを削除します。";

	public static final String MSG_GET_BASE_SENSOR = "センサーマスタ取得";
	public static final String MSG_GET_BASE_SENSOR_01 = "センサーマスタを取得します。";
	public static final String MSG_GET_BASE_SENSOR_ID = "センサーマスタ取得 (ID指定)";
	public static final String MSG_GET_BASE_SENSOR_ID_01 = "センサーマスタを取得します。 (ID指定)";
	public static final String MSG_POST_BASE_SENSOR = "センサーマスタ登録";
	public static final String MSG_POST_BASE_SENSOR_01 = "センサーマスタを登録します。";
	public static final String MSG_PUT_BASE_SENSOR = "センサーマスタ更新";
	public static final String MSG_PUT_BASE_SENSOR_01 = "センサーマスタを更新します。(PUT時 versionは必須項目です。更新前の値をセットして下さい。)";
	public static final String MSG_DELETE_BASE_SENSOR = "センサーマスタ削除";
	public static final String MSG_DELETE_BASE_SENSOR_01 = "センサーマスタを削除します。";

	public static final String MSG_GET_BASE_DEVCONFIG = "デバイスコンフィグマスタ取得";
	public static final String MSG_GET_BASE_DEVCONFIG_01 = "イデバイスコンフィグマスタを取得します。";
	public static final String MSG_GET_BASE_DEVCONFIG_ID = "デバイスコンフィグマスタ取得 (ID指定)";
	public static final String MSG_GET_BASE_DEVCONFIG_ID_01 = "デバイスコンフィグマスタを取得します。 (ID指定)";
	public static final String MSG_POST_BASE_DEVCONFIG = "デバイスコンフィグマスタ登録";
	public static final String MSG_POST_BASE_DEVCONFIG_01 = "デバイスコンフィグマスタを登録します。";
	public static final String MSG_PUT_BASE_DEVCONFIG = "デバイスコンフィグマスタ更新";
	public static final String MSG_PUT_BASE_DEVCONFIG_01 = "デバイスコンフィグマスタを更新します。(PUT時 versionは必須項目です。更新前の値をセットして下さい。)";

	public static final String MSG_GET_DEVCONFIG = "デバイスコンフィグ情報取得";
	public static final String MSG_GET_DEVCONFIG_01 = "デバイスコンフィグ情報を取得します。";
	public static final String MSG_GET_DEVCONFIG_ID = "デバイスコンフィグ情報取得 (ID指定)";
	public static final String MSG_GET_DEVCONFIG_ID_01 = "デバイスコンフィグ情報を取得します。 (ID指定)";
	public static final String MSG_POST_DEVCONFIG = "デバイスコンフィグ情報登録";
	public static final String MSG_POST_DEVCONFIG_01 = "デバイスコンフィグ情報を登録します。";
	public static final String MSG_PUT_DEVCONFIG = "デバイスコンフィグ情報更新";
	public static final String MSG_PUT_DEVCONFIG_01 = "デバイスコンフィグ情報を更新します。(PUT時 versionは必須項目です。更新前の値をセットして下さい。)";

	public static final String MSG_GET_BASE_EVENT = "イベント・アラームマスタ取得";
	public static final String MSG_GET_BASE_EVENT_01 = "イベント・アラームマスタを取得します。";
	public static final String MSG_GET_BASE_EVENT_ID = "イベント・アラームマスタ取得 (ID指定)";
	public static final String MSG_GET_BASE_EVENT_ID_01 = "イベント・アラームマスタを取得します。 (ID指定)";
	public static final String MSG_POST_BASE_EVENT = "イベント・アラームマスタ登録";
	public static final String MSG_POST_BASE_EVENT_01 = "イベント・アラームマスタを登録します。";
	public static final String MSG_PUT_BASE_EVENT = "イベント・アラームマスタ更新";
	public static final String MSG_PUT_BASE_EVENT_01 = "イベント・アラームマスタを更新します。(PUT時 versionは必須項目です。更新前の値をセットして下さい。)";
	public static final String MSG_DELETE_BASE_EVENT = "イベント・アラームマスタ削除";
	public static final String MSG_DELETE_BASE_EVENT_01 = "イベント・アラームマスタを削除します。";

	public static final String MSG_GET_ROLE_ROOT_GROUP = " ロール・ルートグループ取得";
	public static final String MSG_GET_ROLE_ROOT_GROUP_01 = " ロール・ルートグループを取得します。";
	public static final String MSG_GET_ROLE_ROOT_GROUP_ID = " ロール・ルートグループ取得 (ID指定)";
	public static final String MSG_GET_ROLE_ROOT_GROUP_ID_01 = " ロール・ルートグループを取得します。 (ID指定)";
	public static final String MSG_POST_ROLE_ROOT_GROUP = " ロール・ルートグループ登録";
	public static final String MSG_POST_ROLE_ROOT_GROUP_01 = " ロール・ルートグループを登録します。";
	public static final String MSG_PUT_ROLE_ROOT_GROUP = " ロール・ルートグループ更新";
	public static final String MSG_PUT_ROLE_ROOT_GROUP_01 = " ロール・ルートグループを更新します。(PUT時 versionは必須項目です。更新前の値をセットして下さい。)";
	public static final String MSG_DELETE_ROLE_ROOT_GROUP = " ロール・ルートグループ削除";
	public static final String MSG_DELETE_ROLE_ROOT_GROUP_01 = " ロール・ルートグループを削除します。";

	public static final String MSG_GET_ROLE_DEVICE_GROUP = " ロール・デバイスグループ権限取得";
	public static final String MSG_GET_ROLE_DEVICE_GROUP_01 = " ロール・デバイスグループ権限を取得します。";
	public static final String MSG_GET_ROLE_DEVICE_GROUP_ID = " ロール・デバイスグループ権限取得 (ID指定)";
	public static final String MSG_GET_ROLE_DEVICE_GROUP_ID_01 = " ロール・デバイスグループ権限を取得します。 (ID指定)";
	public static final String MSG_POST_ROLE_DEVICE_GROUP = " ロール・デバイスグループ権限登録";
	public static final String MSG_POST_ROLE_DEVICE_GROUP_01 = " ロール・デバイスグループ権限を登録します。";
	public static final String MSG_PUT_ROLE_DEVICE_GROUP = " ロール・デバイスグループ権限更新";
	public static final String MSG_PUT_ROLE_DEVICE_GROUP_01 = " ロール・デバイスグループ権限を更新します。(PUT時 versionは必須項目です。更新前の値をセットして下さい。)";
	public static final String MSG_DELETE_ROLE_DEVICE_GROUP = " ロール・デバイスグループ権限削除";
	public static final String MSG_DELETE_ROLE_DEVICE_GROUP_01 = " ロール・デバイスグループ権限を削除します。";

	public static final String MSG_GET_DEVICE_GROUP_STRUCTURE = "デバイスグループ階層情報取得";
	public static final String MSG_GET_DEVICE_GROUP_STRUCTURE_01 = "デバイスグループ階層情報を取得します。";
	public static final String MSG_GET_DEVICE_GROUP_DEVICE = "指定デバイスグループ下デバイス取得";
	public static final String MSG_GET_DEVICE_GROUP_DEVICE_01 = "指定デバイスグループ下デバイスを取得します。";
	public static final String MSG_GET_DEVICE_STRUCTURE = "デバイス階層情報取得";
	public static final String MSG_GET_DEVICE_STRUCTURE_01 = "デバイス階層情報を取得します。";
	public static final String MSG_GET_DEVICE_SENSOR = "デバイス下センサ情報取得";
	public static final String MSG_GET_DEVICE_SENSOR_01 = "デバイス下センサ情報を取得します。";

	public static final String MSG_SENSOR_DATA = "センサーデータ取得";
	public static final String MSG_SENSOR_DATA_01 = "センサーデータを取得します。検索結果を間引きする場合、検索区分:1、  データ丸め区分:1(丸めあり）、最大件数:n（出力の最大件数）を指定します。最新からｎ件取得する場合は、検索区分:1、 ソート順: -measureTime(計測時刻の降順) 、最大件数:n（出力の最大件数）を指定します。";
	public static final String MSG_LATEST_SENSOR_DATA = "センサー最新値取得";
	public static final String MSG_LATEST_SENSOR_DATA_01 = "センサー最新値を取得します。";
	public static final String MSG_SENSOR_FILE = "センサーファイル情報取得";
	public static final String MSG_SENSOR_FILE_01 = "センサーファイル情報を取得します。";
	public static final String MSG_LATEST_SENSOR_FILE = "最新センサーファイル情報取得";
	public static final String MSG_LATEST_SENSOR_FILE_01 = "最新センサーファイル情報を取得します。";
	public static final String MSG_DEL_SENSOR_DATA = "センサーデータ削除";
	public static final String MSG_DEL_SENSOR_DATA_01 = "センサーデータを削除します。";
	public static final String MSG_GET_FILE = "ファイル取得";
	public static final String MSG_GET_FILE_01 = "ファイルを取得します。(Response の Content-Type : application/octet-stream (200返却時)、application/json (それ以外の場合))";
	public static final String MSG_POST_FILE = "ファイル登録";
	public static final String MSG_POST_FILE_01 = "ファイルを登録します。 ※ファイルに登録するデータがバイナリの時は、base64でエンコードした値をファイルデータにセットし、かつ base64フラグにtrueをセットして下さい。";
	public static final String MSG_POST_MEASURE_FILE = "画像・音ファイル等登録";
	public static final String MSG_POST_MEASURE_FILE_01 = "画像・音ファイル等を登録します。";
	public static final String MSG_POST_EXPANSION_FILE = "展開用ファイル登録";
	public static final String MSG_POST_EXPANSION_FILE_01 = "展開用ファイルを登録します。";

	public static final String MSG_SEARCH_EVENT_HISTORY = "イベント・アラーム履歴検索";
	public static final String MSG_SEARCH_EVENT_HISTORY_01 = "各イベント・アラームの発生・復帰履歴を取得するためのAPIです。最新の状態のみを参照したい場合は「イベント・アラーム状態取得」APIを参照してください。"
														        + " ※１・デバイスグループID 指定時、 [配列]デバイスリスト、 [配列]イベントリスト は指定不可。"
														        + " ※２・[配列]デバイスリスト指定時、デバイスグループID 、 [配列]イベントリスト は指定不可。"
													            + " ※３・[配列]イベントリスト指定時、 [配列]デバイスリスト、デバイスグループID は指定不可。";

	public static final String MSG_GET_EVENT_STATUS = "イベント・アラーム状態取得";
	public static final String MSG_GET_EVENT_STATUS_01 = "各イベント・アラームの最新の状態を取得するためのAPIです。過去の発生・復帰の履歴を参照したい場合は「イベント・アラーム履歴検索」APIを参照してください。"
                                        			        + " ※１・デバイスグループID 指定時、 [配列]デバイスリスト、 [配列]イベントリスト は指定不可。"
		  		                                            + " ※２・[配列]デバイスリスト指定時、デバイスグループID 、 [配列]イベントリスト は指定不可。"
		        	                                        + " ※３・[配列]イベントリスト指定時、 [配列]デバイスリスト、デバイスグループID は指定不可。";
	public static final String MSG_GET_DEVICE_GROUP_ALARM_STATUS = "デバイスグループアラーム状態取得";
	public static final String MSG_GET_DEVICE_GROUP_ALARM_STATUS_01 = "デバイスグループアラーム状態を取得します。";
	public static final String MSG_GET_DEVICE_ALARM_STATUS = "デバイスアラーム状態取得";
	public static final String MSG_GET_DEVICE_ALARM_STATUS_01 = "デバイスアラーム状態を取得します。";
	public static final String MSG_PUT_STATUS = "イベント・アラーム ステータス管理";
	public static final String MSG_PUT_STATUS_01 = "イベント・アラーム状態管理を更新します。";
	public static final String MSG_POST_STD_EVENT = "イベント・アラーム登録";
	public static final String MSG_POST_STD_EVENT_01 = "イベント・アラームを登録します。";

	public static final String MSG_GET_USER_DEVICE_GROUP_AUTHORITY = "ユーザ・デバイスグループ権限情報取得";
	public static final String MSG_GET_USER_DEVICE_GROUP_AUTHORITY_01 = "ユーザ・デバイスグループ権限情報を取得します。";

	public static final String MSG_GET_USER_DEVICE_AUTHORITY = "ユーザ・デバイス権限情報取得";
	public static final String MSG_GET_USER_DEVICE_AUTHORITY_01 = "ユーザ・デバイス権限情報を取得します。";

	public static final String MSG_PUT_USER_BASE_DEVICE_AUTHORITY = "Put user base device authority information";
	public static final String MSG_PUT_USER_BASE_DEVICE_AUTHORITY_01 = "Put user base device authority information";
	public static final String MSG_POST_USER_BASE_DEVICE_AUTHORITY = "Post user base device authority information";
	public static final String MSG_POST_USER_BASE_DEVICE_AUTHORITY_01 = "Post user base device authority information";
	public static final String MSG_GET_USER_BASE_DEVICE_AUTHORITY = "Get user base device authority information";
	public static final String MSG_GET_USER_BASE_DEVICE_AUTHORITY_01 = "Get user base device authority information";

	public static final String MSG_GET_USER_SENSOR_AUTHORITY = "ユーザ・センサー権限情報取得";
	public static final String MSG_GET_USER_SENSOR_AUTHORITY_01 = "ユーザ・センサー権限情報を取得します。";

	public static final String MSG_GET_USER_EVENT_AUTHORITY = "ユーザ・イベント権限情報取得";
	public static final String MSG_GET_USER_EVENT_AUTHORITY_01 = "ユーザ・イベント権限情報を取得します。";

	public static final String MSG_GET_USER_PROGRAM_AUTHORITY = "ユーザ・プログラム権限情報取得";
	public static final String MSG_GET_USER_PROGRAM_AUTHORITY_01 = "ユーザ・プログラム権限情報を取得します。";

	public static final String MSG_DEVICE_OPERATIONS = "デバイスへの送信";
	public static final String MSG_POST_OPEINSTRUCT = "GWへのコマンド実行依頼";
	public static final String MSG_POST_OPEINSTRUCT_01 = "GWへのコマンド実行依頼を指示します。"
	                                                       + " ※１・GWからの応答待ち時間のデフォルトは３０秒です。変更する場合は wait_time を指定してください。"
	                                                       + " ※２・GWではコマンドを即時実行します。GWでの実行時刻を指定する場合は exec_time (日時指定の時:yyyyMMddHHmmss 時刻のみ指定時(日付未指定):HHmmss) を指定してください。";

	public static final String MSG_POST_FILE_INFO_NOTIFICATION = "GWへのファイル情報通知";
	public static final String MSG_POST_FILE_INFO_NOTIFICATION_01 = "指定コンテナ下にBlobファイルを登録し、登録したファイルの情報をGWに通知します。"
	                                                                  + " ※ファイルに登録するデータがバイナリの時は、base64でエンコードした値をファイルデータにセットし、かつ base64フラグにtrueをセットして下さい。";

	public static final String REQUEST_URL_SORT_KEY = "sort";
	public static final String REQUEST_URL_FIELDS_KEY = "fields";

	public static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
	public static final String DATE_FORMAT1 = "yyyyMMddHHmmss";
	public static final String DATETIME_FORMAT_NANO = "yyyy-MM-dd HH:mm:ss.SSSSSSS";

	public static final String COMMA = ",";
	public static final String SPACE = " ";
	public static final String AND = "&";
	public static final String LINE_SEPARATOR = "\r\n";
	public static final String DELIMITER = "/";
	public static final String EXTENSION_CSV = ".csv";
	public static final String EXTENSION_AVRO = ".avro";
	public static final String MEASURE_TIME_FORMAT_HOUR = "%07d";
	public static final String MEASURE_TIME_FORMAT_DAY = "%09d";
	public static final String DEVICE_SEPARATOR = "$";		// 機種IDとシリアルNoの区切り文字

	/****************************
	 * 検索区分
	 ****************************/
	public static final String KBN_SEARCH_1 = "1";
	public static final String KBN_SEARCH_2 = "2";

	/****************************
	 * 範囲検索用パラメータ
	 ****************************/
	public static final String PARAMETER_KBN_RAW = "1";
	public static final String PARAMETER_KBN_HOUR = "2";
	public static final String PARAMETER_KBN_DAY = "3";
	public static final String PARAMETER_KBN_BLOB = "4";
	public static final String PARAMETER_KBN_MONTH = "5";

	/****************************
	 * センサ情報のデータ区分
	 ****************************/
	public static final String DATA_TYPE_INT = "int";
	public static final String DATA_TYPE_REAL = "real";
	public static final String DATA_TYPE_STAT = "stat";
	public static final String DATA_TYPE_LONG = "long";
	public static final String DATA_TYPE_FLOAT = "float";
	public static final String DATA_TYPE_BIT = "bit";

	/****************************
	 * ファイル種別
	 ****************************/
	public static final String FILE_TYPE_1 = "1";
	public static final String FILE_TYPE_2 = "2";
	public static final String FILE_TYPE_9 = "9";

	/****************************
	 * 計測タイプ
	 ****************************/
	// 1:データ
	public static final char MEASURE_TYPE_1 = '1';
	// 2:ファイル
	public static final char MEASURE_TYPE_2 = '2';

	/****************************
	 * ソート「センサーデータ取得」
	 ****************************/
	public static final String SORT_SS_DATA_ASC = "measureTime";
	public static final String SORT_SS_DATA_DESC = "-measureTime";

	/****************************
	 * 検出区分
	 ****************************/
	public static final String DETECTION_CLASS_5 = "5";

	/****************************
	 * サービスバスキュー
	 ****************************/
	public static final String SERVICE_BUS_QUEUE_EVENT = "event";

	/****************************
	 * 発生復帰区分
	 ****************************/
	public static final String INCIDENT_CLASS_3 = "3";

	/****************************
	 * 取得情報区分
	 ****************************/
	public static final String GET_INFO_CLASS_KBN_1 = "1";

	/****************************
	 * 比較区分
	 ****************************/
	public static final String COMPARE_CLASS_1 = "1";

	/****************************
	 * 月別Blob
	 ****************************/
	//AvroファイルSchema
	public static final String MONTH_BLOB_SCHEMA = "{ \"type\":\"array\", \"items\":\"string\" }";
	//Avroファイルの行数
	public static final int BLOB_LINE = 31;
	/****************************************************
	 * システムの設定情報テーブル（mst_system_info）
	 ****************************************************/
	// システム日時
	public static final String KEY_DATA_NOW = "Now";
	// 時間別移行待機時間
	public static final String KEY_DATA_HOUR_WAIT = "DataHourMigrateWaite";
	// 日別Blob移行待機日数
	public static final String KEY_DATA_BLOB_WAIT = "DataBlobMigrateWaite";
	// 日別Blob移行待機日数２
	public static final String KEY_DATA_BLOB_WAIT2 = "DataBlobMigrateWaite2";

	/****************************
	 * デバイスツイン用
	 ****************************/
	// タグ セクション
	public static final String DT_MODEL_ID = "modelId";
	public static final String DT_SERIAL_NO = "serialNo";
	public static final String DT_DEVICE_TYPE = "deviceType";
	public static final String DT_CONNECT_MAIL_FLG = "connectMailFlg";
	// 必要なプロパティ セクション
	public static final String DT_APP_REGIST_FLG = "appRegistFlg";
	public static final String DT_DEVICE_MODE = "deviceMode";
	// 報告されるプロパティ セクション
	public static final String DT_DEVICE_STATUS = "deviceStatus";
	public static final String DT_ALIVE_TIME = "aliveTime";

	/****************************
	 * テーブル名
	 ****************************/
	public static final String TABLE_MEASURE_DATA = "measuredData";
	// 時間別計測データ
	//public static final String TABLE_HH_DATA = "devHHData";
	public static final String TABLE_HH_DATA = "hourlyData";
	// ｢降順｣時間別計測データ
	public static final String TABLE_HH_DATA_DESC = "devHHDataDesc";
	// 日別計測データ
	public static final String TABLE_DAY_DATA = "devDayData";
	// ｢降順｣日別計測データ
	public static final String TABLE_DAY_DATA_DESC = "devDayDataDesc";
	// 日付別Blobファイル
	public static final String BLOB_FILE = "monthlydata";
	// 計測ファイル
	public static final String BLOB_MEASURE_FILE = "measurefile";
	// 展開用ファイル
	public static final String BLOB_EXPANSION = "expansion";
	//受信ファイル
	public static final String BLOB_RECEIVEFILE = "receivefile";
	// PartitionKey
	public static final String PARTITION_KEY = "PartitionKey";
	// RowKey
	public static final String ROW_KEY = "RowKey";
	public static final String ROW_KEY_00 = "_00";
	public static final String ROW_KEY_99 = "_99";

	public static final String FOLDER_MEASURE_DATA = "measuredData";




	/****************************
	 * 応答コード
	 ****************************/
	public static final int HTTP_CODE_200 = 200;
	public static final int HTTP_CODE_201 = 201;
	public static final int HTTP_CODE_400 = 400;
	public static final int HTTP_CODE_401 = 401;
	public static final int HTTP_CODE_403 = 403;
	public static final int HTTP_CODE_404 = 404;
	public static final int HTTP_CODE_405 = 405;
	public static final int HTTP_CODE_408 = 408;
	public static final int HTTP_CODE_409 = 409;
	public static final int HTTP_CODE_500 = 500;
	public static final int HTTP_CODE_503 = 503;

	public static final String HTTP_MESSAGE_200 = "OK";
	public static final String HTTP_MESSAGE_201 = "Created";
	public static final String HTTP_MESSAGE_400 = "Bad Request";
	public static final String HTTP_MESSAGE_401 = "Unauthorized";
	public static final String HTTP_MESSAGE_403 = "Forbidden";
	public static final String HTTP_MESSAGE_404 = "Not Found";
	public static final String HTTP_MESSAGE_405 = "Method Not Allowed";
	public static final String HTTP_MESSAGE_408 = "Request Time-out";
	public static final String HTTP_MESSAGE_409 = "Conflicted";
	public static final String HTTP_MESSAGE_500 = "Internal Server Error";
	public static final String HTTP_MESSAGE_503 = "Service Unavailable";

	/****************************
	 * エラーフラグ
	 ****************************/
	public static final boolean ERROR = true;
	public static final boolean NO_ERROR = false;

	/*******************************
	 * エラーメッセージ
	 *******************************/
	public static final String MESSAGE_E000001 = "E000001";
	public static final String MESSAGE_E000011 = "E000011";
	public static final String MESSAGE_E000012 = "E000012";
	public static final String MESSAGE_E000013 = "E000013";
	public static final String MESSAGE_E000014 = "E000014";
	public static final String MESSAGE_E000015 = "E000015";
	public static final String MESSAGE_E000017 = "E000017";
	public static final String MESSAGE_E000018 = "E000018";
	public static final String MESSAGE_E000019 = "E000019";
	public static final String MESSAGE_E000021 = "E000021";
	public static final String MESSAGE_E000022 = "E000022";
	public static final String MESSAGE_E000023 = "E000023";
	public static final String MESSAGE_E000024 = "E000024";
	public static final String MESSAGE_E000025 = "E000025";
	public static final String MESSAGE_E000031 = "E000031";
	public static final String MESSAGE_E000032 = "E000032";
	public static final String MESSAGE_E000033 = "E000033";
	public static final String MESSAGE_E000034 = "E000034";
	public static final String MESSAGE_E000041 = "E000041";
	public static final String MESSAGE_E000042 = "E000042";
	public static final String MESSAGE_E000043 = "E000043";
	public static final String MESSAGE_E000044 = "E000044";
	public static final String MESSAGE_E000045 = "E000045";
	public static final String MESSAGE_E000046 = "E000046";
	public static final String MESSAGE_E000047 = "E000047";
	public static final String MESSAGE_E000048 = "E000048";
	public static final String MESSAGE_E000049 = "E000049";
	public static final String MESSAGE_E000050 = "E000050";
	public static final String MESSAGE_E000051 = "E000051";
	public static final String MESSAGE_E000052 = "E000052";
	public static final String MESSAGE_E000053 = "E000053";
	public static final String MESSAGE_E000054 = "E000054";
	public static final String MESSAGE_E000055 = "E000055";
	public static final String MESSAGE_E000056 = "E000056";

	public static final String MESSAGE_E000101 = "E000101";
	public static final String MESSAGE_E000102 = "E000102";
	public static final String MESSAGE_E000103 = "E000103";
	public static final String MESSAGE_E000104 = "E000104";
	public static final String MESSAGE_E000105 = "E000105";
	public static final String MESSAGE_E000106 = "E000106";
	public static final String MESSAGE_E000107 = "E000107";
	public static final String MESSAGE_E000108 = "E000108";
	public static final String MESSAGE_E000109 = "E000109";
	public static final String MESSAGE_E000110 = "E000110";
	public static final String MESSAGE_E000111 = "E000111";
	public static final String MESSAGE_E000112 = "E000112";
	public static final String MESSAGE_E000113 = "E000113";
	public static final String MESSAGE_E000114 = "E000114";
	public static final String MESSAGE_E000115 = "E000115";
	public static final String MESSAGE_E000116 = "E000116";
	public static final String MESSAGE_E000117 = "E000117";
	public static final String MESSAGE_E000118 = "E000118";
	public static final String MESSAGE_E000119 = "E000119";
	public static final String MESSAGE_E000120 = "E000120";
	public static final String MESSAGE_E000121 = "E000121";
	public static final String MESSAGE_E000122 = "E000122";
	public static final String MESSAGE_E000123 = "E000123";
	public static final String MESSAGE_E000124 = "E000124";
	public static final String MESSAGE_E000125 = "E000125";
	public static final String MESSAGE_E000126 = "E000126";
	public static final String MESSAGE_E000127 = "E000127";
	public static final String MESSAGE_E000128 = "E000128";
	public static final String MESSAGE_E000129 = "E000129";
	public static final String MESSAGE_E000130 = "E000130";
	public static final String MESSAGE_E000131 = "E000131";

	public static final String MESSAGE_TARGET_PERIOD_FROM = "target.period.from";
	public static final String MESSAGE_TARGET_PERIOD_TO = "target.period.to";
	public static final String MESSAGE_EVENT_TIME_FROM = "event.time.from";
	public static final String MESSAGE_EVENT_TIME_TO = "event.time.to";
	public static final String MESSAGE_SYSTEM_DATETIME = "system.datetime";
	public static final String MESSAGE_MST_DEVICE_GROUP = "message.deviceGroup";

	// Azure FunctionからAPIを呼び出した場合に割り当てるユーザID
	public static final String FUNCTION_USER_ID = "##@ Azure Application @##";

    /****************************
     * ログレベル
     ****************************/
    public static final int LOG_INFO_LEVEL = 1;
    public static final int LOG_WARN_LEVEL = 2;
    public static final int LOG_ERROR_LEVEL = 3;
}
