package com.app.model;

/**
 * NotFoundエラーモデルクラス
 * @author（TOSCO）ウェイ
 */
public class NotFoundErrorModel {

    // エラーキー
    public String notFound;

    public NotFoundErrorModel(String notFound) {
        this.notFound = notFound;
    }
}
