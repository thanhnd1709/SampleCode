package com.app.repository;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.app.entity.MstRollEntity;
import com.app.model.RollQueryModel;

public interface RoleRepositoryCustom {
	List<MstRollEntity> findAll(RollQueryModel query, List<String> sort, Integer limit, Integer offset);
	Long countAll(RollQueryModel query);
	Boolean isSystemAdmin(String user_id);
	Boolean isRoleExist(String role_id);
	Boolean  hasAuthorityByRoleId(String userId, String roleId);
    MstRollEntity findOneForUpdate(@Param("id") int id);
}