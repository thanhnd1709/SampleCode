package com.app.repository;

import org.springframework.data.repository.query.Param;

import com.app.entity.StdGwCommandHistoryEntity;

public interface GWCommandHistoryRepositoryCustom {
    StdGwCommandHistoryEntity findOneForUpdate(@Param("id") int id);
}