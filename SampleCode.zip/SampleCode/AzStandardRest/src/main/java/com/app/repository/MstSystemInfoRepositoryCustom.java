package com.app.repository;

import java.util.List;

import com.app.entity.MstSystemInfoEntity;

/**
 * システムの設定情報リポジトリクラス
 * @author（TOSCO）ウェイ
 */
public interface MstSystemInfoRepositoryCustom{

	/**
	 * システムの設定情報取得処理を行います。
	 * @return システムの設定情報
	 */
	List<MstSystemInfoEntity> search() throws Exception;

}
