package com.app.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 計測データモデルクラス
 * @author（TOSCO）ウェイ
 */
@Data
public class ResponseMeasureDataModel {

	@ApiModelProperty(value = "計測時刻")
	private String measureTime;
	@ApiModelProperty(value = "計測値")
	private String data;

	public ResponseMeasureDataModel(String measureTime, String data){
		this.measureTime = measureTime;
		this.data = data;
	}
}
