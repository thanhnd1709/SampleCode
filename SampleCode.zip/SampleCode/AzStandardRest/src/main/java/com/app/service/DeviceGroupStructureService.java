package com.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.entity.DeviceGroupStructureEntity;
import com.app.model.DeviceGroupStructureModel;
import com.app.model.ResponseDeviceGroupStructureModel;
import com.app.repository.DeviceGroupStructureRepositoryCustom;

@Service
@Transactional(readOnly = true)
public class DeviceGroupStructureService {

	@Autowired
	private DeviceGroupStructureRepositoryCustom deviceGroupStructureRepositoryCustom;

	/**
	 * デバイスグループ階層情報取得サービスクラス
	 * @return デバイスグループ階層情報リスト
	 */
	public List<ResponseDeviceGroupStructureModel> getDeviceGroupStructure(DeviceGroupStructureModel reqModel) throws Exception {

		List<ResponseDeviceGroupStructureModel> lstDeviceGroupStructure = new ArrayList<>();

		List<DeviceGroupStructureEntity> deviceGroupStructureEntitylist = new ArrayList<DeviceGroupStructureEntity>();

		// 取得フィールド処理
		ModelFilter mf = makeModelFilter(reqModel.getFields());

		String sort = null;
		if (reqModel.getSort() != null) {
			for (String item : reqModel.getSort().split(",")) {
				if (sort != null) {
					sort = ",";
				} else
					sort = "";
				if (item.startsWith("-")) {
					if (item.equalsIgnoreCase("-device_group_structure")) sort += (item.toLowerCase().replace("-device_group_structure", "parent_device_group_list")) + " DESC";
					else
						sort += (item.toLowerCase().replace("-", "")) + " DESC";
				} else {
					if (item.equalsIgnoreCase("device_group_structure")) sort += item.toLowerCase().replace("device_group_structure", "parent_device_group_list");
					else
						sort += item.toLowerCase();
				}
			}
		}

		// ページング処理
		Integer limit = null;
		Integer offset = null;
		if (reqModel.getPage() != null && reqModel.getLimit() != null) {
			limit = Integer.parseInt(reqModel.getLimit());
			offset = (Integer.parseInt(reqModel.getPage()) - 1) * limit;
		}

		deviceGroupStructureEntitylist = deviceGroupStructureRepositoryCustom.getDeviceGroupStructure(reqModel, sort, limit, offset);

		if (deviceGroupStructureEntitylist.size() > 0) {
				for (DeviceGroupStructureEntity dgsEntity : deviceGroupStructureEntitylist) {
				ResponseDeviceGroupStructureModel newModel = new ResponseDeviceGroupStructureModel();
				if (mf.device_group_structure) newModel.setDevice_group_structure(dgsEntity.getParent_device_group_list());
				if (mf.level) newModel.setLevel(Integer.parseInt(dgsEntity.getLevel()));
				if (mf.device_group_id) newModel.setDevice_group_id(dgsEntity.getDevice_group_id());
				lstDeviceGroupStructure.add(newModel);
			}
		}
		return lstDeviceGroupStructure;
	}

	private ModelFilter makeModelFilter(String fields) {
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if ("device_group_structure".equals(str))
					mf.device_group_structure = true;
				if ("level".equals(str))
					mf.level = true;
				if ("device_group_id".equals(str))
					mf.device_group_id = true;
			}
		}
		return mf;
	}

	class ModelFilter {
		public ModelFilter(boolean b) {
			device_group_structure = b;
			level = b;
			device_group_id = b;
		}

		public boolean device_group_structure;
		public boolean level;
		public boolean device_group_id;
	}
}

