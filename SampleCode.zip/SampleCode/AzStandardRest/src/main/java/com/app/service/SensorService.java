package com.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.common.utils.DateTimeUtil;
import com.app.entity.MstSensorEntity;
import com.app.exception.DataNotFoundException;
import com.app.exception.LockingFailureException;
import com.app.model.SensorModel;
import com.app.model.SensorQueryModel;
import com.app.repository.SensorRepository;
import com.app.repository.SensorRepositoryCustom;

@Service
@Transactional(readOnly = true)
public class SensorService {
	@Autowired
	private SensorRepository sensorRepository;
	@Autowired
	private SensorRepositoryCustom sensorRepositoryCustom;

	public SensorModel findOne(int uuid, String fields) throws Exception{
		ModelFilter mf = makeModelFilter(fields);

		MstSensorEntity entity = sensorRepository.findOne(uuid);
		SensorModel newModel = null;
		if (entity != null) {
			newModel = new SensorModel();
			if (mf.id) newModel.setId(entity.getId());
			if (mf.model_id) newModel.setModel_id(entity.getModel_id());
			if (mf.serial_no) newModel.setSerial_no(entity.getSerial_no());
			if (mf.sensor_id) newModel.setSensor_id(entity.getSensor_id());
			if (mf.sensor_type) newModel.setSensor_type(entity.getSensor_type());
			if (mf.name_locale1) newModel.setName_locale1(entity.getName_locale1());
			if (mf.name_locale2) newModel.setName_locale2(entity.getName_locale2());
			if (mf.name_locale3) newModel.setName_locale3(entity.getName_locale3());
			if (mf.unit_locale1) newModel.setUnit_locale1(entity.getUnit_locale1());
			if (mf.unit_locale2) newModel.setUnit_locale2(entity.getUnit_locale2());
			if (mf.unit_locale3) newModel.setUnit_locale3(entity.getUnit_locale3());
			if (mf.transform_locale1) newModel.setTransform_locale1(entity.getTransform_locale1());
			if (mf.transform_locale2) newModel.setTransform_locale2(entity.getTransform_locale2());
			if (mf.transform_locale3) newModel.setTransform_locale3(entity.getTransform_locale3());
			if (mf.decimal_num_locale1) newModel.setDecimal_num_locale1(entity.getDecimal_num_locale1());
			if (mf.decimal_num_locale2) newModel.setDecimal_num_locale2(entity.getDecimal_num_locale2());
			if (mf.decimal_num_locale3) newModel.setDecimal_num_locale3(entity.getDecimal_num_locale3());
			if (mf.max_value_locale1) newModel.setMax_value_locale1(entity.getMax_value_locale1());
			if (mf.max_value_locale2) newModel.setMax_value_locale2(entity.getMax_value_locale2());
			if (mf.max_value_locale3) newModel.setMax_value_locale3(entity.getMax_value_locale3());
			if (mf.min_value_locale1) newModel.setMin_value_locale1(entity.getMin_value_locale1());
			if (mf.min_value_locale2) newModel.setMin_value_locale2(entity.getMin_value_locale2());
			if (mf.min_value_locale3) newModel.setMin_value_locale3(entity.getMin_value_locale3());
			if (mf.description_locale1) newModel.setDescription_locale1(entity.getDescription_locale1());
			if (mf.description_locale2) newModel.setDescription_locale2(entity.getDescription_locale2());
			if (mf.description_locale3) newModel.setDescription_locale3(entity.getDescription_locale3());
			if (mf.measure_type) newModel.setMeasure_type(entity.getMeasure_type());
			if (mf.data_type) newModel.setData_type(entity.getData_type());
			if (mf.fixed_length) newModel.setFixed_length(entity.getFixed_length());
			if (mf.time_data_create_flg) newModel.setTime_data_create_flg(entity.getTime_data_create_flg());
			if (mf.short_term_minutes) newModel.setShort_term_minutes(entity.getShort_term_minutes());
			if (mf.note) newModel.setNote(entity.getNote());
			if (mf.version) newModel.setVersion(entity.getVersion());
			if (mf.inserted) newModel.setInserted(entity.getInserted());
			if (mf.insert_time) newModel.setInsert_time(DateTimeUtil.formatTimestamp(entity.getInsert_time()));
			if (mf.updated) newModel.setUpdated(entity.getUpdated());
			if (mf.update_time) newModel.setUpdate_time(DateTimeUtil.formatTimestamp(entity.getUpdate_time()));
		}
		return  newModel;
	}

	public List<SensorModel> findAll(SensorQueryModel filter) throws Exception{

		ModelFilter mf = makeModelFilter(filter.getFields());

		List<String> sort = new ArrayList<String>();
		if (filter.getSort() != null) {
			for (String item : filter.getSort().split(",")) {
				sort.add(item.trim().toLowerCase());
			}
		}

		Integer limit = null;
		Integer offset = null;
		if (filter.getPage() != null && filter.getLimit() != null) {
			limit = Integer.parseInt(filter.getLimit());
			offset = (Integer.parseInt(filter.getPage()) - 1) * limit;
		}

		List<MstSensorEntity> entList = sensorRepositoryCustom.findAll(filter, sort, limit, offset);
		List<SensorModel> modelList = new ArrayList<SensorModel>();
		for (MstSensorEntity entity : entList) {
			SensorModel newModel = new SensorModel();
			if (mf.id) newModel.setId(entity.getId());
			if (mf.model_id) newModel.setModel_id(entity.getModel_id());
			if (mf.serial_no) newModel.setSerial_no(entity.getSerial_no());
			if (mf.sensor_id) newModel.setSensor_id(entity.getSensor_id());
			if (mf.sensor_type) newModel.setSensor_type(entity.getSensor_type());
			if (mf.name_locale1) newModel.setName_locale1(entity.getName_locale1());
			if (mf.name_locale2) newModel.setName_locale2(entity.getName_locale2());
			if (mf.name_locale3) newModel.setName_locale3(entity.getName_locale3());
			if (mf.unit_locale1) newModel.setUnit_locale1(entity.getUnit_locale1());
			if (mf.unit_locale2) newModel.setUnit_locale2(entity.getUnit_locale2());
			if (mf.unit_locale3) newModel.setUnit_locale3(entity.getUnit_locale3());
			if (mf.transform_locale1) newModel.setTransform_locale1(entity.getTransform_locale1());
			if (mf.transform_locale2) newModel.setTransform_locale2(entity.getTransform_locale2());
			if (mf.transform_locale3) newModel.setTransform_locale3(entity.getTransform_locale3());
			if (mf.decimal_num_locale1) newModel.setDecimal_num_locale1(entity.getDecimal_num_locale1());
			if (mf.decimal_num_locale2) newModel.setDecimal_num_locale2(entity.getDecimal_num_locale2());
			if (mf.decimal_num_locale3) newModel.setDecimal_num_locale3(entity.getDecimal_num_locale3());
			if (mf.max_value_locale1) newModel.setMax_value_locale1(entity.getMax_value_locale1());
			if (mf.max_value_locale2) newModel.setMax_value_locale2(entity.getMax_value_locale2());
			if (mf.max_value_locale3) newModel.setMax_value_locale3(entity.getMax_value_locale3());
			if (mf.min_value_locale1) newModel.setMin_value_locale1(entity.getMin_value_locale1());
			if (mf.min_value_locale2) newModel.setMin_value_locale2(entity.getMin_value_locale2());
			if (mf.min_value_locale3) newModel.setMin_value_locale3(entity.getMin_value_locale3());
			if (mf.description_locale1) newModel.setDescription_locale1(entity.getDescription_locale1());
			if (mf.description_locale2) newModel.setDescription_locale2(entity.getDescription_locale2());
			if (mf.description_locale3) newModel.setDescription_locale3(entity.getDescription_locale3());
			if (mf.measure_type) newModel.setMeasure_type(entity.getMeasure_type());
			if (mf.data_type) newModel.setData_type(entity.getData_type());
			if (mf.fixed_length) newModel.setFixed_length(entity.getFixed_length());
			if (mf.time_data_create_flg) newModel.setTime_data_create_flg(entity.getTime_data_create_flg());
			if (mf.short_term_minutes) newModel.setShort_term_minutes(entity.getShort_term_minutes());
			if (mf.note) newModel.setNote(entity.getNote());
			if (mf.version) newModel.setVersion(entity.getVersion());
			if (mf.inserted) newModel.setInserted(entity.getInserted());
			if (mf.insert_time) newModel.setInsert_time(DateTimeUtil.formatTimestamp(entity.getInsert_time()));
			if (mf.updated) newModel.setUpdated(entity.getUpdated());
			if (mf.update_time) newModel.setUpdate_time(DateTimeUtil.formatTimestamp(entity.getUpdate_time()));
			modelList.add(newModel);
		}
		return modelList;
	}

	public Long countAll(SensorQueryModel filter) throws Exception{
		return sensorRepositoryCustom.countAll(filter);
	}

	@Transactional(readOnly = false)
	public SensorModel save(SensorModel model) throws Exception{

		MstSensorEntity newRec = new MstSensorEntity();

		if (model.getModel_id() != null) newRec.setModel_id(model.getModel_id());
		if (model.getSerial_no() != null) newRec.setSerial_no(model.getSerial_no());
		if (model.getSensor_id() != null) newRec.setSensor_id(model.getSensor_id());
		if (model.getSensor_type() != null) newRec.setSensor_type(model.getSensor_type());
		if (model.getName_locale1() != null) newRec.setName_locale1(model.getName_locale1());
		if (model.getName_locale2() != null) newRec.setName_locale2(model.getName_locale2());
		if (model.getName_locale3() != null) newRec.setName_locale3(model.getName_locale3());
		if (model.getUnit_locale1() != null) newRec.setUnit_locale1(model.getUnit_locale1());
		if (model.getUnit_locale2() != null) newRec.setUnit_locale2(model.getUnit_locale2());
		if (model.getUnit_locale3() != null) newRec.setUnit_locale3(model.getUnit_locale3());
		if (model.getTransform_locale1() != null) newRec.setTransform_locale1(model.getTransform_locale1());
		if (model.getTransform_locale2() != null) newRec.setTransform_locale2(model.getTransform_locale2());
		if (model.getTransform_locale3() != null) newRec.setTransform_locale3(model.getTransform_locale3());
		if (model.getDecimal_num_locale1() != null) newRec.setDecimal_num_locale1(model.getDecimal_num_locale1());
		if (model.getDecimal_num_locale2() != null) newRec.setDecimal_num_locale2(model.getDecimal_num_locale2());
		if (model.getDecimal_num_locale3() != null) newRec.setDecimal_num_locale3(model.getDecimal_num_locale3());
		if (model.getMax_value_locale1() != null) newRec.setMax_value_locale1(model.getMax_value_locale1());
		if (model.getMax_value_locale2() != null) newRec.setMax_value_locale2(model.getMax_value_locale2());
		if (model.getMax_value_locale3() != null) newRec.setMax_value_locale3(model.getMax_value_locale3());
		if (model.getMin_value_locale1() != null) newRec.setMin_value_locale1(model.getMin_value_locale1());
		if (model.getMin_value_locale2() != null) newRec.setMin_value_locale2(model.getMin_value_locale2());
		if (model.getMin_value_locale3() != null) newRec.setMin_value_locale3(model.getMin_value_locale3());
		if (model.getDescription_locale1() != null) newRec.setDescription_locale1(model.getDescription_locale1());
		if (model.getDescription_locale2() != null) newRec.setDescription_locale2(model.getDescription_locale2());
		if (model.getDescription_locale3() != null) newRec.setDescription_locale3(model.getDescription_locale3());
		if (model.getMeasure_type() != null) newRec.setMeasure_type(model.getMeasure_type());
		if (model.getData_type() != null) newRec.setData_type(model.getData_type());
		if (model.getFixed_length() != null) newRec.setFixed_length(model.getFixed_length());
		if (model.getTime_data_create_flg() != null) newRec.setTime_data_create_flg(model.getTime_data_create_flg());
		if (model.getShort_term_minutes() != null) newRec.setShort_term_minutes(model.getShort_term_minutes());
		if (model.getNote() != null) newRec.setNote(model.getNote());
		newRec.setVersion(0L);

		newRec = sensorRepository.save(newRec);

		SensorModel newModel = new SensorModel();
		newModel.setId(newRec.getId());
		newModel.setModel_id(newRec.getModel_id());
		newModel.setSerial_no(newRec.getSerial_no());
		newModel.setSensor_id(newRec.getSensor_id());
		newModel.setSensor_type(newRec.getSensor_type());
		newModel.setName_locale1(newRec.getName_locale1());
		newModel.setName_locale2(newRec.getName_locale2());
		newModel.setName_locale3(newRec.getName_locale3());
		newModel.setUnit_locale1(newRec.getUnit_locale1());
		newModel.setUnit_locale2(newRec.getUnit_locale2());
		newModel.setUnit_locale3(newRec.getUnit_locale3());
		newModel.setTransform_locale1(newRec.getTransform_locale1());
		newModel.setTransform_locale2(newRec.getTransform_locale2());
		newModel.setTransform_locale3(newRec.getTransform_locale3());
		newModel.setDecimal_num_locale1(newRec.getDecimal_num_locale1());
		newModel.setDecimal_num_locale2(newRec.getDecimal_num_locale2());
		newModel.setDecimal_num_locale3(newRec.getDecimal_num_locale3());
		newModel.setMax_value_locale1(newRec.getMax_value_locale1());
		newModel.setMax_value_locale2(newRec.getMax_value_locale2());
		newModel.setMax_value_locale3(newRec.getMax_value_locale3());
		newModel.setMin_value_locale1(newRec.getMin_value_locale1());
		newModel.setMin_value_locale2(newRec.getMin_value_locale2());
		newModel.setMin_value_locale3(newRec.getMin_value_locale3());
		newModel.setDescription_locale1(newRec.getDescription_locale1());
		newModel.setDescription_locale2(newRec.getDescription_locale2());
		newModel.setDescription_locale3(newRec.getDescription_locale3());
		newModel.setMeasure_type(newRec.getMeasure_type());
		newModel.setData_type(newRec.getData_type());
		newModel.setFixed_length(newRec.getFixed_length());
		newModel.setTime_data_create_flg(newRec.getTime_data_create_flg());
		newModel.setShort_term_minutes(newRec.getShort_term_minutes());
		newModel.setNote(newRec.getNote());
		newModel.setVersion(newRec.getVersion());
		newModel.setInserted(newRec.getInserted());
		newModel.setInsert_time(DateTimeUtil.formatTimestamp(newRec.getInsert_time()));
		newModel.setUpdated(newRec.getUpdated());
		newModel.setUpdate_time(DateTimeUtil.formatTimestamp(newRec.getUpdate_time()));
		return newModel;
	}

	@Transactional(readOnly = false)
	public SensorModel update(Locale locale,int id, SensorModel model) throws Exception{
		MstSensorEntity rec = sensorRepositoryCustom.findOneForUpdate(id);
		if(rec == null) {
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.sensorInfo")});
			throw exp;
		}

		rec.setModel_id(model.getModel_id());
		rec.setSerial_no(model.getSerial_no());
		rec.setSensor_id(model.getSensor_id());
		rec.setSensor_type(model.getSensor_type());
		rec.setName_locale1(model.getName_locale1());
		rec.setName_locale2(model.getName_locale2());
		rec.setName_locale3(model.getName_locale3());
		rec.setUnit_locale1(model.getUnit_locale1());
		rec.setUnit_locale2(model.getUnit_locale2());
		rec.setUnit_locale3(model.getUnit_locale3());
		rec.setTransform_locale1(model.getTransform_locale1());
		rec.setTransform_locale2(model.getTransform_locale2());
		rec.setTransform_locale3(model.getTransform_locale3());
		rec.setDecimal_num_locale1(model.getDecimal_num_locale1());
		rec.setDecimal_num_locale2(model.getDecimal_num_locale2());
		rec.setDecimal_num_locale3(model.getDecimal_num_locale3());
		rec.setMax_value_locale1(model.getMax_value_locale1());
		rec.setMax_value_locale2(model.getMax_value_locale2());
		rec.setMax_value_locale3(model.getMax_value_locale3());
		rec.setMin_value_locale1(model.getMin_value_locale1());
		rec.setMin_value_locale2(model.getMin_value_locale2());
		rec.setMin_value_locale3(model.getMin_value_locale3());
		rec.setDescription_locale1(model.getDescription_locale1());
		rec.setDescription_locale2(model.getDescription_locale2());
		rec.setDescription_locale3(model.getDescription_locale3());
		rec.setMeasure_type(model.getMeasure_type());
		rec.setData_type(model.getData_type());
		rec.setFixed_length(model.getFixed_length());
		rec.setTime_data_create_flg(model.getTime_data_create_flg());
		rec.setShort_term_minutes(model.getShort_term_minutes());
		rec.setNote(model.getNote());
		if (model.getVersion() == null || model.getVersion() != rec.getVersion()) {
			LockingFailureException exp = new LockingFailureException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.sensorInfo")});
			throw exp;
		}





		sensorRepository.saveAndFlush(rec);
		MstSensorEntity updateRec = sensorRepository.findOne(id);
		SensorModel newModel = new SensorModel();
		newModel.setId(updateRec.getId());
		newModel.setModel_id(updateRec.getModel_id());
		newModel.setSerial_no(updateRec.getSerial_no());
		newModel.setSensor_id(updateRec.getSensor_id());
		newModel.setSensor_type(updateRec.getSensor_type());
		newModel.setName_locale1(updateRec.getName_locale1());
		newModel.setName_locale2(updateRec.getName_locale2());
		newModel.setName_locale3(updateRec.getName_locale3());
		newModel.setUnit_locale1(updateRec.getUnit_locale1());
		newModel.setUnit_locale2(updateRec.getUnit_locale2());
		newModel.setUnit_locale3(updateRec.getUnit_locale3());
		newModel.setTransform_locale1(updateRec.getTransform_locale1());
		newModel.setTransform_locale2(updateRec.getTransform_locale2());
		newModel.setTransform_locale3(updateRec.getTransform_locale3());
		newModel.setDecimal_num_locale1(updateRec.getDecimal_num_locale1());
		newModel.setDecimal_num_locale2(updateRec.getDecimal_num_locale2());
		newModel.setDecimal_num_locale3(updateRec.getDecimal_num_locale3());
		newModel.setMax_value_locale1(updateRec.getMax_value_locale1());
		newModel.setMax_value_locale2(updateRec.getMax_value_locale2());
		newModel.setMax_value_locale3(updateRec.getMax_value_locale3());
		newModel.setMin_value_locale1(updateRec.getMin_value_locale1());
		newModel.setMin_value_locale2(updateRec.getMin_value_locale2());
		newModel.setMin_value_locale3(updateRec.getMin_value_locale3());
		newModel.setDescription_locale1(updateRec.getDescription_locale1());
		newModel.setDescription_locale2(updateRec.getDescription_locale2());
		newModel.setDescription_locale3(updateRec.getDescription_locale3());
		newModel.setMeasure_type(updateRec.getMeasure_type());
		newModel.setData_type(updateRec.getData_type());
		newModel.setFixed_length(updateRec.getFixed_length());
		newModel.setTime_data_create_flg(updateRec.getTime_data_create_flg());
		newModel.setShort_term_minutes(updateRec.getShort_term_minutes());
		newModel.setNote(updateRec.getNote());
		newModel.setVersion(updateRec.getVersion());
		newModel.setInserted(updateRec.getInserted());
		newModel.setInsert_time(DateTimeUtil.formatTimestamp(updateRec.getInsert_time()));
		newModel.setUpdated(updateRec.getUpdated());
		newModel.setUpdate_time(DateTimeUtil.formatTimestamp(updateRec.getUpdate_time()));
		return newModel;
	}


	@Transactional(readOnly = false)
	public void delete(int uuid) throws Exception {
		MstSensorEntity rec = sensorRepository.findOne(uuid);
		if(rec == null) {
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.sensorInfo")});
			throw exp;
		}
		sensorRepository.delete(rec);
	}

	private ModelFilter makeModelFilter(String fields) {
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if ("id".equals(str)) mf.id = true;
				if ("model_id".equals(str)) mf.model_id = true;
				if ("serial_no".equals(str)) mf.serial_no = true;
				if ("sensor_id".equals(str)) mf.sensor_id = true;
				if ("sensor_type".equals(str)) mf.sensor_type = true;
				if ("name_locale1".equals(str)) mf.name_locale1 = true;
				if ("name_locale2".equals(str)) mf.name_locale2 = true;
				if ("name_locale3".equals(str)) mf.name_locale3 = true;
				if ("unit_locale1".equals(str)) mf.unit_locale1 = true;
				if ("unit_locale2".equals(str)) mf.unit_locale2 = true;
				if ("unit_locale3".equals(str)) mf.unit_locale3 = true;
				if ("transform_locale1".equals(str)) mf.transform_locale1 = true;
				if ("transform_locale2".equals(str)) mf.transform_locale2 = true;
				if ("transform_locale3".equals(str)) mf.transform_locale3 = true;
				if ("decimal_num_locale1".equals(str)) mf.decimal_num_locale1 = true;
				if ("decimal_num_locale2".equals(str)) mf.decimal_num_locale2 = true;
				if ("decimal_num_locale3".equals(str)) mf.decimal_num_locale3 = true;
				if ("max_value_locale1".equals(str)) mf.max_value_locale1 = true;
				if ("max_value_locale2".equals(str)) mf.max_value_locale2 = true;
				if ("max_value_locale3".equals(str)) mf.max_value_locale3 = true;
				if ("min_value_locale1".equals(str)) mf.min_value_locale1 = true;
				if ("min_value_locale2".equals(str)) mf.min_value_locale2 = true;
				if ("min_value_locale3".equals(str)) mf.min_value_locale3 = true;
				if ("description_locale1".equals(str)) mf.description_locale1 = true;
				if ("description_locale2".equals(str)) mf.description_locale2 = true;
				if ("description_locale3".equals(str)) mf.description_locale3 = true;
				if ("measure_type".equals(str)) mf.measure_type = true;
				if ("data_type".equals(str)) mf.data_type = true;
				if ("fixed_length".equals(str)) mf.fixed_length = true;
				if ("time_data_create_flg".equals(str)) mf.time_data_create_flg = true;
				if ("short_term_minutes".equals(str)) mf.short_term_minutes = true;
				if ("note".equals(str)) mf.note = true;
				if ("version".equals(str)) mf.version = true;
				if ("inserted".equals(str)) mf.inserted = true;
				if ("insert_time".equals(str)) mf.insert_time = true;
				if ("updated".equals(str)) mf.updated = true;
				if ("update_time".equals(str)) mf.update_time = true;
			}
		}
		return mf;
	}

	class ModelFilter {
		public ModelFilter(boolean b) {
			id = b;
			model_id = b;
			serial_no = b;
			sensor_id = b;
			sensor_type = b;
			name_locale1 = b;
			name_locale2 = b;
			name_locale3 = b;
			unit_locale1 = b;
			unit_locale2 = b;
			unit_locale3 = b;
			transform_locale1 = b;
			transform_locale2 = b;
			transform_locale3 = b;
			decimal_num_locale1 = b;
			decimal_num_locale2 = b;
			decimal_num_locale3 = b;
			max_value_locale1 = b;
			max_value_locale2 = b;
			max_value_locale3 = b;
			min_value_locale1 = b;
			min_value_locale2 = b;
			min_value_locale3 = b;
			description_locale1 = b;
			description_locale2 = b;
			description_locale3 = b;
			measure_type = b;
			data_type = b;
			fixed_length = b;
			time_data_create_flg = b;
			short_term_minutes = b;
			note = b;
			version = b;
			inserted = b;
			insert_time = b;
			updated = b;
			update_time = b;
		}
		public boolean id = true;
		public boolean model_id = true;
		public boolean serial_no = true;
		public boolean sensor_id = true;
		public boolean sensor_type = true;
		public boolean name_locale1 = true;
		public boolean name_locale2 = true;
		public boolean name_locale3 = true;
		public boolean unit_locale1 = true;
		public boolean unit_locale2 = true;
		public boolean unit_locale3 = true;
		public boolean transform_locale1 = true;
		public boolean transform_locale2 = true;
		public boolean transform_locale3 = true;
		public boolean decimal_num_locale1 = true;
		public boolean decimal_num_locale2 = true;
		public boolean decimal_num_locale3 = true;
		public boolean max_value_locale1 = true;
		public boolean max_value_locale2 = true;
		public boolean max_value_locale3 = true;
		public boolean min_value_locale1 = true;
		public boolean min_value_locale2 = true;
		public boolean min_value_locale3 = true;
		public boolean description_locale1 = true;
		public boolean description_locale2 = true;
		public boolean description_locale3 = true;
		public boolean measure_type = true;
		public boolean data_type = true;
		public boolean fixed_length = true;
		public boolean time_data_create_flg = true;
		public boolean short_term_minutes = true;
		public boolean note = true;
		public boolean version = true;
		public boolean inserted = true;
		public boolean insert_time = true;
		public boolean updated = true;
		public boolean update_time = true;
	}
}

