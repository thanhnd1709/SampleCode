package com.app.model;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * ユーザ・プログラム権限情報取得モデル
 * @author 9571
 *
 */
@Data
public class UserProgramAuthorityModel implements Serializable {

	@ApiModelProperty(value = "ID")
	private String id;

	@ApiModelProperty(value = "権限ID")
	private String authority_id;

	@ApiModelProperty(value = "権限種別")
	private String authority_type;

	@ApiModelProperty(value = "名称(ロケール1)")
	private String program_name_locale1;

	@ApiModelProperty(value = "名称(ロケール2)")
	private String program_name_locale2;

	@ApiModelProperty(value = "名称(ロケール3)")
	private String program_name_locale3;

	@ApiModelProperty(value = "説明(ロケール1)")
	private String program_description_locale1;

	@ApiModelProperty(value = "説明(ロケール2)")
	private String program_description_locale2;

	@ApiModelProperty(value = "説明(ロケール3)")
	private String program_description_locale3;

	@ApiModelProperty(value = "プログラムID")
	private String program_id;

	@ApiModelProperty(value = "URL")
	private String url;

	@ApiModelProperty(value = "メソッド")
	private String method;

	@ApiModelProperty(value = "備考")
	private String program_note;

	@ApiModelProperty(value = "ロールID")
	private String role_id;

	@ApiModelProperty(value = "名称(ロケール1)")
	private String role_name_locale1;

	@ApiModelProperty(value = "名称(ロケール2)")
	private String role_name_locale2;

	@ApiModelProperty(value = "名称(ロケール3)")
	private String role_name_locale3;

	@ApiModelProperty(value = "説明(ロケール1)")
	private String role_description_locale1;

	@ApiModelProperty(value = "説明(ロケール2)")
	private String role_description_locale2;

	@ApiModelProperty(value = "説明(ロケール3)")
	private String role_description_locale3;

	@ApiModelProperty(value = "備考")
	private String role_note;
}
