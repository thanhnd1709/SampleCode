package com.app.model;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * イベント・アラーム状態取得モデル
 */
@Data
public class ResponseEventStatusModel {

	@ApiModelProperty(value = "トータル件数")
	private Integer total;

	@ApiModelProperty(value = "イベント状態")
	private List<EventStatusListModel> event_status_list;

}
