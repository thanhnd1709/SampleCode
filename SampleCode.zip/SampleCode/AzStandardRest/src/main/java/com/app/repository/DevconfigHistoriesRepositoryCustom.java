package com.app.repository;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.app.entity.StdDevconfigHistoryEntity;
import com.app.model.DevconfigHistoriesQueryModel;

public interface DevconfigHistoriesRepositoryCustom {
	List<StdDevconfigHistoryEntity> findAll(DevconfigHistoriesQueryModel query, List<String> sort, Integer limit, Integer offset);
	Long countAll(DevconfigHistoriesQueryModel query);

    StdDevconfigHistoryEntity findOneForUpdate(@Param("id") int id);
}