package com.app.repository;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.app.entity.MstUserRollEntity;
import com.app.model.UserRollModel;
import com.app.model.UserRollQueryModel;

public interface UserRoleRepositoryCustom {
	List<MstUserRollEntity> findAll(UserRollQueryModel query, List<String> sort, Integer limit, Integer offset);
	Long countAll(UserRollQueryModel query);

    MstUserRollEntity findOneForUpdate(@Param("id") int id);
    
    List<MstUserRollEntity> RoleAccessChk(UserRollQueryModel query);
    List<MstUserRollEntity> RoleAccessChk(UserRollModel query);
    List<MstUserRollEntity> RoleAccessChkId(Integer id);
    
    
}