package com.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.common.utils.DateTimeUtil;
import com.app.entity.MstBaseDeviceEntity;
import com.app.exception.DataNotFoundException;
import com.app.exception.LockingFailureException;
import com.app.model.BaseDeviceModel;
import com.app.model.BaseDeviceQueryModel;
import com.app.repository.BaseDeviceRepository;
import com.app.repository.BaseDeviceRepositoryCustom;

@Service
@Transactional(readOnly = true)
public class BaseDeviceService {
	@Autowired
	private BaseDeviceRepository baseDeviceRepository;
	@Autowired
	private BaseDeviceRepositoryCustom baseDeviceRepositoryCustom;

	public BaseDeviceModel findOne(int uuid, String fields) throws Exception{
		ModelFilter mf = makeModelFilter(fields);

		MstBaseDeviceEntity entity = baseDeviceRepository.findOne(uuid);
		BaseDeviceModel newModel = null;
		if (entity != null) {
			newModel = new BaseDeviceModel();
			if (mf.id) newModel.setId(entity.getId());
			if (mf.model_id) newModel.setModel_id(entity.getModel_id());
			if (mf.device_type) newModel.setDevice_type(entity.getDevice_type());
			if (mf.iot_device_flg) newModel.setIot_device_flg(entity.getIot_device_flg());
			if (mf.communication_flg) newModel.setCommunication_flg(entity.getCommunication_flg());
			if (mf.name_locale1) newModel.setName_locale1(entity.getName_locale1());
			if (mf.name_locale2) newModel.setName_locale2(entity.getName_locale2());
			if (mf.name_locale3) newModel.setName_locale3(entity.getName_locale3());
			if (mf.description_locale1) newModel.setDescription_locale1(entity.getDescription_locale1());
			if (mf.description_locale2) newModel.setDescription_locale2(entity.getDescription_locale2());
			if (mf.description_locale3) newModel.setDescription_locale3(entity.getDescription_locale3());
			if (mf.maker_code) newModel.setMaker_code(entity.getMaker_code());
			if (mf.parent_model_id) newModel.setParent_model_id(entity.getParent_model_id());
			if (mf.setup_place) newModel.setSetup_place(entity.getSetup_place());
			if (mf.setup_status) newModel.setSetup_status(entity.getSetup_status());
			if (mf.time_zone) newModel.setTime_zone(entity.getTime_zone());
			if (mf.latitude) newModel.setLatitude(entity.getLatitude());
			if (mf.longitude) newModel.setLongitude(entity.getLongitude());
			if (mf.unreceive_seconds) newModel.setUnreceive_seconds(entity.getUnreceive_seconds());
			if (mf.note) newModel.setNote(entity.getNote());
			if (mf.version) newModel.setVersion(entity.getVersion());
			if (mf.inserted) newModel.setInserted(entity.getInserted());
			if (mf.insert_time) newModel.setInsert_time(DateTimeUtil.formatTimestamp(entity.getInsert_time()));
			if (mf.updated) newModel.setUpdated(entity.getUpdated());
			if (mf.update_time) newModel.setUpdate_time(DateTimeUtil.formatTimestamp(entity.getUpdate_time()));
		}
		return  newModel;
	}

	public List<BaseDeviceModel> findAll(BaseDeviceQueryModel filter) throws Exception{

		ModelFilter mf = makeModelFilter(filter.getFields());

		List<String> sort = new ArrayList<String>();
		if (filter.getSort() != null) {
			for (String item : filter.getSort().split(",")) {
				sort.add(item.trim().toLowerCase());
			}
		}

		Integer limit = null;
		Integer offset = null;
		if (filter.getPage() != null && filter.getLimit() != null) {
			limit = Integer.parseInt(filter.getLimit());
			offset = (Integer.parseInt(filter.getPage()) - 1) * limit;
		}

		List<MstBaseDeviceEntity> entList = baseDeviceRepositoryCustom.findAll(filter, sort, limit, offset);
		List<BaseDeviceModel> modelList = new ArrayList<BaseDeviceModel>();
		for (MstBaseDeviceEntity entity : entList) {
			BaseDeviceModel newModel = new BaseDeviceModel();
			if (mf.id) newModel.setId(entity.getId());
			if (mf.model_id) newModel.setModel_id(entity.getModel_id());
			if (mf.device_type) newModel.setDevice_type(entity.getDevice_type());
			if (mf.iot_device_flg) newModel.setIot_device_flg(entity.getIot_device_flg());
			if (mf.communication_flg) newModel.setCommunication_flg(entity.getCommunication_flg());
			if (mf.name_locale1) newModel.setName_locale1(entity.getName_locale1());
			if (mf.name_locale2) newModel.setName_locale2(entity.getName_locale2());
			if (mf.name_locale3) newModel.setName_locale3(entity.getName_locale3());
			if (mf.description_locale1) newModel.setDescription_locale1(entity.getDescription_locale1());
			if (mf.description_locale2) newModel.setDescription_locale2(entity.getDescription_locale2());
			if (mf.description_locale3) newModel.setDescription_locale3(entity.getDescription_locale3());
			if (mf.maker_code) newModel.setMaker_code(entity.getMaker_code());
			if (mf.parent_model_id) newModel.setParent_model_id(entity.getParent_model_id());
			if (mf.setup_place) newModel.setSetup_place(entity.getSetup_place());
			if (mf.setup_status) newModel.setSetup_status(entity.getSetup_status());
			if (mf.time_zone) newModel.setTime_zone(entity.getTime_zone());
			if (mf.latitude) newModel.setLatitude(entity.getLatitude());
			if (mf.longitude) newModel.setLongitude(entity.getLongitude());
			if (mf.unreceive_seconds) newModel.setUnreceive_seconds(entity.getUnreceive_seconds());
			if (mf.note) newModel.setNote(entity.getNote());
			if (mf.version) newModel.setVersion(entity.getVersion());
			if (mf.inserted) newModel.setInserted(entity.getInserted());
			if (mf.insert_time) newModel.setInsert_time(DateTimeUtil.formatTimestamp(entity.getInsert_time()));
			if (mf.updated) newModel.setUpdated(entity.getUpdated());
			if (mf.update_time) newModel.setUpdate_time(DateTimeUtil.formatTimestamp(entity.getUpdate_time()));
			modelList.add(newModel);
		}
		return modelList;
	}

	public Long countAll(BaseDeviceQueryModel filter) throws Exception{
		return baseDeviceRepositoryCustom.countAll(filter);
	}

	@Transactional(readOnly = false)
	public BaseDeviceModel save(BaseDeviceModel model) throws Exception{

		MstBaseDeviceEntity newRec = new MstBaseDeviceEntity();

		if (model.getModel_id() != null) newRec.setModel_id(model.getModel_id());
		if (model.getDevice_type() != null) newRec.setDevice_type(model.getDevice_type());
		if (model.getIot_device_flg() != null) newRec.setIot_device_flg(model.getIot_device_flg());
		if (model.getCommunication_flg() != null) newRec.setCommunication_flg(model.getCommunication_flg());
		if (model.getName_locale1() != null) newRec.setName_locale1(model.getName_locale1());
		if (model.getName_locale2() != null) newRec.setName_locale2(model.getName_locale2());
		if (model.getName_locale3() != null) newRec.setName_locale3(model.getName_locale3());
		if (model.getDescription_locale1() != null) newRec.setDescription_locale1(model.getDescription_locale1());
		if (model.getDescription_locale2() != null) newRec.setDescription_locale2(model.getDescription_locale2());
		if (model.getDescription_locale3() != null) newRec.setDescription_locale3(model.getDescription_locale3());
		if (model.getMaker_code() != null) newRec.setMaker_code(model.getMaker_code());
		if (model.getParent_model_id() != null) newRec.setParent_model_id(model.getParent_model_id());
		if (model.getSetup_place() != null) newRec.setSetup_place(model.getSetup_place());
		if (model.getSetup_status() != null) newRec.setSetup_status(model.getSetup_status());
		if (model.getTime_zone() != null) newRec.setTime_zone(model.getTime_zone());
		if (model.getLatitude() != null) newRec.setLatitude(model.getLatitude());
		if (model.getLongitude() != null) newRec.setLongitude(model.getLongitude());
		if (model.getUnreceive_seconds() != null) newRec.setUnreceive_seconds(model.getUnreceive_seconds());
		if (model.getNote() != null) newRec.setNote(model.getNote());
		newRec.setVersion(0L);

		newRec = baseDeviceRepository.save(newRec);

		BaseDeviceModel newModel = new BaseDeviceModel();
		newModel.setId(newRec.getId());
		newModel.setModel_id(newRec.getModel_id());
		newModel.setDevice_type(newRec.getDevice_type());
		newModel.setIot_device_flg(newRec.getIot_device_flg());
		newModel.setCommunication_flg(newRec.getCommunication_flg());
		newModel.setName_locale1(newRec.getName_locale1());
		newModel.setName_locale2(newRec.getName_locale2());
		newModel.setName_locale3(newRec.getName_locale3());
		newModel.setDescription_locale1(newRec.getDescription_locale1());
		newModel.setDescription_locale2(newRec.getDescription_locale2());
		newModel.setDescription_locale3(newRec.getDescription_locale3());
		newModel.setMaker_code(newRec.getMaker_code());
		newModel.setParent_model_id(newRec.getParent_model_id());
		newModel.setSetup_place(newRec.getSetup_place());
		newModel.setSetup_status(newRec.getSetup_status());
		newModel.setTime_zone(newRec.getTime_zone());
		newModel.setLatitude(newRec.getLatitude());
		newModel.setLongitude(newRec.getLongitude());
		newModel.setUnreceive_seconds(newRec.getUnreceive_seconds());
		newModel.setNote(newRec.getNote());
		newModel.setVersion(newRec.getVersion());
		newModel.setInserted(newRec.getInserted());
		newModel.setInsert_time(DateTimeUtil.formatTimestamp(newRec.getInsert_time()));
		newModel.setUpdated(newRec.getUpdated());
		newModel.setUpdate_time(DateTimeUtil.formatTimestamp(newRec.getUpdate_time()));
		return newModel;
	}

	@Transactional(readOnly = false)
	public BaseDeviceModel update(Locale locale,int id, BaseDeviceModel model) throws Exception{
		MstBaseDeviceEntity rec = baseDeviceRepositoryCustom.findOneForUpdate(id);
		if(rec == null) {
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.baseDeviceInfo")});
			throw exp;
		}

		rec.setModel_id(model.getModel_id());
		rec.setDevice_type(model.getDevice_type());
		rec.setIot_device_flg(model.getIot_device_flg());
		rec.setCommunication_flg(model.getCommunication_flg());
		rec.setName_locale1(model.getName_locale1());
		rec.setName_locale2(model.getName_locale2());
		rec.setName_locale3(model.getName_locale3());
		rec.setDescription_locale1(model.getDescription_locale1());
		rec.setDescription_locale2(model.getDescription_locale2());
		rec.setDescription_locale3(model.getDescription_locale3());
		rec.setMaker_code(model.getMaker_code());
		rec.setParent_model_id(model.getParent_model_id());
		rec.setSetup_place(model.getSetup_place());
		rec.setSetup_status(model.getSetup_status());
		rec.setTime_zone(model.getTime_zone());
		rec.setLatitude(model.getLatitude());
		rec.setLongitude(model.getLongitude());
		rec.setUnreceive_seconds(model.getUnreceive_seconds());
		rec.setNote(model.getNote());
		if (model.getVersion() == null || model.getVersion() != rec.getVersion()) {
			LockingFailureException exp = new LockingFailureException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.baseDeviceInfo")});
			throw exp;
		}





		baseDeviceRepository.saveAndFlush(rec);
		MstBaseDeviceEntity updateRec = baseDeviceRepository.findOne(id);
		BaseDeviceModel newModel = new BaseDeviceModel();
		newModel.setId(updateRec.getId());
		newModel.setModel_id(updateRec.getModel_id());
		newModel.setDevice_type(updateRec.getDevice_type());
		newModel.setIot_device_flg(updateRec.getIot_device_flg());
		newModel.setCommunication_flg(updateRec.getCommunication_flg());
		newModel.setName_locale1(updateRec.getName_locale1());
		newModel.setName_locale2(updateRec.getName_locale2());
		newModel.setName_locale3(updateRec.getName_locale3());
		newModel.setDescription_locale1(updateRec.getDescription_locale1());
		newModel.setDescription_locale2(updateRec.getDescription_locale2());
		newModel.setDescription_locale3(updateRec.getDescription_locale3());
		newModel.setMaker_code(updateRec.getMaker_code());
		newModel.setParent_model_id(updateRec.getParent_model_id());
		newModel.setSetup_place(updateRec.getSetup_place());
		newModel.setSetup_status(updateRec.getSetup_status());
		newModel.setTime_zone(updateRec.getTime_zone());
		newModel.setLatitude(updateRec.getLatitude());
		newModel.setLongitude(updateRec.getLongitude());
		newModel.setUnreceive_seconds(updateRec.getUnreceive_seconds());
		newModel.setNote(updateRec.getNote());
		newModel.setVersion(updateRec.getVersion());
		newModel.setInserted(updateRec.getInserted());
		newModel.setInsert_time(DateTimeUtil.formatTimestamp(updateRec.getInsert_time()));
		newModel.setUpdated(updateRec.getUpdated());
		newModel.setUpdate_time(DateTimeUtil.formatTimestamp(updateRec.getUpdate_time()));
		return newModel;
	}


	@Transactional(readOnly = false)
	public void delete(int uuid) throws Exception {
		MstBaseDeviceEntity rec = baseDeviceRepository.findOne(uuid);
		if(rec == null) {
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("message.baseDeviceInfo")});
			throw exp;
		}
		baseDeviceRepository.delete(rec);
	}

	private ModelFilter makeModelFilter(String fields) {
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if ("id".equals(str)) mf.id = true;
				if ("model_id".equals(str)) mf.model_id = true;
				if ("device_type".equals(str)) mf.device_type = true;
				if ("iot_device_flg".equals(str)) mf.iot_device_flg = true;
				if ("communication_flg".equals(str)) mf.communication_flg = true;
				if ("name_locale1".equals(str)) mf.name_locale1 = true;
				if ("name_locale2".equals(str)) mf.name_locale2 = true;
				if ("name_locale3".equals(str)) mf.name_locale3 = true;
				if ("description_locale1".equals(str)) mf.description_locale1 = true;
				if ("description_locale2".equals(str)) mf.description_locale2 = true;
				if ("description_locale3".equals(str)) mf.description_locale3 = true;
				if ("maker_code".equals(str)) mf.maker_code = true;
				if ("parent_model_id".equals(str)) mf.parent_model_id = true;
				if ("setup_place".equals(str)) mf.setup_place = true;
				if ("setup_status".equals(str)) mf.setup_status = true;
				if ("time_zone".equals(str)) mf.time_zone = true;
				if ("latitude".equals(str)) mf.latitude = true;
				if ("longitude".equals(str)) mf.longitude = true;
				if ("unreceive_seconds".equals(str)) mf.unreceive_seconds = true;
				if ("note".equals(str)) mf.note = true;
				if ("version".equals(str)) mf.version = true;
				if ("inserted".equals(str)) mf.inserted = true;
				if ("insert_time".equals(str)) mf.insert_time = true;
				if ("updated".equals(str)) mf.updated = true;
				if ("update_time".equals(str)) mf.update_time = true;
			}
		}
		return mf;
	}

	class ModelFilter {
		public ModelFilter(boolean b) {
			id = b;
			model_id = b;
			device_type = b;
			iot_device_flg = b;
			communication_flg = b;
			name_locale1 = b;
			name_locale2 = b;
			name_locale3 = b;
			description_locale1 = b;
			description_locale2 = b;
			description_locale3 = b;
			maker_code = b;
			parent_model_id = b;
			setup_place = b;
			setup_status = b;
			time_zone = b;
			latitude = b;
			longitude = b;
			unreceive_seconds = b;
			note = b;
			version = b;
			inserted = b;
			insert_time = b;
			updated = b;
			update_time = b;
		}
		public boolean id = true;
		public boolean model_id = true;
		public boolean device_type = true;
		public boolean iot_device_flg = true;
		public boolean communication_flg = true;
		public boolean name_locale1 = true;
		public boolean name_locale2 = true;
		public boolean name_locale3 = true;
		public boolean description_locale1 = true;
		public boolean description_locale2 = true;
		public boolean description_locale3 = true;
		public boolean maker_code = true;
		public boolean parent_model_id = true;
		public boolean setup_place = true;
		public boolean setup_status = true;
		public boolean time_zone = true;
		public boolean latitude = true;
		public boolean longitude = true;
		public boolean unreceive_seconds = true;
		public boolean note = true;
		public boolean version = true;
		public boolean inserted = true;
		public boolean insert_time = true;
		public boolean updated = true;
		public boolean update_time = true;
	}
}

