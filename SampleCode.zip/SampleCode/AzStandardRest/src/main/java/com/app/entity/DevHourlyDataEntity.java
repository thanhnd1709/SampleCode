package com.app.entity;

import com.microsoft.azure.storage.table.TableServiceEntity;

public class DevHourlyDataEntity  extends TableServiceEntity
{

    public static int MAX_SENSOR_COUNT = 100;
    public static int TABLE_FIELD_SIZE_MAX = 63 * 1024;

    public DevHourlyDataEntity()
    {
//        this.PartitionKey = null;
//        this.RowKey = null;
    }

//    public DevHourlyDataEntity(String deviceIdAndSeqNo, String measureHour)
//    {
//        this.PartitionKey = deviceIdAndSeqNo;
//        this.RowKey = measureHour;
//    }

//    public String getDeviceId()
//    {
//        if (this.PartitionKey == null) return "";
//
//        int firstDollerPos = this.PartitionKey.IndexOf("$", StringComparison.Ordinal);
//        if (firstDollerPos == -1) return this.PartitionKey;
//
//        int secondDollerPos = this.PartitionKey.IndexOf("$", firstDollerPos + 1, StringComparison.Ordinal);
//        if (secondDollerPos == -1) return this.PartitionKey;
//
//        return this.PartitionKey.SubString(0, secondDollerPos);
//    }
//
//    public String getModelId()
//    {
//        if (this.PartitionKey == null) return "";
//
//        int firstDollerPos = this.PartitionKey.IndexOf("$", StringComparison.Ordinal);
//        if (firstDollerPos == -1) return this.PartitionKey;
//
//        return this.PartitionKey.SubString(0, firstDollerPos);
//    }
//
//    public String getSerialNo()
//    {
//        if (this.PartitionKey == null) return "";
//
//        int firstDollerPos = this.PartitionKey.IndexOf("$", StringComparison.Ordinal);
//        if (firstDollerPos == -1) return "";
//
//        int secondDollerPos = this.PartitionKey.IndexOf("$", firstDollerPos + 1, StringComparison.Ordinal);
//        if (secondDollerPos == -1) return "";
//
//        int serialNoLength = secondDollerPos - firstDollerPos - 1;
//        if (serialNoLength <= 0) return "";
//
//        return this.PartitionKey.SubString(firstDollerPos + 1, serialNoLength);
//    }

    /*
     * 指定したセンサ数を格納する場合のセンサごとの最大データサイズを返す
     * 指定したセンサ数で格納できない場合はエラー(例外)を返す
     */
    public static int getMaxSensorDataSize(int sensorNum)
    {
        if (sensorNum < 0 || sensorNum > MAX_SENSOR_COUNT)
        {
//			throw new Exception("number of sensor(" + sensorNum + ") exceeds maximum count");
        	return -1;
        }

        return (TABLE_FIELD_SIZE_MAX * MAX_SENSOR_COUNT) / sensorNum;
    }

    /*
     * 指定したフィールド番号に対応するセンサIDを返す
     * フィールド番号が範囲外の場合はエラー(例外)を返す
     */
    public String GetSensorId(int no)
    {
        switch (no)
        {
            case 0: return getSensorId0();
            case 1: return getSensorId1();
            case 2: return getSensorId2();
            case 3: return getSensorId3();
            case 4: return getSensorId4();
            case 5: return getSensorId5();
            case 6: return getSensorId6();
            case 7: return getSensorId7();
            case 8: return getSensorId8();
            case 9: return getSensorId9();
            case 10: return getSensorId10();
            case 11: return getSensorId11();
            case 12: return getSensorId12();
            case 13: return getSensorId13();
            case 14: return getSensorId14();
            case 15: return getSensorId15();
            case 16: return getSensorId16();
            case 17: return getSensorId17();
            case 18: return getSensorId18();
            case 19: return getSensorId19();
            case 20: return getSensorId20();
            case 21: return getSensorId21();
            case 22: return getSensorId22();
            case 23: return getSensorId23();
            case 24: return getSensorId24();
            case 25: return getSensorId25();
            case 26: return getSensorId26();
            case 27: return getSensorId27();
            case 28: return getSensorId28();
            case 29: return getSensorId29();
            case 30: return getSensorId30();
            case 31: return getSensorId31();
            case 32: return getSensorId32();
            case 33: return getSensorId33();
            case 34: return getSensorId34();
            case 35: return getSensorId35();
            case 36: return getSensorId36();
            case 37: return getSensorId37();
            case 38: return getSensorId38();
            case 39: return getSensorId39();
            case 40: return getSensorId40();
            case 41: return getSensorId41();
            case 42: return getSensorId42();
            case 43: return getSensorId43();
            case 44: return getSensorId44();
            case 45: return getSensorId45();
            case 46: return getSensorId46();
            case 47: return getSensorId47();
            case 48: return getSensorId48();
            case 49: return getSensorId49();
            case 50: return getSensorId50();
            case 51: return getSensorId51();
            case 52: return getSensorId52();
            case 53: return getSensorId53();
            case 54: return getSensorId54();
            case 55: return getSensorId55();
            case 56: return getSensorId56();
            case 57: return getSensorId57();
            case 58: return getSensorId58();
            case 59: return getSensorId59();
            case 60: return getSensorId60();
            case 61: return getSensorId61();
            case 62: return getSensorId62();
            case 63: return getSensorId63();
            case 64: return getSensorId64();
            case 65: return getSensorId65();
            case 66: return getSensorId66();
            case 67: return getSensorId67();
            case 68: return getSensorId68();
            case 69: return getSensorId69();
            case 70: return getSensorId70();
            case 71: return getSensorId71();
            case 72: return getSensorId72();
            case 73: return getSensorId73();
            case 74: return getSensorId74();
            case 75: return getSensorId75();
            case 76: return getSensorId76();
            case 77: return getSensorId77();
            case 78: return getSensorId78();
            case 79: return getSensorId79();
            case 80: return getSensorId80();
            case 81: return getSensorId81();
            case 82: return getSensorId82();
            case 83: return getSensorId83();
            case 84: return getSensorId84();
            case 85: return getSensorId85();
            case 86: return getSensorId86();
            case 87: return getSensorId87();
            case 88: return getSensorId88();
            case 89: return getSensorId89();
            case 90: return getSensorId90();
            case 91: return getSensorId91();
            case 92: return getSensorId92();
            case 93: return getSensorId93();
            case 94: return getSensorId94();
            case 95: return getSensorId95();
            case 96: return getSensorId96();
            case 97: return getSensorId97();
            case 98: return getSensorId98();
            case 99: return getSensorId99();
//            default: throw new Exception("unsupported sensor no:" + no);
            default: return null;
        }
    }

    /*
     * 指定したフィールド番号に対応するセンサデータを返す
     * フィールド番号が範囲外の場合はエラー(例外)を返す
     */
    public byte[] GetSensorData(int no)
    {
        switch (no)
        {
            case 0: return getSensorData0();
            case 1: return getSensorData1();
            case 2: return getSensorData2();
            case 3: return getSensorData3();
            case 4: return getSensorData4();
            case 5: return getSensorData5();
            case 6: return getSensorData6();
            case 7: return getSensorData7();
            case 8: return getSensorData8();
            case 9: return getSensorData9();
            case 10: return getSensorData10();
            case 11: return getSensorData11();
            case 12: return getSensorData12();
            case 13: return getSensorData13();
            case 14: return getSensorData14();
            case 15: return getSensorData15();
            case 16: return getSensorData16();
            case 17: return getSensorData17();
            case 18: return getSensorData18();
            case 19: return getSensorData19();
            case 20: return getSensorData20();
            case 21: return getSensorData21();
            case 22: return getSensorData22();
            case 23: return getSensorData23();
            case 24: return getSensorData24();
            case 25: return getSensorData25();
            case 26: return getSensorData26();
            case 27: return getSensorData27();
            case 28: return getSensorData28();
            case 29: return getSensorData29();
            case 30: return getSensorData30();
            case 31: return getSensorData31();
            case 32: return getSensorData32();
            case 33: return getSensorData33();
            case 34: return getSensorData34();
            case 35: return getSensorData35();
            case 36: return getSensorData36();
            case 37: return getSensorData37();
            case 38: return getSensorData38();
            case 39: return getSensorData39();
            case 40: return getSensorData40();
            case 41: return getSensorData41();
            case 42: return getSensorData42();
            case 43: return getSensorData43();
            case 44: return getSensorData44();
            case 45: return getSensorData45();
            case 46: return getSensorData46();
            case 47: return getSensorData47();
            case 48: return getSensorData48();
            case 49: return getSensorData49();
            case 50: return getSensorData50();
            case 51: return getSensorData51();
            case 52: return getSensorData52();
            case 53: return getSensorData53();
            case 54: return getSensorData54();
            case 55: return getSensorData55();
            case 56: return getSensorData56();
            case 57: return getSensorData57();
            case 58: return getSensorData58();
            case 59: return getSensorData59();
            case 60: return getSensorData60();
            case 61: return getSensorData61();
            case 62: return getSensorData62();
            case 63: return getSensorData63();
            case 64: return getSensorData64();
            case 65: return getSensorData65();
            case 66: return getSensorData66();
            case 67: return getSensorData67();
            case 68: return getSensorData68();
            case 69: return getSensorData69();
            case 70: return getSensorData70();
            case 71: return getSensorData71();
            case 72: return getSensorData72();
            case 73: return getSensorData73();
            case 74: return getSensorData74();
            case 75: return getSensorData75();
            case 76: return getSensorData76();
            case 77: return getSensorData77();
            case 78: return getSensorData78();
            case 79: return getSensorData79();
            case 80: return getSensorData80();
            case 81: return getSensorData81();
            case 82: return getSensorData82();
            case 83: return getSensorData83();
            case 84: return getSensorData84();
            case 85: return getSensorData85();
            case 86: return getSensorData86();
            case 87: return getSensorData87();
            case 88: return getSensorData88();
            case 89: return getSensorData89();
            case 90: return getSensorData90();
            case 91: return getSensorData91();
            case 92: return getSensorData92();
            case 93: return getSensorData93();
            case 94: return getSensorData94();
            case 95: return getSensorData95();
            case 96: return getSensorData96();
            case 97: return getSensorData97();
            case 98: return getSensorData98();
            case 99: return getSensorData99();
//            default: throw new Exception("unsupported sensor no:" + no);
            default: return null;
        }
    }

    /*
     * 指定したフィールド番号に対応するフィールドにセンサIDを格納する
     * フィールド番号が範囲外の場合はエラー(例外)を返す
     */
    public void SetSensorId(int no, String sensorId)
    {
        switch (no)
        {
            case 0: setSensorId0(sensorId); break;
            case 1: setSensorId1(sensorId); break;
            case 2: setSensorId2(sensorId); break;
            case 3: setSensorId3(sensorId); break;
            case 4: setSensorId4(sensorId); break;
            case 5: setSensorId5(sensorId); break;
            case 6: setSensorId6(sensorId); break;
            case 7: setSensorId7(sensorId); break;
            case 8: setSensorId8(sensorId); break;
            case 9: setSensorId9(sensorId); break;
            case 10: setSensorId10(sensorId); break;
            case 11: setSensorId11(sensorId); break;
            case 12: setSensorId12(sensorId); break;
            case 13: setSensorId13(sensorId); break;
            case 14: setSensorId14(sensorId); break;
            case 15: setSensorId15(sensorId); break;
            case 16: setSensorId16(sensorId); break;
            case 17: setSensorId17(sensorId); break;
            case 18: setSensorId18(sensorId); break;
            case 19: setSensorId19(sensorId); break;
            case 20: setSensorId20(sensorId); break;
            case 21: setSensorId21(sensorId); break;
            case 22: setSensorId22(sensorId); break;
            case 23: setSensorId23(sensorId); break;
            case 24: setSensorId24(sensorId); break;
            case 25: setSensorId25(sensorId); break;
            case 26: setSensorId26(sensorId); break;
            case 27: setSensorId27(sensorId); break;
            case 28: setSensorId28(sensorId); break;
            case 29: setSensorId29(sensorId); break;
            case 30: setSensorId30(sensorId); break;
            case 31: setSensorId31(sensorId); break;
            case 32: setSensorId32(sensorId); break;
            case 33: setSensorId33(sensorId); break;
            case 34: setSensorId34(sensorId); break;
            case 35: setSensorId35(sensorId); break;
            case 36: setSensorId36(sensorId); break;
            case 37: setSensorId37(sensorId); break;
            case 38: setSensorId38(sensorId); break;
            case 39: setSensorId39(sensorId); break;
            case 40: setSensorId40(sensorId); break;
            case 41: setSensorId41(sensorId); break;
            case 42: setSensorId42(sensorId); break;
            case 43: setSensorId43(sensorId); break;
            case 44: setSensorId44(sensorId); break;
            case 45: setSensorId45(sensorId); break;
            case 46: setSensorId46(sensorId); break;
            case 47: setSensorId47(sensorId); break;
            case 48: setSensorId48(sensorId); break;
            case 49: setSensorId49(sensorId); break;
            case 50: setSensorId50(sensorId); break;
            case 51: setSensorId51(sensorId); break;
            case 52: setSensorId52(sensorId); break;
            case 53: setSensorId53(sensorId); break;
            case 54: setSensorId54(sensorId); break;
            case 55: setSensorId55(sensorId); break;
            case 56: setSensorId56(sensorId); break;
            case 57: setSensorId57(sensorId); break;
            case 58: setSensorId58(sensorId); break;
            case 59: setSensorId59(sensorId); break;
            case 60: setSensorId60(sensorId); break;
            case 61: setSensorId61(sensorId); break;
            case 62: setSensorId62(sensorId); break;
            case 63: setSensorId63(sensorId); break;
            case 64: setSensorId64(sensorId); break;
            case 65: setSensorId65(sensorId); break;
            case 66: setSensorId66(sensorId); break;
            case 67: setSensorId67(sensorId); break;
            case 68: setSensorId68(sensorId); break;
            case 69: setSensorId69(sensorId); break;
            case 70: setSensorId70(sensorId); break;
            case 71: setSensorId71(sensorId); break;
            case 72: setSensorId72(sensorId); break;
            case 73: setSensorId73(sensorId); break;
            case 74: setSensorId74(sensorId); break;
            case 75: setSensorId75(sensorId); break;
            case 76: setSensorId76(sensorId); break;
            case 77: setSensorId77(sensorId); break;
            case 78: setSensorId78(sensorId); break;
            case 79: setSensorId79(sensorId); break;
            case 80: setSensorId80(sensorId); break;
            case 81: setSensorId81(sensorId); break;
            case 82: setSensorId82(sensorId); break;
            case 83: setSensorId83(sensorId); break;
            case 84: setSensorId84(sensorId); break;
            case 85: setSensorId85(sensorId); break;
            case 86: setSensorId86(sensorId); break;
            case 87: setSensorId87(sensorId); break;
            case 88: setSensorId88(sensorId); break;
            case 89: setSensorId89(sensorId); break;
            case 90: setSensorId90(sensorId); break;
            case 91: setSensorId91(sensorId); break;
            case 92: setSensorId92(sensorId); break;
            case 93: setSensorId93(sensorId); break;
            case 94: setSensorId94(sensorId); break;
            case 95: setSensorId95(sensorId); break;
            case 96: setSensorId96(sensorId); break;
            case 97: setSensorId97(sensorId); break;
            case 98: setSensorId98(sensorId); break;
            case 99: setSensorId99(sensorId); break;
//            default: throw new Exception("unsupported sensor no:" + no);
            default: return;
        }
    }

    /*
     * 指定したフィールド番号に対応するフィールドにセンサデータを格納する
     * フィールド番号が範囲外の場合はエラー(例外)を返す
     */
    public void setSensorData(int no, byte[] sensorData)
    {
        if (sensorData.length > TABLE_FIELD_SIZE_MAX)
        {
//            throw new Exception("sensor data size(" + sensorData.length + ") exceeds maximum size(" + TABLE_FIELD_SIZE_MAX + ")");
        	return;
        }

        switch (no)
        {
            case 0: setSensorData0(sensorData); break;
            case 1: setSensorData1(sensorData); break;
            case 2: setSensorData2(sensorData); break;
            case 3: setSensorData3(sensorData); break;
            case 4: setSensorData4(sensorData); break;
            case 5: setSensorData5(sensorData); break;
            case 6: setSensorData6(sensorData); break;
            case 7: setSensorData7(sensorData); break;
            case 8: setSensorData8(sensorData); break;
            case 9: setSensorData9(sensorData); break;
            case 10: setSensorData10(sensorData); break;
            case 11: setSensorData11(sensorData); break;
            case 12: setSensorData12(sensorData); break;
            case 13: setSensorData13(sensorData); break;
            case 14: setSensorData14(sensorData); break;
            case 15: setSensorData15(sensorData); break;
            case 16: setSensorData16(sensorData); break;
            case 17: setSensorData17(sensorData); break;
            case 18: setSensorData18(sensorData); break;
            case 19: setSensorData19(sensorData); break;
            case 20: setSensorData20(sensorData); break;
            case 21: setSensorData21(sensorData); break;
            case 22: setSensorData22(sensorData); break;
            case 23: setSensorData23(sensorData); break;
            case 24: setSensorData24(sensorData); break;
            case 25: setSensorData25(sensorData); break;
            case 26: setSensorData26(sensorData); break;
            case 27: setSensorData27(sensorData); break;
            case 28: setSensorData28(sensorData); break;
            case 29: setSensorData29(sensorData); break;
            case 30: setSensorData30(sensorData); break;
            case 31: setSensorData31(sensorData); break;
            case 32: setSensorData32(sensorData); break;
            case 33: setSensorData33(sensorData); break;
            case 34: setSensorData34(sensorData); break;
            case 35: setSensorData35(sensorData); break;
            case 36: setSensorData36(sensorData); break;
            case 37: setSensorData37(sensorData); break;
            case 38: setSensorData38(sensorData); break;
            case 39: setSensorData39(sensorData); break;
            case 40: setSensorData40(sensorData); break;
            case 41: setSensorData41(sensorData); break;
            case 42: setSensorData42(sensorData); break;
            case 43: setSensorData43(sensorData); break;
            case 44: setSensorData44(sensorData); break;
            case 45: setSensorData45(sensorData); break;
            case 46: setSensorData46(sensorData); break;
            case 47: setSensorData47(sensorData); break;
            case 48: setSensorData48(sensorData); break;
            case 49: setSensorData49(sensorData); break;
            case 50: setSensorData50(sensorData); break;
            case 51: setSensorData51(sensorData); break;
            case 52: setSensorData52(sensorData); break;
            case 53: setSensorData53(sensorData); break;
            case 54: setSensorData54(sensorData); break;
            case 55: setSensorData55(sensorData); break;
            case 56: setSensorData56(sensorData); break;
            case 57: setSensorData57(sensorData); break;
            case 58: setSensorData58(sensorData); break;
            case 59: setSensorData59(sensorData); break;
            case 60: setSensorData60(sensorData); break;
            case 61: setSensorData61(sensorData); break;
            case 62: setSensorData62(sensorData); break;
            case 63: setSensorData63(sensorData); break;
            case 64: setSensorData64(sensorData); break;
            case 65: setSensorData65(sensorData); break;
            case 66: setSensorData66(sensorData); break;
            case 67: setSensorData67(sensorData); break;
            case 68: setSensorData68(sensorData); break;
            case 69: setSensorData69(sensorData); break;
            case 70: setSensorData70(sensorData); break;
            case 71: setSensorData71(sensorData); break;
            case 72: setSensorData72(sensorData); break;
            case 73: setSensorData73(sensorData); break;
            case 74: setSensorData74(sensorData); break;
            case 75: setSensorData75(sensorData); break;
            case 76: setSensorData76(sensorData); break;
            case 77: setSensorData77(sensorData); break;
            case 78: setSensorData78(sensorData); break;
            case 79: setSensorData79(sensorData); break;
            case 80: setSensorData80(sensorData); break;
            case 81: setSensorData81(sensorData); break;
            case 82: setSensorData82(sensorData); break;
            case 83: setSensorData83(sensorData); break;
            case 84: setSensorData84(sensorData); break;
            case 85: setSensorData85(sensorData); break;
            case 86: setSensorData86(sensorData); break;
            case 87: setSensorData87(sensorData); break;
            case 88: setSensorData88(sensorData); break;
            case 89: setSensorData89(sensorData); break;
            case 90: setSensorData90(sensorData); break;
            case 91: setSensorData91(sensorData); break;
            case 92: setSensorData92(sensorData); break;
            case 93: setSensorData93(sensorData); break;
            case 94: setSensorData94(sensorData); break;
            case 95: setSensorData95(sensorData); break;
            case 96: setSensorData96(sensorData); break;
            case 97: setSensorData97(sensorData); break;
            case 98: setSensorData98(sensorData); break;
            case 99: setSensorData99(sensorData); break;
//            default: throw new Exception("unsupported sensor no:" + no);
            default: return;
        }
    }

    private String sensorId0;
    public static int getMAX_SENSOR_COUNT() {
		return MAX_SENSOR_COUNT;
	}

	public static void setMAX_SENSOR_COUNT(int mAX_SENSOR_COUNT) {
		MAX_SENSOR_COUNT = mAX_SENSOR_COUNT;
	}

	public String getSensorId0() {
		return sensorId0;
	}

	public void setSensorId0(String sensorId0) {
		this.sensorId0 = sensorId0;
	}

	public byte[] getSensorData0() {
		return sensorData0;
	}

	public void setSensorData0(byte[] sensorData0) {
		this.sensorData0 = sensorData0;
	}

	public String getSensorId1() {
		return sensorId1;
	}

	public void setSensorId1(String sensorId1) {
		this.sensorId1 = sensorId1;
	}

	public byte[] getSensorData1() {
		return sensorData1;
	}

	public void setSensorData1(byte[] sensorData1) {
		this.sensorData1 = sensorData1;
	}

	public String getSensorId2() {
		return sensorId2;
	}

	public void setSensorId2(String sensorId2) {
		this.sensorId2 = sensorId2;
	}

	public byte[] getSensorData2() {
		return sensorData2;
	}

	public void setSensorData2(byte[] sensorData2) {
		this.sensorData2 = sensorData2;
	}

	public String getSensorId3() {
		return sensorId3;
	}

	public void setSensorId3(String sensorId3) {
		this.sensorId3 = sensorId3;
	}

	public byte[] getSensorData3() {
		return sensorData3;
	}

	public void setSensorData3(byte[] sensorData3) {
		this.sensorData3 = sensorData3;
	}

	public String getSensorId4() {
		return sensorId4;
	}

	public void setSensorId4(String sensorId4) {
		this.sensorId4 = sensorId4;
	}

	public byte[] getSensorData4() {
		return sensorData4;
	}

	public void setSensorData4(byte[] sensorData4) {
		this.sensorData4 = sensorData4;
	}

	public String getSensorId5() {
		return sensorId5;
	}

	public void setSensorId5(String sensorId5) {
		this.sensorId5 = sensorId5;
	}

	public byte[] getSensorData5() {
		return sensorData5;
	}

	public void setSensorData5(byte[] sensorData5) {
		this.sensorData5 = sensorData5;
	}

	public String getSensorId6() {
		return sensorId6;
	}

	public void setSensorId6(String sensorId6) {
		this.sensorId6 = sensorId6;
	}

	public byte[] getSensorData6() {
		return sensorData6;
	}

	public void setSensorData6(byte[] sensorData6) {
		this.sensorData6 = sensorData6;
	}

	public String getSensorId7() {
		return sensorId7;
	}

	public void setSensorId7(String sensorId7) {
		this.sensorId7 = sensorId7;
	}

	public byte[] getSensorData7() {
		return sensorData7;
	}

	public void setSensorData7(byte[] sensorData7) {
		this.sensorData7 = sensorData7;
	}

	public String getSensorId8() {
		return sensorId8;
	}

	public void setSensorId8(String sensorId8) {
		this.sensorId8 = sensorId8;
	}

	public byte[] getSensorData8() {
		return sensorData8;
	}

	public void setSensorData8(byte[] sensorData8) {
		this.sensorData8 = sensorData8;
	}

	public String getSensorId9() {
		return sensorId9;
	}

	public void setSensorId9(String sensorId9) {
		this.sensorId9 = sensorId9;
	}

	public byte[] getSensorData9() {
		return sensorData9;
	}

	public void setSensorData9(byte[] sensorData9) {
		this.sensorData9 = sensorData9;
	}

	public String getSensorId10() {
		return sensorId10;
	}

	public void setSensorId10(String sensorId10) {
		this.sensorId10 = sensorId10;
	}

	public byte[] getSensorData10() {
		return sensorData10;
	}

	public void setSensorData10(byte[] sensorData10) {
		this.sensorData10 = sensorData10;
	}

	public String getSensorId11() {
		return sensorId11;
	}

	public void setSensorId11(String sensorId11) {
		this.sensorId11 = sensorId11;
	}

	public byte[] getSensorData11() {
		return sensorData11;
	}

	public void setSensorData11(byte[] sensorData11) {
		this.sensorData11 = sensorData11;
	}

	public String getSensorId12() {
		return sensorId12;
	}

	public void setSensorId12(String sensorId12) {
		this.sensorId12 = sensorId12;
	}

	public byte[] getSensorData12() {
		return sensorData12;
	}

	public void setSensorData12(byte[] sensorData12) {
		this.sensorData12 = sensorData12;
	}

	public String getSensorId13() {
		return sensorId13;
	}

	public void setSensorId13(String sensorId13) {
		this.sensorId13 = sensorId13;
	}

	public byte[] getSensorData13() {
		return sensorData13;
	}

	public void setSensorData13(byte[] sensorData13) {
		this.sensorData13 = sensorData13;
	}

	public String getSensorId14() {
		return sensorId14;
	}

	public void setSensorId14(String sensorId14) {
		this.sensorId14 = sensorId14;
	}

	public byte[] getSensorData14() {
		return sensorData14;
	}

	public void setSensorData14(byte[] sensorData14) {
		this.sensorData14 = sensorData14;
	}

	public String getSensorId15() {
		return sensorId15;
	}

	public void setSensorId15(String sensorId15) {
		this.sensorId15 = sensorId15;
	}

	public byte[] getSensorData15() {
		return sensorData15;
	}

	public void setSensorData15(byte[] sensorData15) {
		this.sensorData15 = sensorData15;
	}

	public String getSensorId16() {
		return sensorId16;
	}

	public void setSensorId16(String sensorId16) {
		this.sensorId16 = sensorId16;
	}

	public byte[] getSensorData16() {
		return sensorData16;
	}

	public void setSensorData16(byte[] sensorData16) {
		this.sensorData16 = sensorData16;
	}

	public String getSensorId17() {
		return sensorId17;
	}

	public void setSensorId17(String sensorId17) {
		this.sensorId17 = sensorId17;
	}

	public byte[] getSensorData17() {
		return sensorData17;
	}

	public void setSensorData17(byte[] sensorData17) {
		this.sensorData17 = sensorData17;
	}

	public String getSensorId18() {
		return sensorId18;
	}

	public void setSensorId18(String sensorId18) {
		this.sensorId18 = sensorId18;
	}

	public byte[] getSensorData18() {
		return sensorData18;
	}

	public void setSensorData18(byte[] sensorData18) {
		this.sensorData18 = sensorData18;
	}

	public String getSensorId19() {
		return sensorId19;
	}

	public void setSensorId19(String sensorId19) {
		this.sensorId19 = sensorId19;
	}

	public byte[] getSensorData19() {
		return sensorData19;
	}

	public void setSensorData19(byte[] sensorData19) {
		this.sensorData19 = sensorData19;
	}

	public String getSensorId20() {
		return sensorId20;
	}

	public void setSensorId20(String sensorId20) {
		this.sensorId20 = sensorId20;
	}

	public byte[] getSensorData20() {
		return sensorData20;
	}

	public void setSensorData20(byte[] sensorData20) {
		this.sensorData20 = sensorData20;
	}

	public String getSensorId21() {
		return sensorId21;
	}

	public void setSensorId21(String sensorId21) {
		this.sensorId21 = sensorId21;
	}

	public byte[] getSensorData21() {
		return sensorData21;
	}

	public void setSensorData21(byte[] sensorData21) {
		this.sensorData21 = sensorData21;
	}

	public String getSensorId22() {
		return sensorId22;
	}

	public void setSensorId22(String sensorId22) {
		this.sensorId22 = sensorId22;
	}

	public byte[] getSensorData22() {
		return sensorData22;
	}

	public void setSensorData22(byte[] sensorData22) {
		this.sensorData22 = sensorData22;
	}

	public String getSensorId23() {
		return sensorId23;
	}

	public void setSensorId23(String sensorId23) {
		this.sensorId23 = sensorId23;
	}

	public byte[] getSensorData23() {
		return sensorData23;
	}

	public void setSensorData23(byte[] sensorData23) {
		this.sensorData23 = sensorData23;
	}

	public String getSensorId24() {
		return sensorId24;
	}

	public void setSensorId24(String sensorId24) {
		this.sensorId24 = sensorId24;
	}

	public byte[] getSensorData24() {
		return sensorData24;
	}

	public void setSensorData24(byte[] sensorData24) {
		this.sensorData24 = sensorData24;
	}

	public String getSensorId25() {
		return sensorId25;
	}

	public void setSensorId25(String sensorId25) {
		this.sensorId25 = sensorId25;
	}

	public byte[] getSensorData25() {
		return sensorData25;
	}

	public void setSensorData25(byte[] sensorData25) {
		this.sensorData25 = sensorData25;
	}

	public String getSensorId26() {
		return sensorId26;
	}

	public void setSensorId26(String sensorId26) {
		this.sensorId26 = sensorId26;
	}

	public byte[] getSensorData26() {
		return sensorData26;
	}

	public void setSensorData26(byte[] sensorData26) {
		this.sensorData26 = sensorData26;
	}

	public String getSensorId27() {
		return sensorId27;
	}

	public void setSensorId27(String sensorId27) {
		this.sensorId27 = sensorId27;
	}

	public byte[] getSensorData27() {
		return sensorData27;
	}

	public void setSensorData27(byte[] sensorData27) {
		this.sensorData27 = sensorData27;
	}

	public String getSensorId28() {
		return sensorId28;
	}

	public void setSensorId28(String sensorId28) {
		this.sensorId28 = sensorId28;
	}

	public byte[] getSensorData28() {
		return sensorData28;
	}

	public void setSensorData28(byte[] sensorData28) {
		this.sensorData28 = sensorData28;
	}

	public String getSensorId29() {
		return sensorId29;
	}

	public void setSensorId29(String sensorId29) {
		this.sensorId29 = sensorId29;
	}

	public byte[] getSensorData29() {
		return sensorData29;
	}

	public void setSensorData29(byte[] sensorData29) {
		this.sensorData29 = sensorData29;
	}

	public String getSensorId30() {
		return sensorId30;
	}

	public void setSensorId30(String sensorId30) {
		this.sensorId30 = sensorId30;
	}

	public byte[] getSensorData30() {
		return sensorData30;
	}

	public void setSensorData30(byte[] sensorData30) {
		this.sensorData30 = sensorData30;
	}

	public String getSensorId31() {
		return sensorId31;
	}

	public void setSensorId31(String sensorId31) {
		this.sensorId31 = sensorId31;
	}

	public byte[] getSensorData31() {
		return sensorData31;
	}

	public void setSensorData31(byte[] sensorData31) {
		this.sensorData31 = sensorData31;
	}

	public String getSensorId32() {
		return sensorId32;
	}

	public void setSensorId32(String sensorId32) {
		this.sensorId32 = sensorId32;
	}

	public byte[] getSensorData32() {
		return sensorData32;
	}

	public void setSensorData32(byte[] sensorData32) {
		this.sensorData32 = sensorData32;
	}

	public String getSensorId33() {
		return sensorId33;
	}

	public void setSensorId33(String sensorId33) {
		this.sensorId33 = sensorId33;
	}

	public byte[] getSensorData33() {
		return sensorData33;
	}

	public void setSensorData33(byte[] sensorData33) {
		this.sensorData33 = sensorData33;
	}

	public String getSensorId34() {
		return sensorId34;
	}

	public void setSensorId34(String sensorId34) {
		this.sensorId34 = sensorId34;
	}

	public byte[] getSensorData34() {
		return sensorData34;
	}

	public void setSensorData34(byte[] sensorData34) {
		this.sensorData34 = sensorData34;
	}

	public String getSensorId35() {
		return sensorId35;
	}

	public void setSensorId35(String sensorId35) {
		this.sensorId35 = sensorId35;
	}

	public byte[] getSensorData35() {
		return sensorData35;
	}

	public void setSensorData35(byte[] sensorData35) {
		this.sensorData35 = sensorData35;
	}

	public String getSensorId36() {
		return sensorId36;
	}

	public void setSensorId36(String sensorId36) {
		this.sensorId36 = sensorId36;
	}

	public byte[] getSensorData36() {
		return sensorData36;
	}

	public void setSensorData36(byte[] sensorData36) {
		this.sensorData36 = sensorData36;
	}

	public String getSensorId37() {
		return sensorId37;
	}

	public void setSensorId37(String sensorId37) {
		this.sensorId37 = sensorId37;
	}

	public byte[] getSensorData37() {
		return sensorData37;
	}

	public void setSensorData37(byte[] sensorData37) {
		this.sensorData37 = sensorData37;
	}

	public String getSensorId38() {
		return sensorId38;
	}

	public void setSensorId38(String sensorId38) {
		this.sensorId38 = sensorId38;
	}

	public byte[] getSensorData38() {
		return sensorData38;
	}

	public void setSensorData38(byte[] sensorData38) {
		this.sensorData38 = sensorData38;
	}

	public String getSensorId39() {
		return sensorId39;
	}

	public void setSensorId39(String sensorId39) {
		this.sensorId39 = sensorId39;
	}

	public byte[] getSensorData39() {
		return sensorData39;
	}

	public void setSensorData39(byte[] sensorData39) {
		this.sensorData39 = sensorData39;
	}

	public String getSensorId40() {
		return sensorId40;
	}

	public void setSensorId40(String sensorId40) {
		this.sensorId40 = sensorId40;
	}

	public byte[] getSensorData40() {
		return sensorData40;
	}

	public void setSensorData40(byte[] sensorData40) {
		this.sensorData40 = sensorData40;
	}

	public String getSensorId41() {
		return sensorId41;
	}

	public void setSensorId41(String sensorId41) {
		this.sensorId41 = sensorId41;
	}

	public byte[] getSensorData41() {
		return sensorData41;
	}

	public void setSensorData41(byte[] sensorData41) {
		this.sensorData41 = sensorData41;
	}

	public String getSensorId42() {
		return sensorId42;
	}

	public void setSensorId42(String sensorId42) {
		this.sensorId42 = sensorId42;
	}

	public byte[] getSensorData42() {
		return sensorData42;
	}

	public void setSensorData42(byte[] sensorData42) {
		this.sensorData42 = sensorData42;
	}

	public String getSensorId43() {
		return sensorId43;
	}

	public void setSensorId43(String sensorId43) {
		this.sensorId43 = sensorId43;
	}

	public byte[] getSensorData43() {
		return sensorData43;
	}

	public void setSensorData43(byte[] sensorData43) {
		this.sensorData43 = sensorData43;
	}

	public String getSensorId44() {
		return sensorId44;
	}

	public void setSensorId44(String sensorId44) {
		this.sensorId44 = sensorId44;
	}

	public byte[] getSensorData44() {
		return sensorData44;
	}

	public void setSensorData44(byte[] sensorData44) {
		this.sensorData44 = sensorData44;
	}

	public String getSensorId45() {
		return sensorId45;
	}

	public void setSensorId45(String sensorId45) {
		this.sensorId45 = sensorId45;
	}

	public byte[] getSensorData45() {
		return sensorData45;
	}

	public void setSensorData45(byte[] sensorData45) {
		this.sensorData45 = sensorData45;
	}

	public String getSensorId46() {
		return sensorId46;
	}

	public void setSensorId46(String sensorId46) {
		this.sensorId46 = sensorId46;
	}

	public byte[] getSensorData46() {
		return sensorData46;
	}

	public void setSensorData46(byte[] sensorData46) {
		this.sensorData46 = sensorData46;
	}

	public String getSensorId47() {
		return sensorId47;
	}

	public void setSensorId47(String sensorId47) {
		this.sensorId47 = sensorId47;
	}

	public byte[] getSensorData47() {
		return sensorData47;
	}

	public void setSensorData47(byte[] sensorData47) {
		this.sensorData47 = sensorData47;
	}

	public String getSensorId48() {
		return sensorId48;
	}

	public void setSensorId48(String sensorId48) {
		this.sensorId48 = sensorId48;
	}

	public byte[] getSensorData48() {
		return sensorData48;
	}

	public void setSensorData48(byte[] sensorData48) {
		this.sensorData48 = sensorData48;
	}

	public String getSensorId49() {
		return sensorId49;
	}

	public void setSensorId49(String sensorId49) {
		this.sensorId49 = sensorId49;
	}

	public byte[] getSensorData49() {
		return sensorData49;
	}

	public void setSensorData49(byte[] sensorData49) {
		this.sensorData49 = sensorData49;
	}

	public String getSensorId50() {
		return sensorId50;
	}

	public void setSensorId50(String sensorId50) {
		this.sensorId50 = sensorId50;
	}

	public byte[] getSensorData50() {
		return sensorData50;
	}

	public void setSensorData50(byte[] sensorData50) {
		this.sensorData50 = sensorData50;
	}

	public String getSensorId51() {
		return sensorId51;
	}

	public void setSensorId51(String sensorId51) {
		this.sensorId51 = sensorId51;
	}

	public byte[] getSensorData51() {
		return sensorData51;
	}

	public void setSensorData51(byte[] sensorData51) {
		this.sensorData51 = sensorData51;
	}

	public String getSensorId52() {
		return sensorId52;
	}

	public void setSensorId52(String sensorId52) {
		this.sensorId52 = sensorId52;
	}

	public byte[] getSensorData52() {
		return sensorData52;
	}

	public void setSensorData52(byte[] sensorData52) {
		this.sensorData52 = sensorData52;
	}

	public String getSensorId53() {
		return sensorId53;
	}

	public void setSensorId53(String sensorId53) {
		this.sensorId53 = sensorId53;
	}

	public byte[] getSensorData53() {
		return sensorData53;
	}

	public void setSensorData53(byte[] sensorData53) {
		this.sensorData53 = sensorData53;
	}

	public String getSensorId54() {
		return sensorId54;
	}

	public void setSensorId54(String sensorId54) {
		this.sensorId54 = sensorId54;
	}

	public byte[] getSensorData54() {
		return sensorData54;
	}

	public void setSensorData54(byte[] sensorData54) {
		this.sensorData54 = sensorData54;
	}

	public String getSensorId55() {
		return sensorId55;
	}

	public void setSensorId55(String sensorId55) {
		this.sensorId55 = sensorId55;
	}

	public byte[] getSensorData55() {
		return sensorData55;
	}

	public void setSensorData55(byte[] sensorData55) {
		this.sensorData55 = sensorData55;
	}

	public String getSensorId56() {
		return sensorId56;
	}

	public void setSensorId56(String sensorId56) {
		this.sensorId56 = sensorId56;
	}

	public byte[] getSensorData56() {
		return sensorData56;
	}

	public void setSensorData56(byte[] sensorData56) {
		this.sensorData56 = sensorData56;
	}

	public String getSensorId57() {
		return sensorId57;
	}

	public void setSensorId57(String sensorId57) {
		this.sensorId57 = sensorId57;
	}

	public byte[] getSensorData57() {
		return sensorData57;
	}

	public void setSensorData57(byte[] sensorData57) {
		this.sensorData57 = sensorData57;
	}

	public String getSensorId58() {
		return sensorId58;
	}

	public void setSensorId58(String sensorId58) {
		this.sensorId58 = sensorId58;
	}

	public byte[] getSensorData58() {
		return sensorData58;
	}

	public void setSensorData58(byte[] sensorData58) {
		this.sensorData58 = sensorData58;
	}

	public String getSensorId59() {
		return sensorId59;
	}

	public void setSensorId59(String sensorId59) {
		this.sensorId59 = sensorId59;
	}

	public byte[] getSensorData59() {
		return sensorData59;
	}

	public void setSensorData59(byte[] sensorData59) {
		this.sensorData59 = sensorData59;
	}

	public String getSensorId60() {
		return sensorId60;
	}

	public void setSensorId60(String sensorId60) {
		this.sensorId60 = sensorId60;
	}

	public byte[] getSensorData60() {
		return sensorData60;
	}

	public void setSensorData60(byte[] sensorData60) {
		this.sensorData60 = sensorData60;
	}

	public String getSensorId61() {
		return sensorId61;
	}

	public void setSensorId61(String sensorId61) {
		this.sensorId61 = sensorId61;
	}

	public byte[] getSensorData61() {
		return sensorData61;
	}

	public void setSensorData61(byte[] sensorData61) {
		this.sensorData61 = sensorData61;
	}

	public String getSensorId62() {
		return sensorId62;
	}

	public void setSensorId62(String sensorId62) {
		this.sensorId62 = sensorId62;
	}

	public byte[] getSensorData62() {
		return sensorData62;
	}

	public void setSensorData62(byte[] sensorData62) {
		this.sensorData62 = sensorData62;
	}

	public String getSensorId63() {
		return sensorId63;
	}

	public void setSensorId63(String sensorId63) {
		this.sensorId63 = sensorId63;
	}

	public byte[] getSensorData63() {
		return sensorData63;
	}

	public void setSensorData63(byte[] sensorData63) {
		this.sensorData63 = sensorData63;
	}

	public String getSensorId64() {
		return sensorId64;
	}

	public void setSensorId64(String sensorId64) {
		this.sensorId64 = sensorId64;
	}

	public byte[] getSensorData64() {
		return sensorData64;
	}

	public void setSensorData64(byte[] sensorData64) {
		this.sensorData64 = sensorData64;
	}

	public String getSensorId65() {
		return sensorId65;
	}

	public void setSensorId65(String sensorId65) {
		this.sensorId65 = sensorId65;
	}

	public byte[] getSensorData65() {
		return sensorData65;
	}

	public void setSensorData65(byte[] sensorData65) {
		this.sensorData65 = sensorData65;
	}

	public String getSensorId66() {
		return sensorId66;
	}

	public void setSensorId66(String sensorId66) {
		this.sensorId66 = sensorId66;
	}

	public byte[] getSensorData66() {
		return sensorData66;
	}

	public void setSensorData66(byte[] sensorData66) {
		this.sensorData66 = sensorData66;
	}

	public String getSensorId67() {
		return sensorId67;
	}

	public void setSensorId67(String sensorId67) {
		this.sensorId67 = sensorId67;
	}

	public byte[] getSensorData67() {
		return sensorData67;
	}

	public void setSensorData67(byte[] sensorData67) {
		this.sensorData67 = sensorData67;
	}

	public String getSensorId68() {
		return sensorId68;
	}

	public void setSensorId68(String sensorId68) {
		this.sensorId68 = sensorId68;
	}

	public byte[] getSensorData68() {
		return sensorData68;
	}

	public void setSensorData68(byte[] sensorData68) {
		this.sensorData68 = sensorData68;
	}

	public String getSensorId69() {
		return sensorId69;
	}

	public void setSensorId69(String sensorId69) {
		this.sensorId69 = sensorId69;
	}

	public byte[] getSensorData69() {
		return sensorData69;
	}

	public void setSensorData69(byte[] sensorData69) {
		this.sensorData69 = sensorData69;
	}

	public String getSensorId70() {
		return sensorId70;
	}

	public void setSensorId70(String sensorId70) {
		this.sensorId70 = sensorId70;
	}

	public byte[] getSensorData70() {
		return sensorData70;
	}

	public void setSensorData70(byte[] sensorData70) {
		this.sensorData70 = sensorData70;
	}

	public String getSensorId71() {
		return sensorId71;
	}

	public void setSensorId71(String sensorId71) {
		this.sensorId71 = sensorId71;
	}

	public byte[] getSensorData71() {
		return sensorData71;
	}

	public void setSensorData71(byte[] sensorData71) {
		this.sensorData71 = sensorData71;
	}

	public String getSensorId72() {
		return sensorId72;
	}

	public void setSensorId72(String sensorId72) {
		this.sensorId72 = sensorId72;
	}

	public byte[] getSensorData72() {
		return sensorData72;
	}

	public void setSensorData72(byte[] sensorData72) {
		this.sensorData72 = sensorData72;
	}

	public String getSensorId73() {
		return sensorId73;
	}

	public void setSensorId73(String sensorId73) {
		this.sensorId73 = sensorId73;
	}

	public byte[] getSensorData73() {
		return sensorData73;
	}

	public void setSensorData73(byte[] sensorData73) {
		this.sensorData73 = sensorData73;
	}

	public String getSensorId74() {
		return sensorId74;
	}

	public void setSensorId74(String sensorId74) {
		this.sensorId74 = sensorId74;
	}

	public byte[] getSensorData74() {
		return sensorData74;
	}

	public void setSensorData74(byte[] sensorData74) {
		this.sensorData74 = sensorData74;
	}

	public String getSensorId75() {
		return sensorId75;
	}

	public void setSensorId75(String sensorId75) {
		this.sensorId75 = sensorId75;
	}

	public byte[] getSensorData75() {
		return sensorData75;
	}

	public void setSensorData75(byte[] sensorData75) {
		this.sensorData75 = sensorData75;
	}

	public String getSensorId76() {
		return sensorId76;
	}

	public void setSensorId76(String sensorId76) {
		this.sensorId76 = sensorId76;
	}

	public byte[] getSensorData76() {
		return sensorData76;
	}

	public void setSensorData76(byte[] sensorData76) {
		this.sensorData76 = sensorData76;
	}

	public String getSensorId77() {
		return sensorId77;
	}

	public void setSensorId77(String sensorId77) {
		this.sensorId77 = sensorId77;
	}

	public byte[] getSensorData77() {
		return sensorData77;
	}

	public void setSensorData77(byte[] sensorData77) {
		this.sensorData77 = sensorData77;
	}

	public String getSensorId78() {
		return sensorId78;
	}

	public void setSensorId78(String sensorId78) {
		this.sensorId78 = sensorId78;
	}

	public byte[] getSensorData78() {
		return sensorData78;
	}

	public void setSensorData78(byte[] sensorData78) {
		this.sensorData78 = sensorData78;
	}

	public String getSensorId79() {
		return sensorId79;
	}

	public void setSensorId79(String sensorId79) {
		this.sensorId79 = sensorId79;
	}

	public byte[] getSensorData79() {
		return sensorData79;
	}

	public void setSensorData79(byte[] sensorData79) {
		this.sensorData79 = sensorData79;
	}

	public String getSensorId80() {
		return sensorId80;
	}

	public void setSensorId80(String sensorId80) {
		this.sensorId80 = sensorId80;
	}

	public byte[] getSensorData80() {
		return sensorData80;
	}

	public void setSensorData80(byte[] sensorData80) {
		this.sensorData80 = sensorData80;
	}

	public String getSensorId81() {
		return sensorId81;
	}

	public void setSensorId81(String sensorId81) {
		this.sensorId81 = sensorId81;
	}

	public byte[] getSensorData81() {
		return sensorData81;
	}

	public void setSensorData81(byte[] sensorData81) {
		this.sensorData81 = sensorData81;
	}

	public String getSensorId82() {
		return sensorId82;
	}

	public void setSensorId82(String sensorId82) {
		this.sensorId82 = sensorId82;
	}

	public byte[] getSensorData82() {
		return sensorData82;
	}

	public void setSensorData82(byte[] sensorData82) {
		this.sensorData82 = sensorData82;
	}

	public String getSensorId83() {
		return sensorId83;
	}

	public void setSensorId83(String sensorId83) {
		this.sensorId83 = sensorId83;
	}

	public byte[] getSensorData83() {
		return sensorData83;
	}

	public void setSensorData83(byte[] sensorData83) {
		this.sensorData83 = sensorData83;
	}

	public String getSensorId84() {
		return sensorId84;
	}

	public void setSensorId84(String sensorId84) {
		this.sensorId84 = sensorId84;
	}

	public byte[] getSensorData84() {
		return sensorData84;
	}

	public void setSensorData84(byte[] sensorData84) {
		this.sensorData84 = sensorData84;
	}

	public String getSensorId85() {
		return sensorId85;
	}

	public void setSensorId85(String sensorId85) {
		this.sensorId85 = sensorId85;
	}

	public byte[] getSensorData85() {
		return sensorData85;
	}

	public void setSensorData85(byte[] sensorData85) {
		this.sensorData85 = sensorData85;
	}

	public String getSensorId86() {
		return sensorId86;
	}

	public void setSensorId86(String sensorId86) {
		this.sensorId86 = sensorId86;
	}

	public byte[] getSensorData86() {
		return sensorData86;
	}

	public void setSensorData86(byte[] sensorData86) {
		this.sensorData86 = sensorData86;
	}

	public String getSensorId87() {
		return sensorId87;
	}

	public void setSensorId87(String sensorId87) {
		this.sensorId87 = sensorId87;
	}

	public byte[] getSensorData87() {
		return sensorData87;
	}

	public void setSensorData87(byte[] sensorData87) {
		this.sensorData87 = sensorData87;
	}

	public String getSensorId88() {
		return sensorId88;
	}

	public void setSensorId88(String sensorId88) {
		this.sensorId88 = sensorId88;
	}

	public byte[] getSensorData88() {
		return sensorData88;
	}

	public void setSensorData88(byte[] sensorData88) {
		this.sensorData88 = sensorData88;
	}

	public String getSensorId89() {
		return sensorId89;
	}

	public void setSensorId89(String sensorId89) {
		this.sensorId89 = sensorId89;
	}

	public byte[] getSensorData89() {
		return sensorData89;
	}

	public void setSensorData89(byte[] sensorData89) {
		this.sensorData89 = sensorData89;
	}

	public String getSensorId90() {
		return sensorId90;
	}

	public void setSensorId90(String sensorId90) {
		this.sensorId90 = sensorId90;
	}

	public byte[] getSensorData90() {
		return sensorData90;
	}

	public void setSensorData90(byte[] sensorData90) {
		this.sensorData90 = sensorData90;
	}

	public String getSensorId91() {
		return sensorId91;
	}

	public void setSensorId91(String sensorId91) {
		this.sensorId91 = sensorId91;
	}

	public byte[] getSensorData91() {
		return sensorData91;
	}

	public void setSensorData91(byte[] sensorData91) {
		this.sensorData91 = sensorData91;
	}

	public String getSensorId92() {
		return sensorId92;
	}

	public void setSensorId92(String sensorId92) {
		this.sensorId92 = sensorId92;
	}

	public byte[] getSensorData92() {
		return sensorData92;
	}

	public void setSensorData92(byte[] sensorData92) {
		this.sensorData92 = sensorData92;
	}

	public String getSensorId93() {
		return sensorId93;
	}

	public void setSensorId93(String sensorId93) {
		this.sensorId93 = sensorId93;
	}

	public byte[] getSensorData93() {
		return sensorData93;
	}

	public void setSensorData93(byte[] sensorData93) {
		this.sensorData93 = sensorData93;
	}

	public String getSensorId94() {
		return sensorId94;
	}

	public void setSensorId94(String sensorId94) {
		this.sensorId94 = sensorId94;
	}

	public byte[] getSensorData94() {
		return sensorData94;
	}

	public void setSensorData94(byte[] sensorData94) {
		this.sensorData94 = sensorData94;
	}

	public String getSensorId95() {
		return sensorId95;
	}

	public void setSensorId95(String sensorId95) {
		this.sensorId95 = sensorId95;
	}

	public byte[] getSensorData95() {
		return sensorData95;
	}

	public void setSensorData95(byte[] sensorData95) {
		this.sensorData95 = sensorData95;
	}

	public String getSensorId96() {
		return sensorId96;
	}

	public void setSensorId96(String sensorId96) {
		this.sensorId96 = sensorId96;
	}

	public byte[] getSensorData96() {
		return sensorData96;
	}

	public void setSensorData96(byte[] sensorData96) {
		this.sensorData96 = sensorData96;
	}

	public String getSensorId97() {
		return sensorId97;
	}

	public void setSensorId97(String sensorId97) {
		this.sensorId97 = sensorId97;
	}

	public byte[] getSensorData97() {
		return sensorData97;
	}

	public void setSensorData97(byte[] sensorData97) {
		this.sensorData97 = sensorData97;
	}

	public String getSensorId98() {
		return sensorId98;
	}

	public void setSensorId98(String sensorId98) {
		this.sensorId98 = sensorId98;
	}

	public byte[] getSensorData98() {
		return sensorData98;
	}

	public void setSensorData98(byte[] sensorData98) {
		this.sensorData98 = sensorData98;
	}

	public String getSensorId99() {
		return sensorId99;
	}

	public void setSensorId99(String sensorId99) {
		this.sensorId99 = sensorId99;
	}

	public byte[] getSensorData99() {
		return sensorData99;
	}

	public void setSensorData99(byte[] sensorData99) {
		this.sensorData99 = sensorData99;
	}

	private byte[] sensorData0;
    private String sensorId1;
    private byte[] sensorData1;
    private String sensorId2;
    private byte[] sensorData2;
    private String sensorId3;
    private byte[] sensorData3;
    private String sensorId4;
    private byte[] sensorData4;
    private String sensorId5;
    private byte[] sensorData5;
    private String sensorId6;
    private byte[] sensorData6;
    private String sensorId7;
    private byte[] sensorData7;
    private String sensorId8;
    private byte[] sensorData8;
    private String sensorId9;
    private byte[] sensorData9;

    private String sensorId10;
    private byte[] sensorData10;
    private String sensorId11;
    private byte[] sensorData11;
    private String sensorId12;
    private byte[] sensorData12;
    private String sensorId13;
    private byte[] sensorData13;
    private String sensorId14;
    private byte[] sensorData14;
    private String sensorId15;
    private byte[] sensorData15;
    private String sensorId16;
    private byte[] sensorData16;
    private String sensorId17;
    private byte[] sensorData17;
    private String sensorId18;
    private byte[] sensorData18;
    private String sensorId19;
    private byte[] sensorData19;

    private String sensorId20;
    private byte[] sensorData20;
    private String sensorId21;
    private byte[] sensorData21;
    private String sensorId22;
    private byte[] sensorData22;
    private String sensorId23;
    private byte[] sensorData23;
    private String sensorId24;
    private byte[] sensorData24;
    private String sensorId25;
    private byte[] sensorData25;
    private String sensorId26;
    private byte[] sensorData26;
    private String sensorId27;
    private byte[] sensorData27;
    private String sensorId28;
    private byte[] sensorData28;
    private String sensorId29;
    private byte[] sensorData29;

    private String sensorId30;
    private byte[] sensorData30;
    private String sensorId31;
    private byte[] sensorData31;
    private String sensorId32;
    private byte[] sensorData32;
    private String sensorId33;
    private byte[] sensorData33;
    private String sensorId34;
    private byte[] sensorData34;
    private String sensorId35;
    private byte[] sensorData35;
    private String sensorId36;
    private byte[] sensorData36;
    private String sensorId37;
    private byte[] sensorData37;
    private String sensorId38;
    private byte[] sensorData38;
    private String sensorId39;
    private byte[] sensorData39;

    private String sensorId40;
    private byte[] sensorData40;
    private String sensorId41;
    private byte[] sensorData41;
    private String sensorId42;
    private byte[] sensorData42;
    private String sensorId43;
    private byte[] sensorData43;
    private String sensorId44;
    private byte[] sensorData44;
    private String sensorId45;
    private byte[] sensorData45;
    private String sensorId46;
    private byte[] sensorData46;
    private String sensorId47;
    private byte[] sensorData47;
    private String sensorId48;
    private byte[] sensorData48;
    private String sensorId49;
    private byte[] sensorData49;

    private String sensorId50;
    private byte[] sensorData50;
    private String sensorId51;
    private byte[] sensorData51;
    private String sensorId52;
    private byte[] sensorData52;
    private String sensorId53;
    private byte[] sensorData53;
    private String sensorId54;
    private byte[] sensorData54;
    private String sensorId55;
    private byte[] sensorData55;
    private String sensorId56;
    private byte[] sensorData56;
    private String sensorId57;
    private byte[] sensorData57;
    private String sensorId58;
    private byte[] sensorData58;
    private String sensorId59;
    private byte[] sensorData59;

    private String sensorId60;
    private byte[] sensorData60;
    private String sensorId61;
    private byte[] sensorData61;
    private String sensorId62;
    private byte[] sensorData62;
    private String sensorId63;
    private byte[] sensorData63;
    private String sensorId64;
    private byte[] sensorData64;
    private String sensorId65;
    private byte[] sensorData65;
    private String sensorId66;
    private byte[] sensorData66;
    private String sensorId67;
    private byte[] sensorData67;
    private String sensorId68;
    private byte[] sensorData68;
    private String sensorId69;
    private byte[] sensorData69;

    private String sensorId70;
    private byte[] sensorData70;
    private String sensorId71;
    private byte[] sensorData71;
    private String sensorId72;
    private byte[] sensorData72;
    private String sensorId73;
    private byte[] sensorData73;
    private String sensorId74;
    private byte[] sensorData74;
    private String sensorId75;
    private byte[] sensorData75;
    private String sensorId76;
    private byte[] sensorData76;
    private String sensorId77;
    private byte[] sensorData77;
    private String sensorId78;
    private byte[] sensorData78;
    private String sensorId79;
    private byte[] sensorData79;

    private String sensorId80;
    private byte[] sensorData80;
    private String sensorId81;
    private byte[] sensorData81;
    private String sensorId82;
    private byte[] sensorData82;
    private String sensorId83;
    private byte[] sensorData83;
    private String sensorId84;
    private byte[] sensorData84;
    private String sensorId85;
    private byte[] sensorData85;
    private String sensorId86;
    private byte[] sensorData86;
    private String sensorId87;
    private byte[] sensorData87;
    private String sensorId88;
    private byte[] sensorData88;
    private String sensorId89;
    private byte[] sensorData89;

    private String sensorId90;
    private byte[] sensorData90;
    private String sensorId91;
    private byte[] sensorData91;
    private String sensorId92;
    private byte[] sensorData92;
    private String sensorId93;
    private byte[] sensorData93;
    private String sensorId94;
    private byte[] sensorData94;
    private String sensorId95;
    private byte[] sensorData95;
    private String sensorId96;
    private byte[] sensorData96;
    private String sensorId97;
    private byte[] sensorData97;
    private String sensorId98;
    private byte[] sensorData98;
    private String sensorId99;
    private byte[] sensorData99;
}