package com.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.entity.DeviceGroupDeviceEntity;
import com.app.model.DeviceGroupDeviceModel;
import com.app.model.DeviceGroupDeviceQueryModel;
import com.app.repository.DeviceGroupDeviceRepository;

@Service
@Transactional(readOnly = true)
public class DeviceGroupDeviceService {

	@Autowired
	private DeviceGroupDeviceRepository DeviceGroupDeviceRepository;

	public List<DeviceGroupDeviceModel> findAll(DeviceGroupDeviceQueryModel filter) throws Exception{

		//取得フィールド処理
		ModelFilter mf = makeModelFilter(filter.getFields());

		List<String> sort = new ArrayList<String>();
		if (filter.getSort() != null) {
			for (String item : filter.getSort().split(",")) {
				sort.add(item.trim().toLowerCase());
			}
		}

		//ページング処理
		Integer limit = null;
		Integer offset = null;
		if (filter.getPage() != null && filter.getLimit() != null) {
			limit = Integer.parseInt(filter.getLimit());
			offset = (Integer.parseInt(filter.getPage()) - 1) * limit;
		}

		List<DeviceGroupDeviceEntity> entList = DeviceGroupDeviceRepository.findAll(filter, sort, limit, offset);

		// 返却項目フィルタ処理
		List<DeviceGroupDeviceModel> modelList = new ArrayList<DeviceGroupDeviceModel>();
		for (DeviceGroupDeviceEntity entity : entList) {
			DeviceGroupDeviceModel newModel = new DeviceGroupDeviceModel();
			if (mf.device_group_list) newModel.setDevice_group_list(entity.getDevice_group_list());
			if (mf.level) newModel.setLevel(entity.getLevel());
			if (mf.model_id) newModel.setModel_id(entity.getModel_id());
			if (mf.serial_no) newModel.setSerial_no(entity.getSerial_no());
			modelList.add(newModel);
		}
		return modelList;
	}


	/**
	 * 返却項目フィルター作成
	 * @param fields 取得対象項目名リスト（カンマ区切り）
	 * @return フィルターオブジェクト
	 */
	private ModelFilter makeModelFilter(String fields) {
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if ("device_group_list".equals(str)) mf.device_group_list = true;
				if ("level".equals(str)) mf.level = true;
				if ("model_id".equals(str)) mf.model_id = true;
				if ("serial_no".equals(str)) mf.serial_no = true;
			}
		}
		return mf;
	}

	/**
	 * 返却項目フィルタークラス
	 * true=返却する。false=返却しない。
	 * @author 1572
	 *
	 */
	class ModelFilter {
		public ModelFilter(boolean b) {
			device_group_list = b;
			level = b;
			model_id = b;
			serial_no = b;
		}
		public boolean device_group_list = true;
		public boolean level = true;
		public boolean model_id = true;
		public boolean serial_no = true;
	}

}

