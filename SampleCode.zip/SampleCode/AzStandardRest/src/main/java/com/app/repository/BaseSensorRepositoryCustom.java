package com.app.repository;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.app.entity.MstBaseSensorEntity;
import com.app.model.BaseSensorQueryModel;

public interface BaseSensorRepositoryCustom {
	List<MstBaseSensorEntity> findAll(BaseSensorQueryModel query, List<String> sort, Integer limit, Integer offset);
	Long countAll(BaseSensorQueryModel query);

    MstBaseSensorEntity findOneForUpdate(@Param("id") int id);
}