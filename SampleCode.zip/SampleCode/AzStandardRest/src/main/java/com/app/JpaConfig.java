package com.app;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import com.app.filter.AuthUserInfoComponent;

/**
 * JPA 監査情報自動登録JavaConfigクラス
 * ServletFilterで仕込んだ認証情報コンポーネントからユーザIDを取得してセットします
 * @author 1168
 *
 */
@EnableJpaAuditing
@Configuration
public class JpaConfig {



    @Bean
    public AuditorAware<String> auditorAware()
    {
        return new SecurityAuditor();
    }


    public static class SecurityAuditor implements AuditorAware<String>
    {
    	@Autowired
    	AuthUserInfoComponent  authUserInfoComponent;

        @Override
        public String getCurrentAuditor()
        {
            return  authUserInfoComponent.getPrincipalName();
        }
    }

}
