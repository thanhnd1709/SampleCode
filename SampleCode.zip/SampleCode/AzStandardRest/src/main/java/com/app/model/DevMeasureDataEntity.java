package com.app.model;

import java.awt.List;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import com.microsoft.azure.storage.table.TableServiceEntity;

public class DevMeasureDataEntity extends TableServiceEntity{
	public String MessageClass ;

    public byte[] Data0 ;
    public byte[] Data1 ;
    public byte[] Data2 ;
    public byte[] Data3 ;
    public byte[] Data4 ;
    public byte[] Data5 ;
    public byte[] Data6 ;
    public byte[] Data7 ;
    public byte[] Data8 ;
    public byte[] Data9 ;
    public byte[] Data10 ;
    public byte[] Data11 ;
    public byte[] Data12 ;
    public byte[] Data13 ;
    public byte[] Data14 ;
    
    public String getMessageClass() {
		return MessageClass;
	}
	public void setMessageClass(String messageClass) {
		MessageClass = messageClass;
	}
	public byte[] getData0() {
		return Data0;
	}
	public void setData0(byte[] data0) {
		Data0 = data0;
	}
	public byte[] getData1() {
		return Data1;
	}
	public void setData1(byte[] data1) {
		Data1 = data1;
	}
	public byte[] getData2() {
		return Data2;
	}
	public void setData2(byte[] data2) {
		Data2 = data2;
	}
	public byte[] getData3() {
		return Data3;
	}
	public void setData3(byte[] data3) {
		Data3 = data3;
	}
	public byte[] getData4() {
		return Data4;
	}
	public void setData4(byte[] data4) {
		Data4 = data4;
	}
	public byte[] getData5() {
		return Data5;
	}
	public void setData5(byte[] data5) {
		Data5 = data5;
	}
	public byte[] getData6() {
		return Data6;
	}
	public void setData6(byte[] data6) {
		Data6 = data6;
	}
	public byte[] getData7() {
		return Data7;
	}
	public void setData7(byte[] data7) {
		Data7 = data7;
	}
	public byte[] getData8() {
		return Data8;
	}
	public void setData8(byte[] data8) {
		Data8 = data8;
	}
	public byte[] getData9() {
		return Data9;
	}
	public void setData9(byte[] data9) {
		Data9 = data9;
	}
	public byte[] getData10() {
		return Data10;
	}
	public void setData10(byte[] data10) {
		Data10 = data10;
	}
	public byte[] getData11() {
		return Data11;
	}
	public void setData11(byte[] data11) {
		Data11 = data11;
	}
	public byte[] getData12() {
		return Data12;
	}
	public void setData12(byte[] data12) {
		Data12 = data12;
	}
	public byte[] getData13() {
		return Data13;
	}
	public void setData13(byte[] data13) {
		Data13 = data13;
	}
	public byte[] getData14() {
		return Data14;
	}
	public void setData14(byte[] data14) {
		Data14 = data14;
	}
	public String getData() {
		 String str = "";
		try {
			str = new String(Data0, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return str;
	}
    
}
