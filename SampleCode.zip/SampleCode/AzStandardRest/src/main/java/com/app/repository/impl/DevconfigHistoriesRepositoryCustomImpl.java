package com.app.repository.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.ParameterExpression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.common.utils.StringUtil;
import com.app.entity.StdDevconfigHistoryEntity;
import com.app.model.DevconfigHistoriesQueryModel;
import com.app.repository.DevconfigHistoriesRepositoryCustom;

@Component
public class DevconfigHistoriesRepositoryCustomImpl implements DevconfigHistoriesRepositoryCustom {

	// SQL FUNCTIONの引数のデフォルト値
	private static final String SQL_FUNC_DEFAULT_VAL = "";
	@Autowired EntityManager em;

	@Override
	public StdDevconfigHistoryEntity findOneForUpdate(int id) {
		return em.find(StdDevconfigHistoryEntity.class, id, LockModeType.PESSIMISTIC_WRITE);
	}

	@Override
	public Long countAll(DevconfigHistoriesQueryModel query) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = builder.createQuery(Long.class);
		Root<StdDevconfigHistoryEntity> root = criteriaQuery.from(StdDevconfigHistoryEntity.class);
		criteriaQuery.select(builder.count(root));
		List<Predicate> conditionList = buildConditionList(query, root);

		CriteriaBuilder cb = em.getCriteriaBuilder();

		ParameterExpression<Integer> ret = cb.parameter(int.class);
		ParameterExpression <String>user = cb.parameter(String.class);
		ParameterExpression <String>defaultVal = cb.parameter(String.class);

		conditionList.add(builder.equal(ret ,cb.function("dbo.fn_ConfigAuthChk", int.class,root.get("model_id") ,root.get("serial_no"),root.get("config_id"),user,defaultVal,defaultVal)));

		if( conditionList.size() > 0 ){
			criteriaQuery.where(conditionList.toArray(new Predicate[conditionList.size()]));
		}

		TypedQuery<Long> q =em.createQuery(criteriaQuery);

		q.setParameter(ret, 1);
		q.setParameter(user, query.getUser_id());
		q.setParameter(defaultVal, SQL_FUNC_DEFAULT_VAL);

		return q.getSingleResult().longValue();
	}

	@Override
	public List<StdDevconfigHistoryEntity> findAll(DevconfigHistoriesQueryModel query, List<String> sort, Integer limit, Integer offset) {

		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<StdDevconfigHistoryEntity> criteriaQuery = builder.createQuery(StdDevconfigHistoryEntity.class);
		Root<StdDevconfigHistoryEntity> root = criteriaQuery.from(StdDevconfigHistoryEntity.class);
		List<Predicate> conditionList = buildConditionList(query, root);

		CriteriaBuilder cb = em.getCriteriaBuilder();

		ParameterExpression<Integer> ret = cb.parameter(int.class);
		ParameterExpression <String>user = cb.parameter(String.class);
		ParameterExpression <String>defaultVal = cb.parameter(String.class);

		conditionList.add(builder.equal(ret ,cb.function("dbo.fn_ConfigAuthChk", int.class,root.get("model_id") ,root.get("serial_no"),root.get("config_id"),user,defaultVal,defaultVal)));

		if(conditionList.size() > 0){
			criteriaQuery.where(conditionList.toArray(new Predicate[conditionList.size()]));
		}

		if (sort.size() > 0) {
			List<Order> orderList = new ArrayList<Order>();
			for (String col : sort) {
				if (col.startsWith("-")) {
					orderList.add(builder.desc(root.get(col.substring(1))));
				} else {
					orderList.add(builder.asc(root.get(col)));
				}
			}
			criteriaQuery.orderBy(orderList);
		}

		TypedQuery<StdDevconfigHistoryEntity> q = em.createQuery(criteriaQuery);
		q.setParameter(ret, 1);
		q.setParameter(user, query.getUser_id());
		q.setParameter(defaultVal, "");
		if (offset != null) q.setFirstResult(offset);
		if (limit != null) q.setMaxResults(limit);

		return q.getResultList();
	}

	public <T> long count(List<Predicate> conditionList, Class<T> entity) {
		CriteriaBuilder builder = em.getCriteriaBuilder();
		CriteriaQuery<Long> criteriaQuery = builder.createQuery(Long.class);
		Root<T> root = criteriaQuery.from(entity);
		criteriaQuery.select(builder.count(root));
		if( conditionList.size() > 0 ){
			criteriaQuery.where(conditionList.toArray(new Predicate[conditionList.size()]));
		}
		return em.createQuery(criteriaQuery).getSingleResult().longValue();
	}

	private List<Predicate> buildConditionList(DevconfigHistoriesQueryModel query, Root<StdDevconfigHistoryEntity> root) {
		List<Predicate> conditionList = new ArrayList<>();
		if (query.getId() != null && query.getId().length > 0) {
			Object[] arr = Stream.of(query.getId()).map(StringUtil.String2Integer).toArray();
			conditionList.add(root.get("id").in(Arrays.asList(arr)));
		}
		if (query.getModel_id() != null && query.getModel_id().length > 0) {
			conditionList.add(root.get("model_id").in(Arrays.asList(query.getModel_id())));
		}
		if (query.getSerial_no() != null && query.getSerial_no().length > 0) {
			conditionList.add(root.get("serial_no").in(Arrays.asList(query.getSerial_no())));
		}
		if (query.getConfig_id() != null && query.getConfig_id().length > 0) {
			conditionList.add(root.get("config_id").in(Arrays.asList(query.getConfig_id())));
		}
		if (query.getConfig_file() != null && query.getConfig_file().length > 0) {
			conditionList.add(root.get("config_file").in(Arrays.asList(query.getConfig_file())));
		}
		if (query.getGw_upload_time() != null && query.getGw_upload_time().length > 0) {
			Object[] arr = Stream.of(query.getGw_upload_time()).map(StringUtil.String2Timestamp).toArray();
			conditionList.add(root.get("gw_upload_time").in(Arrays.asList(arr)));
		}
		if (query.getFormat_version() != null && query.getFormat_version().length > 0) {
			conditionList.add(root.get("format_version").in(Arrays.asList(query.getFormat_version())));
		}
		if (query.getConfig_version() != null && query.getConfig_version().length > 0) {
			conditionList.add(root.get("config_version").in(Arrays.asList(query.getConfig_version())));
		}
		if (query.getFile_notification_key() != null && query.getFile_notification_key().length > 0) {
			conditionList.add(root.get("file_notification_key").in(Arrays.asList(query.getFile_notification_key())));
		}
		if (query.getRegist_flg() != null && query.getRegist_flg().length > 0) {
			Object[] arr = Stream.of(query.getRegist_flg()).map(StringUtil.String2Boolean).toArray();
			conditionList.add(root.get("regist_flg").in(Arrays.asList(arr)));
		}
		if (query.getResult_send_id() != null && query.getResult_send_id().length > 0) {
			Object[] arr = Stream.of(query.getResult_send_id()).map(StringUtil.String2Long).toArray();
			conditionList.add(root.get("result_send_id").in(Arrays.asList(arr)));
		}
		if (query.getVersion() != null && query.getVersion().length > 0) {
			Object[] arr = Stream.of(query.getVersion()).map(StringUtil.String2Long).toArray();
			conditionList.add(root.get("version").in(Arrays.asList(arr)));
		}
		if (query.getInsert_time() != null && query.getInsert_time().length > 0) {
			Object[] arr = Stream.of(query.getInsert_time()).map(StringUtil.String2Timestamp).toArray();
			conditionList.add(root.get("insert_time").in(Arrays.asList(arr)));
		}
		if (query.getUpdate_time() != null && query.getUpdate_time().length > 0) {
			Object[] arr = Stream.of(query.getUpdate_time()).map(StringUtil.String2Timestamp).toArray();
			conditionList.add(root.get("update_time").in(Arrays.asList(arr)));
		}
		return conditionList;
	}
}