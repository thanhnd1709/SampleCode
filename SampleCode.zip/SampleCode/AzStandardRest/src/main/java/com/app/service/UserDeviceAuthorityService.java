package com.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.entity.UserDeviceAuthorityEntity;
import com.app.model.UserDeviceAuthorityModel;
import com.app.model.UserDeviceAuthorityQueryModel;
import com.app.repository.UserDeviceAuthorityRepository;

/**
 * ユーザ・デバイス権限情報サービスクラス
 * @author 1572
 *
 */
@Service
@Transactional(readOnly = true)
public class UserDeviceAuthorityService {
	@Autowired
	private UserDeviceAuthorityRepository UserDeviceAuthorityRepository;

	/**
	 * ユーザ・デバイス権限情報一覧取得
	 * @param filter 検索条件オブジェクト
	 * @return ユーザ・デバイス権限情報リスト
	 * @throws Exception
	 */
	public List<UserDeviceAuthorityModel> findAll(UserDeviceAuthorityQueryModel filter) throws Exception {

		ModelFilter mf = makeModelFilter(filter.getFields());

		List<String> sort = new ArrayList<String>();
		if (filter.getSort() != null) {
			for (String item : filter.getSort().split(",")) {
				sort.add(item.trim().toLowerCase());
			}
		}

		Integer limit = null;
		Integer offset = null;
		if (filter.getPage() != null && filter.getLimit() != null) {
			limit = Integer.parseInt(filter.getLimit());
			offset = (Integer.parseInt(filter.getPage()) - 1) * limit;
		}

		// 検索実行
		List<UserDeviceAuthorityEntity> entList = UserDeviceAuthorityRepository.findAll(filter, sort, limit, offset);

		// 返却項目フィルタ処理
		List<UserDeviceAuthorityModel> modelList = new ArrayList<UserDeviceAuthorityModel>();
		for (UserDeviceAuthorityEntity entity : entList) {
			UserDeviceAuthorityModel newModel = new UserDeviceAuthorityModel();
			if (mf.model_id)
				newModel.setModel_id(entity.getModel_id());
			if (mf.serial_no)
				newModel.setSerial_no(entity.getSerial_no());
			if (mf.device_type)
				newModel.setDevice_type(entity.getDevice_type());
			if (mf.iot_device_flg)
				newModel.setIot_device_flg(entity.getIot_device_flg());
			if (mf.communication_flg)
				newModel.setCommunication_flg(entity.getCommunication_flg());
			if (mf.device_name_locale1)
				newModel.setDevice_name_locale1(entity.getDevice_name_locale1());
			if (mf.device_name_locale2)
				newModel.setDevice_name_locale2(entity.getDevice_name_locale2());
			if (mf.device_name_locale3)
				newModel.setDevice_name_locale3(entity.getDevice_name_locale3());
			if (mf.device_description_locale1)
				newModel.setDevice_description_locale1(entity.getDevice_description_locale1());
			if (mf.device_description_locale2)
				newModel.setDevice_description_locale2(entity.getDevice_description_locale2());
			if (mf.device_description_locale3)
				newModel.setDevice_description_locale3(entity.getDevice_description_locale3());
			if (mf.maker_code)
				newModel.setMaker_code(entity.getMaker_code());
			if (mf.parent_model_id)
				newModel.setParent_model_id(entity.getParent_model_id());
			if (mf.parent_serial_no)
				newModel.setParent_serial_no(entity.getParent_serial_no());
			if (mf.setup_place)
				newModel.setSetup_place(entity.getSetup_place());
			if (mf.setup_status)
				newModel.setSetup_status(entity.getSetup_status());
			if (mf.time_zone)
				newModel.setTime_zone(entity.getTime_zone());
			if (mf.latitude)
				newModel.setLatitude(entity.getLatitude());
			if (mf.longitude)
				newModel.setLongitude(entity.getLongitude());
			if (mf.device_mode)
				newModel.setDevice_mode(entity.getDevice_mode());
			if (mf.unreceive_seconds)
				newModel.setUnreceive_seconds(entity.getUnreceive_seconds());
			if (mf.device_note)
				newModel.setDevice_note(entity.getDevice_note());
			if (mf.device_group_id)
				newModel.setDevice_group_id(entity.getDevice_group_id());
			if (mf.device_group_type)
				newModel.setDevice_group_type(entity.getDevice_group_type());
			if (mf.device_group_subtype)
				newModel.setDevice_group_subtype(entity.getDevice_group_subtype());
			if (mf.device_group_name_locale1)
				newModel.setDevice_group_name_locale1(entity.getDevice_group_name_locale1());
			if (mf.device_group_name_locale2)
				newModel.setDevice_group_name_locale2(entity.getDevice_group_name_locale2());
			if (mf.device_group_name_locale3)
				newModel.setDevice_group_name_locale3(entity.getDevice_group_name_locale3());
			if (mf.device_group_description_locale1)
				newModel.setDevice_group_description_locale1(entity.getDevice_group_description_locale1());
			if (mf.device_group_description_locale2)
				newModel.setDevice_group_description_locale2(entity.getDevice_group_description_locale2());
			if (mf.device_group_description_locale3)
				newModel.setDevice_group_description_locale3(entity.getDevice_group_description_locale3());
			if (mf.parent_device_group_id)
				newModel.setParent_device_group_id(entity.getParent_device_group_id());
			if (mf.device_group_note)
				newModel.setDevice_group_note(entity.getDevice_group_note());
			if (mf.role_id)	
				newModel.setRole_id(entity.getRole_id());
			if (mf.root_group_id)
				newModel.setRoot_group_id(entity.getRoot_group_id());
			if (mf.role_name_locale1)
				newModel.setRole_name_locale1(entity.getRole_name_locale1());
			if (mf.role_name_locale2)
				newModel.setRole_name_locale2(entity.getRole_name_locale2());
			if (mf.role_name_locale3)
				newModel.setRole_name_locale3(entity.getRole_name_locale3());
			if (mf.role_description_locale1)
				newModel.setRole_description_locale1(entity.getRole_description_locale1());
			if (mf.role_description_locale2)
				newModel.setRole_description_locale2(entity.getRole_description_locale2());
			if (mf.role_description_locale3)
				newModel.setRole_description_locale3(entity.getRole_description_locale3());
			if (mf.role_note)
				newModel.setRole_note(entity.getRole_note());
			if (mf.hierarchy)
				newModel.setHierarchy(entity.getHierarchy());

			modelList.add(newModel);
		}
		return modelList;
	}

	/**
	 * ユーザ・デバイス権限情報一覧件数取得
	 * 
	 * @param filter
	 *            検索条件オブジェクト
	 * @return 検索結果件数
	 * @throws Exception
	 */
	public Long countAll(UserDeviceAuthorityQueryModel filter) throws Exception {
		return UserDeviceAuthorityRepository.countAll(filter);
	}

	/**
	 * 返却項目フィルター作成
	 * 
	 * @param fields
	 *            取得対象項目名リスト（カンマ区切り）
	 * @return フィルターオブジェクト
	 */
	private ModelFilter makeModelFilter(String fields) {
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if ("model_id".equals(str))
					mf.model_id = true;
				if ("serial_no".equals(str))
					mf.serial_no = true;
				if ("device_type".equals(str))
					mf.device_type = true;
				if ("iot_device_flg".equals(str))
					mf.iot_device_flg = true;
				if ("communication_flg".equals(str))
					mf.communication_flg = true;
				if ("device_name_locale1".equals(str))
					mf.device_name_locale1 = true;
				if ("device_name_locale2".equals(str))
					mf.device_name_locale2 = true;
				if ("device_name_locale3".equals(str))
					mf.device_name_locale3 = true;
				if ("device_description_locale1".equals(str))
					mf.device_description_locale1 = true;
				if ("device_description_locale2".equals(str))
					mf.device_description_locale2 = true;
				if ("device_description_locale3".equals(str))
					mf.device_description_locale3 = true;
				if ("maker_code".equals(str))
					mf.maker_code = true;
				if ("parent_model_id".equals(str))
					mf.parent_model_id = true;
				if ("parent_serial_no".equals(str))
					mf.parent_serial_no = true;
				if ("setup_place".equals(str))
					mf.setup_place = true;
				if ("setup_status".equals(str))
					mf.setup_status = true;
				if ("time_zone".equals(str))
					mf.time_zone = true;
				if ("latitude".equals(str))
					mf.latitude = true;
				if ("longitude".equals(str))
					mf.longitude = true;
				if ("device_mode".equals(str))
					mf.device_mode = true;
				if ("unreceive_seconds".equals(str))
					mf.unreceive_seconds = true;
				if ("device_note".equals(str))
					mf.device_note = true;
				if ("device_group_id".equals(str))
					mf.device_group_id = true;
				if ("device_group_type".equals(str))
					mf.device_group_type = true;
				if ("device_group_subtype".equals(str))
					mf.device_group_subtype = true;
				if ("device_group_name_locale1".equals(str))
					mf.device_group_name_locale1 = true;
				if ("device_group_name_locale2".equals(str))
					mf.device_group_name_locale2 = true;
				if ("device_group_name_locale3".equals(str))
					mf.device_group_name_locale3 = true;
				if ("device_group_description_locale1".equals(str))
					mf.device_group_description_locale1 = true;
				if ("device_group_description_locale2".equals(str))
					mf.device_group_description_locale2 = true;
				if ("device_group_description_locale3".equals(str))
					mf.device_group_description_locale3 = true;
				if ("parent_device_group_id".equals(str))
					mf.parent_device_group_id = true;
				if ("device_group_note".equals(str))
					mf.device_group_note = true;
				if ("role_id".equals(str))
					mf.role_id = true;
				if ("root_group_id".equals(str))
					mf.root_group_id = true;
				if ("role_name_locale1".equals(str))
					mf.role_name_locale1 = true;
				if ("role_name_locale2".equals(str))
					mf.role_name_locale2 = true;
				if ("role_name_locale3".equals(str))
					mf.role_name_locale3 = true;
				if ("role_description_locale1".equals(str))
					mf.role_description_locale1 = true;
				if ("role_description_locale2".equals(str))
					mf.role_description_locale2 = true;
				if ("role_description_locale3".equals(str))
					mf.role_description_locale3 = true;
				if ("role_note".equals(str))
					mf.role_note = true;
				if ("hierarchy".equals(str))
					mf.hierarchy = true;
			}
		}
		return mf;
	}

	/**
	 * 返却項目フィルタークラス true=返却する。false=返却しない。
	 * 
	 * @author 1572
	 */
	class ModelFilter {
		public ModelFilter(boolean b) {
			model_id = b;
			serial_no = b;
			device_type = b;
			iot_device_flg = b;
			communication_flg = b;
			device_name_locale1 = b;
			device_name_locale2 = b;
			device_name_locale3 = b;
			device_description_locale1 = b;
			device_description_locale2 = b;
			device_description_locale3 = b;
			maker_code = b;
			parent_model_id = b;
			parent_serial_no = b;
			setup_place = b;
			setup_status = b;
			time_zone = b;
			latitude = b;
			longitude = b;
			device_mode = b;
			unreceive_seconds = b;
			device_note = b;
			device_group_id = b;
			device_group_type = b;
			device_group_subtype = b;
			device_group_name_locale1 = b;
			device_group_name_locale2 = b;
			device_group_name_locale3 = b;
			device_group_description_locale1 = b;
			device_group_description_locale2 = b;
			device_group_description_locale3 = b;
			parent_device_group_id = b;
			device_group_note = b;
			role_id = b;
			root_group_id = b;
			role_name_locale1 = b;
			role_name_locale2 = b;
			role_name_locale3 = b;
			role_description_locale1 = b;
			role_description_locale2 = b;
			role_description_locale3 = b;
			role_note = b;
			hierarchy = b;
		}

		public boolean model_id = true;
		public boolean serial_no = true;
		public boolean device_type = true;
		public boolean iot_device_flg = true;
		public boolean communication_flg = true;
		public boolean device_name_locale1 = true;
		public boolean device_name_locale2 = true;
		public boolean device_name_locale3 = true;
		public boolean device_description_locale1 = true;
		public boolean device_description_locale2 = true;
		public boolean device_description_locale3 = true;
		public boolean maker_code = true;
		public boolean parent_model_id = true;
		public boolean parent_serial_no = true;
		public boolean setup_place = true;
		public boolean setup_status = true;
		public boolean time_zone = true;
		public boolean latitude = true;
		public boolean longitude = true;
		public boolean device_mode = true;
		public boolean unreceive_seconds = true;
		public boolean device_note = true;
		public boolean device_group_id = true;
		public boolean device_group_type = true;
		public boolean device_group_subtype = true;
		public boolean device_group_name_locale1 = true;
		public boolean device_group_name_locale2 = true;
		public boolean device_group_name_locale3 = true;
		public boolean device_group_description_locale1 = true;
		public boolean device_group_description_locale2 = true;
		public boolean device_group_description_locale3 = true;
		public boolean parent_device_group_id = true;
		public boolean device_group_note = true;
		public boolean role_id = true;
		public boolean root_group_id = true;
		public boolean role_name_locale1 = true;
		public boolean role_name_locale2 = true;
		public boolean role_name_locale3 = true;
		public boolean role_description_locale1 = true;
		public boolean role_description_locale2 = true;
		public boolean role_description_locale3 = true;
		public boolean role_note = true;
		public boolean hierarchy = true;

	}
}
