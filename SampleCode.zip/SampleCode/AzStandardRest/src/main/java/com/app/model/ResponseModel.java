package com.app.model;


import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * エラー情報モデルクラス
 * @author（TOSCO）ウェイ
 */
public class ResponseModel {

    // エラーコードの値
    public int code;
    // エラーコードの理由フレーズ
    public String message;
    // エラー詳細
    @JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY)
    public String detail;

    // 複数エラー詳細
    @JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
    public List<SubResponseModel> details;

    public ResponseModel(int code
    						, String message
    						, String detail) {
        this.code = code;
        this.message = message;
        this.detail = detail;
        this.details = null;
    }

    public ResponseModel(int code
							, String message
							, List<SubResponseModel> details) {
		this.code = code;
		this.message = message;
		this.detail = "";
		this.details = details;
	}
}
