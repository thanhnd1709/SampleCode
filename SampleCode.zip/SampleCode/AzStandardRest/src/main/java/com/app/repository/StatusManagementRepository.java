package com.app.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.entity.StdEventIncidenceEntity;

@Repository
public interface StatusManagementRepository extends JpaRepository<StdEventIncidenceEntity, Integer>, StatusManagementRepositoryCustom {

}