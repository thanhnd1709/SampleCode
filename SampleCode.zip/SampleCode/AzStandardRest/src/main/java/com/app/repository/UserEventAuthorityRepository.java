package com.app.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.entity.UserEventAuthorityEntity;

/**
 * ユーザ・イベント権限情報リポジトリ
 * @author 1625
 *
 */
@Repository
public interface UserEventAuthorityRepository extends JpaRepository<UserEventAuthorityEntity, Integer>, UserEventAuthorityRepositoryCustom {
}