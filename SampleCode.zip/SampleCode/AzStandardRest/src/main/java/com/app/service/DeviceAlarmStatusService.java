package com.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.entity.DeviceAlarmStatusEntity;
import com.app.model.DeviceAlarmStatusModel;
import com.app.model.ResponseDeviceAlarmStatusModel;
import com.app.repository.imple.EventStatusRepositoryCustomImple;

/**
 * デバイスアラーム状態取得サービスクラス
 * @author 810
 *
 */
@Service
@Transactional(readOnly = true)
public class DeviceAlarmStatusService {

	@Autowired
	private EventStatusRepositoryCustomImple eventStatusRepository;

	// 取得情報区分 2:配下最大イベントレベル
	private static final String INFO_CLASS_RECURSIVE = "2";

	/**
	 * 各デバイスのイベント状態から、最大のイベントレベルを取得する。
	 * @param デバイスアラーム状態検索条件
	 * @return デバイスアラーム状態リスト
	 */
	public List<ResponseDeviceAlarmStatusModel> getDeviceAlarmStatus(DeviceAlarmStatusModel reqModel) throws Exception{

		List<ResponseDeviceAlarmStatusModel> lstDeviceAlarmStatus = new ArrayList<>();

		List<String> sort = new ArrayList<String>();
		if (reqModel.getSort() != null) {
			for (String item : reqModel.getSort().split(",")) {
				sort.add(item.trim().toLowerCase());
			}
		}

		Integer limit = null;
		Integer offset = null;
		if (reqModel.getPage() != null && reqModel.getLimit() != null) {
			limit = Integer.parseInt(reqModel.getLimit());
			offset = (Integer.parseInt(reqModel.getPage()) - 1) * limit;
		}

		List<DeviceAlarmStatusEntity> eventList = null;
		if (INFO_CLASS_RECURSIVE.equals(reqModel.getGet_info_class())) {
			// 指定デバイスの配下を含む情報を取得
			eventList = eventStatusRepository.searchDeviceAlarmStatusRecursive(reqModel, sort, limit, offset);
		} else {
			// 指定デバイスの情報を取得
			eventList = eventStatusRepository.searchDeviceAlarmStatus(reqModel, sort, limit, offset);
		}

		ModelFilter mf = makeModelFilter(reqModel.getFields());
		for (DeviceAlarmStatusEntity ev : eventList) {
			ResponseDeviceAlarmStatusModel model = new ResponseDeviceAlarmStatusModel();
			if (mf.model_id) model.setModel_id(ev.getModel_id());
			if (mf.serial_no) model.setSerial_no(ev.getSerial_no());
			if (mf.detection_class) model.setDetection_class(ev.getDetection_class());
			if (mf.max_event_level) model.setMax_event_level(ev.getMax_event_level());
			lstDeviceAlarmStatus.add(model);
		}

		return lstDeviceAlarmStatus;
	}

	public Long countAll(DeviceAlarmStatusModel reqModel) throws Exception{
		if (INFO_CLASS_RECURSIVE.equals(reqModel.getGet_info_class())) {
			// 指定デバイスの配下を含む情報を取得
			return eventStatusRepository.countDeviceAlarmStatusRecursive(reqModel);
		} else {
			// 指定デバイスの情報を取得
			return eventStatusRepository.countDeviceAlarmStatus(reqModel);
		}
	}

	/**
	 * 返却項目フィルター作成
	 * @param fields 取得対象項目名リスト（カンマ区切り）
	 * @return フィルターオブジェクト
	 */
	private ModelFilter makeModelFilter(String fields) {
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if ("model_id".equals(str)) mf.model_id = true;
				if ("serial_no".equals(str)) mf.serial_no = true;
				if ("detection_class".equals(str)) mf.detection_class = true;
				if ("max_event_level".equals(str)) mf.max_event_level = true;
			}
		}
		return mf;
	}

	/**
	 * 返却項目フィルタークラス
	 * true=返却する。false=返却しない。
	 * @author 810
	 *
	 */
	class ModelFilter {
		public ModelFilter(boolean b) {
			model_id = b;
			serial_no = b;
			detection_class = b;
			max_event_level = b;
		}
		public boolean model_id = true;
		public boolean serial_no = true;
		public boolean detection_class = true;
		public boolean max_event_level = true;
	}

}
