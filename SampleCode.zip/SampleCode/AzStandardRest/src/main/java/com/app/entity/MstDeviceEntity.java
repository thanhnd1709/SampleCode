package com.app.entity;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Version;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 */
@Entity
@Table(name="mst_device")
@Data
@EntityListeners(AuditingEntityListener.class)
@AllArgsConstructor
@NoArgsConstructor
public class MstDeviceEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column
	private Integer id;

	@Column
	private String model_id;
	@Column
	private String serial_no;
	@Column
	private String device_type;
	@Column
	private Boolean iot_device_flg;
	@Column
	private Boolean communication_flg;
	@Column
	private String name_locale1;
	@Column
	private String name_locale2;
	@Column
	private String name_locale3;
	@Column
	private String description_locale1;
	@Column
	private String description_locale2;
	@Column
	private String description_locale3;
	@Column
	private String maker_code;
	@Column
	private String parent_model_id;
	@Column
	private String parent_serial_no;
	@Column
	private String setup_place;
	@Column
	private String setup_status;
	@Column
	private String time_zone;
	@Column
	private BigDecimal latitude;
	@Column
	private BigDecimal longitude;
	@Column
	private String device_mode;
	@Column
	private Integer unreceive_seconds;
	@Column
	private String note;
	@Version
	@Column
	private Long version;

	@CreatedBy
    @Column
	private String inserted;

	@Column
	private Timestamp insert_time;

	@PrePersist
    public void onPrePersist() {
        setInsert_time(new Timestamp(System.currentTimeMillis()));
        setUpdate_time(new Timestamp(System.currentTimeMillis()));
    }

	@LastModifiedBy
    @Column
	private String updated;

	@Column
	private Timestamp update_time;

	@PreUpdate
    public void onPreUpdate() {
        setUpdate_time(new Timestamp(System.currentTimeMillis()));
    }

}

