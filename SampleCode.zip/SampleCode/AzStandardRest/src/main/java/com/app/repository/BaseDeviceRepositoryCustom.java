package com.app.repository;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.app.entity.MstBaseDeviceEntity;
import com.app.model.BaseDeviceQueryModel;

public interface BaseDeviceRepositoryCustom {
	List<MstBaseDeviceEntity> findAll(BaseDeviceQueryModel query, List<String> sort, Integer limit, Integer offset);
	Long countAll(BaseDeviceQueryModel query);

    MstBaseDeviceEntity findOneForUpdate(@Param("id") int id);
}