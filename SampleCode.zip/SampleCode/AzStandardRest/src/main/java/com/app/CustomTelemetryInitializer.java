package com.app;

import com.microsoft.applicationinsights.telemetry.Telemetry;
import com.microsoft.applicationinsights.web.extensibility.initializers.WebTelemetryInitializerBase;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.app.common.utils.CustomTelemetryThreadLocal;


public class CustomTelemetryInitializer extends WebTelemetryInitializerBase {

	public static final Logger logger = LoggerFactory.getLogger(CustomTelemetryInitializer.class);

	@Override
	protected void onInitializeTelemetry(Telemetry telemetry) {

		// set default parameter
		telemetry.getProperties().put("prop__tenant", System.getenv("TENANT_NAME"));
		telemetry.getProperties().put("prop__resourceName", System.getenv("RESOURCE_NAME"));
		telemetry.getProperties().put("prop__applicationName", System.getenv("APPLICATION_NAME"));

		// set error code
		if(CustomTelemetryThreadLocal.getErrorCode() != null && !"".equals(CustomTelemetryThreadLocal.getErrorCode())){
			telemetry.getProperties().put("prop__errorCode", CustomTelemetryThreadLocal.getErrorCode());
			CustomTelemetryThreadLocal.setErrorCode(null);
		}

		// set error message
		if(CustomTelemetryThreadLocal.getErrorMsg() != null && !"".equals(CustomTelemetryThreadLocal.getErrorMsg())){
			telemetry.getProperties().put("prop__errorMessage", CustomTelemetryThreadLocal.getErrorMsg());
			CustomTelemetryThreadLocal.setErrorMsg(null);
		}

	}

}
