package com.app.repository.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.entity.PostEventEntity;
import com.app.filter.AuthUserInfoComponent;
import com.app.repository.PostEventRepositoryCustom;
import com.app.service.PostEventService;

/**
 * イベント・アラーム登録イベント権限チェックリポジトリ実装クラス
 * @author 1572
 */
@Component
public class PostEventRepositoryImpl implements PostEventRepositoryCustom {
	private static final String SELECT_STR1 = "SELECT ";

	private static final String MODEL_STR1 = " (:model_id";
	private static final String SERIAL_STR1 = ") as model_id,(:serial_no";
	private static final String SENSOR_STR1 = ") as serial_no,(:event_id";
	private static final String MODEL_STR2 = ") as event_id WHERE dbo.fn_SensorAuthChk((:model_id";
	private static final String SERIAL_STR2 ="),(:serial_no";
	private static final String SENSOR_STR2 ="),(:event_id";
	private static final String WHERE_STR ="),(:user_id),(:url),(:method)) IS NULL ";

	@PersistenceContext EntityManager em;
	@Autowired PostEventService s;
	@Autowired AuthUserInfoComponent authUserInfo;

	@SuppressWarnings("unchecked")
	@Override
	public List<PostEventEntity> eventAuthChk(List<String> list,String userId)  {
		// SELECT句、WHERE句作成
		StringBuffer sql = new StringBuffer(SELECT_STR1);

		for (int i = 0; i < list.size(); i++) {
			sql.append(MODEL_STR1 + i);
			sql.append(SERIAL_STR1 + i);
			sql.append(SENSOR_STR1 + i);
			sql.append(MODEL_STR2 + i);
			sql.append(SERIAL_STR2 + i);
			sql.append(SENSOR_STR2 + i);
			sql.append(WHERE_STR);

			if(i+1 < list.size()) sql.append(" UNION SELECT ");
		}

		Query q = em.createNativeQuery(sql.toString(),PostEventEntity.class);

		Map<String, Object> params = new HashMap<String, Object>();
		String strVal = "";
		String modelId = "";
		String serialNo = "";
		String sensorId = "";
		for (int i = 0; i < list.size(); i++) {
			strVal = list.get(i);
			modelId = (strVal.substring(0, strVal.indexOf("$")));
			strVal = (strVal.substring(strVal.indexOf("$")+1));
			serialNo = (strVal.substring(0, strVal.indexOf("$")));
			sensorId = (strVal.substring(strVal.indexOf("$")+1));
			params.put("model_id" + i, modelId);
			params.put("serial_no" + i, serialNo);
			params.put("event_id" + i, sensorId);
			params.put("user_id", userId);
			params.put("url", "/v1/alarm-event-mgt/event");
			params.put("method", "POST");

			// クエリ作成
			Set<String> keys = params.keySet();
			for (String key : keys) {
				q.setParameter(key, params.get(key));
			}
			params.clear();
		}
		// クエリ実行
		return q.getResultList();
	}
}
