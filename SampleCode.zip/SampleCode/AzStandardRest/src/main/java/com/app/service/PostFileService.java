package com.app.service;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.zip.Deflater;
import java.util.zip.DeflaterInputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.common.Consts;
import com.app.common.utils.DateTimeUtil;
import com.app.common.utils.StringUtil;
import com.app.exception.BadRequestException;
import com.app.model.PostFileModel;
import com.app.model.SubResponseModel;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.codec.binary.Base64;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;
import com.microsoft.azure.storage.blob.ListBlobItem;

/**
 * ファイル登録サービスクラス
 *
 * @author 1572
 */
@Service
@Transactional(readOnly = true)
public class PostFileService {

	private final String _storageConnectionString = System.getenv("storage.connection.string");
	@Autowired private MessageSource _msgSource;

	/**
	 * ファイル登録処理
	 *
	 * @auther 1572
	 */

	public String postFile(PostFileModel fileModel,Locale locale) throws Exception {

		String fileName = fileModel.getFile_name();
		String container = fileModel.getContainer();
		String storageUrl = "";
		String strZipFlg = "";
		Date sysDate = new Date();
		String strSysDate = DateTimeUtil.formatDate(sysDate);

		/****************************
		 * Azureへの接続処理
		 ****************************/
		// Azure Table Storage、Azure Blob Storageへの接続処理を行う
		// Azure Storage接続文字列を取得して、Azure のストレージ アカウントにアクセスする
		CloudStorageAccount storageAccount = CloudStorageAccount.parse(_storageConnectionString);

		// CloudBlobClient オブジェクトを作成し、これを使用するコンテナーへの参照を取得する
		// 入力パラメータにて指定されたBlobコンテナへの参照を取得する
		CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
		CloudBlobContainer blobContainer = blobClient.getContainerReference(container);

		//指定コンテナの存在チェック(存在しない場合、BadRequest)
		if(!blobContainer.exists()){
			List<SubResponseModel> lstError = new ArrayList<>();
			BadRequestException exp = new BadRequestException("");
			lstError.add(new SubResponseModel("container"
					, _msgSource.getMessage(Consts.MESSAGE_E000118, null, locale)));
			exp.setArgs(lstError);
			throw exp;
		}

		// メタデータをセットする（IN パラメータに Key がセットされている項目のみ）
		HashMap<String, String> metadata = new LinkedHashMap<String, String>();

		// 圧縮フラグがtrueの場合は "true", それ以外の場合は "false"
		if (Boolean.valueOf(fileModel.getZip_flg())) {
			strZipFlg = "true";
		} else {
			strZipFlg = "false";
		}

		// メタデータ.圧縮フラグ
		metadata.put("zipFlg", strZipFlg);

		// メタデータ.機種ID(Keyがあり、値が空白("") の時は、"#"をセットする)
		if (!StringUtil.IsNullOrEmpty(fileModel.getModel_id())) {
			if (StringUtil.IsBlank(fileModel.getModel_id())) {
				metadata.put("modelId", "#");
			} else {
				metadata.put("modelId", fileModel.getModel_id());
			}
		}

		// メタデータ.シリアルNo(Keyがあり、値が空白("") の時は、"#"をセットする)
		if (!StringUtil.IsNullOrEmpty(fileModel.getSerial_no())) {
			if (StringUtil.IsBlank(fileModel.getSerial_no())) {
				metadata.put("serialNo", "#");
			} else {
				metadata.put("serialNo", fileModel.getSerial_no());
			}
		}

		// メタデータ.センサーID(Keyがあり、値が空白("") の時は、"#"をセットする)
		if (!StringUtil.IsNullOrEmpty(fileModel.getSensor_id())) {
			if (StringUtil.IsBlank(fileModel.getSensor_id())) {
				metadata.put("sensorId", "#");
			} else {
				metadata.put("sensorId", fileModel.getSensor_id());
			}
		}

		// メタデータ.ファイル種別 (値が空白("") の時はセットしない)
		if (!StringUtil.IsNullOrEmpty(fileModel.getFile_type()) && !StringUtil.IsBlank(fileModel.getFile_type())) {
			metadata.put("fileType", fileModel.getFile_type());
		}

		// メタデータ.予備1
		if (!StringUtil.IsNullOrEmpty(fileModel.getReserve1()) && !StringUtil.IsBlank(fileModel.getReserve1())) {
			metadata.put("reserve1", URLEncoder.encode(fileModel.getReserve1(), "UTF-8"));
		}

		// メタデータ.予備2
		if (!StringUtil.IsNullOrEmpty(fileModel.getReserve2()) && !StringUtil.IsBlank(fileModel.getReserve2())) {
			metadata.put("reserve2", URLEncoder.encode(fileModel.getReserve2(), "UTF-8"));
		}

		// メタデータ.予備3
		if (!StringUtil.IsNullOrEmpty(fileModel.getReserve3()) && !StringUtil.IsBlank(fileModel.getReserve3())) {
			metadata.put("reserve3", URLEncoder.encode(fileModel.getReserve3(), "UTF-8"));
		}

		// メタデータ.予備4
		if (!StringUtil.IsNullOrEmpty(fileModel.getReserve4()) && !StringUtil.IsBlank(fileModel.getReserve4())) {
			metadata.put("reserve4", URLEncoder.encode(fileModel.getReserve4(), "UTF-8"));
		}

		// メタデータ.予備5
		if (!StringUtil.IsNullOrEmpty(fileModel.getReserve5()) && !StringUtil.IsBlank(fileModel.getReserve5())) {
			metadata.put("reserve5", URLEncoder.encode(fileModel.getReserve5(), "UTF-8"));
		}

		metadata.put("uploadUserID", fileModel.getUser_id());
		metadata.put("uploadTime", strSysDate.substring(0, 17));

		// base64 フラグがtrueの場合、デコード
		ByteArrayInputStream fileStream = null;
		byte[] fileBinary = null;

		if (Boolean.valueOf(fileModel.getBase64_flg())) {
			fileBinary = Base64.decodeBase64(fileModel.getFile_data());
		} else {
			fileBinary = fileModel.getFile_data().getBytes("UTF-8");
		}
		fileStream = new ByteArrayInputStream(fileBinary);

		Boolean nameFlg = false;
		if (StringUtil.IsNullOrEmpty(fileName) || StringUtil.IsBlank(fileName)) {
			// INパラメータのファイル名(ファイルパス情報含む)が未設定の時は、ファイル名を自動採番する。
			fileName = "api_upload/" + strSysDate.substring(0, 6) + "/" + strSysDate.substring(6, 8) + "/"
					+ strSysDate.substring(8, 10) + "/" + strSysDate.substring(10, 12) + "/"
					+ strSysDate.substring(12, 14) + "." + strSysDate.substring(14, 21);
			nameFlg = true;
		}


		// storageのURLを取得
		storageUrl = storageAccount.getBlobStorageUri().getPrimaryUri().toString();

		// 指定コンテナ内に、自動採番したファイル名が存在するかチェック
		if (nameFlg) {
			ArrayList<String> blobList = new ArrayList<String>();
			for (ListBlobItem blobItem : blobContainer.listBlobs(fileName)) {
				blobList.add(blobItem.getUri().toString());
			}

			if (!blobList.isEmpty()) {
				// 連番なしのファイル名が存在する場合、連番を付与
				if ((blobList.contains(storageUrl + "/" + container + "/" + fileName))) {
					int cnt = 1;
					for (String name : blobList) {
						if (blobList.contains(storageUrl + "/" + container + "/" + fileName + "-" + cnt)) {
							cnt = cnt + 1;
						} else {
							fileName = fileName + "-" + cnt;
							break;
						}
					}
				}
			}
		}

		CloudBlockBlob blockBlob = blobContainer.getBlockBlobReference(fileName);

		// メタデータを設定する
		blockBlob.setMetadata(metadata);

		// 圧縮有無フラグがtrueの場合、圧縮アルゴリズム Deflate で圧縮後、登録する
		InputStream blobStream = null;
		if (strZipFlg == "true") {
			blobStream = new DeflaterInputStream(fileStream, new Deflater());
		} else {
			blobStream = fileStream;
		}
		blockBlob.upload(blobStream, -1);

		return fileName;
	}


}
