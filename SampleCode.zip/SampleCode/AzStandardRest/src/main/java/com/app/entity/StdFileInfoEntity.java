package com.app.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 計測ファイル情報エンティティクラス
 * @author（TOSCO）ウェイ
 */
@Entity
@Table(name="std_fileinfo")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class StdFileInfoEntity implements Serializable{

	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	@Column
	private String model_id;
	@Column
	private String serial_no;
	@Column
	private String sensor_id;
	@Column
	private String measure_time;
	@Column
	private String upload_time;
	@Column
	private String zip_flg;
	@Column
	private String file_name;
	@Column
	private String hash;
	@Column
	private String sender_device_id;
	@Column
	private String notice_time;
	@Column
	private String reserve1;
	@Column
	private String reserve2;
	@Column
	private String reserve3;
	@Column
	private String reserve4;
	@Column
	private String reserve5;
	@Column
	private String other_metadata;
	@Column
	private String upload_user_id;
}
