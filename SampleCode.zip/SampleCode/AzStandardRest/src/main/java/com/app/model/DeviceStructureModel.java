package com.app.model;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * デバイス階層情報取得モデル
 */
@Data
public class DeviceStructureModel {

	@ApiModelProperty(value = "検索区分（1：指定されたデバイス下の全ての階層のデバイスを取得 (指定されたデバイスを含む) / 2：1.で取得したデバイスの内、末端のデバイスのみ取得）" , required =true)
	private String get_class;

	@ApiModelProperty(value = "機種ID" , required =true)
	private String model_id;

	@ApiModelProperty(value = "シリアルNo" , required =true)
	private String serial_no;

	@ApiModelProperty(value = "階層数（1～40） ※未指定時は40")
	private String level;

	@ApiModelProperty(value = "任意並び順条件(カンマ区切り)")
	private String sort;

	@ApiModelProperty(value = "取得フィールド(カンマ区切り)")
	private String fields;

	@ApiModelProperty(value = "表示対象ページ番号")
	private String page;

	@ApiModelProperty(value = "1度に返すItem数")
	private String limit;


}
