package com.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.entity.UserEventAuthorityEntity;
import com.app.model.UserEventAuthorityModel;
import com.app.model.UserEventAuthorityQueryModel;
import com.app.repository.UserEventAuthorityRepository;

/**
 * ユーザ・イベント権限情報サービスクラス
 * @author 1625
 *
 */
@Service
@Transactional(readOnly = true)
public class UserEventAuthorityService {
	@Autowired
	private UserEventAuthorityRepository userEventAuthorityRepository;

	/**
	 * ユーザ・イベント権限情報一覧取得
	 * @param filter 検索条件オブジェクト
	 * @return ユーザ・デバイス権限情報リスト
	 * @throws Exception
	 */
	public List<UserEventAuthorityModel> findAll(UserEventAuthorityQueryModel filter) throws Exception {

		ModelFilter mf = makeModelFilter(filter.getFields());

		List<String> sort = new ArrayList<String>();
		if (filter.getSort() != null) {
			for (String item : filter.getSort().split(",")) {
				sort.add(item.trim().toLowerCase());
			}
		}

		Integer limit = null;
		Integer offset = null;
		if (filter.getPage() != null && filter.getLimit() != null) {
			limit = Integer.parseInt(filter.getLimit());
			offset = (Integer.parseInt(filter.getPage()) - 1) * limit;
		}

		// 検索実行
		List<UserEventAuthorityEntity> entList = userEventAuthorityRepository.findAll(filter, sort, limit, offset);

		// 返却項目フィルタ処理
		List<UserEventAuthorityModel> modelList = new ArrayList<UserEventAuthorityModel>();
		for (UserEventAuthorityEntity entity : entList) {
			UserEventAuthorityModel newModel = new UserEventAuthorityModel();
			if (mf.model_id)
				newModel.setModel_id(entity.getModel_id());
			if (mf.serial_no)
				newModel.setSerial_no(entity.getSerial_no());
			if (mf.event_id)
				newModel.setEvent_id(entity.getEvent_id());
			if (mf.event_type)
				newModel.setEvent_type(entity.getEvent_type());
			if (mf.event_level)
				newModel.setEvent_level(entity.getEvent_level());
			if (mf.sensor_id)
				newModel.setSensor_id(entity.getSensor_id());
			if (mf.name_locale1)
				newModel.setName_locale1(entity.getName_locale1());
			if (mf.name_locale2)
				newModel.setName_locale2(entity.getName_locale2());
			if (mf.name_locale3)
				newModel.setName_locale3(entity.getName_locale3());
			if (mf.description_locale1)
				newModel.setDescription_locale1(entity.getDescription_locale1());
			if (mf.description_locale2)
				newModel.setDescription_locale2(entity.getDescription_locale2());
			if (mf.description_locale3)
				newModel.setDescription_locale3(entity.getDescription_locale3());
			if (mf.chk_app_name)
				newModel.setChk_app_name(entity.getChk_app_name());
			if (mf.chk_app_parameter)
				newModel.setChk_app_parameter(entity.getChk_app_parameter());
			if (mf.chk_timing)
				newModel.setCheck_timing(entity.getCheck_timing());
			if (mf.note)
				newModel.setNote(entity.getNote());
			if (mf.device_group_id)
				newModel.setDevice_group_id(entity.getDevice_group_id());
			if (mf.device_group_type)
				newModel.setDevice_group_type(entity.getDevice_group_type());
			if (mf.device_group_subtype)
				newModel.setDevice_group_subtype(entity.getDevice_group_subtype());
			if (mf.device_group_name_locale1)
				newModel.setDevice_group_name_locale1(entity.getDevice_group_name_locale1());
			if (mf.device_group_name_locale2)
				newModel.setDevice_group_name_locale2(entity.getDevice_group_name_locale2());
			if (mf.device_group_name_locale3)
				newModel.setDevice_group_name_locale3(entity.getDevice_group_name_locale3());
			if (mf.device_group_description_locale1)
				newModel.setDevice_group_description_locale1(entity.getDevice_group_description_locale1());
			if (mf.device_group_description_locale2)
				newModel.setDevice_group_description_locale2(entity.getDevice_group_description_locale2());
			if (mf.device_group_description_locale3)
				newModel.setDevice_group_description_locale3(entity.getDevice_group_description_locale3());
			if (mf.parent_device_group_id)
				newModel.setParent_device_group_id(entity.getParent_device_group_id());
			if (mf.setup_place)
				newModel.setSetup_place(entity.getSetup_place());
			if (mf.setup_status)
				newModel.setSetup_status(entity.getSetup_status());
			if (mf.latitude)
				newModel.setLatitude(entity.getLatitude());
			if (mf.longitude)
				newModel.setLongitude(entity.getLongitude());
			if (mf.device_group_note)
				newModel.setDevice_group_note(entity.getDevice_group_note());
			if (mf.role_id)
				newModel.setRole_id(entity.getRole_id());
			if (mf.root_group_id)
				newModel.setRoot_group_id(entity.getRoot_group_id());
			if (mf.role_name_locale1)
				newModel.setRole_name_locale1(entity.getRole_name_locale1());
			if (mf.role_name_locale2)
				newModel.setRole_name_locale2(entity.getRole_name_locale2());
			if (mf.role_name_locale3)
				newModel.setRole_name_locale3(entity.getRole_name_locale3());
			if (mf.role_description_locale1)
				newModel.setRole_description_locale1(entity.getRole_description_locale1());
			if (mf.role_description_locale2)
				newModel.setRole_description_locale2(entity.getRole_description_locale2());
			if (mf.role_description_locale3)
				newModel.setRole_description_locale3(entity.getRole_description_locale3());
			if (mf.role_note)
				newModel.setRole_note(entity.getRole_note());
			if (mf.hierarchy)
				newModel.setHierarchy(entity.getHierarchy());

			modelList.add(newModel);
		}
		return modelList;
	}

	/**
	 * ユーザ・イベント権限情報一覧件数取得
	 *
	 * @param filter 検索条件オブジェクト
	 * @return 検索結果件数
	 * @throws Exception
	 */
	public Long countAll(UserEventAuthorityQueryModel filter) throws Exception {
		return userEventAuthorityRepository.countAll(filter);
	}

	/**
	 * 返却項目フィルター作成
	 *
	 * @param fields 取得対象項目名リスト（カンマ区切り）
	 * @return フィルターオブジェクト
	 */
	private ModelFilter makeModelFilter(String fields) {
		ModelFilter mf = null;
		if (fields == null || fields.trim().length() == 0) {
			mf = new ModelFilter(true);
		} else {
			mf = new ModelFilter(false);
			for (String f : fields.split(",")) {
				String str = f.trim().toLowerCase();
				if ("model_id".equals(str))
					mf.model_id = true;
				if ("serial_no".equals(str))
					mf.serial_no = true;
				if ("event_id".equals(str))
					mf.event_id = true;
				if ("event_type".equals(str))
					mf.event_type = true;
				if ("event_level".equals(str))
					mf.event_level = true;
				if ("sensor_id".equals(str))
					mf.sensor_id = true;
				if ("name_locale1".equals(str))
					mf.name_locale1 = true;
				if ("name_locale2".equals(str))
					mf.name_locale2 = true;
				if ("name_locale3".equals(str))
					mf.name_locale3 = true;
				if ("description_locale1".equals(str))
					mf.description_locale1 = true;
				if ("description_locale2".equals(str))
					mf.description_locale2 = true;
				if ("description_locale3".equals(str))
					mf.description_locale3 = true;
				if ("chk_app_name".equals(str))
					mf.chk_app_name = true;
				if ("chk_app_parameter".equals(str))
					mf.chk_app_parameter = true;
				if ("chk_timing".equals(str))
					mf.chk_timing = true;
				if ("note".equals(str))
					mf.note = true;
				if ("device_group_id".equals(str))
					mf.device_group_id = true;
				if ("device_group_type".equals(str))
					mf.device_group_type = true;
				if ("device_group_subtype".equals(str))
					mf.device_group_subtype = true;
				if ("device_group_name_locale1".equals(str))
					mf.device_group_name_locale1 = true;
				if ("device_group_name_locale2".equals(str))
					mf.device_group_name_locale2 = true;
				if ("device_group_name_locale3".equals(str))
					mf.device_group_name_locale3 = true;
				if ("device_group_description_locale1".equals(str))
					mf.device_group_description_locale1 = true;
				if ("device_group_description_locale2".equals(str))
					mf.device_group_description_locale2 = true;
				if ("device_group_description_locale3".equals(str))
					mf.device_group_description_locale3 = true;
				if ("parent_device_group_id".equals(str))
					mf.parent_device_group_id = true;
				if ("setup_place".equals(str))
					mf.setup_place = true;
				if ("setup_status".equals(str))
					mf.setup_status = true;
				if ("latitude".equals(str))
					mf.latitude = true;
				if ("longitude".equals(str))
					mf.longitude = true;
				if ("device_group_note".equals(str))
					mf.device_group_note = true;
				if ("role_id".equals(str))
					mf.role_id = true;
				if ("root_group_id".equals(str))
					mf.root_group_id = true;
				if ("create_auth_flg".equals(str))
					mf.create_auth_flg = true;
				if ("update_auth_flg".equals(str))
					mf.update_auth_flg = true;
				if ("delete_auth_flg".equals(str))
					mf.delete_auth_flg = true;
				if ("reference_auth_flg".equals(str))
					mf.reference_auth_flg = true;
				if ("user_id".equals(str))
					mf.user_id = true;
				if ("role_name_locale1".equals(str))
					mf.role_name_locale1 = true;
				if ("role_name_locale2".equals(str))
					mf.role_name_locale2 = true;
				if ("role_name_locale3".equals(str))
					mf.role_name_locale3 = true;
				if ("role_description_locale1".equals(str))
					mf.role_description_locale1 = true;
				if ("role_description_locale2".equals(str))
					mf.role_description_locale2 = true;
				if ("role_description_locale3".equals(str))
					mf.role_description_locale3 = true;
				if ("role_note".equals(str))
					mf.role_note = true;
				if ("hierarchy".equals(str))
					mf.hierarchy = true;
			}
		}
		return mf;
	}

	/**
	 * 返却項目フィルタークラス true=返却する。false=返却しない。
	 *
	 * @author 1625
	 */
	class ModelFilter {
		public ModelFilter(boolean b) {
			model_id = b;
			serial_no = b;
			event_id = b;
			event_type = b;
			event_level = b;
			sensor_id = b;
			name_locale1 = b;
			name_locale2 = b;
			name_locale3 = b;
			description_locale1 = b;
			description_locale2 = b;
			description_locale3 = b;
			chk_app_name = b;
			chk_app_parameter = b;
			chk_timing = b;
			note = b;
			device_group_id = b;
			device_group_type = b;
			device_group_subtype = b;
			device_group_name_locale1 = b;
			device_group_name_locale2 = b;
			device_group_name_locale3 = b;
			device_group_description_locale1 = b;
			device_group_description_locale2 = b;
			device_group_description_locale3 = b;
			parent_device_group_id = b;
			setup_place = b;
			setup_status = b;
			latitude = b;
			longitude = b;
			device_group_note = b;
			role_id = b;
			root_group_id = b;
			create_auth_flg = b;
			update_auth_flg = b;
			delete_auth_flg = b;
			reference_auth_flg = b;
			user_id = b;
			role_name_locale1 = b;
			role_name_locale2 = b;
			role_name_locale3 = b;
			role_description_locale1 = b;
			role_description_locale2 = b;
			role_description_locale3 = b;
			role_note = b;
			hierarchy = b;
		}

		public boolean model_id = true;
		public boolean serial_no = true;
		public boolean event_id = true;
		public boolean event_type = true;
		public boolean event_level = true;
		public boolean sensor_id = true;
		public boolean name_locale1 = true;
		public boolean name_locale2 = true;
		public boolean name_locale3 = true;
		public boolean description_locale1 = true;
		public boolean description_locale2 = true;
		public boolean description_locale3 = true;
		public boolean chk_app_name = true;
		public boolean chk_app_parameter = true;
		public boolean chk_timing = true;
		public boolean note = true;
		public boolean device_group_id = true;
		public boolean device_group_type = true;
		public boolean device_group_subtype = true;
		public boolean device_group_name_locale1 = true;
		public boolean device_group_name_locale2 = true;
		public boolean device_group_name_locale3 = true;
		public boolean device_group_description_locale1 = true;
		public boolean device_group_description_locale2 = true;
		public boolean device_group_description_locale3 = true;
		public boolean parent_device_group_id = true;
		public boolean setup_place = true;
		public boolean setup_status = true;
		public boolean latitude = true;
		public boolean longitude = true;
		public boolean device_group_note = true;
		public boolean role_id = true;
		public boolean root_group_id = true;
		public boolean create_auth_flg = true;
		public boolean update_auth_flg = true;
		public boolean delete_auth_flg = true;
		public boolean reference_auth_flg = true;
		public boolean user_id = true;
		public boolean role_name_locale1 = true;
		public boolean role_name_locale2 = true;
		public boolean role_name_locale3 = true;
		public boolean role_description_locale1 = true;
		public boolean role_description_locale2 = true;
		public boolean role_description_locale3 = true;
		public boolean role_note = true;
		public boolean hierarchy = true;

	}
}
