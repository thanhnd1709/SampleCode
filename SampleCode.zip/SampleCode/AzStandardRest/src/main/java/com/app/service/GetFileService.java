package com.app.service;

import java.io.InputStream;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;

import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.stereotype.Service;

import com.app.common.Consts;
import com.app.exception.DataNotFoundException;
import com.app.model.FileModel;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;

/**
 * ファイル取得サービスクラス
 * @author（TOSCO）
 */
@Service
public class GetFileService {
//	private ResourceBundle _bundle = ResourceBundle.getBundle("application");
//	private final String _storageConnectionString = _bundle.getString("storage.connection.string");

	private final String _storageConnectionString = System.getenv("storage.connection.string");
	
	String fileType = "";
	String containerName = "";
	String fileName = "";
	boolean zipFlg;

	/**
	 * ファイル取得処理
	 * @return ファイル Stream
	 */
	public InputStream getFile(FileModel fileModel) throws Exception{
		fileType = fileModel.getFile_type();
		fileName = fileModel.getFile_name();

		switch(fileType){
		case Consts.FILE_TYPE_1:
			containerName = Consts.BLOB_MEASURE_FILE;
			break;

		case Consts.FILE_TYPE_9:
			containerName = fileModel.getContainer();
			break;
		}

		/****************************
		 * Azureへの接続処理
		 ****************************/
		// Azure Table Storage、Azure Blob Storageへの接続処理を行う
		// Azure Storage接続文字列を取得して、Azure のストレージ アカウントにアクセスする
		CloudStorageAccount storageAccount = CloudStorageAccount.parse(_storageConnectionString);

		// CloudBlobClient オブジェクトを作成し、これを使用するコンテナーへの参照を取得する
		// 入力パラメータにて指定されたBlobコンテナへの参照を取得する
		CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
		CloudBlobContainer container = blobClient.getContainerReference(containerName);
		CloudBlockBlob blockBlob = container.getBlockBlobReference(fileName);

		
		try{
			//メタデータの圧縮有無フラグを取得する
			blockBlob.downloadAttributes();
		}
		catch(StorageException e){
			DataNotFoundException exp = new DataNotFoundException("");
			exp.setArgs(new MessageSourceResolvable[]{
					new DefaultMessageSourceResolvable("file.name")});
			throw exp;
		}

		zipFlg = Boolean.valueOf(blockBlob.getMetadata().get("zipFlg"));

		InputStream blobStream = null;

		if(zipFlg){
			blobStream = new InflaterInputStream(blockBlob.openInputStream(), new Inflater(true));
		}
		else{
			blobStream = blockBlob.openInputStream();
		}

		return blobStream;
	}
}
