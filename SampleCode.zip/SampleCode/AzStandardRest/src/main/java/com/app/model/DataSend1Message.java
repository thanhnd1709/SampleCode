package com.app.model;

import java.util.List;

public class DataSend1Message extends DataSendMessage {
	public List<DataSend1TimeData> timeList;

	public class DataSend1TimeData {
		// 計測時間
		public String measureTime;
		// [配列]データ
		public List<DataSend1MeasureData> dataList;

		public String getMeasureTime() {
			return measureTime;
		}

		public void setMeasureTime(String measureTime) {
			this.measureTime = measureTime;
		}

		public List<DataSend1MeasureData> getDataList() {
			return dataList;
		}

		public void setDataList(List<DataSend1MeasureData> dataList) {
			this.dataList = dataList;
		}
	}

	public class DataSend1MeasureData {
		public String sensorId;
		public String data;

		public String getSensorId() {
			return sensorId;
		}

		public void setSensorId(String sensorId) {
			this.sensorId = sensorId;
		}

		public String getData() {
			return data;
		}

		public void setData(String data) {
			this.data = data;
		}
	}

	public List<DataSend1TimeData> getTimeList() {
		return timeList;
	}

	public void setTimeList(List<DataSend1TimeData> timeList) {
		this.timeList = timeList;
	}

}
