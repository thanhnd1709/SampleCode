package com.app.model;

public class HourlySensorData {
	private int size;
	int time;
	String data;
	
	
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public  int getTime() {
		return time;
	}
	public void setTime( int time) {
		this.time = time;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}

	
}
