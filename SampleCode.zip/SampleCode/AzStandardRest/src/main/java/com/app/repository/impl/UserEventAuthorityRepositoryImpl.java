package com.app.repository.impl;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.common.utils.StringUtil;
import com.app.entity.UserEventAuthorityEntity;
import com.app.model.UserEventAuthorityQueryModel;
import com.app.repository.UserEventAuthorityRepositoryCustom;

/**
 * ユーザ・イベント権限情報リポジトリクラス
 * @author 1625
 *
 */
@Component
public class UserEventAuthorityRepositoryImpl implements UserEventAuthorityRepositoryCustom {
	private static final String SELECT_COUNT_STR = "SELECT count(*) FROM ";
	private static final String SELECT_STR = "SELECT row_number() over(ORDER BY (SELECT NULL) ASC) as id, tmp.* FROM ";
	private static final String SELECT_ALL_STR =
			"SELECT DISTINCT " +
			"e.event_id as event_id, " +
			"e.event_type as event_type, " +
			"e.event_level as event_level, " +
			"e.sensor_id as sensor_id, " +
			"e.name_locale1 as name_locale1, " +
			"e.name_locale2 as name_locale2, " +
			"e.name_locale3 as name_locale3, " +
			"e.description_locale1 as description_locale1, " +
			"e.description_locale2 as description_locale2, " +
			"e.description_locale3 as description_locale3, " +
			"e.chk_app_name as chk_app_name, " +
			"e.chk_app_parameter as chk_app_parameter, " +
			"e.check_timing as check_timing, " +
			"e.note as note, " +
			"e.model_id as model_id, " +
			"e.serial_no as serial_no, " +
			"gl.device_group_id as device_group_id, " +
			"gl.device_group_type as device_group_type, "+
			"gl.device_group_subtype as device_group_subtype, "+
			"gl.device_group_name_locale1 as device_group_name_locale1, "+
			"gl.device_group_name_locale2 as device_group_name_locale2, "+
			"gl.device_group_name_locale3 as device_group_name_locale3, "+
			"gl.device_group_description_locale1 as device_group_description_locale1, "+
			"gl.device_group_description_locale2 as device_group_description_locale2, "+
			"gl.device_group_description_locale3 as device_group_description_locale3, "+
			"gl.parent_device_group_id as parent_device_group_id, " +
			"gl.setup_place as setup_place, " +
			"gl.setup_status as setup_status, " +
			"gl.latitude as latitude, " +
			"gl.longitude as longitude, "+
			"gl.device_group_note as device_group_note, " +
			"gl.role_id as role_id, " +
			"gl.root_group_id as root_group_id, " +
			"gl.role_name_locale1 as role_name_locale1, " +
			"gl.role_name_locale2 as role_name_locale2,  " +
			"gl.role_name_locale3 as role_name_locale3, " +
			"gl.role_description_locale1 as role_description_locale1, " +
			"gl.role_description_locale2 as role_description_locale2, " +
			"gl.role_description_locale3 as role_description_locale3, " +
			"gl.role_note as role_note, " +
			"gl.hierarchy as hierarchy ";
	private static final String FROM_STR =
			" FROM dbo.fn_UserDeviceGroup(:user_id, :url, :method) gl, mst_event e, mst_group_composition_device gcd";
	private static final String FROM_STR_2 =
			" FROM dbo.fn_UserDeviceGroup(:user_id, default, default) gl, mst_event e, mst_group_composition_device gcd";
	private static final String WHERE_STR = " WHERE e.model_id = gcd.model_id " +
												"AND e.serial_no = gcd.serial_no " +
												"AND gcd.device_group_id = gl.device_group_id " +
												"AND NOT EXISTS (SELECT 1 FROM mst_role_event_visual rv " +
												"WHERE rv.role_id = gl.role_id " +
												"AND rv.model_id = gcd.model_id " +
												"AND rv.serial_no = gcd.serial_no " +
												"AND rv. event_id = e.event_id " +
												"AND rv.visual_auth_flg = 0) ";

	@Autowired EntityManager em;

	/**
	 * ユーザ・イベント権限情報件数取得
	 * @param query 検索条件オブジェクト
	 * @return 件数
	 */
	@Override
	public Long countAll(UserEventAuthorityQueryModel query) {

		Map<String, Object> params = new HashMap<String, Object>();

		String sql = SELECT_COUNT_STR + "(" + buildSubQuery(query, params) + ") as tmp";
		// クエリ作成
		Query q = em.createNativeQuery(sql.toString());
		Set<String> keys = params.keySet();
		for (String key : keys) {
			q.setParameter(key, params.get(key));
		}

		// クエリ実行
		return ((Integer)q.getSingleResult()).longValue();
	}

	/**
	 * ユーザ・イベント権限情報検索
	 * @param query 検索条件オブジェクト
	 * @param sort ソート条件リスト
	 * @param limit 取得件数
	 * @param offset 取得開始オフセット値
	 * @return 検索結果リスト
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<UserEventAuthorityEntity> findAll(UserEventAuthorityQueryModel query, List<String> sort, Integer limit, Integer offset) {

		// ORDER BY句作成
		StringBuffer orderBy = new StringBuffer();
		if (sort.size() > 0) {
			orderBy.append(" ORDER BY ");
			for (String col : sort) {
				if (col.startsWith("-")) {
					orderBy.append(col.substring(1) + " desc,");
				} else {
					orderBy.append(col + " asc,");
				}
			}
			orderBy.deleteCharAt(orderBy.length()-1);
		}

		// SELECT文作成
		Map<String, Object> params = new HashMap<String, Object>();
		String sql = SELECT_STR + "(" + buildSubQuery(query, params) + orderBy.toString() + ") as tmp";
		if (offset == null && limit == null) {
			sql = SELECT_STR + "(" + buildSubQuery(query, params) + ") as tmp " + orderBy.toString();
		} else {
			sql = SELECT_STR + "(" + buildSubQuery(query, params) + orderBy.toString() + ") as tmp";
		}

		// クエリ作成
		Query q = em.createNativeQuery(sql.toString(), UserEventAuthorityEntity.class);
		Set<String> keys = params.keySet();
		for (String key : keys) {
			q.setParameter(key, params.get(key));
		}

		// ページング設定
		if (offset != null) q.setFirstResult(offset);
		if (limit != null) q.setMaxResults(limit);

		List<UserEventAuthorityEntity> list = q.getResultList();

		// クエリ実行
		return list;
	}

	/**
	 * WHERE句文字列と、バインド変数KVオブジェクトを作成する。
	 * @param query 検索条件オブジェクト
	 * @param params バインド変数KVオブジェクト（返却用）
	 * @return WHERE句文字列
	 */
	private String buildCondition(UserEventAuthorityQueryModel query, Map<String, Object> params) {
		StringBuffer where = new StringBuffer(WHERE_STR);
		Object[] arr = null;
		addCondition(where, params, "e.model_id", query.getModel_id());
		addCondition(where, params, "e.serial_no", query.getSerial_no());
		addCondition(where, params, "e.event_id", query.getEvent_id());
		addCondition(where, params, "e.event_type", query.getEvent_type());
		addCondition(where, params, "e.event_level", query.getEvent_level());
		addCondition(where, params, "e.sensor_id", query.getSensor_id());
		addPartialMatchCondition(where, params, "e.name_locale1", query.getName_locale1());
		addPartialMatchCondition(where, params, "e.name_locale2", query.getName_locale2());
		addPartialMatchCondition(where, params, "e.name_locale3", query.getName_locale3());
		addPartialMatchCondition(where, params, "e.description_locale1", query.getDescription_locale1());
		addPartialMatchCondition(where, params, "e.description_locale2", query.getDescription_locale2());
		addPartialMatchCondition(where, params, "e.description_locale3", query.getDescription_locale3());
		addCondition(where, params, "e.chk_app_name", query.getChk_app_name());
		addCondition(where, params, "e.chk_app_parameter", query.getChk_app_parameter());
		addCondition(where, params, "e.check_timing", query.getCheck_timing());
		addPartialMatchCondition(where, params, "e.note", query.getNote());
		addCondition(where, params, "gl.device_group_id", query.getDevice_group_id());
		addCondition(where, params, "gl.device_group_type", query.getDevice_group_type());
		addCondition(where, params, "gl.device_group_subtype", query.getDevice_group_subtype());
		addPartialMatchCondition(where, params, "gl.device_group_name_locale1", query.getDevice_group_name_locale1());
		addPartialMatchCondition(where, params, "gl.device_group_name_locale2", query.getDevice_group_name_locale2());
		addPartialMatchCondition(where, params, "gl.device_group_name_locale3", query.getDevice_group_name_locale3());
		addPartialMatchCondition(where, params, "gl.device_group_description_locale1", query.getDevice_group_description_locale1());
		addPartialMatchCondition(where, params, "gl.device_group_description_locale2", query.getDevice_group_description_locale2());
		addPartialMatchCondition(where, params, "gl.device_group_description_locale3", query.getDevice_group_description_locale3());
		addCondition(where, params, "gl.parent_device_group_id", query.getParent_device_group_id());
		addPartialMatchCondition(where, params, "gl.setup_place", query.getSetup_place());
		addCondition(where, params, "gl.setup_status", query.getSetup_status());
		if (query.getLatitude() != null) {
			arr = Stream.of(query.getLatitude()).map(StringUtil.String2BigDecimal).toArray();
			addCondition(where, params, "gl.latitude", arr);
		}
		if (query.getLongitude() != null) {
			arr = Stream.of(query.getLongitude()).map(StringUtil.String2BigDecimal).toArray();
			addCondition(where, params, "gl.longitude", arr);
		}
		addPartialMatchCondition(where, params, "gl.device_group_note", query.getDevice_group_note());
		addCondition(where, params, "gl.role_id", query.getRole_id());
		addCondition(where, params, "gl.root_group_id", query.getRoot_group_id());
		addCondition(where, params, "gl.role_name_locale1", query.getRole_name_locale1());
		addCondition(where, params, "gl.role_name_locale2", query.getRole_name_locale2());
		addCondition(where, params, "gl.role_name_locale3", query.getRole_name_locale3());
		addCondition(where, params, "gl.role_description_locale1", query.getRole_description_locale1());
		addCondition(where, params, "gl.role_description_locale2", query.getRole_description_locale2());
		addCondition(where, params, "gl.role_description_locale3", query.getRole_description_locale3());
		addCondition(where, params, "gl.role_note", query.getRole_note());

		if (query.getHierarchy() != null && query.getHierarchy().length > 0) {
			arr = Stream.of(query.getHierarchy()).map(StringUtil.String2Integer).toArray();
			addCondition(where, params, "gl.hierarchy", arr);
		}

		String ret = where.toString();
		return (ret.equals(WHERE_STR) ? "" : ret);
	}

	/**
	 * WHERE句用検索条件追加
	 * 引数のwhere句文字列にAND 列名 IN (バインド変数,...)の形式で検索条件を追加する。
	 * バインド変数名は"列名_配列インデックス"の形式とする。
	 * paramsには、キーにバインド変数名、値にvaluesの値を設定する。
	 * @param where WHERE句文字列
	 * @param params バインド変数KVオブジェクト（返却用）
	 * @param col 検索条件列名
	 * @param values 検索条件値配列
	 */
	private void addCondition(StringBuffer where, Map<String, Object> params, String col, Object[] values) {
		if (values == null || values.length == 0) return;
		where.append("AND " + col + " in (");
		for (int i = 0; i < values.length; i++) {
			String name = col + "_" + i;
			where.append(":").append(name).append(",");
			params.put(name, values[i]);
		}
		where.deleteCharAt(where.length()-1);
		where.append(")");
	}

	/**
	 * WHERE句用部分一致検索条件追加
	 * 引数のwhere句文字列にAND (列名 like バインド変数 OR ...)の形式で検索条件を追加する。
	 * バインド変数名は"列名_配列インデックス"の形式とする。
	 * paramsには、キーにバインド変数名、値にvaluesの値を設定する。
	 * @param where WHERE句文字列
	 * @param params バインド変数KVオブジェクト（返却用）
	 * @param col 検索条件列名
	 * @param values 検索条件値配列
	 */
	private void addPartialMatchCondition(StringBuffer where, Map<String, Object> params, String col, Object[] values) {
		if (values == null || values.length == 0) return;
		where.append(" AND (");
		for (int i = 0; i < values.length; i++) {
			if (i > 0) where.append(" OR ");

			String name = col + "_" + i;
			where.append(col).append(" like :").append(name);
			params.put(name, values[i]);
		}
		where.append(")");
	}

	/**
	 * サブクエリ作成
	 * @param query
	 * @param params
	 * @return
	 */
	private String buildSubQuery(UserEventAuthorityQueryModel query, Map<String, Object> params) {
		StringBuffer sql = new StringBuffer();

		if (query.getFields() == null) {
			sql.append(SELECT_ALL_STR);
		} else {
			sql.append("SELECT DISTINCT ");

			// INパラメータのfieldsで指定された項目以外のカラムはnull固定値を取得する
			List<String> list = Arrays.asList(query.getFields().split(","));
			Field[] fields = UserEventAuthorityEntity.class.getDeclaredFields();
			for (Field f : fields) {
				if ("id".equals(f.getName())) {
					// idは親クエリのrow_numberで取得するため除外する。
					continue;
				}
				String item = list.contains(f.getName()) ? f.getName() : "null";

				if (!item.equals("null")) {
					if (item.equals("model_id") || item.equals("serial_no") || item.equals("event_id")
							|| item.equals("event_type") || item.equals("event_level") || item.equals("sensor_id")
							|| item.equals("name_locale1") || item.equals("name_locale2") || item.equals("name_locale3")
							|| item.equals("description_locale1") || item.equals("description_locale2")
							|| item.equals("description_locale3") || item.equals("chk_app_name") || item.equals("chk_app_parameter")
							|| item.equals("check_timing") || item.equals("note")) {
						sql.append("e.");
					} else {
						sql.append("gl.");
					}
				}
				sql.append(item + " as " + f.getName() + ",");
			}
			sql.deleteCharAt(sql.length() - 1);	// 末端の,を削除
		}

		params.put("user_id", query.getUser_id());
		if (StringUtil.IsNullOrEmpty(query.getUrl())) {
			sql.append(FROM_STR_2);
		} else {
			sql.append(FROM_STR);
			params.put("url", query.getUrl());
			params.put("method", query.getMethod());
		}

		// WHERE句作成
		String where = buildCondition(query, params);

		if (where.equals("")) {
			sql.append(WHERE_STR);
		} else {
			sql.append(where);
		}

		return sql.toString();
	}
}