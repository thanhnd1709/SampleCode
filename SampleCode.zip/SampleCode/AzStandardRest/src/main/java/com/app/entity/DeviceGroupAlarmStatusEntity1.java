package com.app.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * イベント・アラーム状態取得エンティティクラス
 * @author（TOSCO）エヒー
 */
@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class DeviceGroupAlarmStatusEntity1 {
	@Id
	private String device_group_id;

}
