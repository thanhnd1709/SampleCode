package com.app.model;

import javax.validation.constraints.NotNull;

import com.app.common.Consts;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * ファイルモデルクラス
 * @author（TOSCO）ウェイ
 */
@Data
public class FileModel01 {

	@ApiModelProperty(value = "ファイル種別（1：画像・音ファイル等 / 2：展開用ファイル / 9：その他ファイル）", required = true)
	private String file_type;

	@ApiModelProperty(value = "コンテナ名 ※ファイル種別が9の時は、コンテナ名も必須である。(9以外の時は、設定されていても無視する)")
	private String container;

	@ApiModelProperty(value = "ファイル名(ファイルパス情報含む)")
	private String file_name;

	@NotNull(message = "{" + Consts.MESSAGE_E000001 + "}")
	@ApiModelProperty(value = "圧縮有無フラグ（true / false）", required = true)
	private Boolean zip_flag;

	@ApiModelProperty(value = "機種ID ※ファイル種別が1の時は必須")
	private String model_id;

	@ApiModelProperty(value = "シリアルNo ※ファイル種別が1の時は必須")
	private String serial_no;

	@ApiModelProperty(value = "センサーID ※ファイル種別が1の時は必須")
	private String sensor_id;

	@ApiModelProperty(value = "計測時刻 ※ファイル種別が1の時は必須")
	private String measure_time;

	@ApiModelProperty(value = "メッセージ区分 ※ファイル種別が2の時は必須")
	private String message_class;

	@ApiModelProperty(value = "ファイル Stream", required = true)
	private String file;
}
