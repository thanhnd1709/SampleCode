package com.app.repository.impl;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.entity.StdGwCommandHistoryEntity;
import com.app.repository.GWCommandHistoryRepositoryCustom;

@Component
public class GWCommandHistoryRepositoryImpl implements GWCommandHistoryRepositoryCustom {
	@Autowired EntityManager em;

	@Override
	public StdGwCommandHistoryEntity findOneForUpdate(int id) {
		return em.find(StdGwCommandHistoryEntity.class, id, LockModeType.PESSIMISTIC_WRITE);
	}
}