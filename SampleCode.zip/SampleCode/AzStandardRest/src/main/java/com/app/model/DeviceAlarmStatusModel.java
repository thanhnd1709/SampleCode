package com.app.model;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;
import java.util.StringJoiner;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * デバイスアラーム状態モデル
 */
@Data
public class DeviceAlarmStatusModel {
	private static final String ENCODING = "UTF-8";


	@ApiModelProperty(value = "検出区分（1：GW異常検知(未受信) / 2：GW異常検知(受信SEQ抜け) / 3：デバイス異常検知 / 4：エッジ側イベント検出 / 5：クラウド側イベント検出   "
			+ "※複数が対象となる場合、区分値リストを配列で指定する（例：1と4が検索対象の場合、1,4 とセット））" , required =true)
	private String[] get_class;

	@ApiModelProperty(value = "発生復帰区分（1：発生(デフォルト値) / 2：復帰 / 3：全て")
	private String incident_class;

	@ApiModelProperty(value = "取得情報区分（1：直下最大イベントレベル / 2：配下最大イベントレベル）" , required =true)
	private String get_info_class;

	@ApiModelProperty(value = "比較区分（1：文字列としてレベル値を大小比較(デフォルト値) / 2：数値に変換し比較）")
	private String compare_class;

	@ApiModelProperty(value = "[配列]デバイスリスト(機種ID、シリアルNo)" , required =true)
	private List<DeviceListModel> device_list;

	@ApiModelProperty(value = "任意並び順条件(カンマ区切り)")
	private String sort;

	@ApiModelProperty(value = "取得フィールド")
	private String fields;

	@ApiModelProperty(value = "表示対象ページ番号")
	private String page;

	@ApiModelProperty(value = "1度に返すItem数")
	private String limit;

	public String buildUrlParameter() {
		StringJoiner sj = new StringJoiner("&", "?", "");
		sj.setEmptyValue("");
		try {
			if (get_class != null) for (String s : get_class) sj.add("get_class=" + URLEncoder.encode(s, ENCODING));

			if (incident_class != null) sj.add("incident_class=" + URLEncoder.encode(incident_class, ENCODING));

			if (get_info_class != null) sj.add("get_info_class=" + URLEncoder.encode(get_info_class, ENCODING));

			if (compare_class != null) sj.add("compare_class=" + URLEncoder.encode(compare_class, ENCODING));

			if (device_list != null) {
				for (int i = 0; i < device_list.size(); i++) {
					sj.add("device_list[" + i + "].model_id=" + URLEncoder.encode(device_list.get(i).getModel_id(), ENCODING));
					sj.add("device_list[" + i + "].serial_no=" + URLEncoder.encode(device_list.get(i).getSerial_no(), ENCODING));
				}
			}

			if (sort != null) sj.add("sort=" + URLEncoder.encode(sort, ENCODING));

			if (fields != null) sj.add("fields=" + URLEncoder.encode(fields, ENCODING));

			if (page != null) sj.add("page=" + URLEncoder.encode(page, ENCODING));

			if (limit != null) sj.add("limit=" + URLEncoder.encode(limit, ENCODING));

		} catch (UnsupportedEncodingException e) {
		}
		return sj.toString();
	}
}
