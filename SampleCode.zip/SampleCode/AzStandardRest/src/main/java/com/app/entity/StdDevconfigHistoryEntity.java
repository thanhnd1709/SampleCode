package com.app.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Version;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 */
@Entity
@Table(name="std_devconfig_history")
@Data
@EntityListeners(AuditingEntityListener.class)
@AllArgsConstructor
@NoArgsConstructor
public class StdDevconfigHistoryEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column
	private Integer id;

	@Column
	private String model_id;
	@Column
	private String serial_no;
	@Column
	private String config_id;
	@Column
	private String config_file;
	@Column
	private Timestamp gw_upload_time;
	@Column
	private String format_version;
	@Column
	private String config_version;
	@Column
	private String file_notification_key;
	@Column
	private Boolean regist_flg;
	@Column
	private Long result_send_id;
	@Version
	@Column
	private Long version;

	@Column
	private Timestamp insert_time;

	@PrePersist
    public void onPrePersist() {
        setInsert_time(new Timestamp(System.currentTimeMillis()));
        setUpdate_time(new Timestamp(System.currentTimeMillis()));
    }

	@Column
	private Timestamp update_time;

	@PreUpdate
    public void onPreUpdate() {
        setUpdate_time(new Timestamp(System.currentTimeMillis()));
    }

}

