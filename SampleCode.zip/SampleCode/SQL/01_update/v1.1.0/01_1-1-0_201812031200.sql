 -- =======================================================
 -- 受信メッセージをイベント・アラーム検出履歴(SQL Database)に登録する
 -- イベント・アラーム検出履歴を登録する
 -- =======================================================
CREATE PROCEDURE batch_insert_std_event_incidence_history
	-- 計測データ登録用 ユーザー定義テーブル型  
    @std_event_incidence_history_type std_event_incidence_history_type READONLY
AS
    BEGIN 
        DECLARE @model_id nvarchar(50);
        SELECT @model_id = model_id FROM @std_event_incidence_history_type
		DECLARE @serial_no nvarchar(50);
        SELECT @serial_no = serial_no FROM @std_event_incidence_history_type
		DECLARE @detection_class char;
        SELECT @detection_class = detection_class FROM @std_event_incidence_history_type
		DECLARE @event_id nvarchar(50);
        SELECT @event_id = event_id FROM @std_event_incidence_history_type
		DECLARE @event_time datetime2;
        SELECT @event_time = event_time FROM @std_event_incidence_history_type
		DECLARE @event_status nvarchar(50);
        SELECT @event_status = event_status FROM @std_event_incidence_history_type
		DECLARE @incident_class char;
        SELECT @incident_class = incident_class FROM @std_event_incidence_history_type
		DECLARE @event_level nvarchar(50);
        SELECT @event_level = event_level FROM @std_event_incidence_history_type
		DECLARE @detection_info nvarchar(4000);
        SELECT @detection_info = detection_info FROM @std_event_incidence_history_type
		DECLARE @version bigint;
        SELECT @version = version FROM @std_event_incidence_history_type
		DECLARE @inserted nvarchar(50);
        SELECT @inserted = inserted FROM @std_event_incidence_history_type
		DECLARE @insert_time datetime2;
        SELECT @insert_time = insert_time FROM @std_event_incidence_history_type

        MERGE INTO
        std_event_incidence_history AS EIR
        USING
        (
        SELECT
        @model_id AS m,
        @serial_no AS s,
        @detection_class AS dc,
        @event_id AS ei,
        @event_time AS et,
        @event_status AS es,
        @incident_class AS ic,
        @event_level AS el,
        @detection_info AS di
        ) AS EIR2
        ON (
        EIR.model_id = EIR2.m
        AND EIR.serial_no = EIR2.s
        AND EIR.detection_class = EIR2.dc
        AND EIR.event_id = EIR2.ei
        AND EIR.event_time = EIR2.et
        AND (EIR.event_status = EIR2.es OR (EIR.event_status is null AND EIR2.es is null))
        AND EIR.incident_class = EIR2.ic
        AND (EIR.event_level = EIR2.el OR (EIR.event_level is null AND EIR2.el is null))
        AND (EIR.detection_info = EIR2.di OR (EIR.detection_info is null AND EIR2.di is null))
        )
        WHEN NOT MATCHED THEN
        INSERT(model_id, serial_no, detection_class, event_id, event_time, event_status, incident_class, event_level, detection_info, version, inserted)
        VALUES
        (EIR2.m,  EIR2.s, EIR2.dc, EIR2.ei, EIR2.et, EIR2.es, EIR2.ic, EIR2.el, EIR2.di, @version, @inserted);
    END
GO


 -- =======================================================
 -- Stored procedures for insert std_receive_seq
 -- Register in the reception sequence table std_receive_seq (Sql Database)
 -- =======================================================
CREATE PROCEDURE batch_insert_std_receive_seq
	-- 計測データ登録用 ユーザー定義テーブル型  
    @std_receive_seq_type std_receive_seq_type READONLY
AS
    BEGIN 
        BEGIN
            DECLARE @start_time datetime2;
            SELECT @start_time = start_time FROM @std_receive_seq_type
            DECLARE @gw_model_id nvarchar(128);
            SELECT @gw_model_id = gw_model_id FROM @std_receive_seq_type
            DECLARE @gw_serial_no nvarchar(128);
            SELECT @gw_serial_no = gw_serial_no FROM @std_receive_seq_type
            DECLARE @receive_seq nvarchar(128);
            SELECT @receive_seq = receive_seq FROM @std_receive_seq_type
            DECLARE @receive_time datetime2;
            SELECT @receive_time = receive_time FROM @std_receive_seq_type
           
            UPDATE std_receive_seq
            SET start_time = @start_time
            WHERE gw_model_id = @gw_model_id AND 
            gw_serial_no = @gw_serial_no AND 
            start_time = @start_time AND
            receive_seq = @receive_seq AND 
            receive_time = @receive_time 
            IF @@ROWCOUNT = 0 
            INSERT INTO std_receive_seq (gw_model_id,gw_serial_no,start_time,receive_seq,receive_time)
            SELECT @gw_model_id,@gw_serial_no,@start_time,@receive_seq,@receive_time
            WHERE NOT EXISTS (SELECT gw_model_id,gw_serial_no FROM std_receive_seq WHERE gw_model_id = @gw_model_id AND
            gw_serial_no = @gw_serial_no AND start_time = @start_time AND receive_seq = @receive_seq)
        END
    END
GO

CREATE FUNCTION [dbo].[get_mst_device_device_mode]
(
@model_id nvarchar(50),
@serial_no nvarchar(50)
)  
RETURNS TABLE  
AS  
RETURN  
    SELECT device_mode 
    FROM mst_device 
    WHERE model_id = @model_id 
    AND serial_no = @serial_no
GO

CREATE FUNCTION [dbo].[get_mst_event_event_level]
 (
 @model_id nvarchar(50),
 @serial_no nvarchar(50),
 @event_id nvarchar(50)
 ) 
 RETURNS TABLE 
 AS 
 RETURN 
 SELECT event_level FROM mst_event
 WHERE model_id = @model_id
 AND serial_no = @serial_no
 AND event_id = @event_id
GO

CREATE TYPE mst_event_key_type AS TABLE (
 model_id nvarchar(50),
 serial_no nvarchar(50),
 event_id nvarchar(50)
);

CREATE TYPE std_event_incidence_history_type AS TABLE (
    model_id nvarchar(50),
    serial_no nvarchar(50),
    detection_class char,
    event_id nvarchar(50),
    event_time datetime2,
    event_status nvarchar(50),
    incident_class char,
    event_level nvarchar(50),
    detection_info nvarchar(4000),
    version bigint,
    inserted nvarchar(50),
    insert_time datetime2
);

CREATE TYPE std_receive_seq_type AS TABLE (
 gw_model_id nvarchar(128),
 gw_serial_no nvarchar(128),
 start_time datetime2,
 receive_seq nvarchar(128),
 receive_time datetime2
);

UPDATE [dbo].[mst_system_info] SET VALUE_STRING = '1.1.0_201812031200' where [key] = 'DBVersion';