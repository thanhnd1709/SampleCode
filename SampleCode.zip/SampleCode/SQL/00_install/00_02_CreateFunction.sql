GO
CREATE FUNCTION [dbo].[fn_BaseConfigAuthChk]
(
  @model_id AS nvarchar(50),
  @config_id AS nvarchar(50),
  @user_id AS nvarchar(100),
  @url nvarchar(500) = '',
  @method nvarchar(50) = ''
)
RETURNS bit
    AS
    BEGIN
        Declare @ret bit;
        IF @user_id = '##@ Azure Application @##' RETURN 1;

     -- SELECT (CHECK)
        SELECT @ret=(SELECT 1
                      WHERE EXISTS (SELECT 1
                                      FROM mst_user_role u,
                                           mst_role_base_device_visual d
                                     WHERE u.user_id = @user_id
                                       AND d.role_id = u.role_id
                                       AND d.model_id = @model_id
                                       AND d.visual_auth_flg = 1
                                       AND (@url = ''
                                            OR EXISTS (SELECT 1 FROM mst_program_authority pg,
                                                                     mst_role_program_authority rp
                                                               WHERE pg.url = @url
                                                                 AND pg.method = @method
                                                                 AND rp.role_id = u.role_id
                                                                 AND rp.authority_id = pg.authority_id))
                                       AND NOT EXISTS (SELECT 1 FROM mst_role_base_config_visual rv
                                                               WHERE rv.role_id = u.role_id
                                                                 AND rv.model_id = @model_id
                                                                 AND rv.config_id = @config_id
                                                                 AND rv.visual_auth_flg = 0))
         );

        RETURN @ret;
    END
;

GO
CREATE FUNCTION [dbo].[fn_BaseDeviceAuthChk]
(
  @model_id AS nvarchar(50),
  @user_id AS nvarchar(100),
  @url nvarchar(500) = '',
  @method nvarchar(50) = ''
)
RETURNS bit
    AS
    BEGIN
        Declare @ret bit;
        IF @user_id = '##@ Azure Application @##' RETURN 1;

     -- SELECT (CHECK)
        SELECT @ret=(SELECT 1
                      WHERE EXISTS (SELECT 1
                                      FROM mst_user_role u,
                                           mst_role_base_device_visual d
                                     WHERE u.user_id = @user_id
                                       AND d.role_id = u.role_id
                                       AND d.model_id = @model_id
                                       AND d.visual_auth_flg = 1
                                       AND (@url = ''
                                            OR EXISTS (SELECT 1 FROM mst_program_authority pg,
                                                                     mst_role_program_authority rp
                                                               WHERE pg.url = @url
                                                                 AND pg.method = @method
                                                                 AND rp.role_id = u.role_id
                                                                 AND rp.authority_id = pg.authority_id)))
         );

        RETURN @ret;
    END
;

GO
CREATE FUNCTION [dbo].[fn_BaseEventAuthChk]
(
  @model_id AS nvarchar(50),
  @event_id AS nvarchar(50),
  @user_id AS nvarchar(100),
  @url nvarchar(500) = '',
  @method nvarchar(50) = ''
)
RETURNS bit
    AS
    BEGIN
        Declare @ret bit;
        IF @user_id = '##@ Azure Application @##' RETURN 1;

     -- SELECT (CHECK)
        SELECT @ret=(SELECT 1
                      WHERE EXISTS (SELECT 1
                                      FROM mst_user_role u,
                                           mst_role_base_device_visual d
                                     WHERE u.user_id = @user_id
                                       AND d.role_id = u.role_id
                                       AND d.model_id = @model_id
                                       AND d.visual_auth_flg = 1
                                       AND (@url = ''
                                            OR EXISTS (SELECT 1 FROM mst_program_authority pg,
                                                                     mst_role_program_authority rp
                                                               WHERE pg.url = @url
                                                                 AND pg.method = @method
                                                                 AND rp.role_id = u.role_id
                                                                 AND rp.authority_id = pg.authority_id))
                                       AND NOT EXISTS (SELECT 1 FROM mst_role_base_event_visual rv
                                                               WHERE rv.role_id = u.role_id
                                                                 AND rv.model_id = @model_id
                                                                 AND rv.event_id = @event_id
                                                                 AND rv.visual_auth_flg = 0))
         );

        RETURN @ret;
    END
;

GO
CREATE FUNCTION [dbo].[fn_BaseSensorAuthChk]
(
  @model_id AS nvarchar(50),
  @sensor_id AS nvarchar(50),
  @user_id AS nvarchar(100),
  @url nvarchar(500) = '',
  @method nvarchar(50) = ''
)
RETURNS bit
    AS
    BEGIN
        Declare @ret bit;
        IF @user_id = '##@ Azure Application @##' RETURN 1;

     -- SELECT (CHECK)
        SELECT @ret=(SELECT 1
                      WHERE EXISTS (SELECT 1
                                      FROM mst_user_role u,
                                           mst_role_base_device_visual d
                                     WHERE u.user_id = @user_id
                                       AND d.role_id = u.role_id
                                       AND d.model_id = @model_id
                                       AND d.visual_auth_flg = 1
                                       AND (@url = ''
                                            OR EXISTS (SELECT 1 FROM mst_program_authority pg,
                                                                     mst_role_program_authority rp
                                                               WHERE pg.url = @url
                                                                 AND pg.method = @method
                                                                 AND rp.role_id = u.role_id
                                                                 AND rp.authority_id = pg.authority_id))
                                       AND NOT EXISTS (SELECT 1 FROM mst_role_base_sensor_visual rv
                                                               WHERE rv.role_id = u.role_id
                                                                 AND rv.model_id = @model_id
                                                                 AND rv.sensor_id = @sensor_id
                                                                 AND rv.visual_auth_flg = 0))
         );

        RETURN @ret;
    END
;

GO
CREATE FUNCTION [dbo].[fn_ConfigAuthChk]
(
  @model_id AS nvarchar(50),
  @serial_no AS nvarchar(50),
  @config_id AS nvarchar(50),
  @user_id AS nvarchar(100),
  @url nvarchar(500) = '',
  @method nvarchar(50) = ''
)
RETURNS bit
    AS
    BEGIN
        Declare @ret bit;
        IF @user_id = '##@ Azure Application @##' RETURN 1;

     -- SELECT (CHECK)
        SELECT @ret=(SELECT 1
                      WHERE EXISTS (SELECT 1
                                      FROM mst_user_role u,
                                           std_role_device rd
                                     WHERE u.user_id = @user_id
                                       AND rd.role_id = u.role_id
                                       AND rd.model_id = @model_id
                                       AND rd.serial_no = @serial_no
                                       AND (@url = ''
                                            OR EXISTS (SELECT 1 FROM mst_program_authority pg,
                                                                     mst_role_program_authority rp
                                                               WHERE pg.url = @url
                                                                 AND pg.method = @method
                                                                 AND rp.role_id = u.role_id
                                                                 AND rp.authority_id = pg.authority_id))
                                       AND NOT EXISTS (SELECT 1 FROM mst_role_config_visual rv
                                                               WHERE rv.role_id = u.role_id
                                                                 AND rv.model_id = @model_id
                                                                 AND rv.serial_no = @serial_no
                                                                 AND rv.config_id = @config_id
                                                                 AND rv.visual_auth_flg = 0)
                                       AND NOT EXISTS (SELECT 1 FROM mst_role_base_config_visual rv
                                                               WHERE rv.role_id = u.role_id
                                                                 AND rv.model_id = @model_id
                                                                 AND rv.config_id = @config_id
                                                                 AND rv.visual_auth_flg = 0))
         );

        RETURN @ret;
    END
;

GO
CREATE FUNCTION [dbo].[fn_DeviceAuthChk]
(
  @model_id AS nvarchar(50),
  @serial_no AS nvarchar(50),
  @user_id AS nvarchar(100),
  @url nvarchar(500) = '',
  @method nvarchar(50) = ''
)
RETURNS bit
    AS
    BEGIN
        Declare @ret bit;
        IF @user_id = '##@ Azure Application @##' RETURN 1;

     -- SELECT (CHECK)
        SELECT @ret=(SELECT 1
                      WHERE EXISTS (SELECT 1
                                      FROM mst_user_role u,
                                           std_role_device rd
                                     WHERE u.user_id = @user_id
                                       AND rd.role_id = u.role_id
                                       AND rd.model_id = @model_id
                                       AND rd.serial_no = @serial_no
                                       AND (@url = ''
                                            OR EXISTS (SELECT 1 FROM mst_program_authority pg,
                                                                     mst_role_program_authority rp
                                                               WHERE pg.url = @url
                                                                 AND pg.method = @method
                                                                 AND rp.role_id = u.role_id
                                                                 AND rp.authority_id = pg.authority_id)))
         );

        RETURN @ret;
    END
;

GO
CREATE FUNCTION [dbo].[fn_DeviceGroupAuthChk]
(
  @device_group_id AS nvarchar(50),
  @user_id AS nvarchar(100),
  @url nvarchar(500) = '',
  @method nvarchar(50) = ''
)
RETURNS bit
    AS
    BEGIN
        Declare @ret bit;
        IF @user_id = '##@ Azure Application @##' RETURN 1;

        WITH device_group_list (parent_device_group_id, device_group_id, loop_cnt) AS (
     -- Root
        SELECT parent_device_group_id, device_group_id, 1 as loop_cnt
          FROM mst_device_group
         WHERE device_group_id = @device_group_id
        UNION ALL
     -- Child
        SELECT g.parent_device_group_id, g.device_group_id, gl.loop_cnt + 1 as loop_cnt
          FROM device_group_list gl,
               mst_device_group g
         WHERE gl.loop_cnt < 40
           AND gl.parent_device_group_id is not null
           AND g.device_group_id = gl.parent_device_group_id)
     -- SELECT (CHECK)
        SELECT @ret=(SELECT 1
                      WHERE EXISTS (SELECT 1
                                      FROM mst_user_role u,
                                           mst_role_root_group g,
                                           device_group_list gl
                                     WHERE u.user_id = @user_id
                                       AND g.role_id = u.role_id
                                       AND g.root_group_id = gl.device_group_id
                                       AND (@url = ''
                                            OR EXISTS (SELECT 1 FROM mst_program_authority pg,
                                                                     mst_role_program_authority rp
                                                               WHERE pg.url = @url
                                                                 AND pg.method = @method
                                                                 AND rp.role_id = u.role_id
                                                                 AND rp.authority_id = pg.authority_id)))
         );

        RETURN @ret;
    END
;

GO
CREATE FUNCTION [dbo].[fn_EventAuthChk]
(
  @model_id AS nvarchar(50),
  @serial_no AS nvarchar(50),
  @event_id AS nvarchar(50),
  @user_id AS nvarchar(100),
  @url nvarchar(500) = '',
  @method nvarchar(50) = ''
)
RETURNS bit
    AS
    BEGIN
        Declare @ret bit;
        IF @user_id = '##@ Azure Application @##' RETURN 1;

     -- SELECT (CHECK)
        SELECT @ret=(SELECT 1
                      WHERE EXISTS (SELECT 1
                                      FROM mst_user_role u,
                                           std_role_device rd
                                     WHERE u.user_id = @user_id
                                       AND rd.role_id = u.role_id
                                       AND rd.model_id = @model_id
                                       AND rd.serial_no = @serial_no
                                       AND (@url = ''
                                            OR EXISTS (SELECT 1 FROM mst_program_authority pg,
                                                                     mst_role_program_authority rp
                                                               WHERE pg.url = @url
                                                                 AND pg.method = @method
                                                                 AND rp.role_id = u.role_id
                                                                 AND rp.authority_id = pg.authority_id))
                                       AND NOT EXISTS (SELECT 1 FROM mst_role_event_visual rv
                                                               WHERE rv.role_id = u.role_id
                                                                 AND rv.model_id = @model_id
                                                                 AND rv.serial_no = @serial_no
                                                                 AND rv.event_id = @event_id
                                                                 AND rv.visual_auth_flg = 0)
                                       AND NOT EXISTS (SELECT 1 FROM mst_role_base_event_visual rv
                                                               WHERE rv.role_id = u.role_id
                                                                 AND rv.model_id = @model_id
                                                                 AND rv.event_id = @event_id
                                                                 AND rv.visual_auth_flg = 0))
         );

        RETURN @ret;
    END
;

GO
CREATE FUNCTION [dbo].[fn_SensorAuthChk]
(
  @model_id AS nvarchar(50),
  @serial_no AS nvarchar(50),
  @sensor_id AS nvarchar(50),
  @user_id AS nvarchar(100),
  @url nvarchar(500) = '',
  @method nvarchar(50) = ''
)
RETURNS bit
    AS
    BEGIN
        Declare @ret bit;
        IF @user_id = '##@ Azure Application @##' RETURN 1;

     -- SELECT (CHECK)
        SELECT @ret=(SELECT 1
                      WHERE EXISTS (SELECT 1
                                      FROM mst_user_role u,
                                           std_role_device rd
                                     WHERE u.user_id = @user_id
                                       AND rd.role_id = u.role_id
                                       AND rd.model_id = @model_id
                                       AND rd.serial_no = @serial_no
                                       AND (@url = ''
                                            OR EXISTS (SELECT 1 FROM mst_program_authority pg,
                                                                     mst_role_program_authority rp
                                                               WHERE pg.url = @url
                                                                 AND pg.method = @method
                                                                 AND rp.role_id = u.role_id
                                                                 AND rp.authority_id = pg.authority_id))
                                       AND NOT EXISTS (SELECT 1 FROM mst_role_sensor_visual rv
                                                               WHERE rv.role_id = u.role_id
                                                                 AND rv.model_id = @model_id
                                                                 AND rv.serial_no = @serial_no
                                                                 AND rv.sensor_id = @sensor_id
                                                                 AND rv.visual_auth_flg = 0)
                                       AND NOT EXISTS (SELECT 1 FROM mst_role_base_sensor_visual rv
                                                               WHERE rv.role_id = u.role_id
                                                                 AND rv.model_id = @model_id
                                                                 AND rv.sensor_id = @sensor_id
                                                                 AND rv.visual_auth_flg = 0))
         );

        RETURN @ret;
    END
;

GO
CREATE FUNCTION [dbo].[fn_GetParentRootGroup]
(
  @device_group_id  nvarchar(50)
)
RETURNS TABLE
AS
RETURN 
(
 WITH device_group_list (parent_device_group_id, device_group_id, loop_cnt) AS (
 -- Root
    SELECT parent_device_group_id,
           device_group_id,
           1 as loop_cnt
    　FROM mst_device_group
     WHERE device_group_id = @device_group_id
    UNION ALL
 -- Child
    SELECT g.parent_device_group_id,
           g.device_group_id,
           gl.loop_cnt + 1 as loop_cnt
      FROM device_group_list gl,
           mst_device_group g
     WHERE gl.loop_cnt < 40
       AND g.device_group_id = gl.parent_device_group_id)
  SELECT rg.role_id, rg.root_group_id
    FROM device_group_list gl,
         mst_role_root_group rg
   WHERE rg.root_group_id = gl.device_group_id
)

GO
CREATE FUNCTION [dbo].[fn_GetCngRootGroup]
(
  @before_parent_id nvarchar(50),
  @after_parent_id nvarchar(50)
)
RETURNS TABLE
AS
RETURN 
(
   SELECT CASE WHEN a.role_id is null       THEN b.role_id       ELSE a.role_id       END role_id,
          CASE WHEN a.root_group_id is null THEN b.root_group_id ELSE a.root_group_id END root_group_id
     FROM dbo.fn_GetParentRootGroup(@after_parent_id) AS a
     FULL JOIN dbo.fn_GetParentRootGroup(@before_parent_id) AS b
       ON b.role_id = a.role_id
      AND b.root_group_id = a.root_group_id
    WHERE a.role_id is null or b.role_id is null
)

GO
CREATE FUNCTION [dbo].[fn_UserDeviceGroup] 
(
  @user_id nvarchar(100),
  @url nvarchar(500) = '',
  @method nvarchar(50) = ''
)
RETURNS TABLE 
AS
RETURN 
(
 WITH device_group_list (
    device_group_id,
    device_group_type,
    device_group_subtype,
    device_group_name_locale1,
    device_group_name_locale2,
    device_group_name_locale3,
    device_group_description_locale1,
    device_group_description_locale2,
    device_group_description_locale3,
    parent_device_group_id,
    setup_place, setup_status,
    latitude,
    longitude,
    device_group_note,
    role_id,
    root_group_id,
    role_name_locale1,
    role_name_locale2,
    role_name_locale3,
    role_description_locale1,
    role_description_locale2,
    role_description_locale3,
    role_note,
    hierarchy) AS (
 -- Root
    SELECT g.device_group_id,
           g.device_group_type,
           g.device_group_subtype,
           g.name_locale1 as device_group_name_locale1,
           g.name_locale2 as device_group_name_locale2,
           g.name_locale3 as device_group_name_locale3,
           g.description_locale1 as device_group_description_locale1,
           g.description_locale2 as device_group_description_locale2,
           g.description_locale3 as device_group_description_locale3,
           g.parent_device_group_id,
           g.setup_place,
           g.setup_status,
           g.latitude,
           g.longitude,
           g.note as device_group_note,
           ur.role_id,
           rg.root_group_id,
           r.name_locale1 as role_name_locale1,
           r.name_locale2 as role_name_locale2,
           r.name_locale3 as role_name_locale3,
           r.description_locale1 as role_description_locale1,
           r.description_locale2 as role_description_locale2,
           r.description_locale3 as role_description_locale3,
           r.note as role_note,
           1 as hierarchy
       FROM mst_user_role ur,
           mst_role_root_group rg,
           mst_device_group g,
           mst_role r
     WHERE ur.user_id = @user_id
       AND rg.role_id = ur.role_id
       AND r.role_id  = rg.role_id
       AND g.device_group_id = rg.root_group_id
       AND (@url = ''
            OR EXISTS (SELECT 1 FROM mst_program_authority pg,
                                 mst_role_program_authority rp
                           WHERE pg.url = @url
                             AND pg.method = @method
                             AND rp.role_id = ur.role_id
                             AND rp.authority_id = pg.authority_id))
    UNION ALL
 -- Child
    SELECT g.device_group_id,
           g.device_group_type,
           g.device_group_subtype,
           g.name_locale1 as device_group_name_locale1,
           g.name_locale2 as device_group_name_locale2,
           g.name_locale3 as device_group_name_locale3,
           g.description_locale1 as device_group_description_locale1,
           g.description_locale2 as device_group_description_locale2,
           g.description_locale3 as device_group_description_locale3,
           g.parent_device_group_id,
           g.setup_place,
           g.setup_status,
           g.latitude,
           g.longitude,
           g.note as device_group_note,
           gl.role_id,
           gl.root_group_id,
           gl.role_name_locale1,
           gl.role_name_locale2,
           gl.role_name_locale3,
           gl.role_description_locale1,
           gl.role_description_locale2,
           gl.role_description_locale3,
           gl.role_note,
           gl.hierarchy + 1 as hierarchy
      FROM device_group_list gl,
           mst_device_group g
     WHERE gl.hierarchy < 40
       AND gl.device_group_id = g.parent_device_group_id)
  SELECT * FROM device_group_list
);

GO
CREATE FUNCTION [dbo].[get_mst_event_event_level]
(
@model_id nvarchar(50),
@serial_no nvarchar(50),
@event_id nvarchar(50)
)  
RETURNS TABLE  
AS  
RETURN  
    SELECT event_level FROM mst_event
        WHERE model_id = @model_id
        AND serial_no = @serial_no
        AND event_id = @event_id

 
GO
CREATE FUNCTION [dbo].[get_mst_device_device_mode]
(
@model_id nvarchar(50),
@serial_no nvarchar(50)
)  
RETURNS TABLE  
AS  
RETURN  
    SELECT device_mode 
    FROM mst_device 
    WHERE model_id = @model_id 
    AND serial_no = @serial_no
