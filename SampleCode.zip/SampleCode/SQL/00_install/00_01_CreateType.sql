GO
CREATE TYPE [dbo].[std_gw_receve_time_type] AS TABLE(
	[model_id] [nvarchar](50) NULL,
	[serial_no] [nvarchar](50) NULL,
	[receve_time] [datetime2](7) NULL
)

GO
CREATE TYPE [dbo].[std_measure_data_table_type] AS TABLE(
	[rownum] [int] NULL,
	[model_id] [nvarchar](50) NULL,
	[serial_no] [nvarchar](50) NULL,
	[sensor_id] [nvarchar](50) NULL,
	[measure_time] [datetime2](7) NULL,
	[measure_data] [nvarchar](4000) NULL,
	[data_migrate_class] [char](1) NULL,
	[version] [bigint] NULL
)

GO
CREATE TYPE [dbo].[std_event_incidence_history_type] AS TABLE(
	[model_id] [nvarchar](50) NULL,
	[serial_no] [nvarchar](50) NULL,
	[detection_class] [char](1) NULL,
	[event_id] [nvarchar](50) NULL,
	[event_time] [datetime2](7) NULL,
	[event_status] [nvarchar](50) NULL,
	[incident_class] [char](1) NULL,
	[event_level] [nvarchar](50) NULL,
	[detection_info] [nvarchar](4000) NULL,
	[version] [bigint] NULL,
	[inserted] [nvarchar](50) NULL,
	[insert_time] [datetime2](7) NULL
)

GO
CREATE TYPE [dbo].[std_receive_seq_type] AS TABLE(
	[gw_model_id] [nvarchar](128) NULL,
	[gw_serial_no] [nvarchar](128) NULL,
	[start_time] [datetime2](7) NULL,
	[receive_seq] [nvarchar](128) NULL,
	[receive_time] [datetime2](7) NULL
)
