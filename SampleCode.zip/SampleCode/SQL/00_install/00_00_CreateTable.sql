
CREATE TABLE [dbo].[mst_device_group](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[device_group_id] [nvarchar](50) NOT NULL,
	[device_group_type] [nvarchar](50) NOT NULL,
	[device_group_subtype] [nvarchar](50) NULL,
	[name_locale1] [nvarchar](100) NOT NULL,
	[name_locale2] [nvarchar](100) NULL,
	[name_locale3] [nvarchar](100) NULL,
	[description_locale1] [nvarchar](2000) NULL,
	[description_locale2] [nvarchar](2000) NULL,
	[description_locale3] [nvarchar](2000) NULL,
	[parent_device_group_id] [nvarchar](50) NULL,
	[setup_place] [nvarchar](100) NULL,
	[setup_status] [nvarchar](50) NULL,
	[latitude] [decimal](11, 9) NULL,
	[longitude] [decimal](12, 9) NULL,
	[note] [nvarchar](2000) NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_device_group] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_facility] UNIQUE NONCLUSTERED 
(
	[device_group_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_role_root_group](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[role_id] [nvarchar](50) NOT NULL,
	[root_group_id] [nvarchar](50) NOT NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_role_root_group] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_role_root_group] UNIQUE NONCLUSTERED 
(
	[role_id] ASC,
	[root_group_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_user_role](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[user_id] [nvarchar](100) NOT NULL,
	[role_id] [nvarchar](50) NOT NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_user_role] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_user_role] UNIQUE NONCLUSTERED 
(
	[user_id] ASC,
	[role_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_program_authority](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[authority_id] [nvarchar](50) NOT NULL,
	[authority_type] [nvarchar](50) NULL,
	[name_locale1] [nvarchar](100) NOT NULL,
	[name_locale2] [nvarchar](100) NULL,
	[name_locale3] [nvarchar](100) NULL,
	[description_locale1] [nvarchar](2000) NULL,
	[description_locale2] [nvarchar](2000) NULL,
	[description_locale3] [nvarchar](2000) NULL,
	[program_id] [nvarchar](50) NULL,
	[url] [nvarchar](500) NULL,
	[method] [nvarchar](50) NULL,
	[note] [nvarchar](2000) NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_program_authority] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_program_authority] UNIQUE NONCLUSTERED 
(
	[authority_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_role_program_authority](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[role_id] [nvarchar](50) NOT NULL,
	[authority_id] [nvarchar](50) NOT NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_role_program_authority] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_role_program_authority] UNIQUE NONCLUSTERED 
(
	[role_id] ASC,
	[authority_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_role](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[role_id] [nvarchar](50) NOT NULL,
	[base_role_flg] [bit] NULL,
	[authority_role_id] [nvarchar](50) NULL,
	[name_locale1] [nvarchar](100) NOT NULL,
	[name_locale2] [nvarchar](100) NULL,
	[name_locale3] [nvarchar](100) NULL,
	[description_locale1] [nvarchar](2000) NULL,
	[description_locale2] [nvarchar](2000) NULL,
	[description_locale3] [nvarchar](2000) NULL,
	[note] [nvarchar](2000) NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_role] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_role] UNIQUE NONCLUSTERED 
(
	[role_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_base_devconfig](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[config_id] [nvarchar](50) NOT NULL,
	[config_type] [nvarchar](50) NULL,
	[required_class] [char](1) NULL,
	[name_locale1] [nvarchar](100) NOT NULL,
	[name_locale2] [nvarchar](100) NULL,
	[name_locale3] [nvarchar](100) NULL,
	[description_locale1] [nvarchar](2000) NULL,
	[description_locale2] [nvarchar](2000) NULL,
	[description_locale3] [nvarchar](2000) NULL,
	[data_type] [nvarchar](50) NULL,
	[data] [nvarchar](2000) NULL,
	[template_file_name] [nvarchar](200) NULL,
	[tool_address] [nvarchar](2000) NULL,
	[tool_class] [char](1) NULL,
	[apply_command] [nvarchar](2000) NULL,
	[inventory_command] [nvarchar](2000) NULL,
	[note] [nvarchar](2000) NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_base_devconfig] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_base_devconfig] UNIQUE NONCLUSTERED 
(
	[model_id] ASC,
	[config_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_base_device](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[device_type] [nvarchar](50) NOT NULL,
	[iot_device_flg] [bit] NOT NULL,
	[communication_flg] [bit] NOT NULL,
	[name_locale1] [nvarchar](100) NOT NULL,
	[name_locale2] [nvarchar](100) NULL,
	[name_locale3] [nvarchar](100) NULL,
	[description_locale1] [nvarchar](2000) NULL,
	[description_locale2] [nvarchar](2000) NULL,
	[description_locale3] [nvarchar](2000) NULL,
	[maker_code] [nvarchar](50) NULL,
	[parent_model_id] [nvarchar](50) NULL,
	[setup_place] [nvarchar](100) NULL,
	[setup_status] [nvarchar](50) NULL,
	[time_zone] [nvarchar](10) NULL,
	[latitude] [decimal](11, 9) NULL,
	[longitude] [decimal](12, 9) NULL,
	[unreceive_seconds] [int] NULL,
	[note] [nvarchar](2000) NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_base_device] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_base_device] UNIQUE NONCLUSTERED 
(
	[model_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_base_event](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[event_id] [nvarchar](50) NOT NULL,
	[event_type] [nvarchar](50) NULL,
	[event_level] [nvarchar](50) NULL,
	[sensor_id] [nvarchar](50) NULL,
	[name_locale1] [nvarchar](100) NOT NULL,
	[name_locale2] [nvarchar](100) NULL,
	[name_locale3] [nvarchar](100) NULL,
	[description_locale1] [nvarchar](2000) NULL,
	[description_locale2] [nvarchar](2000) NULL,
	[description_locale3] [nvarchar](2000) NULL,
	[chk_app_name] [nvarchar](50) NULL,
	[chk_app_parameter] [nvarchar](500) NULL,
	[check_timing] [nvarchar](50) NULL,
	[note] [nvarchar](2000) NULL,
	[attribute_sync_flg] [bit] NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_base_event] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_base_event] UNIQUE NONCLUSTERED 
(
	[model_id] ASC,
	[event_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_base_sensor](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[sensor_id] [nvarchar](50) NOT NULL,
	[sensor_type] [nvarchar](50) NOT NULL,
	[name_locale1] [nvarchar](100) NOT NULL,
	[name_locale2] [nvarchar](100) NULL,
	[name_locale3] [nvarchar](100) NULL,
	[unit_locale1] [nvarchar](50) NOT NULL,
	[unit_locale2] [nvarchar](50) NULL,
	[unit_locale3] [nvarchar](50) NULL,
	[transform_locale1] [nvarchar](100) NULL,
	[transform_locale2] [nvarchar](100) NULL,
	[transform_locale3] [nvarchar](100) NULL,
	[decimal_num_locale1] [int] NULL,
	[decimal_num_locale2] [int] NULL,
	[decimal_num_locale3] [int] NULL,
	[max_value_locale1] [float] NULL,
	[max_value_locale2] [float] NULL,
	[max_value_locale3] [float] NULL,
	[min_value_locale1] [float] NULL,
	[min_value_locale2] [float] NULL,
	[min_value_locale3] [float] NULL,
	[description_locale1] [nvarchar](2000) NULL,
	[description_locale2] [nvarchar](2000) NULL,
	[description_locale3] [nvarchar](2000) NULL,
	[measure_type] [char](1) NOT NULL,
	[data_type] [nvarchar](50) NOT NULL,
	[fixed_length] [int] NULL,
	[time_data_create_flg] [bit] NULL,
	[short_term_minutes] [int] NULL,
	[note] [nvarchar](2000) NULL,
	[attribute_sync_flg] [bit] NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_base_sensor] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_base_sensor] UNIQUE NONCLUSTERED 
(
	[model_id] ASC,
	[sensor_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_devconfig](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[serial_no] [nvarchar](50) NOT NULL,
	[config_id] [nvarchar](50) NOT NULL,
	[config_type] [nvarchar](50) NULL,
	[required_class] [char](1) NULL,
	[name_locale1] [nvarchar](100) NOT NULL,
	[name_locale2] [nvarchar](100) NULL,
	[name_locale3] [nvarchar](100) NULL,
	[description_locale1] [nvarchar](2000) NULL,
	[description_locale2] [nvarchar](2000) NULL,
	[description_locale3] [nvarchar](2000) NULL,
	[data_type] [nvarchar](50) NULL,
	[data] [nvarchar](2000) NULL,
	[config_file_name] [nvarchar](200) NULL,
	[tool_address] [nvarchar](2000) NULL,
	[tool_class] [char](1) NULL,
	[apply_command] [nvarchar](2000) NULL,
	[inventory_command] [nvarchar](2000) NULL,
	[note] [nvarchar](2000) NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_devconfig] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_devconfig] UNIQUE NONCLUSTERED 
(
	[model_id] ASC,
	[serial_no] ASC,
	[config_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_device](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[serial_no] [nvarchar](50) NOT NULL,
	[device_type] [nvarchar](50) NOT NULL,
	[iot_device_flg] [bit] NOT NULL,
	[communication_flg] [bit] NOT NULL,
	[name_locale1] [nvarchar](100) NOT NULL,
	[name_locale2] [nvarchar](100) NULL,
	[name_locale3] [nvarchar](100) NULL,
	[description_locale1] [nvarchar](2000) NULL,
	[description_locale2] [nvarchar](2000) NULL,
	[description_locale3] [nvarchar](2000) NULL,
	[maker_code] [nvarchar](50) NULL,
	[parent_model_id] [nvarchar](50) NULL,
	[parent_serial_no] [nvarchar](50) NULL,
	[setup_place] [nvarchar](100) NULL,
	[setup_status] [nvarchar](50) NULL,
	[time_zone] [nvarchar](10) NULL,
	[latitude] [decimal](11, 9) NULL,
	[longitude] [decimal](12, 9) NULL,
	[device_mode] [char](1) NOT NULL,
	[unreceive_seconds] [int] NULL,
	[note] [nvarchar](2000) NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_device] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_device] UNIQUE NONCLUSTERED 
(
	[model_id] ASC,
	[serial_no] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_device_mode_history](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[serial_no] [nvarchar](50) NOT NULL,
	[device_mode] [char](1) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_device_mode_history] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


CREATE TABLE [dbo].[mst_event](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[serial_no] [nvarchar](50) NOT NULL,
	[event_id] [nvarchar](50) NOT NULL,
	[event_type] [nvarchar](50) NULL,
	[event_level] [nvarchar](50) NULL,
	[sensor_id] [nvarchar](50) NULL,
	[name_locale1] [nvarchar](100) NOT NULL,
	[name_locale2] [nvarchar](100) NULL,
	[name_locale3] [nvarchar](100) NULL,
	[description_locale1] [nvarchar](2000) NULL,
	[description_locale2] [nvarchar](2000) NULL,
	[description_locale3] [nvarchar](2000) NULL,
	[chk_app_name] [nvarchar](50) NULL,
	[chk_app_parameter] [nvarchar](500) NULL,
	[check_timing] [nvarchar](50) NULL,
	[note] [nvarchar](2000) NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_event] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_event] UNIQUE NONCLUSTERED 
(
	[model_id] ASC,
	[serial_no] ASC,
	[event_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_generic_master](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[master_type] [nvarchar](50) NULL,
	[key] [nvarchar](200) NOT NULL,
	[config_type] [nvarchar](50) NULL,
	[config_subtype] [nvarchar](50) NULL,
	[name_locale1] [nvarchar](100) NULL,
	[name_locale2] [nvarchar](100) NULL,
	[name_locale3] [nvarchar](100) NULL,
	[description_locale1] [nvarchar](2000) NULL,
	[description_locale2] [nvarchar](2000) NULL,
	[description_locale3] [nvarchar](2000) NULL,
	[item_type] [nvarchar](100) NULL,
	[value_int1] [bigint] NULL,
	[value_int2] [bigint] NULL,
	[value_int3] [bigint] NULL,
	[value_float1] [float] NULL,
	[value_float2] [float] NULL,
	[value_float3] [float] NULL,
	[value_flg1] [bit] NULL,
	[value_flg2] [bit] NULL,
	[value_flg3] [bit] NULL,
	[value_string1] [nvarchar](2000) NULL,
	[value_string2] [nvarchar](2000) NULL,
	[value_string3] [nvarchar](2000) NULL,
	[value_string4] [nvarchar](2000) NULL,
	[value_string5] [nvarchar](2000) NULL,
	[value_string6] [nvarchar](2000) NULL,
	[value_string7] [nvarchar](2000) NULL,
	[value_string8] [nvarchar](2000) NULL,
	[value_string9] [nvarchar](2000) NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_generic_master] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_generic_master] UNIQUE NONCLUSTERED 
(
	[key] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


CREATE TABLE [dbo].[mst_group_composition_device](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[device_group_id] [nvarchar](50) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[serial_no] [nvarchar](50) NOT NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_group_composition_device] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_group_composition_device] UNIQUE NONCLUSTERED 
(
	[device_group_id] ASC,
	[model_id] ASC,
	[serial_no] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_role_base_config_visual](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[role_id] [nvarchar](50) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[config_id] [nvarchar](50) NOT NULL,
	[visual_auth_flg] [bit] NOT NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_role_base_config_visual] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_role_base_config_visual] UNIQUE NONCLUSTERED 
(
	[role_id] ASC,
	[model_id] ASC,
	[config_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_role_base_device_visual](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[role_id] [nvarchar](50) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[visual_auth_flg] [bit] NOT NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_role_base_device_visual] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_role_base_device_visual] UNIQUE NONCLUSTERED 
(
	[role_id] ASC,
	[model_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_role_base_event_visual](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[role_id] [nvarchar](50) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[event_id] [nvarchar](50) NOT NULL,
	[visual_auth_flg] [bit] NOT NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_role_base_event_visual] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_role_base_event_visual] UNIQUE NONCLUSTERED 
(
	[role_id] ASC,
	[model_id] ASC,
	[event_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_role_base_sensor_visual](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[role_id] [nvarchar](50) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[sensor_id] [nvarchar](50) NOT NULL,
	[visual_auth_flg] [bit] NOT NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_role_base_sensor_visual] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_role_base_sensor_visual] UNIQUE NONCLUSTERED 
(
	[role_id] ASC,
	[model_id] ASC,
	[sensor_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_role_config_visual](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[role_id] [nvarchar](50) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[serial_no] [nvarchar](50) NOT NULL,
	[config_id] [nvarchar](50) NOT NULL,
	[visual_auth_flg] [bit] NOT NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_role_config_visual] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_role_config_visual] UNIQUE NONCLUSTERED 
(
	[role_id] ASC,
	[model_id] ASC,
	[serial_no] ASC,
	[config_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_role_event_visual](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[role_id] [nvarchar](50) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[serial_no] [nvarchar](50) NOT NULL,
	[event_id] [nvarchar](50) NOT NULL,
	[visual_auth_flg] [bit] NOT NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_role_event_visual] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_role_event_visual] UNIQUE NONCLUSTERED 
(
	[role_id] ASC,
	[model_id] ASC,
	[serial_no] ASC,
	[event_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_role_sensor_visual](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[role_id] [nvarchar](50) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[serial_no] [nvarchar](50) NOT NULL,
	[sensor_id] [nvarchar](50) NOT NULL,
	[visual_auth_flg] [bit] NOT NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_role_sensor_visual] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_role_sensor_visual] UNIQUE NONCLUSTERED 
(
	[role_id] ASC,
	[model_id] ASC,
	[serial_no] ASC,
	[sensor_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_sensor](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[serial_no] [nvarchar](50) NOT NULL,
	[sensor_id] [nvarchar](50) NOT NULL,
	[sensor_type] [nvarchar](50) NOT NULL,
	[name_locale1] [nvarchar](100) NOT NULL,
	[name_locale2] [nvarchar](100) NULL,
	[name_locale3] [nvarchar](100) NULL,
	[unit_locale1] [nvarchar](50) NOT NULL,
	[unit_locale2] [nvarchar](50) NULL,
	[unit_locale3] [nvarchar](50) NULL,
	[transform_locale1] [nvarchar](100) NULL,
	[transform_locale2] [nvarchar](100) NULL,
	[transform_locale3] [nvarchar](100) NULL,
	[decimal_num_locale1] [int] NULL,
	[decimal_num_locale2] [int] NULL,
	[decimal_num_locale3] [int] NULL,
	[max_value_locale1] [float] NULL,
	[max_value_locale2] [float] NULL,
	[max_value_locale3] [float] NULL,
	[min_value_locale1] [float] NULL,
	[min_value_locale2] [float] NULL,
	[min_value_locale3] [float] NULL,
	[description_locale1] [nvarchar](2000) NULL,
	[description_locale2] [nvarchar](2000) NULL,
	[description_locale3] [nvarchar](2000) NULL,
	[measure_type] [char](1) NOT NULL,
	[data_type] [nvarchar](50) NOT NULL,
	[fixed_length] [int] NULL,
	[time_data_create_flg] [bit] NULL,
	[short_term_minutes] [int] NULL,
	[note] [nvarchar](2000) NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_sensor] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_sensor] UNIQUE NONCLUSTERED 
(
	[model_id] ASC,
	[serial_no] ASC,
	[sensor_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[mst_system_info](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[key] [nvarchar](200) NOT NULL,
	[config_type] [nvarchar](50) NULL,
	[config_subtype] [nvarchar](50) NULL,
	[name_locale1] [nvarchar](100) NULL,
	[name_locale2] [nvarchar](100) NULL,
	[name_locale3] [nvarchar](100) NULL,
	[item_type] [nvarchar](10) NULL,
	[value_int] [bigint] NULL,
	[value_float] [float] NULL,
	[value_string] [nvarchar](2000) NULL,
	[value_flg] [bit] NULL,
	[unit_locale1] [nvarchar](50) NULL,
	[unit_locale2] [nvarchar](50) NULL,
	[unit_locale3] [nvarchar](50) NULL,
	[description_locale1] [nvarchar](2000) NULL,
	[description_locale2] [nvarchar](2000) NULL,
	[description_locale3] [nvarchar](2000) NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[updated] [nvarchar](100) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_mst_system_info] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_mst_system_info] UNIQUE NONCLUSTERED 
(
	[key] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[std_devconfig_history](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[serial_no] [nvarchar](50) NOT NULL,
	[config_id] [nvarchar](50) NOT NULL,
	[config_file] [nvarchar](200) NOT NULL,
	[gw_upload_time] [datetime2](7) NOT NULL,
	[format_version] [nvarchar](50) NULL,
	[config_version] [nvarchar](50) NULL,
	[file_notification_key] [nvarchar](50) NULL,
	[regist_flg] [bit] NOT NULL,
	[result_send_id] [bigint] NULL,
	[version] [bigint] NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_std_devconfig_history] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_std_devconfig_history] UNIQUE NONCLUSTERED 
(
	[model_id] ASC,
	[serial_no] ASC,
	[config_id] ASC,
	[config_file] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


CREATE TABLE [dbo].[std_devicetwin_chang](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[serial_no] [nvarchar](50) NOT NULL,
	[change_info] [nvarchar](max) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_std_devicetwin_chang] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


CREATE TABLE [dbo].[std_event_incidence](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[serial_no] [nvarchar](50) NOT NULL,
	[detection_class] [char](1) NOT NULL,
	[event_id] [nvarchar](50) NOT NULL,
	[event_time] [datetime2](7) NOT NULL,
	[event_status] [nvarchar](50) NULL,
	[incident_class] [char](1) NOT NULL,
	[event_level] [nvarchar](50) NULL,
	[cope_status] [nvarchar](50) NULL,
	[version] [bigint] NOT NULL,
	[incident_time] [datetime2](7) NULL,
	[return_time] [datetime2](7) NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_std_event_incidence] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_std_event_incidence] UNIQUE NONCLUSTERED 
(
	[model_id] ASC,
	[serial_no] ASC,
	[detection_class] ASC,
	[event_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[std_event_incidence_history](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[serial_no] [nvarchar](50) NOT NULL,
	[detection_class] [char](1) NOT NULL,
	[event_id] [nvarchar](50) NOT NULL,
	[event_time] [datetime2](7) NOT NULL,
	[event_status] [nvarchar](50) NULL,
	[incident_class] [char](1) NOT NULL,
	[event_level] [nvarchar](50) NULL,
	[detection_info] [nvarchar](4000) NULL,
	[version] [bigint] NOT NULL,
	[inserted] [nvarchar](100) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_std_event_incidence_history] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[std_file_recept_mng](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[sender_device_id] [nvarchar](101) NOT NULL,
	[notice_time] [datetime2](7) NOT NULL,
	[file_class] [nvarchar](50) NOT NULL,
	[file_name] [nvarchar](500) NOT NULL,
	[size] [bigint] NULL,
	[hash] [char](32) NULL,
	[upload_flg] [bit] NOT NULL,
	[upload_time] [datetime2](7) NULL,
	[err_blob_flg] [bit] NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_std_file_recept_mng] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_std_file_recept_mng] UNIQUE NONCLUSTERED 
(
	[sender_device_id] ASC,
	[notice_time] ASC,
	[file_class] ASC,
	[file_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[std_fileinfo](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[model_id] [nvarchar](50) NULL,
	[serial_no] [nvarchar](50) NULL,
	[sensor_id] [nvarchar](50) NULL,
	[measure_time] [datetime2](7) NULL,
	[upload_time] [datetime2](7) NOT NULL,
	[zip_flg] [bit] NOT NULL,
	[file_name] [nvarchar](400) NOT NULL,
	[hash] [char](16) NOT NULL,
	[sender_device_id] [nvarchar](101) NULL,
	[notice_time] [datetime2](7) NULL,
	[reserve1] [nvarchar](100) NULL,
	[reserve2] [nvarchar](100) NULL,
	[reserve3] [nvarchar](100) NULL,
	[reserve4] [nvarchar](100) NULL,
	[reserve5] [nvarchar](100) NULL,
	[other_metadata] [nvarchar](2000) NULL,
	[upload_user_id] [nvarchar](100) NULL,
 CONSTRAINT [PK_std_fileinfo] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_std_fileinfo] UNIQUE NONCLUSTERED 
(
	[file_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[std_gw_command_history](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[gw_model_id] [nvarchar](50) NULL,
	[gw_serial_no] [nvarchar](50) NULL,
	[model_id] [nvarchar](50) NULL,
	[serial_no] [nvarchar](50) NULL,
	[operation] [nvarchar](50) NULL,
	[argument] [nvarchar](max) NULL,
	[exec_time] [nvarchar](20) NULL,
	[wait_time] [int] NULL,
	[request_user_id] [nvarchar](100) NULL,
	[remote_addr] [nvarchar](50) NULL,
	[client_addr] [nvarchar](500) NULL,
	[http_referer] [nvarchar](500) NULL,
	[cors_origin] [nvarchar](500) NULL,
	[request_time] [datetime2](7) NOT NULL,
	[result_code] [nvarchar](10) NULL,
	[result_detail_code] [nvarchar](100) NULL,
	[result_message] [nvarchar](2000) NULL,
	[result_data] [nvarchar](max) NULL,
	[result_time] [datetime2](7) NULL,
 CONSTRAINT [PK_std_gw_command_history] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


CREATE TABLE [dbo].[std_gw_receve_time](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[serial_no] [nvarchar](50) NOT NULL,
	[receve_time] [datetime2](7) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_std_gw_receve_time] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_std_gw_receve_time] UNIQUE NONCLUSTERED 
(
	[model_id] ASC,
	[serial_no] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


CREATE TABLE [dbo].[std_master_chang](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[table_name] [nvarchar](50) NOT NULL,
	[chang_class] [char](1) NOT NULL,
	[key1] [nvarchar](50) NULL,
	[key2] [nvarchar](200) NULL,
	[key3] [nvarchar](150) NULL,
	[key4] [nvarchar](150) NULL,
	[key5] [nvarchar](100) NULL,
	[before_info] [nvarchar](max) NULL,
	[after_info] [nvarchar](max) NULL,
	[insert_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_std_master_chang] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

CREATE TABLE [dbo].[std_measure_data](
	[model_id] [nvarchar](50) NOT NULL,
	[serial_no] [nvarchar](50) NOT NULL,
	[sensor_id] [nvarchar](50) NOT NULL,
	[measure_time] [datetime2](7) NOT NULL,
	[measure_data] [nvarchar](4000) NULL,
	[data_migrate_class] [char](1) NOT NULL,
	[version] [bigint] NOT NULL
) ON [PRIMARY]

CREATE TABLE [dbo].[std_new_measure_data](
	[model_id] [nvarchar](50) NOT NULL,
	[serial_no] [nvarchar](50) NOT NULL,
	[sensor_id] [nvarchar](50) NOT NULL,
	[measure_time] [datetime2](7) NOT NULL,
	[measure_data] [nvarchar](4000) NULL,
	[version] [bigint] NOT NULL,
 CONSTRAINT [PK_std_new_measure_data] PRIMARY KEY CLUSTERED 
(
	[model_id] ASC,
	[serial_no] ASC,
	[sensor_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[std_receive_seq](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[gw_model_id] [nvarchar](50) NOT NULL,
	[gw_serial_no] [nvarchar](50) NOT NULL,
	[start_time] [datetime2](7) NOT NULL,
	[receive_seq] [bigint] NOT NULL,
	[receive_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_std_receive_seq] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_std_receive_seq] UNIQUE NONCLUSTERED 
(
	[gw_model_id] ASC,
	[gw_serial_no] ASC,
	[start_time] ASC,
	[receive_seq] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[std_receive_seq_missing](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[gw_model_id] [nvarchar](50) NOT NULL,
	[gw_serial_no] [nvarchar](50) NOT NULL,
	[start_time] [datetime2](7) NOT NULL,
	[from_seq] [bigint] NOT NULL,
	[to_seq] [bigint] NOT NULL,
	[incident_class] [char](1) NOT NULL,
	[resend_request_flg] [bit] NOT NULL,
	[resend_request_time] [datetime2](7) NULL,
	[version] [bigint] NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_std_receive_seq_missing] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_std_receive_seq_missing] UNIQUE NONCLUSTERED 
(
	[gw_model_id] ASC,
	[gw_serial_no] ASC,
	[start_time] ASC,
	[from_seq] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[std_role_device](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[role_id] [nvarchar](50) NOT NULL,
	[root_group_id] [nvarchar](50) NOT NULL,
	[device_group_id] [nvarchar](50) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[serial_no] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_std_role_device] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_std_role_device] UNIQUE NONCLUSTERED 
(
	[role_id] ASC,
	[root_group_id] ASC,
	[device_group_id] ASC,
	[model_id] ASC,
	[serial_no] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[std_sensor_receve_time](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[model_id] [nvarchar](50) NOT NULL,
	[serial_no] [nvarchar](50) NOT NULL,
	[sensor_id] [nvarchar](50) NOT NULL,
	[measure_time] [datetime2](7) NOT NULL,
	[insert_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_std_sensor_receve_time] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_std_sensor_receve_time] UNIQUE NONCLUSTERED 
(
	[model_id] ASC,
	[serial_no] ASC,
	[sensor_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE std_info_alertmail_destination_list (
    id BIGINT IDENTITY(1, 1) NOT NULL PRIMARY KEY
    ,source_flag NVARCHAR(15) NOT NULL
    ,source_type NVARCHAR(256) NOT NULL
    ,user_name NVARCHAR(256)
    ,mail NVARCHAR(256)
    ,locale NVARCHAR(20)
    ,severity NVARCHAR(100)
    ,version BIGINT NOT NULL
    ,inserted NVARCHAR(100) NOT NULL
    ,insert_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
    ,updated NVARCHAR(100) NOT NULL
    ,update_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);

CREATE TABLE std_info_custom_trendgroup (
    id BIGINT IDENTITY(1, 1) NOT NULL PRIMARY KEY
    ,client_id NVARCHAR(500) NOT NULL
    ,ordinal INT NOT NULL
    ,items NVARCHAR(4000) NOT NULL
    ,name_locale1 NVARCHAR(100) NOT NULL
    ,name_locale2 NVARCHAR(100) NOT NULL
    ,name_locale3 NVARCHAR(100) NOT NULL
    ,range FLOAT NOT NULL DEFAULT 1
    ,version BIGINT NOT NULL
    ,inserted NVARCHAR(100) NOT NULL
    ,insert_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
    ,updated NVARCHAR(100) NOT NULL
    ,update_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);

ALTER TABLE std_info_custom_trendgroup
ADD CONSTRAINT UQ_std_info_custom_trendgroup_1 UNIQUE (client_id, ordinal);


CREATE TABLE std_info_device_operation_history (
    id BIGINT IDENTITY(1, 1) NOT NULL PRIMARY KEY
    ,model_id NVARCHAR(500) NOT NULL
    ,serial_no NVARCHAR(500) NOT NULL
    ,operation_type NVARCHAR(100)
    ,csvdata NVARCHAR(max)
    ,jsondata NVARCHAR(max)
    ,status NVARCHAR(100)
    ,file_notification_key NVARCHAR(50)
    ,version BIGINT NOT NULL
    ,inserted NVARCHAR(100) NOT NULL
    ,insert_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
    ,updated NVARCHAR(100) NOT NULL
    ,update_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);


CREATE TABLE std_info_device_status_mapping (
    id BIGINT IDENTITY(1, 1) NOT NULL PRIMARY KEY
    ,model_id NVARCHAR(500) NOT NULL
    ,ordinal INT NOT NULL
    ,sensor_id NVARCHAR(500) NOT NULL
    ,name_locale1 NVARCHAR(100)
    ,name_locale2 NVARCHAR(100)
    ,name_locale3 NVARCHAR(100)
    ,bit INT NOT NULL
    ,outer_background_color NVARCHAR(50)
    ,inner_background_color NVARCHAR(50)
    ,font_color NVARCHAR(50)
    ,version BIGINT NOT NULL
    ,inserted NVARCHAR(100) NOT NULL
    ,insert_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
    ,updated NVARCHAR(100) NOT NULL
    ,update_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);

ALTER TABLE std_info_device_status_mapping
ADD CONSTRAINT UQ_std_info_device_status_mapping_1 UNIQUE (model_id, ordinal);


CREATE TABLE std_info_deviceview (
    id BIGINT IDENTITY(1, 1) NOT NULL PRIMARY KEY
    ,model_id NVARCHAR(500) NOT NULL
    ,ordinal INT NOT NULL
    ,content NVARCHAR(500) NOT NULL
    ,version BIGINT NOT NULL
    ,inserted NVARCHAR(100) NOT NULL
    ,insert_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
    ,updated NVARCHAR(100) NOT NULL
    ,update_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);

ALTER TABLE std_info_deviceview
ADD CONSTRAINT UQ_std_info_deviceview_1 UNIQUE (model_id, ordinal);


CREATE TABLE std_info_image_item (
    id BIGINT IDENTITY(1, 1) NOT NULL PRIMARY KEY
    ,name NVARCHAR(200) NOT NULL
    ,itembody NVARCHAR(max) NOT NULL
    ,version BIGINT NOT NULL
    ,inserted NVARCHAR(100) NOT NULL
    ,insert_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
    ,updated NVARCHAR(100) NOT NULL
    ,update_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);

ALTER TABLE std_info_image_item
ADD CONSTRAINT UQ_std_info_image_item_1 UNIQUE (name);


CREATE TABLE std_info_mail_mst (
    id BIGINT IDENTITY(1, 1) NOT NULL PRIMARY KEY
    ,locale NVARCHAR(20) NOT NULL
    ,title NVARCHAR(4000) NOT NULL
    ,body NVARCHAR(4000) NOT NULL
    ,version BIGINT NOT NULL
    ,inserted NVARCHAR(50) NOT NULL
    ,insert_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
    ,updated NVARCHAR(50) NOT NULL
    ,update_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);

ALTER TABLE std_info_mail_mst
ADD CONSTRAINT UQ_std_info_mail_mst_1 UNIQUE (locale);


CREATE TABLE std_info_preset_trendgroup (
    id BIGINT IDENTITY(1, 1) NOT NULL PRIMARY KEY
    ,model_id NVARCHAR(500) NOT NULL
    ,ordinal INT NOT NULL
    ,items NVARCHAR(4000) NOT NULL
    ,name_locale1 NVARCHAR(100) NOT NULL
    ,name_locale2 NVARCHAR(100) NOT NULL
    ,name_locale3 NVARCHAR(100) NOT NULL
    ,range FLOAT NOT NULL DEFAULT 1
    ,version BIGINT NOT NULL
    ,inserted NVARCHAR(100) NOT NULL
    ,insert_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
    ,updated NVARCHAR(100) NOT NULL
    ,update_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);

ALTER TABLE std_info_preset_trendgroup
ADD CONSTRAINT UQ_std_info_preset_trendgroup_1 UNIQUE (model_id, ordinal);


CREATE TABLE std_info_process_flow (
    id BIGINT IDENTITY(1, 1) NOT NULL PRIMARY KEY
    ,flow_id NVARCHAR(100) NOT NULL
    ,device_group_id NVARCHAR(100) NOT NULL
    ,name_locale1 NVARCHAR(500)
    ,name_locale2 NVARCHAR(500)
    ,name_locale3 NVARCHAR(500)
    ,background NVARCHAR(max)
    ,version BIGINT NOT NULL
    ,inserted NVARCHAR(100) NOT NULL
    ,insert_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
    ,updated NVARCHAR(100) NOT NULL
    ,update_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);

ALTER TABLE std_info_process_flow
ADD CONSTRAINT UQ_std_info_process_flow_1 UNIQUE (flow_id);


CREATE TABLE std_info_process_flow_item (
    id BIGINT IDENTITY(1, 1) NOT NULL PRIMARY KEY
    ,flow_item_id NVARCHAR(100) NOT NULL
    ,flow_id NVARCHAR(100) NOT NULL
    ,position_x FLOAT
    ,position_y FLOAT
    ,scale_x FLOAT
    ,scale_y FLOAT
    ,rotate FLOAT
    ,model_id NVARCHAR(50)
    ,serial_no NVARCHAR(50)
    ,sensor_id NVARCHAR(50)
    ,stencil_id NVARCHAR(100) NOT NULL
    ,version BIGINT NOT NULL
    ,inserted NVARCHAR(100) NOT NULL
    ,insert_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
    ,updated NVARCHAR(100) NOT NULL
    ,update_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);

ALTER TABLE std_info_process_flow_item
ADD CONSTRAINT UQ_std_info_process_flow_item_1 UNIQUE (flow_item_id, flow_id);

CREATE TABLE std_info_process_flow_item_param (
    id BIGINT IDENTITY(1, 1) NOT NULL PRIMARY KEY
    ,flow_item_id NVARCHAR(100) NOT NULL
    ,flow_id NVARCHAR(100) NOT NULL
    ,key_name NVARCHAR(100) NOT NULL
    ,value NVARCHAR(100)
    ,version BIGINT NOT NULL
    ,inserted NVARCHAR(100) NOT NULL
    ,insert_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
    ,updated NVARCHAR(100) NOT NULL
    ,update_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);

ALTER TABLE std_info_process_flow_item_param
ADD CONSTRAINT UQ_std_info_process_flow_item_param_1 UNIQUE (flow_item_id, flow_id, key_name);


CREATE TABLE std_info_stencil (
    id BIGINT IDENTITY(1, 1) NOT NULL PRIMARY KEY
    ,stencil_id NVARCHAR(100) NOT NULL
    ,name_locale1 NVARCHAR(500)
    ,name_locale2 NVARCHAR(500)
    ,name_locale3 NVARCHAR(500)
    ,use_bean_flg BIT NOT NULL
    ,sensor_requirement_flg CHAR
    ,bean_name NVARCHAR(100)
    ,script NVARCHAR(2000)
    ,SVG NVARCHAR(max)
    ,version BIGINT NOT NULL
    ,inserted NVARCHAR(100) NOT NULL
    ,insert_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
    ,updated NVARCHAR(100) NOT NULL
    ,update_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);

ALTER TABLE std_info_stencil
ADD CONSTRAINT UQ_std_info_stencil_1 UNIQUE (stencil_id);


CREATE TABLE std_info_stencil_param (
    id BIGINT IDENTITY(1, 1) NOT NULL PRIMARY KEY
    ,stencil_id NVARCHAR(100) NOT NULL
    ,key_name NVARCHAR(100) NOT NULL
    ,value NVARCHAR(100)
    ,version BIGINT NOT NULL
    ,inserted NVARCHAR(100) NOT NULL
    ,insert_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
    ,updated NVARCHAR(100) NOT NULL
    ,update_time DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);

ALTER TABLE std_info_stencil_param
ADD CONSTRAINT UQ_std_info_stencil_param_1 UNIQUE (stencil_id, key_name);

GO
CREATE TABLE std_mail_req_status (
    id BIGINT IDENTITY(1, 1) NOT NULL PRIMARY KEY
    ,request_time DATETIME2 NOT NULL
    ,from_address NVARCHAR(256) NOT NULL
    ,to_address NVARCHAR(256) NOT NULL
    ,bcc_address NVARCHAR(256)
    ,mail_subject NVARCHAR(256) NOT NULL
    ,mail_body NVARCHAR(256)
    ,send_status INT
);


GO
CREATE    TRIGGER [dbo].[mst_base_device_all] ON [dbo].[mst_base_device]
   FOR INSERT , UPDATE , DELETE
AS 
BEGIN

     DECLARE @chang_class char(1);
     DECLARE @id bigint;
     DECLARE @model_id nvarchar(50);
     DECLARE @key3 nvarchar(150);
     DECLARE @key4 nvarchar(150);
     DECLARE @key5 nvarchar(150);
     DECLARE @before_info nvarchar(MAX);
     DECLARE @after_info nvarchar(MAX);
     DECLARE @iot_device_flg bit;
     DECLARE @communication_flg bit;
     
     DECLARE curList CURSOR
       LOCAL FAST_FORWARD
     FOR

        SELECT CASE WHEN i.id is null              THEN d.id              ELSE i.id               END id,
               CASE WHEN i.model_id is null        THEN d.model_id        ELSE i.model_id         END model_id,
               null key3,
               null key4,
               null key5,
               CASE 
                    WHEN i.id is null THEN 'D' 
                    WHEN d.id is null THEN 'I' 
                    ELSE 'U' 
               END chang_class, 
               (SELECT * FROM deleted d2  WHERE d2.id = d.id FOR JSON PATH) before_info,
               (SELECT * FROM inserted i2 WHERE i2.id = i.id FOR JSON PATH) after_info,
               i.iot_device_flg iot_device_flg,
               i.communication_flg communication_flg
          FROM inserted i
          FULL JOIN deleted d
            ON i.id  = d.id;

     OPEN curList;

     FETCH NEXT FROM curList
      INTO @id, @model_id, @key3, @key4, @key5, @chang_class, @before_info, @after_info, @iot_device_flg, @communication_flg;

     -- 全データを処理するまで繰り返す
     WHILE @@FETCH_STATUS = 0
     BEGIN
         --更新前のJSONデータの前後の{}を削除
         IF @before_info IS NOT NULL
            SET @before_info = SUBSTRING(@before_info, 2, LEN(@before_info) -2);

         --更新後のJSONデータの前後の{}を削除
         IF @after_info IS NOT NULL
            SET @after_info = SUBSTRING(@after_info, 2, LEN(@after_info) -2);

         -- 変更履歴の登録
         INSERT INTO std_master_chang
                 (table_name
                 ,chang_class
                 ,key1
                 ,key2
                 ,key3
                 ,key4
                 ,key5
                 ,before_info
                 ,after_info)
          VALUES ('mst_base_device'
                 ,@chang_class
                 ,@id
                 ,@model_id
                 ,@key3
                 ,@key4
                 ,@key5
                 ,@before_info
                 ,@after_info);

         --GWデバイスの時、一定期間未受信、受信SEQ抜けのイベントをイベント・アラームマスタに登録する
         IF @communication_flg = 1
         BEGIN
             --一定期間未受信のイベントをイベント・アラームマスタに登録する
             INSERT INTO mst_base_event
                 ([model_id]
                 ,[event_id]
                 ,[name_locale1]
                 ,[name_locale2]
                 ,[name_locale3]
                 ,[attribute_sync_flg]
                 ,[version]
                 ,[inserted]
                 ,[updated])
             SELECT 
                  @model_id AS [model_id]
                 ,s.[value_string] AS [event_id]
                 ,ISNULL(s.[description_locale1], s.[value_string]) AS [name_locale1]
                 ,s.[description_locale2] AS [name_locale2]
                 ,s.[description_locale3] AS [name_locale2]
                 ,1 AS [attribute_sync_flg]
                 ,0 AS [version]
                 ,'Trigger Insert' AS [inserted]
                 ,'Trigger Insert' AS [updated]
              FROM mst_system_info s
             WHERE [key] = 'GwUnreceiveEventId'
               AND NOT EXISTS (SELECT 1 FROM mst_base_event e WHERE e.[model_id] = @model_id AND e.[event_id] = s.[value_string]);

             --受信SEQ抜けのイベントをイベント・アラームマスタに登録する
             INSERT INTO mst_base_event
                 ([model_id]
                 ,[event_id]
                 ,[name_locale1]
                 ,[name_locale2]
                 ,[name_locale3]
                 ,[attribute_sync_flg]
                 ,[version]
                 ,[inserted]
                 ,[updated])
             SELECT 
                  @model_id AS [model_id]
                 ,s.[value_string] AS [event_id]
                 ,ISNULL(s.[description_locale1], s.[value_string]) AS [name_locale1]
                 ,s.[description_locale2] AS [name_locale2]
                 ,s.[description_locale3] AS [name_locale2]
                 ,1 AS [attribute_sync_flg]
                 ,0 AS [version]
                 ,'Trigger Insert' AS [inserted]
                 ,'Trigger Insert' AS [updated]
              FROM mst_system_info s
             WHERE [key] = 'GwSeqMissingEventId'
               AND NOT EXISTS (SELECT 1 FROM mst_base_event e WHERE e.[model_id] = @model_id AND e.[event_id] = s.[value_string]);
         END
         
         --DeviceTwinに登録するデバイスの時、デバイス異常のイベントをイベント・アラームマスタに登録する
         IF @iot_device_flg = 1
         BEGIN
             --デバイス異常のイベントをイベント・アラームマスタに登録する
             INSERT INTO mst_base_event
                 ([model_id]
                 ,[event_id]
                 ,[name_locale1]
                 ,[name_locale2]
                 ,[name_locale3]
                 ,[attribute_sync_flg]
                 ,[version]
                 ,[inserted]
                 ,[updated])
             SELECT 
                  @model_id AS [model_id]
                 ,s.[value_string] AS [event_id]
                 ,ISNULL(s.[description_locale1], s.[value_string]) AS [name_locale1]
                 ,s.[description_locale2] AS [name_locale2]
                 ,s.[description_locale3] AS [name_locale2]
                 ,1 AS [attribute_sync_flg]
                 ,0 AS [version]
                 ,'Trigger Insert' AS [inserted]
                 ,'Trigger Insert' AS [updated]
              FROM mst_system_info s
             WHERE [key] = 'DeviceAbnormalEventId'
               AND NOT EXISTS (SELECT 1 FROM mst_base_event e WHERE e.[model_id] = @model_id AND e.[event_id] = s.[value_string]);
         END

         -- NEXT行の検索
         FETCH NEXT FROM curList
          INTO @id, @model_id, @key3, @key4, @key5, @chang_class, @before_info, @after_info, @iot_device_flg, @communication_flg;
     END;

     CLOSE curList;
     DEALLOCATE curList;

END;

GO
CREATE    TRIGGER [dbo].[mst_base_event_all] ON [dbo].[mst_base_event]
   FOR INSERT , UPDATE , DELETE
AS 
BEGIN
    DECLARE @chang_class char(1);
    DECLARE @id bigint;
    DECLARE @model_id  nvarchar(50);
	DECLARE @event_id nvarchar(50);
    DECLARE @before_info nvarchar(MAX);
    DECLARE @after_info nvarchar(MAX);

    DECLARE curList CURSOR 
	  LOCAL FAST_FORWARD 
	FOR
      SELECT CASE 
                WHEN i.id is null THEN d.id
                ELSE i.id
             END id,
             CASE 
                WHEN i.model_id is null THEN d.model_id
                ELSE i.model_id
             END model_id,
             CASE
                WHEN i.event_id is null THEN d.event_id
                ELSE i.event_id
             END event_id,
			 CASE 
                WHEN i.model_id is null THEN 'D'
                WHEN d.model_id is null THEN 'I'
                ELSE 'U'
             END chang_class,
             (SELECT * FROM deleted d2  WHERE d2.model_id  = d.model_id AND d2.event_id = d.event_id FOR JSON PATH) before_info,
             (SELECT * FROM inserted i2 WHERE i2.model_id  = i.model_id AND i2.event_id = i.event_id FOR JSON PATH) after_info
        FROM inserted i
        FULL JOIN deleted d
          ON i.model_id  = d.model_id
		 AND i.event_id = d.event_id;

   OPEN curList;

   FETCH NEXT FROM curList
    INTO @id, @model_id, @event_id, @chang_class, @before_info, @after_info;

   -- 全データを処理するまで繰り返す
   WHILE @@FETCH_STATUS = 0
   BEGIN
       --更新前のJSONデータの前後の{}を削除
       IF @before_info IS NOT NULL
          SET @before_info = SUBSTRING(@before_info, 2, LEN(@before_info) -2);

       --更新後のJSONデータの前後の{}を削除
       IF @after_info IS NOT NULL
          SET @after_info = SUBSTRING(@after_info, 2, LEN(@after_info) -2); 
       --変更履歴の登録
       INSERT INTO std_master_chang
               (table_name
               ,chang_class
               ,key1
               ,key2
               ,key3
               ,before_info
               ,after_info)
        VALUES ('mst_base_event'
               ,@chang_class
               ,@id
               ,@model_id
			   ,@event_id
               ,@before_info
               ,@after_info);
       
       --NEXT行の検索
       FETCH NEXT FROM curList
        INTO @id, @model_id, @event_id, @chang_class, @before_info, @after_info;
   END;

   CLOSE curList;
   DEALLOCATE curList;
   
   --更新時、イベント・アラーム情報が存在し個別属性同期フラグがtrueの時は、イベント・アラーム情報も更新する
   UPDATE mst_event
      SET [event_type] = i.[event_type]
         ,[event_level] = i.[event_level]
         ,[sensor_id] = i.[sensor_id]
         ,[name_locale1] = i.[name_locale1]
         ,[name_locale2] = i.[name_locale2]
         ,[name_locale3] = i.[name_locale3]
         ,[description_locale1] = i.[description_locale1]
         ,[description_locale2] = i.[description_locale2]
         ,[description_locale3] = i.[description_locale3]
         ,[chk_app_name] = i.[chk_app_name]
         ,[chk_app_parameter] = i.[chk_app_parameter]
         ,[check_timing] = i.[check_timing]
         ,[note] = i.[note]
         ,[version] = e.[version] + 1
         ,[updated] = 'Trigger Update'
         ,[update_time] = sysdatetime()
   FROM mst_event AS e
   JOIN inserted AS i
       ON e.[model_id] = i.[model_id]
      AND e.[event_id] = i.[event_id]
      AND i.[attribute_sync_flg] = 1;

   --登録時、デバイス情報が存在すればイベント・アラーム情報も登録する
   INSERT INTO mst_event
           ([model_id]
           ,[serial_no]
           ,[event_id]
           ,[event_type]
           ,[event_level]
           ,[sensor_id]
           ,[name_locale1]
           ,[name_locale2]
           ,[name_locale3]
           ,[description_locale1]
           ,[description_locale2]
           ,[description_locale3]
           ,[chk_app_name]
           ,[chk_app_parameter]
           ,[check_timing]
           ,[note]
           ,[version]
           ,[inserted]
           ,[updated])
       SELECT
          i.[model_id]
         ,dev.[serial_no]
         ,i.[event_id]
         ,i.[event_type]
         ,i.[event_level]
         ,i.[sensor_id]
         ,i.[name_locale1]
         ,i.[name_locale2]
         ,i.[name_locale3]
         ,i.[description_locale1]
         ,i.[description_locale2]
         ,i.[description_locale3]
         ,i.[chk_app_name]
         ,i.[chk_app_parameter]
         ,i.[check_timing]
         ,i.[note]
         ,0 AS [version]
         ,'Trigger Copy' AS [inserted]
         ,'Trigger Copy' AS [updated]
        FROM inserted i,
             mst_device dev
       WHERE i.model_id = dev.model_id
         AND i.[attribute_sync_flg] = 1
         AND NOT EXISTS (SELECT 1 FROM mst_event e
                          WHERE e.[model_id] = i.[model_id]
                            AND e.[serial_no] = dev.[serial_no]
                            AND e.[event_id] = i.[event_id]);

END;

GO
CREATE    TRIGGER [dbo].[mst_base_sensor_all] ON [dbo].[mst_base_sensor]
   FOR INSERT , UPDATE , DELETE
AS 
BEGIN
   DECLARE @chang_class char(1);
   DECLARE @id bigint;
   DECLARE @model_id  nvarchar(50);
   DECLARE @sensor_id nvarchar(50);
   DECLARE @before_info nvarchar(MAX);
   DECLARE @after_info nvarchar(MAX);

   DECLARE curList CURSOR 
     LOCAL FAST_FORWARD 
   FOR
      SELECT CASE 
                WHEN i.id is null THEN d.id
                ELSE i.id
             END id,
             CASE 
                WHEN i.model_id is null THEN d.model_id
                ELSE i.model_id
             END model_id,
             CASE 
                WHEN i.sensor_id is null THEN d.sensor_id
                ELSE i.sensor_id
             END sensor_id,
          CASE 
                WHEN i.model_id is null THEN 'D'
                WHEN d.model_id is null THEN 'I'
                ELSE 'U'
             END chang_class,
             (SELECT * FROM deleted d2  WHERE d2.model_id  = d.model_id AND d2.sensor_id = d.sensor_id FOR JSON PATH) before_info,
             (SELECT * FROM inserted i2 WHERE i2.model_id  = i.model_id AND i2.sensor_id = i.sensor_id FOR JSON PATH) after_info
        FROM inserted i
        FULL JOIN deleted d
          ON i.model_id  = d.model_id
         AND i.sensor_id = d.sensor_id;

   OPEN curList;

   FETCH NEXT FROM curList
    INTO @id, @model_id, @sensor_id, @chang_class, @before_info, @after_info;

   -- 全データを処理するまで繰り返す
   WHILE @@FETCH_STATUS = 0
   BEGIN
       --更新前のJSONデータの前後の{}を削除
       IF @before_info IS NOT NULL
          SET @before_info = SUBSTRING(@before_info, 2, LEN(@before_info) -2);

       --更新後のJSONデータの前後の{}を削除
       IF @after_info IS NOT NULL
          SET @after_info = SUBSTRING(@after_info, 2, LEN(@after_info) -2); 

       --変更履歴の登録
       INSERT INTO std_master_chang
               (table_name
               ,chang_class
               ,key1
               ,key2
               ,key3
               ,before_info
               ,after_info)
        VALUES ('mst_base_sensor'
               ,@chang_class
               ,@id
               ,@model_id
               ,@sensor_id
               ,@before_info
               ,@after_info);

       --NEXT行の検索
       FETCH NEXT FROM curList
        INTO @id, @model_id, @sensor_id, @chang_class, @before_info, @after_info;
   END;

   CLOSE curList;
   DEALLOCATE curList;
  
   --更新時、センサー情報が存在し個別属性同期フラグがtrueの時は、センサー情報も更新する
   UPDATE mst_sensor
      SET [sensor_type] = i.[sensor_type]
         ,[name_locale1] = i.[name_locale1]
         ,[name_locale2] = i.[name_locale2]
         ,[name_locale3] = i.[name_locale3]
         ,[unit_locale1] = i.[unit_locale1]
         ,[unit_locale2] = i.[unit_locale2]
         ,[unit_locale3] = i.[unit_locale3]
         ,[transform_locale1] = i.[transform_locale1]
         ,[transform_locale2] = i.[transform_locale2]
         ,[transform_locale3] = i.[transform_locale3]
         ,[decimal_num_locale1] = i.[decimal_num_locale1]
         ,[decimal_num_locale2] = i.[decimal_num_locale2]
         ,[decimal_num_locale3] = i.[decimal_num_locale3]
         ,[max_value_locale1] = i.[max_value_locale1]
         ,[max_value_locale2] = i.[max_value_locale2]
         ,[max_value_locale3] = i.[max_value_locale3]
         ,[min_value_locale1] = i.[min_value_locale1]
         ,[min_value_locale2] = i.[min_value_locale2]
         ,[min_value_locale3] = i.[min_value_locale3]
         ,[description_locale1] = i.[description_locale1]
         ,[description_locale2] = i.[description_locale2]
         ,[description_locale3] = i.[description_locale3]
         ,[measure_type] = i.[measure_type]
         ,[data_type] = i.[data_type]
         ,[fixed_length] = i.[fixed_length]
         ,[time_data_create_flg] = i.[time_data_create_flg]
         ,[short_term_minutes] = i.[short_term_minutes]
         ,[note] = i.[note]
         ,[version] = s.[version] + 1
         ,[updated] = 'Trigger Update'
         ,[update_time] = sysdatetime()
   FROM mst_sensor AS s
   JOIN inserted AS i
       ON s.[model_id] = i.[model_id]
      AND s.[sensor_id] = i.[sensor_id]
      AND i.[attribute_sync_flg] = 1;
   
   --登録時、デバイス情報が存在すればセンサー情報も登録する
   INSERT INTO mst_sensor
           ([model_id]
           ,[serial_no]
           ,[sensor_id]
           ,[sensor_type]
           ,[name_locale1]
           ,[name_locale2]
           ,[name_locale3]
           ,[unit_locale1]
           ,[unit_locale2]
           ,[unit_locale3]
           ,[transform_locale1]
           ,[transform_locale2]
           ,[transform_locale3]
           ,[decimal_num_locale1]
           ,[decimal_num_locale2]
           ,[decimal_num_locale3]
           ,[max_value_locale1]
           ,[max_value_locale2]
           ,[max_value_locale3]
           ,[min_value_locale1]
           ,[min_value_locale2]
           ,[min_value_locale3]
           ,[description_locale1]
           ,[description_locale2]
           ,[description_locale3]
           ,[measure_type]
           ,[data_type]
           ,[fixed_length]
           ,[time_data_create_flg]
           ,[short_term_minutes]
           ,[note]
           ,[version]
           ,[inserted]
           ,[updated])
       SELECT
          i.[model_id]
         ,dev.[serial_no]
         ,i.[sensor_id]
         ,i.[sensor_type]
         ,i.[name_locale1]
         ,i.[name_locale2]
         ,i.[name_locale3]
         ,i.[unit_locale1]
         ,i.[unit_locale2]
         ,i.[unit_locale3]
         ,i.[transform_locale1]
         ,i.[transform_locale2]
         ,i.[transform_locale3]
         ,i.[decimal_num_locale1]
         ,i.[decimal_num_locale2]
         ,i.[decimal_num_locale3]
         ,i.[max_value_locale1]
         ,i.[max_value_locale2]
         ,i.[max_value_locale3]
         ,i.[min_value_locale1]
         ,i.[min_value_locale2]
         ,i.[min_value_locale3]
         ,i.[description_locale1]
         ,i.[description_locale2]
         ,i.[description_locale3]
         ,i.[measure_type]
         ,i.[data_type]
         ,i.[fixed_length]
         ,i.[time_data_create_flg]
         ,i.[short_term_minutes]
         ,i.[note]
         ,0 AS [version]
         ,'Trigger Copy' AS [inserted]
         ,'Trigger Copy' AS [updated]
        FROM inserted i,
             mst_device dev
       WHERE i.model_id = dev.model_id
         AND i.[attribute_sync_flg] = 1
         AND NOT EXISTS (SELECT 1 FROM mst_sensor s
                          WHERE s.[model_id] = i.[model_id]
                            AND s.[serial_no] = dev.[serial_no]
                            AND s.[sensor_id] = i.[sensor_id]);
   
END;

GO
CREATE    TRIGGER [dbo].[mst_device_all] ON [dbo].[mst_device]
   FOR INSERT , UPDATE , DELETE
AS 
BEGIN
    DECLARE @chang_class char(1);
    DECLARE @id bigint;
    DECLARE @model_id  nvarchar(50);
    DECLARE @serial_no nvarchar(50);
    DECLARE @before_info nvarchar(MAX);
    DECLARE @after_info nvarchar(MAX);
    DECLARE @before_device_mode char(1);
    DECLARE @after_device_mode char(1);

    DECLARE curList CURSOR 
	  LOCAL FAST_FORWARD 
	FOR
      SELECT CASE 
                WHEN i.id is null THEN d.id
                ELSE i.id
             END id,
             CASE 
                WHEN i.model_id is null THEN d.model_id
                ELSE i.model_id
             END model_id,
             CASE 
                WHEN i.serial_no is null THEN d.serial_no
                ELSE i.serial_no
             END serial_no,
             CASE 
                WHEN i.model_id is null THEN 'D'
                WHEN d.model_id is null THEN 'I'
                ELSE 'U'
             END chang_class,
             (SELECT * FROM deleted d2  WHERE d2.model_id  = d.model_id AND d2.serial_no = d.serial_no FOR JSON PATH) before_info,
             (SELECT * FROM inserted i2 WHERE i2.model_id  = i.model_id AND i2.serial_no = i.serial_no FOR JSON PATH) after_info,
             d.device_mode before_device_mode,
             i.device_mode after_device_mode
        FROM inserted i
        FULL JOIN deleted d
          ON i.model_id  = d.model_id
         AND i.serial_no = d.serial_no;

   OPEN curList;

   FETCH NEXT FROM curList
    INTO @id, @model_id, @serial_no, @chang_class, @before_info, @after_info, @before_device_mode, @after_device_mode;

   -- 全データを処理するまで繰り返す
   WHILE @@FETCH_STATUS = 0
   BEGIN
       --更新前のJSONデータの前後の{}を削除
       IF @before_info IS NOT NULL
          SET @before_info = SUBSTRING(@before_info, 2, LEN(@before_info) -2);

       --更新後のJSONデータの前後の{}を削除
       IF @after_info IS NOT NULL
          SET @after_info = SUBSTRING(@after_info, 2, LEN(@after_info) -2); 

       --変更履歴の登録
       INSERT INTO std_master_chang
               (table_name
               ,chang_class
               ,key1
               ,key2
               ,key3
               ,before_info
               ,after_info)
        VALUES ('mst_device'
               ,@chang_class
               ,@id
               ,@model_id
               ,@serial_no
               ,@before_info
               ,@after_info);

       --デバイスモード変更時、デバイスモード変更履歴 を登録する
       IF (@chang_class = 'I') OR (@chang_class = 'U' AND @before_device_mode <> @after_device_mode) 
           INSERT INTO mst_device_mode_history
                   (model_id
                   ,serial_no
                   ,device_mode)
            VALUES (@model_id
                   ,@serial_no
                   ,@after_device_mode);
       IF (@chang_class = 'D')
           DELETE FROM mst_device_mode_history 
                 WHERE model_id  = @model_id
                   AND serial_no = @serial_no;

       --新規登録時（XXマスタ⇒XX情報への複写）
       IF @chang_class = 'I'
       BEGIN
	       --センサーマスタをセンサー情報に複写登録する
	       INSERT INTO mst_sensor
	           ([model_id]
	           ,[serial_no]
	           ,[sensor_id]
	           ,[sensor_type]
	           ,[name_locale1]
	           ,[name_locale2]
	           ,[name_locale3]
	           ,[unit_locale1]
	           ,[unit_locale2]
	           ,[unit_locale3]
	           ,[transform_locale1]
	           ,[transform_locale2]
	           ,[transform_locale3]
	           ,[decimal_num_locale1]
	           ,[decimal_num_locale2]
	           ,[decimal_num_locale3]
	           ,[max_value_locale1]
	           ,[max_value_locale2]
	           ,[max_value_locale3]
	           ,[min_value_locale1]
	           ,[min_value_locale2]
	           ,[min_value_locale3]
	           ,[description_locale1]
	           ,[description_locale2]
	           ,[description_locale3]
	           ,[measure_type]
	           ,[data_type]
	           ,[fixed_length]
	           ,[time_data_create_flg]
	           ,[short_term_minutes]
	           ,[note]
	           ,[version]
	           ,[inserted]
	           ,[updated])
           SELECT
			    [model_id]
   	           ,@serial_no AS [serial_no]
			   ,[sensor_id]
			   ,[sensor_type]
			   ,[name_locale1]
			   ,[name_locale2]
			   ,[name_locale3]
			   ,[unit_locale1]
			   ,[unit_locale2]
			   ,[unit_locale3]
			   ,[transform_locale1]
			   ,[transform_locale2]
			   ,[transform_locale3]
			   ,[decimal_num_locale1]
			   ,[decimal_num_locale2]
			   ,[decimal_num_locale3]
			   ,[max_value_locale1]
			   ,[max_value_locale2]
			   ,[max_value_locale3]
			   ,[min_value_locale1]
			   ,[min_value_locale2]
			   ,[min_value_locale3]
			   ,[description_locale1]
			   ,[description_locale2]
			   ,[description_locale3]
			   ,[measure_type]
			   ,[data_type]
			   ,[fixed_length]
			   ,[time_data_create_flg]
			   ,[short_term_minutes]
			   ,[note]
			   ,0 AS [version]
	           ,'Trigger Copy' AS [inserted]
	           ,'Trigger Copy' AS [updated]
			  FROM mst_base_sensor
	       WHERE model_id = @model_id;
	       
	       --イベントマスタをイベント情報に複写登録する
	       INSERT INTO mst_event
	           ([model_id]
	           ,[serial_no]
	           ,[event_id]
	           ,[event_type]
	           ,[event_level]
	           ,[sensor_id]
	           ,[name_locale1]
	           ,[name_locale2]
	           ,[name_locale3]
	           ,[description_locale1]
	           ,[description_locale2]
	           ,[description_locale3]
	           ,[chk_app_name]
	           ,[chk_app_parameter]
	           ,[check_timing]
	           ,[note]
	           ,[version]
	           ,[inserted]
	           ,[updated])
	       SELECT 
	            [model_id]
	           ,@serial_no AS [serial_no]
	           ,[event_id]
	           ,[event_type]
	           ,[event_level]
	           ,[sensor_id]
	           ,[name_locale1]
	           ,[name_locale2]
	           ,[name_locale3]
	           ,[description_locale1]
	           ,[description_locale2]
	           ,[description_locale3]
	           ,[chk_app_name]
	           ,[chk_app_parameter]
	           ,[check_timing]
	           ,[note]
	           ,0 AS [version]
	           ,'Trigger Copy' AS [inserted]
	           ,'Trigger Copy' AS [updated]
	        FROM mst_base_event
	       WHERE model_id = @model_id;
       END
       
       --NEXT行の検索
       FETCH NEXT FROM curList
        INTO @id, @model_id, @serial_no, @chang_class, @before_info, @after_info, @before_device_mode, @after_device_mode;
   END;

   CLOSE curList;
   DEALLOCATE curList;

END;

GO
CREATE    TRIGGER [dbo].[mst_device_group_all] ON [dbo].[mst_device_group]
   FOR INSERT , UPDATE , DELETE
AS 
BEGIN
     DECLARE @chang_class char(1);
     DECLARE @id bigint;
     DECLARE @key2 nvarchar(150);
     DECLARE @key3 nvarchar(150);
     DECLARE @key4 nvarchar(150);
     DECLARE @key5 nvarchar(150);
     DECLARE @before_parent_id nvarchar(50);
     DECLARE @after_parent_id nvarchar(50);
     DECLARE @before_info nvarchar(MAX);
     DECLARE @after_info nvarchar(MAX);
     
     DECLARE curList CURSOR
       LOCAL FAST_FORWARD
     FOR
        SELECT CASE WHEN i.id is null              THEN d.id              ELSE i.id               END id,
               CASE WHEN i.device_group_id is null THEN d.device_group_id ELSE i.device_group_id  END key2,
               null key3,
               null key4,
               null key5,
               CASE
                  WHEN i.id is null THEN 'D'
                  WHEN d.id is null THEN 'I'
                  ELSE 'U'
               END chang_class,
               d.parent_device_group_id before_parent_id,
               i.parent_device_group_id after_parent_id,
               (SELECT * FROM deleted d2  WHERE d2.id = d.id FOR JSON PATH) before_info,
               (SELECT * FROM inserted i2 WHERE i2.id = i.id FOR JSON PATH) after_info
          FROM inserted i
          FULL JOIN deleted d
            ON i.id  = d.id;

     OPEN curList;

     FETCH NEXT FROM curList
      INTO @id, @key2, @key3, @key4, @key5, @chang_class, @before_parent_id, @after_parent_id, @before_info, @after_info;

     -- 全データを処理するまで繰り返す
     WHILE @@FETCH_STATUS = 0
     BEGIN
         --更新前のJSONデータの前後の{}を削除
         IF @before_info IS NOT NULL
            SET @before_info = SUBSTRING(@before_info, 2, LEN(@before_info) -2);

         --更新後のJSONデータの前後の{}を削除
         IF @after_info IS NOT NULL
            SET @after_info = SUBSTRING(@after_info, 2, LEN(@after_info) -2);

         -- 変更履歴の登録
         INSERT INTO std_master_chang
                 (table_name
                 ,chang_class
                 ,key1
                 ,key2
                 ,key3
                 ,key4
                 ,key5
                 ,before_info
                 ,after_info)
          VALUES ('mst_device_group'
                 ,@chang_class
                 ,@id
                 ,@key2
                 ,@key3
                 ,@key4
                 ,@key5
                 ,@before_info
                 ,@after_info);

         -- ルートデバイスグループ下のデバイスグループ追加・削除時、ロールデバイス展開テーブルの削除
         DELETE rd
           FROM std_role_device rd INNER JOIN dbo.fn_GetCngRootGroup(@before_parent_id, @after_parent_id) AS d
             ON rd.role_id = d.role_id
            AND rd.root_group_id = d.root_group_id;
         
         -- ルートデバイスグループ下のデバイスグループ追加・削除、ロールデバイス展開テーブルの登録
         WITH device_group_list (device_group_id, i_role_id, i_root_group_id, loop_cnt) AS (
          -- Root
            SELECT i.root_group_id as device_group_id,
                   i.role_id as i_role_id,
                   i.root_group_id as i_root_group_id,
                   1 as loop_cnt
              FROM dbo.fn_GetCngRootGroup(@before_parent_id, @after_parent_id) i
            UNION ALL
          -- Child
            SELECT g.device_group_id,
                   gl.i_role_id,
                   gl.i_root_group_id,
                   gl.loop_cnt + 1 as loop_cnt
              FROM device_group_list gl,
                   mst_device_group g
             WHERE gl.loop_cnt < 40
               AND g.parent_device_group_id = gl.device_group_id)
         -- INSERT
         INSERT INTO std_role_device(role_id, root_group_id, device_group_id, model_id, serial_no)
         SELECT DISTINCT gl.i_role_id, gl.i_root_group_id, cd.device_group_id, cd.model_id, cd.serial_no
           FROM device_group_list gl,
                mst_group_composition_device cd
 　       WHERE cd.device_group_id = gl.device_group_id
            AND NOT EXISTS (SELECT 1 FROM std_role_device rd
                             WHERE rd.role_id = gl.i_role_id
                               AND rd.root_group_id = gl.i_root_group_id
                               AND rd.device_group_id = cd.device_group_id
                               AND rd.model_id = cd.model_id
                               AND rd.serial_no = cd.serial_no);

         -- NEXT行の検索
         FETCH NEXT FROM curList
          INTO @id, @key2, @key3, @key4, @key5, @chang_class, @before_parent_id, @after_parent_id, @before_info, @after_info;
     END;

     CLOSE curList;
     DEALLOCATE curList;

  END;

GO
CREATE    TRIGGER [dbo].[mst_event_all] ON [dbo].[mst_event]
   FOR INSERT , UPDATE , DELETE
AS 
BEGIN
     DECLARE @chang_class char(1);
     DECLARE @id bigint;
     DECLARE @key2 nvarchar(150);
     DECLARE @key3 nvarchar(150);
     DECLARE @key4 nvarchar(150);
     DECLARE @key5 nvarchar(150);
     DECLARE @before_info nvarchar(MAX);
     DECLARE @after_info nvarchar(MAX);
     
     DECLARE curList CURSOR
       LOCAL FAST_FORWARD
     FOR

        SELECT CASE WHEN i.id is null              THEN d.id              ELSE i.id               END id,
               CASE WHEN i.model_id is null        THEN d.model_id        ELSE i.model_id         END key2,
               CASE WHEN i.serial_no is null       THEN d.serial_no       ELSE i.serial_no        END key3,
               CASE WHEN i.event_id is null        THEN d.event_id        ELSE i.event_id         END key4,
               null key5,
               CASE
                  WHEN i.id is null THEN 'D'
                  WHEN d.id is null THEN 'I'
                  ELSE 'U'
               END chang_class,
               (SELECT * FROM deleted d2  WHERE d2.id = d.id FOR JSON PATH) before_info,
               (SELECT * FROM inserted i2 WHERE i2.id = i.id FOR JSON PATH) after_info
          FROM inserted i
          FULL JOIN deleted d
            ON i.id  = d.id;

     OPEN curList;

     FETCH NEXT FROM curList
      INTO @id, @key2, @key3, @key4, @key5, @chang_class, @before_info, @after_info;

     -- 全データを処理するまで繰り返す
     WHILE @@FETCH_STATUS = 0
     BEGIN
         --更新前のJSONデータの前後の{}を削除
         IF @before_info IS NOT NULL
            SET @before_info = SUBSTRING(@before_info, 2, LEN(@before_info) -2);

         --更新後のJSONデータの前後の{}を削除
         IF @after_info IS NOT NULL
            SET @after_info = SUBSTRING(@after_info, 2, LEN(@after_info) -2);

         -- 変更履歴の登録
         INSERT INTO std_master_chang
                 (table_name
                 ,chang_class
                 ,key1
                 ,key2
                 ,key3
                 ,key4
                 ,key5
                 ,before_info
                 ,after_info)
          VALUES ('mst_event'
                 ,@chang_class
                 ,@id
                 ,@key2
                 ,@key3
                 ,@key4
                 ,@key5
                 ,@before_info
                 ,@after_info);

         -- NEXT行の検索
         FETCH NEXT FROM curList
          INTO @id, @key2, @key3, @key4, @key5, @chang_class, @before_info, @after_info;
     END;

     CLOSE curList;
     DEALLOCATE curList;

  END;
  
GO
CREATE    TRIGGER [dbo].[mst_group_composition_device_all] ON [dbo].[mst_group_composition_device]
     FOR INSERT , UPDATE , DELETE
  AS
  BEGIN

     DECLARE @chang_class char(1);
     DECLARE @id bigint;
     DECLARE @key2 nvarchar(150);
     DECLARE @key3 nvarchar(150);
     DECLARE @key4 nvarchar(150);
     DECLARE @key5 nvarchar(150);
     DECLARE @before_info nvarchar(MAX);
     DECLARE @after_info nvarchar(MAX);
     
     DECLARE curList CURSOR
       LOCAL FAST_FORWARD
     FOR

        SELECT CASE WHEN i.id is null              THEN d.id              ELSE i.id               END id,
               CASE WHEN i.device_group_id is null THEN d.device_group_id ELSE i.device_group_id  END key2,
               CASE WHEN i.model_id is null        THEN d.model_id        ELSE i.model_id         END key3,
               CASE WHEN i.serial_no is null       THEN d.serial_no       ELSE i.serial_no        END key4,
               null key5,
               CASE
                  WHEN i.id is null THEN 'D'
                  WHEN d.id is null THEN 'I'
                  ELSE 'U'
               END chang_class,
               (SELECT * FROM deleted d2  WHERE d2.id = d.id FOR JSON PATH) before_info,
               (SELECT * FROM inserted i2 WHERE i2.id = i.id FOR JSON PATH) after_info
          FROM inserted i
          FULL JOIN deleted d
            ON i.id  = d.id;

     OPEN curList;

     FETCH NEXT FROM curList
      INTO @id, @key2, @key3, @key4, @key5, @chang_class, @before_info, @after_info;

     -- 全データを処理するまで繰り返す
     WHILE @@FETCH_STATUS = 0
     BEGIN
         --更新前のJSONデータの前後の{}を削除
         IF @before_info IS NOT NULL
            SET @before_info = SUBSTRING(@before_info, 2, LEN(@before_info) -2);

         --更新後のJSONデータの前後の{}を削除
         IF @after_info IS NOT NULL
            SET @after_info = SUBSTRING(@after_info, 2, LEN(@after_info) -2);

         -- 変更履歴の登録
         INSERT INTO std_master_chang
                 (table_name
                 ,chang_class
                 ,key1
                 ,key2
                 ,key3
                 ,key4
                 ,key5
                 ,before_info
                 ,after_info)
          VALUES ('mst_group_composition_device'
                 ,@chang_class
                 ,@id
                 ,@key2
                 ,@key3
                 ,@key4
                 ,@key5
                 ,@before_info
                 ,@after_info);

         -- NEXT行の検索
         FETCH NEXT FROM curList
          INTO @id, @key2, @key3, @key4, @key5, @chang_class, @before_info, @after_info;
     END;

     CLOSE curList;
     DEALLOCATE curList;

     --ロールデバイス展開テーブルの削除
     DELETE rd
       FROM std_role_device rd INNER JOIN deleted d
         ON rd.device_group_id = d.device_group_id
        AND rd.model_id = d.model_id
        AND rd.serial_no = d.serial_no;

     --ロールデバイス展開テーブルの登録
     WITH device_group_list (parent_device_group_id, device_group_id, i_device_group_id, i_model_id, i_serial_no, loop_cnt) AS (
      -- Root
        SELECT g.parent_device_group_id,
               g.device_group_id,
               i.device_group_id as i_device_group_id,
               i.model_id as i_model_id,
               i.serial_no as i_serial_no,
               1 as loop_cnt
          FROM mst_device_group g,
               inserted i
         WHERE g.device_group_id = i.device_group_id
        UNION ALL
      -- Child
        SELECT g.parent_device_group_id,
               g.device_group_id,
               gl.i_device_group_id,
               gl.i_model_id,
               gl.i_serial_no,
               gl.loop_cnt + 1 as loop_cnt
          FROM device_group_list gl,
               mst_device_group g
         WHERE gl.loop_cnt < 40
           AND gl.parent_device_group_id is not null
           AND g.device_group_id = gl.parent_device_group_id)
     -- INSERT
     INSERT INTO std_role_device(role_id, root_group_id, device_group_id, model_id, serial_no)
     SELECT DISTINCT g.role_id, g.root_group_id, gl.i_device_group_id, gl.i_model_id, gl.i_serial_no
       FROM device_group_list gl,
            mst_role_root_group g
      WHERE g.root_group_id = gl.device_group_id
        AND NOT EXISTS (SELECT 1 FROM std_role_device rd
                                WHERE rd.role_id = g.role_id
                                  AND rd.root_group_id = g.root_group_id
                                  AND rd.device_group_id = gl.i_device_group_id
                                  AND rd.model_id = gl.i_model_id
                                  AND rd.serial_no = gl.i_serial_no);
  END;

GO
CREATE    TRIGGER [dbo].[mst_program_authority_all] ON [dbo].[mst_program_authority]
   FOR INSERT , UPDATE , DELETE
AS 
BEGIN

     DECLARE @chang_class char(1);
     DECLARE @id bigint;
     DECLARE @key2 nvarchar(150);
     DECLARE @key3 nvarchar(150);
     DECLARE @key4 nvarchar(150);
     DECLARE @key5 nvarchar(150);
     DECLARE @before_info nvarchar(MAX);
     DECLARE @after_info nvarchar(MAX);
     
     DECLARE curList CURSOR
       LOCAL FAST_FORWARD
     FOR

        SELECT CASE WHEN i.id is null              THEN d.id              ELSE i.id               END id,
               CASE WHEN i.authority_id is null THEN d.authority_id ELSE i.authority_id  END key2,
               null key3,
               null key4,
               null key5,
               CASE
                  WHEN i.id is null THEN 'D'
                  WHEN d.id is null THEN 'I'
                  ELSE 'U'
               END chang_class,
               (SELECT * FROM deleted d2  WHERE d2.id = d.id FOR JSON PATH) before_info,
               (SELECT * FROM inserted i2 WHERE i2.id = i.id FOR JSON PATH) after_info
          FROM inserted i
          FULL JOIN deleted d
            ON i.id  = d.id;

     OPEN curList;

     FETCH NEXT FROM curList
      INTO @id, @key2, @key3, @key4, @key5, @chang_class, @before_info, @after_info;

     -- 全データを処理するまで繰り返す
     WHILE @@FETCH_STATUS = 0
     BEGIN
         --更新前のJSONデータの前後の{}を削除
         IF @before_info IS NOT NULL
            SET @before_info = SUBSTRING(@before_info, 2, LEN(@before_info) -2);

         --更新後のJSONデータの前後の{}を削除
         IF @after_info IS NOT NULL
            SET @after_info = SUBSTRING(@after_info, 2, LEN(@after_info) -2);

         -- 変更履歴の登録
         INSERT INTO std_master_chang
                 (table_name
                 ,chang_class
                 ,key1
                 ,key2
                 ,key3
                 ,key4
                 ,key5
                 ,before_info
                 ,after_info)
          VALUES ('mst_program_authority'
                 ,@chang_class
                 ,@id
                 ,@key2
                 ,@key3
                 ,@key4
                 ,@key5
                 ,@before_info
                 ,@after_info);

         -- NEXT行の検索
         FETCH NEXT FROM curList
          INTO @id, @key2, @key3, @key4, @key5, @chang_class, @before_info, @after_info;
     END;

     CLOSE curList;
     DEALLOCATE curList;

  END;

GO  
CREATE    TRIGGER [dbo].[mst_role_all] ON [dbo].[mst_role]
   FOR INSERT , UPDATE , DELETE
AS 
BEGIN
     DECLARE @chang_class char(1);
     DECLARE @id bigint;
     DECLARE @key2 nvarchar(150);
     DECLARE @key3 nvarchar(150);
     DECLARE @key4 nvarchar(150);
     DECLARE @key5 nvarchar(150);
     DECLARE @before_info nvarchar(MAX);
     DECLARE @after_info nvarchar(MAX);
     DECLARE @before_authority_role_id nvarchar(50);
     DECLARE @after_authority_role_id nvarchar(50);
     DECLARE @insert_user nvarchar(100);
     DECLARE @auth_upd_flg bit;
     
     DECLARE curList CURSOR
       LOCAL FAST_FORWARD
     FOR

        SELECT CASE WHEN i.id is null              THEN d.id              ELSE i.id               END id,
               CASE WHEN i.role_id is null         THEN d.role_id         ELSE i.role_id          END key2,
               null key3,
               null key4,
               null key5,
               CASE
                  WHEN i.id is null THEN 'D'
                  WHEN d.id is null THEN 'I'
                  ELSE 'U'
               END chang_class,
               (SELECT * FROM deleted d2  WHERE d2.id = d.id FOR JSON PATH) before_info,
               (SELECT * FROM inserted i2 WHERE i2.id = i.id FOR JSON PATH) after_info,
               d.authority_role_id before_authority_role_id,
               i.authority_role_id after_authority_role_id,
               CASE WHEN i.inserted is null        THEN d.inserted        ELSE i.inserted          END insert_user
          FROM inserted i
          FULL JOIN deleted d
            ON i.id  = d.id;

     OPEN curList;

     FETCH NEXT FROM curList
      INTO @id, @key2, @key3, @key4, @key5, @chang_class, @before_info, @after_info, @before_authority_role_id, @after_authority_role_id, @insert_user;

     -- 全データを処理するまで繰り返す
     WHILE @@FETCH_STATUS = 0
     BEGIN
         --更新前のJSONデータの前後の{}を削除
         IF @before_info IS NOT NULL
            SET @before_info = SUBSTRING(@before_info, 2, LEN(@before_info) -2);

         --更新後のJSONデータの前後の{}を削除
         IF @after_info IS NOT NULL
            SET @after_info = SUBSTRING(@after_info, 2, LEN(@after_info) -2);

         -- 変更履歴の登録
         INSERT INTO std_master_chang
                 (table_name
                 ,chang_class
                 ,key1
                 ,key2
                 ,key3
                 ,key4
                 ,key5
                 ,before_info
                 ,after_info)
          VALUES ('mst_role'
                 ,@chang_class
                 ,@id
                 ,@key2
                 ,@key3
                 ,@key4
                 ,@key5
                 ,@before_info
                 ,@after_info);

         -- ロール削除時 または プログラム権限基準ロール 変更時、ロール・プログラム権限(mst_role_program_authority) を削除する
         SET @auth_upd_flg = 0;

         IF @chang_class = 'D'
            SET @auth_upd_flg = 1;
         
         IF @chang_class = 'U' AND @before_authority_role_id IS NOT NULL AND @after_authority_role_id IS NULL
            SET @auth_upd_flg = 1;
         
         IF @chang_class = 'U' AND @before_authority_role_id IS NOT NULL AND @after_authority_role_id IS NOT NULL AND @before_authority_role_id <> @after_authority_role_id 
            SET @auth_upd_flg = 1;

         IF @auth_upd_flg = 1
            -- ロール・プログラム権限(mst_role_program_authority) を削除する
            DELETE mst_role_program_authority
             WHERE role_id = @key2;

         -- 登録時 または プログラム権限基準ロール 変更時、ロール・プログラム権限を複写する
         SET @auth_upd_flg = 0;
         IF @after_authority_role_id IS NOT NULL
            BEGIN
              IF @chang_class = 'I'
                 SET @auth_upd_flg = 1;

              IF @chang_class = 'U' AND @before_authority_role_id IS NULL
                 SET @auth_upd_flg = 1;

              IF @chang_class = 'U' AND @before_authority_role_id IS NOT NULL AND @before_authority_role_id <> @after_authority_role_id
                 SET @auth_upd_flg = 1;
             END

         IF @auth_upd_flg = 1
            --ロール・プログラム権限を複写する
            INSERT INTO mst_role_program_authority (role_id, authority_id, [version], [inserted], [updated])
            SELECT @key2 as role_id, a.authority_id, 0 as [version], 'Trigger Copy' AS [inserted], 'Trigger Copy' AS [updated]
              FROM mst_role_program_authority a
             WHERE a.role_id = @after_authority_role_id
               AND NOT EXISTS (SELECT 1 FROM mst_role_program_authority b WHERE b.role_id = @key2 AND b.authority_id =  a.authority_id);

         -- ロール登録時、登録者がシステム管理者でなく かつ ユーザIDがメールアドレス形式であればユーザ・ロールを登録する
         IF @chang_class = 'I'
            INSERT INTO mst_user_role ([user_id], [role_id], [version], [inserted], [updated])
            SELECT @insert_user as [user_id], @key2 as [role_id], 0 as [version], @insert_user as [inserted], @insert_user as [updated]
             WHERE NOT EXISTS (SELECT 1 FROM mst_system_info WHERE [key] = ('SysAdmin_' + @insert_user))
			   --メールアドレス形式の簡易チェック
			   AND (@insert_user LIKE '[^.]%[^.]@[^.]%.%[^.]' OR @insert_user LIKE '[^.]@[^.]%.%[^.]')
               AND LEN(@insert_user) - LEN(REPLACE(@insert_user,'@','')) = 1
			   AND CHARINDEX('..', @insert_user) = 0;

         -- NEXT行の検索
         FETCH NEXT FROM curList
          INTO @id, @key2, @key3, @key4, @key5, @chang_class, @before_info, @after_info, @before_authority_role_id, @after_authority_role_id, @insert_user;
     END;

     CLOSE curList;
     DEALLOCATE curList;

  END;

GO  
CREATE    TRIGGER [dbo].[mst_role_program_authority_all] ON [dbo].[mst_role_program_authority]
   FOR INSERT , UPDATE , DELETE
AS 
BEGIN

     DECLARE @chang_class char(1);
     DECLARE @id bigint;
     DECLARE @key2 nvarchar(150);
     DECLARE @key3 nvarchar(150);
     DECLARE @key4 nvarchar(150);
     DECLARE @key5 nvarchar(150);
     DECLARE @before_info nvarchar(MAX);
     DECLARE @after_info nvarchar(MAX);
     
     DECLARE curList CURSOR
       LOCAL FAST_FORWARD
     FOR

        SELECT CASE WHEN i.id is null              THEN d.id              ELSE i.id               END id,
               CASE WHEN i.role_id is null         THEN d.role_id         ELSE i.role_id          END key2,
               CASE WHEN i.authority_id is null    THEN d.authority_id    ELSE i.authority_id     END key3,
               null key4,
               null key5,
               CASE
                  WHEN i.id is null THEN 'D'
                  WHEN d.id is null THEN 'I'
                  ELSE 'U'
               END chang_class,
               (SELECT * FROM deleted d2  WHERE d2.id = d.id FOR JSON PATH) before_info,
               (SELECT * FROM inserted i2 WHERE i2.id = i.id FOR JSON PATH) after_info
          FROM inserted i
          FULL JOIN deleted d
            ON i.id  = d.id;

     OPEN curList;

     FETCH NEXT FROM curList
      INTO @id, @key2, @key3, @key4, @key5, @chang_class, @before_info, @after_info;

     -- 全データを処理するまで繰り返す
     WHILE @@FETCH_STATUS = 0
     BEGIN
         --更新前のJSONデータの前後の{}を削除
         IF @before_info IS NOT NULL
            SET @before_info = SUBSTRING(@before_info, 2, LEN(@before_info) -2);

         --更新後のJSONデータの前後の{}を削除
         IF @after_info IS NOT NULL
            SET @after_info = SUBSTRING(@after_info, 2, LEN(@after_info) -2);

         -- 変更履歴の登録
         INSERT INTO std_master_chang
                 (table_name
                 ,chang_class
                 ,key1
                 ,key2
                 ,key3
                 ,key4
                 ,key5
                 ,before_info
                 ,after_info)
          VALUES ('mst_role_program_authority'
                 ,@chang_class
                 ,@id
                 ,@key2
                 ,@key3
                 ,@key4
                 ,@key5
                 ,@before_info
                 ,@after_info);

         -- NEXT行の検索
         FETCH NEXT FROM curList
          INTO @id, @key2, @key3, @key4, @key5, @chang_class, @before_info, @after_info;
     END;

     CLOSE curList;
     DEALLOCATE curList;

  END;

GO  
CREATE    TRIGGER [dbo].[mst_role_root_group_all] ON [dbo].[mst_role_root_group]
   FOR INSERT , UPDATE , DELETE
AS 
BEGIN

     DECLARE @chang_class char(1);
     DECLARE @id bigint;
     DECLARE @key2 nvarchar(150);
     DECLARE @key3 nvarchar(150);
     DECLARE @key4 nvarchar(150);
     DECLARE @key5 nvarchar(150);
     DECLARE @before_info nvarchar(MAX);
     DECLARE @after_info nvarchar(MAX);
     
     DECLARE curList CURSOR
       LOCAL FAST_FORWARD
     FOR

        SELECT CASE WHEN i.id is null                THEN d.id                ELSE i.id                 END id,
               CASE WHEN i.role_id is null           THEN d.role_id           ELSE i.role_id            END key2,
               CASE WHEN i.root_group_id is null     THEN d.root_group_id     ELSE i.root_group_id      END key3,
               null key4,
               null key5,
               CASE
                  WHEN i.id is null THEN 'D'
                  WHEN d.id is null THEN 'I'
                  ELSE 'U'
               END chang_class,
               (SELECT * FROM deleted d2  WHERE d2.id = d.id FOR JSON PATH) before_info,
               (SELECT * FROM inserted i2 WHERE i2.id = i.id FOR JSON PATH) after_info
          FROM inserted i
          FULL JOIN deleted d
            ON i.id  = d.id;

     OPEN curList;

     FETCH NEXT FROM curList
      INTO @id, @key2, @key3, @key4, @key5, @chang_class, @before_info, @after_info;

     -- 全データを処理するまで繰り返す
     WHILE @@FETCH_STATUS = 0
     BEGIN
         --更新前のJSONデータの前後の{}を削除
         IF @before_info IS NOT NULL
            SET @before_info = SUBSTRING(@before_info, 2, LEN(@before_info) -2);

         --更新後のJSONデータの前後の{}を削除
         IF @after_info IS NOT NULL
            SET @after_info = SUBSTRING(@after_info, 2, LEN(@after_info) -2);

         -- 変更履歴の登録
         INSERT INTO std_master_chang
                 (table_name
                 ,chang_class
                 ,key1
                 ,key2
                 ,key3
                 ,key4
                 ,key5
                 ,before_info
                 ,after_info)
          VALUES ('mst_role_root_group'
                 ,@chang_class
                 ,@id
                 ,@key2
                 ,@key3
                 ,@key4
                 ,@key5
                 ,@before_info
                 ,@after_info);

         -- NEXT行の検索
         FETCH NEXT FROM curList
          INTO @id, @key2, @key3, @key4, @key5, @chang_class, @before_info, @after_info;
     END;

     CLOSE curList;
     DEALLOCATE curList;

     --ロールデバイス展開テーブルの削除
     DELETE rd
       FROM std_role_device rd INNER JOIN deleted d
         ON rd.role_id = d.role_id
        AND rd.root_group_id = d.root_group_id;

     --ロールデバイス展開テーブルの登録
     WITH device_group_list (device_group_id, i_role_id, i_root_group_id, loop_cnt) AS (
      -- Root
        SELECT i.root_group_id as device_group_id,
               i.role_id as i_role_id,
               i.root_group_id as i_root_group_id,
               1 as loop_cnt
          FROM inserted i
         UNION ALL
      -- Child
        SELECT g.device_group_id,
               gl.i_role_id,
               gl.i_root_group_id,
               gl.loop_cnt + 1 as loop_cnt
          FROM device_group_list gl,
               mst_device_group g
         WHERE gl.loop_cnt < 40
           AND g.parent_device_group_id = gl.device_group_id)
     -- INSERT
     INSERT INTO std_role_device(role_id, root_group_id, device_group_id, model_id, serial_no)
     SELECT DISTINCT gl.i_role_id, gl.i_root_group_id, cd.device_group_id, cd.model_id, cd.serial_no
          FROM device_group_list gl,
               mst_group_composition_device cd
         WHERE cd.device_group_id = gl.device_group_id
           AND NOT EXISTS (SELECT 1 FROM std_role_device rd
                                   WHERE rd.role_id = gl.i_role_id
                                     AND rd.root_group_id = gl.i_root_group_id
                                     AND rd.device_group_id = cd.device_group_id
                                     AND rd.model_id = cd.model_id
                                     AND rd.serial_no = cd.serial_no);
     
  END;

GO  
CREATE    TRIGGER [dbo].[mst_sensor_all] ON [dbo].[mst_sensor]
   FOR INSERT , UPDATE , DELETE
AS 
BEGIN

     DECLARE @chang_class char(1);
     DECLARE @id bigint;
     DECLARE @key2 nvarchar(150);
     DECLARE @key3 nvarchar(150);
     DECLARE @key4 nvarchar(150);
     DECLARE @key5 nvarchar(150);
     DECLARE @before_info nvarchar(MAX);
     DECLARE @after_info nvarchar(MAX);
     
     DECLARE curList CURSOR
       LOCAL FAST_FORWARD
     FOR

        SELECT CASE WHEN i.id is null                 THEN d.id              ELSE i.id               END id,
               CASE WHEN i.model_id is null           THEN d.model_id        ELSE i.model_id         END key2,
               CASE WHEN i.serial_no is null          THEN d.serial_no       ELSE i.serial_no        END key3,
               CASE WHEN i.sensor_id is null          THEN d.sensor_id       ELSE i.sensor_id        END key4,
               null key5,
               CASE
                  WHEN i.id is null THEN 'D'
                  WHEN d.id is null THEN 'I'
                  ELSE 'U'
               END chang_class,
               (SELECT * FROM deleted d2  WHERE d2.id = d.id FOR JSON PATH) before_info,
               (SELECT * FROM inserted i2 WHERE i2.id = i.id FOR JSON PATH) after_info
          FROM inserted i
          FULL JOIN deleted d
            ON i.id  = d.id;

     OPEN curList;

     FETCH NEXT FROM curList
      INTO @id, @key2, @key3, @key4, @key5, @chang_class, @before_info, @after_info;

     -- 全データを処理するまで繰り返す
     WHILE @@FETCH_STATUS = 0
     BEGIN
         --更新前のJSONデータの前後の{}を削除
         IF @before_info IS NOT NULL
            SET @before_info = SUBSTRING(@before_info, 2, LEN(@before_info) -2);

         --更新後のJSONデータの前後の{}を削除
         IF @after_info IS NOT NULL
            SET @after_info = SUBSTRING(@after_info, 2, LEN(@after_info) -2);

         -- 変更履歴の登録
         INSERT INTO std_master_chang
                 (table_name
                 ,chang_class
                 ,key1
                 ,key2
                 ,key3
                 ,key4
                 ,key5
                 ,before_info
                 ,after_info)
          VALUES ('mst_sensor'
                 ,@chang_class
                 ,@id
                 ,@key2
                 ,@key3
                 ,@key4
                 ,@key5
                 ,@before_info
                 ,@after_info);

         -- NEXT行の検索
         FETCH NEXT FROM curList
          INTO @id, @key2, @key3, @key4, @key5, @chang_class, @before_info, @after_info;
     END;

     CLOSE curList;
     DEALLOCATE curList;

  END;

GO
CREATE    TRIGGER [dbo].[mst_system_info_all] ON [dbo].[mst_system_info]
   FOR INSERT , UPDATE , DELETE
AS 
BEGIN

     DECLARE @chang_class char(1);
     DECLARE @id bigint;
     DECLARE @key2 nvarchar(150);
     DECLARE @key3 nvarchar(150);
     DECLARE @key4 nvarchar(150);
     DECLARE @key5 nvarchar(150);
     DECLARE @before_info nvarchar(MAX);
     DECLARE @after_info nvarchar(MAX);
     
     DECLARE curList CURSOR
       LOCAL FAST_FORWARD
     FOR

        SELECT CASE WHEN i.id is null          THEN d.id          ELSE i.id              END id,
               CASE WHEN i.[key] is null       THEN d.[key]       ELSE i.[key]           END key2,
               null key3,
               null key4,
               null key5,
               CASE
                  WHEN i.id is null THEN 'D'
                  WHEN d.id is null THEN 'I'
                  ELSE 'U'
               END chang_class,
               (SELECT * FROM deleted d2  WHERE d2.id = d.id FOR JSON PATH) before_info,
               (SELECT * FROM inserted i2 WHERE i2.id = i.id FOR JSON PATH) after_info
          FROM inserted i
          FULL JOIN deleted d
            ON i.id  = d.id;

     OPEN curList;

     FETCH NEXT FROM curList
      INTO @id, @key2, @key3, @key4, @key5, @chang_class, @before_info, @after_info;

     -- 全データを処理するまで繰り返す
     WHILE @@FETCH_STATUS = 0
     BEGIN
         --更新前のJSONデータの前後の{}を削除
         IF @before_info IS NOT NULL
            SET @before_info = SUBSTRING(@before_info, 2, LEN(@before_info) -2);

         --更新後のJSONデータの前後の{}を削除
         IF @after_info IS NOT NULL
            SET @after_info = SUBSTRING(@after_info, 2, LEN(@after_info) -2);

         -- 変更履歴の登録
         INSERT INTO std_master_chang
                 (table_name
                 ,chang_class
                 ,key1
                 ,key2
                 ,key3
                 ,key4
                 ,key5
                 ,before_info
                 ,after_info)
          VALUES ('mst_system_info'
                 ,@chang_class
                 ,@id
                 ,@key2
                 ,@key3
                 ,@key4
                 ,@key5
                 ,@before_info
                 ,@after_info);

         -- NEXT行の検索
         FETCH NEXT FROM curList
          INTO @id, @key2, @key3, @key4, @key5, @chang_class, @before_info, @after_info;
     END;

     CLOSE curList;
     DEALLOCATE curList;

  END;

GO  
CREATE    TRIGGER [dbo].[mst_user_role_all] ON [dbo].[mst_user_role]
   FOR INSERT , UPDATE , DELETE
AS 
BEGIN

     DECLARE @chang_class char(1);
     DECLARE @id bigint;
     DECLARE @key2 nvarchar(150);
     DECLARE @key3 nvarchar(150);
     DECLARE @key4 nvarchar(150);
     DECLARE @key5 nvarchar(150);
     DECLARE @before_info nvarchar(MAX);
     DECLARE @after_info nvarchar(MAX);
     
     DECLARE curList CURSOR
       LOCAL FAST_FORWARD
     FOR

        SELECT CASE WHEN i.id is null              THEN d.id              ELSE i.id               END id,
               CASE WHEN i.user_id is null         THEN d.user_id         ELSE i.user_id          END key2,
               CASE WHEN i.role_id is null         THEN d.role_id         ELSE i.role_id          END key3,
               null key4,
               null key5,
               CASE
                  WHEN i.id is null THEN 'D'
                  WHEN d.id is null THEN 'I'
                  ELSE 'U'
               END chang_class,
               (SELECT * FROM deleted d2  WHERE d2.id = d.id FOR JSON PATH) before_info,
               (SELECT * FROM inserted i2 WHERE i2.id = i.id FOR JSON PATH) after_info
          FROM inserted i
          FULL JOIN deleted d
            ON i.id  = d.id;

     OPEN curList;

     FETCH NEXT FROM curList
      INTO @id, @key2, @key3, @key4, @key5, @chang_class, @before_info, @after_info;

     -- 全データを処理するまで繰り返す
     WHILE @@FETCH_STATUS = 0
     BEGIN
         --更新前のJSONデータの前後の{}を削除
         IF @before_info IS NOT NULL
            SET @before_info = SUBSTRING(@before_info, 2, LEN(@before_info) -2);

         --更新後のJSONデータの前後の{}を削除
         IF @after_info IS NOT NULL
            SET @after_info = SUBSTRING(@after_info, 2, LEN(@after_info) -2);

         -- 変更履歴の登録
         INSERT INTO std_master_chang
                 (table_name
                 ,chang_class
                 ,key1
                 ,key2
                 ,key3
                 ,key4
                 ,key5
                 ,before_info
                 ,after_info)
          VALUES ('mst_user_role'
                 ,@chang_class
                 ,@id
                 ,@key2
                 ,@key3
                 ,@key4
                 ,@key5
                 ,@before_info
                 ,@after_info);

         -- NEXT行の検索
         FETCH NEXT FROM curList
          INTO @id, @key2, @key3, @key4, @key5, @chang_class, @before_info, @after_info;
     END;

     CLOSE curList;
     DEALLOCATE curList;

  END;

GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F1_mst_base_device]  ******/
CREATE NONCLUSTERED INDEX [F1_mst_base_device] ON [dbo].[mst_base_device]
(
	[parent_model_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F1_mst_base_event]  ******/
CREATE NONCLUSTERED INDEX [F1_mst_base_event] ON [dbo].[mst_base_event]
(
	[model_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F1_mst_base_sensor]  ******/
CREATE NONCLUSTERED INDEX [F1_mst_base_sensor] ON [dbo].[mst_base_sensor]
(
	[model_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F1_mst_device]  ******/
CREATE NONCLUSTERED INDEX [F1_mst_device] ON [dbo].[mst_device]
(
	[parent_model_id] ASC,
	[parent_serial_no] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F2_mst_device]  ******/
CREATE NONCLUSTERED INDEX [F2_mst_device] ON [dbo].[mst_device]
(
	[model_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F1_mst_device_group]  ******/
CREATE NONCLUSTERED INDEX [F1_mst_device_group] ON [dbo].[mst_device_group]
(
	[parent_device_group_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F1_mst_device_mode_history]  ******/
CREATE NONCLUSTERED INDEX [F1_mst_device_mode_history] ON [dbo].[mst_device_mode_history]
(
	[model_id] ASC,
	[serial_no] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F1_mst_event]  ******/
CREATE NONCLUSTERED INDEX [F1_mst_event] ON [dbo].[mst_event]
(
	[model_id] ASC,
	[serial_no] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F2_mst_event]  ******/
CREATE NONCLUSTERED INDEX [F2_mst_event] ON [dbo].[mst_event]
(
	[model_id] ASC,
	[event_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F1_mst_group_composition_device]  ******/
CREATE NONCLUSTERED INDEX [F1_mst_group_composition_device] ON [dbo].[mst_group_composition_device]
(
	[device_group_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F2_mst_group_composition_device]  ******/
CREATE NONCLUSTERED INDEX [F2_mst_group_composition_device] ON [dbo].[mst_group_composition_device]
(
	[model_id] ASC,
	[serial_no] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [I1_mst_program_authority]  ******/
CREATE NONCLUSTERED INDEX [I1_mst_program_authority] ON [dbo].[mst_program_authority]
(
	[url] ASC,
	[method] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F1_mst_role_base_config_visual]  ******/
CREATE NONCLUSTERED INDEX [F1_mst_role_base_config_visual] ON [dbo].[mst_role_base_config_visual]
(
	[role_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F2_mst_role_base_config_visual]  ******/
CREATE NONCLUSTERED INDEX [F2_mst_role_base_config_visual] ON [dbo].[mst_role_base_config_visual]
(
	[model_id] ASC,
	[config_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F1_mst_role_base_device_visual]  ******/
CREATE NONCLUSTERED INDEX [F1_mst_role_base_device_visual] ON [dbo].[mst_role_base_device_visual]
(
	[role_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F2_mst_role_base_device_visual]  ******/
CREATE NONCLUSTERED INDEX [F2_mst_role_base_device_visual] ON [dbo].[mst_role_base_device_visual]
(
	[model_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F1_mst_role_base_event_visual]  ******/
CREATE NONCLUSTERED INDEX [F1_mst_role_base_event_visual] ON [dbo].[mst_role_base_event_visual]
(
	[role_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F2_mst_role_base_event_visual]  ******/
CREATE NONCLUSTERED INDEX [F2_mst_role_base_event_visual] ON [dbo].[mst_role_base_event_visual]
(
	[model_id] ASC,
	[event_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F1_mst_role_base_sensor_visual]  ******/
CREATE NONCLUSTERED INDEX [F1_mst_role_base_sensor_visual] ON [dbo].[mst_role_base_sensor_visual]
(
	[role_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F2_mst_role_base_sensor_visual]  ******/
CREATE NONCLUSTERED INDEX [F2_mst_role_base_sensor_visual] ON [dbo].[mst_role_base_sensor_visual]
(
	[model_id] ASC,
	[sensor_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F1_mst_role_config_visual]  ******/
CREATE NONCLUSTERED INDEX [F1_mst_role_config_visual] ON [dbo].[mst_role_config_visual]
(
	[role_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F2_mst_role_config_visual]  ******/
CREATE NONCLUSTERED INDEX [F2_mst_role_config_visual] ON [dbo].[mst_role_config_visual]
(
	[model_id] ASC,
	[serial_no] ASC,
	[config_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F1_mst_role_event_visual]  ******/
CREATE NONCLUSTERED INDEX [F1_mst_role_event_visual] ON [dbo].[mst_role_event_visual]
(
	[role_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F2_mst_role_event_visual]  ******/
CREATE NONCLUSTERED INDEX [F2_mst_role_event_visual] ON [dbo].[mst_role_event_visual]
(
	[model_id] ASC,
	[serial_no] ASC,
	[event_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F1_mst_role_program_authority]  ******/
CREATE NONCLUSTERED INDEX [F1_mst_role_program_authority] ON [dbo].[mst_role_program_authority]
(
	[role_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F2_mst_role_program_authority]  ******/
CREATE NONCLUSTERED INDEX [F2_mst_role_program_authority] ON [dbo].[mst_role_program_authority]
(
	[authority_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F1_mst_role_root_group]  ******/
CREATE NONCLUSTERED INDEX [F1_mst_role_root_group] ON [dbo].[mst_role_root_group]
(
	[role_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F2_mst_role_root_group]  ******/
CREATE NONCLUSTERED INDEX [F2_mst_role_root_group] ON [dbo].[mst_role_root_group]
(
	[root_group_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F1_mst_role_sensor_visual]  ******/
CREATE NONCLUSTERED INDEX [F1_mst_role_sensor_visual] ON [dbo].[mst_role_sensor_visual]
(
	[role_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F2_mst_role_sensor_visual]  ******/
CREATE NONCLUSTERED INDEX [F2_mst_role_sensor_visual] ON [dbo].[mst_role_sensor_visual]
(
	[model_id] ASC,
	[serial_no] ASC,
	[sensor_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F1_mst_sensor]  ******/
CREATE NONCLUSTERED INDEX [F1_mst_sensor] ON [dbo].[mst_sensor]
(
	[model_id] ASC,
	[serial_no] ASC
)
INCLUDE ( 	[sensor_id],
	[data_type],
	[fixed_length],
	[time_data_create_flg],
	[short_term_minutes]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F2_mst_sensor]  ******/
CREATE NONCLUSTERED INDEX [F2_mst_sensor] ON [dbo].[mst_sensor]
(
	[model_id] ASC,
	[sensor_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [F1_mst_user_role]  ******/
CREATE NONCLUSTERED INDEX [F1_mst_user_role] ON [dbo].[mst_user_role]
(
	[role_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [I1_std_devconfig_history]  ******/
CREATE NONCLUSTERED INDEX [I1_std_devconfig_history] ON [dbo].[std_devconfig_history]
(
	[config_file] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [I2_std_devconfig_history]  ******/
CREATE NONCLUSTERED INDEX [I2_std_devconfig_history] ON [dbo].[std_devconfig_history]
(
	[file_notification_key] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [I1_std_devicetwin_chang]  ******/
CREATE NONCLUSTERED INDEX [I1_std_devicetwin_chang] ON [dbo].[std_devicetwin_chang]
(
	[model_id] ASC,
	[serial_no] ASC,
	[insert_time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [I1_std_event_incidence]  ******/
CREATE NONCLUSTERED INDEX [I1_std_event_incidence] ON [dbo].[std_event_incidence]
(
	[detection_class] ASC,
	[incident_class] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [I1_std_event_incidence_history]  ******/
CREATE NONCLUSTERED INDEX [I1_std_event_incidence_history] ON [dbo].[std_event_incidence_history]
(
	[model_id] ASC,
	[serial_no] ASC,
	[event_time] DESC,
	[event_id] ASC
)
INCLUDE (
	[detection_class],
 	[event_status],
	[incident_class],
	[event_level],
	[detection_info]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [I2_std_event_incidence_history]  ******/
CREATE NONCLUSTERED INDEX [I2_std_event_incidence_history] ON [dbo].[std_event_incidence_history]
(
	[event_time] DESC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [I1_std_fileinfo]  ******/
CREATE NONCLUSTERED INDEX [I1_std_fileinfo] ON [dbo].[std_fileinfo]
(
	[model_id] ASC,
	[serial_no] ASC,
	[sensor_id] ASC,
	[measure_time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [I1_std_master_chang]  ******/
CREATE NONCLUSTERED INDEX [I1_std_master_chang] ON [dbo].[std_master_chang]
(
	[table_name] ASC,
	[key1] ASC,
	[insert_time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [I2_std_master_chang]  ******/
CREATE NONCLUSTERED INDEX [I2_std_master_chang] ON [dbo].[std_master_chang]
(
	[table_name] ASC,
	[key2] ASC,
	[key3] ASC,
	[key4] ASC,
	[key5] ASC,
	[insert_time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UK_std_measure_data]  ******/
CREATE UNIQUE NONCLUSTERED INDEX [UK_std_measure_data] ON [dbo].[std_measure_data]
(
	[model_id] ASC,
	[serial_no] ASC,
	[sensor_id] ASC,
	[measure_time] ASC
)
INCLUDE ( 	[measure_data],
	[data_migrate_class],
	[version]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [I1_std_receive_seq]  ******/
CREATE NONCLUSTERED INDEX [I1_std_receive_seq] ON [dbo].[std_receive_seq]
(
	[gw_model_id] ASC,
	[gw_serial_no] ASC,
	[receive_time] ASC
)
INCLUDE ( 	[start_time],
    [receive_seq]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [I1_std_receive_seq_missing]  ******/
CREATE NONCLUSTERED INDEX [I1_std_receive_seq_missing] ON [dbo].[std_receive_seq_missing]
(
	[incident_class] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [I2_std_receive_seq_missing]  ******/
CREATE NONCLUSTERED INDEX [I2_std_receive_seq_missing] ON [dbo].[std_receive_seq_missing]
(
	[resend_request_flg] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [I3_std_receive_seq_missing]  ******/
CREATE NONCLUSTERED INDEX [I3_std_receive_seq_missing] ON [dbo].[std_receive_seq_missing]
(
	[gw_model_id] ASC,
	[gw_serial_no] ASC,
	[start_time] ASC,
	[to_seq] ASC,
	[incident_class] ASC
)
INCLUDE ( 	[from_seq]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [I1_std_role_device]  ******/
CREATE NONCLUSTERED INDEX [I1_std_role_device] ON [dbo].[std_role_device]
(
	[model_id] ASC,
	[serial_no] ASC,
	[role_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [I2_std_role_device]  ******/
CREATE NONCLUSTERED INDEX [I2_std_role_device] ON [dbo].[std_role_device]
(
	[device_group_id] ASC,
	[role_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [dbo].[mst_base_devconfig] ADD  CONSTRAINT [DF_mst_base_devconfig_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_base_devconfig] ADD  CONSTRAINT [DF_mst_base_devconfig_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_base_device] ADD  CONSTRAINT [DF_mst_base_device_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_base_device] ADD  CONSTRAINT [DF_mst_base_device_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_base_event] ADD  CONSTRAINT [DF_mst_base_event_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_base_event] ADD  CONSTRAINT [DF_mst_base_event_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_base_sensor] ADD  CONSTRAINT [DF_mst_base_sensor_sensor_id]  DEFAULT ('') FOR [sensor_id]
GO
ALTER TABLE [dbo].[mst_base_sensor] ADD  CONSTRAINT [DF_mst_base_sensor_time_data_create_flg]  DEFAULT ((1)) FOR [time_data_create_flg]
GO
ALTER TABLE [dbo].[mst_base_sensor] ADD  CONSTRAINT [DF_mst_base_sensor_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_base_sensor] ADD  CONSTRAINT [DF_mst_base_sensor_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_devconfig] ADD  CONSTRAINT [DF_mst_devconfig_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_devconfig] ADD  CONSTRAINT [DF_mst_devconfig_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_device] ADD  CONSTRAINT [DF_mst_device_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_device] ADD  CONSTRAINT [DF_mst_device_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_device_group] ADD  CONSTRAINT [DF_mst_device_group_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_device_group] ADD  CONSTRAINT [DF_mst_device_group_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_device_mode_history] ADD  CONSTRAINT [DF_mst_device_mode_history_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_event] ADD  CONSTRAINT [DF_mst_event_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_event] ADD  CONSTRAINT [DF_mst_event_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_generic_master] ADD  CONSTRAINT [DF_mst_generic_master_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_generic_master] ADD  CONSTRAINT [DF_mst_generic_master_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_group_composition_device] ADD  CONSTRAINT [DF_mst_group_composition_device_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_group_composition_device] ADD  CONSTRAINT [DF_mst_group_composition_device_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_program_authority] ADD  CONSTRAINT [DF_mst_program_authority_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_program_authority] ADD  CONSTRAINT [DF_mst_program_authority_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_role] ADD  CONSTRAINT [DF_mst_role_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_role] ADD  CONSTRAINT [DF_mst_role_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_role_base_config_visual] ADD  CONSTRAINT [DF_mst_role_base_config_visual_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_role_base_config_visual] ADD  CONSTRAINT [DF_mst_role_base_config_visual_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_role_base_device_visual] ADD  CONSTRAINT [DF_mst_role_base_device_visual_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_role_base_device_visual] ADD  CONSTRAINT [DF_mst_role_base_device_visual_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_role_base_event_visual] ADD  CONSTRAINT [DF_mst_role_base_event_visual_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_role_base_event_visual] ADD  CONSTRAINT [DF_mst_role_base_event_visual_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_role_base_sensor_visual] ADD  CONSTRAINT [DF_mst_role_base_sensor_visual_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_role_base_sensor_visual] ADD  CONSTRAINT [DF_mst_role_base_sensor_visual_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_role_config_visual] ADD  CONSTRAINT [DF_mst_role_config_visual_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_role_config_visual] ADD  CONSTRAINT [DF_mst_role_config_visual_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_role_event_visual] ADD  CONSTRAINT [DF_mst_role_event_visual_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_role_event_visual] ADD  CONSTRAINT [DF_mst_role_event_visual_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_role_program_authority] ADD  CONSTRAINT [DF_mst_role_program_authority_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_role_program_authority] ADD  CONSTRAINT [DF_mst_role_program_authority_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_role_root_group] ADD  CONSTRAINT [DF_mst_role_root_group_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_role_root_group] ADD  CONSTRAINT [DF_mst_role_root_group_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_role_sensor_visual] ADD  CONSTRAINT [DF_mst_role_sensor_visual_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_role_sensor_visual] ADD  CONSTRAINT [DF_mst_role_sensor_visual_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_sensor] ADD  CONSTRAINT [DF_mst_sensor_sensor_id]  DEFAULT ('') FOR [sensor_id]
GO
ALTER TABLE [dbo].[mst_sensor] ADD  CONSTRAINT [DF_mst_sensor_time_data_create_flg]  DEFAULT ((1)) FOR [time_data_create_flg]
GO
ALTER TABLE [dbo].[mst_sensor] ADD  CONSTRAINT [DF_mst_sensor_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_sensor] ADD  CONSTRAINT [DF_mst_sensor_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_system_info] ADD  CONSTRAINT [DF_mst_system_info_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_system_info] ADD  CONSTRAINT [DF_mst_system_info_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[mst_user_role] ADD  CONSTRAINT [DF_mst_user_role_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_user_role] ADD  CONSTRAINT [DF_mst_user_role_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[std_devconfig_history] ADD  CONSTRAINT [DF_std_devconfig_history_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[std_devconfig_history] ADD  CONSTRAINT [DF_std_devconfig_history_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[std_devicetwin_chang] ADD  CONSTRAINT [DF_std_devicetwin_chang]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[std_event_incidence] ADD  CONSTRAINT [DF_std_event_incidence_event_id]  DEFAULT ('') FOR [event_id]
GO
ALTER TABLE [dbo].[std_event_incidence] ADD  CONSTRAINT [DF_std_event_incidence_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[std_event_incidence] ADD  CONSTRAINT [DF_std_event_incidence_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[std_event_incidence_history] ADD  CONSTRAINT [DF_std_event_incidence_history_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[std_file_recept_mng] ADD  CONSTRAINT [DF__std_file___uploa__4E1E9780]  DEFAULT ((0)) FOR [upload_flg]
GO
ALTER TABLE [dbo].[std_file_recept_mng] ADD  CONSTRAINT [DF__std_file___inser__4F12BBB9]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[std_file_recept_mng] ADD  CONSTRAINT [DF_std_file_recept_mng_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[std_gw_command_history] ADD  CONSTRAINT [DF_std_gw_command_history_request_time]  DEFAULT (sysdatetime()) FOR [request_time]
GO
ALTER TABLE [dbo].[std_gw_receve_time] ADD  CONSTRAINT [DF__std_gw_re__inser__00200768]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[std_master_chang] ADD  CONSTRAINT [DF_std_master_chang_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[std_measure_data] ADD  CONSTRAINT [DF_std_measure_data_data_migrate_class]  DEFAULT ((1)) FOR [data_migrate_class]
GO
ALTER TABLE [dbo].[std_measure_data] ADD  CONSTRAINT [DF_std_measure_data_version]  DEFAULT ((0)) FOR [version]
GO
ALTER TABLE [dbo].[std_new_measure_data] ADD  CONSTRAINT [DF_std_new_measure_data_version]  DEFAULT ((0)) FOR [version]
GO
ALTER TABLE [dbo].[std_receive_seq] ADD  CONSTRAINT [DF_std_receive_seq_receive_time]  DEFAULT (sysdatetime()) FOR [receive_time]
GO
ALTER TABLE [dbo].[std_receive_seq_missing] ADD  CONSTRAINT [DF_std_receive_seq_missing_resend_request_flg]  DEFAULT ((0)) FOR [resend_request_flg]
GO
ALTER TABLE [dbo].[std_receive_seq_missing] ADD  CONSTRAINT [DF_std_receive_seq_missing_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[std_receive_seq_missing] ADD  CONSTRAINT [DF_std_receive_seq_missing_update_time]  DEFAULT (sysdatetime()) FOR [update_time]
GO
ALTER TABLE [dbo].[std_sensor_receve_time] ADD  CONSTRAINT [DF_std_sensor_receve_time_insert_time]  DEFAULT (sysdatetime()) FOR [insert_time]
GO
ALTER TABLE [dbo].[mst_base_devconfig]  WITH CHECK ADD  CONSTRAINT [F1_mst_base_devconfig] FOREIGN KEY([model_id])
REFERENCES [dbo].[mst_base_device] ([model_id])
GO
ALTER TABLE [dbo].[mst_base_devconfig] CHECK CONSTRAINT [F1_mst_base_devconfig]
GO
ALTER TABLE [dbo].[mst_base_device]  WITH CHECK ADD  CONSTRAINT [F1_mst_base_device] FOREIGN KEY([parent_model_id])
REFERENCES [dbo].[mst_base_device] ([model_id])
GO
ALTER TABLE [dbo].[mst_base_device] CHECK CONSTRAINT [F1_mst_base_device]
GO
ALTER TABLE [dbo].[mst_base_event]  WITH CHECK ADD  CONSTRAINT [F1_mst_base_event] FOREIGN KEY([model_id])
REFERENCES [dbo].[mst_base_device] ([model_id])
GO
ALTER TABLE [dbo].[mst_base_event] CHECK CONSTRAINT [F1_mst_base_event]
GO
ALTER TABLE [dbo].[mst_base_sensor]  WITH CHECK ADD  CONSTRAINT [F1_mst_base_sensor] FOREIGN KEY([model_id])
REFERENCES [dbo].[mst_base_device] ([model_id])
GO
ALTER TABLE [dbo].[mst_base_sensor] CHECK CONSTRAINT [F1_mst_base_sensor]
GO
ALTER TABLE [dbo].[mst_devconfig]  WITH CHECK ADD  CONSTRAINT [F1_mst_devconfig] FOREIGN KEY([model_id], [serial_no])
REFERENCES [dbo].[mst_device] ([model_id], [serial_no])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_devconfig] CHECK CONSTRAINT [F1_mst_devconfig]
GO
ALTER TABLE [dbo].[mst_devconfig]  WITH CHECK ADD  CONSTRAINT [F2_mst_devconfig] FOREIGN KEY([model_id], [config_id])
REFERENCES [dbo].[mst_base_devconfig] ([model_id], [config_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_devconfig] CHECK CONSTRAINT [F2_mst_devconfig]
GO
ALTER TABLE [dbo].[mst_device]  WITH CHECK ADD  CONSTRAINT [F1_mst_device] FOREIGN KEY([parent_model_id], [parent_serial_no])
REFERENCES [dbo].[mst_device] ([model_id], [serial_no])
GO
ALTER TABLE [dbo].[mst_device] CHECK CONSTRAINT [F1_mst_device]
GO
ALTER TABLE [dbo].[mst_device]  WITH CHECK ADD  CONSTRAINT [F2_mst_device] FOREIGN KEY([model_id])
REFERENCES [dbo].[mst_base_device] ([model_id])
GO
ALTER TABLE [dbo].[mst_device] CHECK CONSTRAINT [F2_mst_device]
GO
ALTER TABLE [dbo].[mst_device_group]  WITH CHECK ADD  CONSTRAINT [F1_mst_device_group] FOREIGN KEY([parent_device_group_id])
REFERENCES [dbo].[mst_device_group] ([device_group_id])
GO
ALTER TABLE [dbo].[mst_device_group] CHECK CONSTRAINT [F1_mst_device_group]
GO
ALTER TABLE [dbo].[mst_device_mode_history]  WITH CHECK ADD  CONSTRAINT [F1_mst_device_mode_history] FOREIGN KEY([model_id], [serial_no])
REFERENCES [dbo].[mst_device] ([model_id], [serial_no])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_device_mode_history] CHECK CONSTRAINT [F1_mst_device_mode_history]
GO
ALTER TABLE [dbo].[mst_event]  WITH CHECK ADD  CONSTRAINT [F1_mst_event] FOREIGN KEY([model_id], [serial_no])
REFERENCES [dbo].[mst_device] ([model_id], [serial_no])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_event] CHECK CONSTRAINT [F1_mst_event]
GO
ALTER TABLE [dbo].[mst_event]  WITH CHECK ADD  CONSTRAINT [F2_mst_event] FOREIGN KEY([model_id], [event_id])
REFERENCES [dbo].[mst_base_event] ([model_id], [event_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_event] CHECK CONSTRAINT [F2_mst_event]
GO
ALTER TABLE [dbo].[mst_group_composition_device]  WITH CHECK ADD  CONSTRAINT [F1_mst_group_composition_device] FOREIGN KEY([device_group_id])
REFERENCES [dbo].[mst_device_group] ([device_group_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_group_composition_device] CHECK CONSTRAINT [F1_mst_group_composition_device]
GO
ALTER TABLE [dbo].[mst_group_composition_device]  WITH CHECK ADD  CONSTRAINT [F2_mst_group_composition_device] FOREIGN KEY([model_id], [serial_no])
REFERENCES [dbo].[mst_device] ([model_id], [serial_no])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_group_composition_device] CHECK CONSTRAINT [F2_mst_group_composition_device]
GO
ALTER TABLE [dbo].[mst_role_base_config_visual]  WITH CHECK ADD  CONSTRAINT [F1_mst_role_base_config_visual] FOREIGN KEY([role_id])
REFERENCES [dbo].[mst_role] ([role_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_role_base_config_visual] CHECK CONSTRAINT [F1_mst_role_base_config_visual]
GO
ALTER TABLE [dbo].[mst_role_base_config_visual]  WITH CHECK ADD  CONSTRAINT [F2_mst_role_base_config_visual] FOREIGN KEY([model_id], [config_id])
REFERENCES [dbo].[mst_base_devconfig] ([model_id], [config_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_role_base_config_visual] CHECK CONSTRAINT [F2_mst_role_base_config_visual]
GO
ALTER TABLE [dbo].[mst_role_base_device_visual]  WITH CHECK ADD  CONSTRAINT [F1_mst_role_base_device_visual] FOREIGN KEY([role_id])
REFERENCES [dbo].[mst_role] ([role_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_role_base_device_visual] CHECK CONSTRAINT [F1_mst_role_base_device_visual]
GO
ALTER TABLE [dbo].[mst_role_base_device_visual]  WITH CHECK ADD  CONSTRAINT [F2_mst_role_base_device_visual] FOREIGN KEY([model_id])
REFERENCES [dbo].[mst_base_device] ([model_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_role_base_device_visual] CHECK CONSTRAINT [F2_mst_role_base_device_visual]
GO
ALTER TABLE [dbo].[mst_role_base_event_visual]  WITH CHECK ADD  CONSTRAINT [F1_mst_role_base_event_visual] FOREIGN KEY([role_id])
REFERENCES [dbo].[mst_role] ([role_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_role_base_event_visual] CHECK CONSTRAINT [F1_mst_role_base_event_visual]
GO
ALTER TABLE [dbo].[mst_role_base_event_visual]  WITH CHECK ADD  CONSTRAINT [F2_mst_role_base_event_visual] FOREIGN KEY([model_id], [event_id])
REFERENCES [dbo].[mst_base_event] ([model_id], [event_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_role_base_event_visual] CHECK CONSTRAINT [F2_mst_role_base_event_visual]
GO
ALTER TABLE [dbo].[mst_role_base_sensor_visual]  WITH CHECK ADD  CONSTRAINT [F1_mst_role_base_sensor_visual] FOREIGN KEY([role_id])
REFERENCES [dbo].[mst_role] ([role_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_role_base_sensor_visual] CHECK CONSTRAINT [F1_mst_role_base_sensor_visual]
GO
ALTER TABLE [dbo].[mst_role_base_sensor_visual]  WITH CHECK ADD  CONSTRAINT [F2_mst_role_base_sensor_visual] FOREIGN KEY([model_id], [sensor_id])
REFERENCES [dbo].[mst_base_sensor] ([model_id], [sensor_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_role_base_sensor_visual] CHECK CONSTRAINT [F2_mst_role_base_sensor_visual]
GO
ALTER TABLE [dbo].[mst_role_config_visual]  WITH CHECK ADD  CONSTRAINT [F1_mst_role_config_visual] FOREIGN KEY([role_id])
REFERENCES [dbo].[mst_role] ([role_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_role_config_visual] CHECK CONSTRAINT [F1_mst_role_config_visual]
GO
ALTER TABLE [dbo].[mst_role_config_visual]  WITH CHECK ADD  CONSTRAINT [F2_mst_role_config_visual] FOREIGN KEY([model_id], [serial_no], [config_id])
REFERENCES [dbo].[mst_devconfig] ([model_id], [serial_no], [config_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_role_config_visual] CHECK CONSTRAINT [F2_mst_role_config_visual]
GO
ALTER TABLE [dbo].[mst_role_event_visual]  WITH CHECK ADD  CONSTRAINT [F1_mst_role_event_visual] FOREIGN KEY([role_id])
REFERENCES [dbo].[mst_role] ([role_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_role_event_visual] CHECK CONSTRAINT [F1_mst_role_event_visual]
GO
ALTER TABLE [dbo].[mst_role_event_visual]  WITH CHECK ADD  CONSTRAINT [F2_mst_role_event_visual] FOREIGN KEY([model_id], [serial_no], [event_id])
REFERENCES [dbo].[mst_event] ([model_id], [serial_no], [event_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_role_event_visual] CHECK CONSTRAINT [F2_mst_role_event_visual]
GO
ALTER TABLE [dbo].[mst_role_program_authority]  WITH CHECK ADD  CONSTRAINT [F1_mst_role_program_authority] FOREIGN KEY([role_id])
REFERENCES [dbo].[mst_role] ([role_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_role_program_authority] CHECK CONSTRAINT [F1_mst_role_program_authority]
GO
ALTER TABLE [dbo].[mst_role_program_authority]  WITH CHECK ADD  CONSTRAINT [F2_mst_role_program_authority] FOREIGN KEY([authority_id])
REFERENCES [dbo].[mst_program_authority] ([authority_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_role_program_authority] CHECK CONSTRAINT [F2_mst_role_program_authority]
GO
ALTER TABLE [dbo].[mst_role_root_group]  WITH CHECK ADD  CONSTRAINT [F1_mst_role_root_group] FOREIGN KEY([role_id])
REFERENCES [dbo].[mst_role] ([role_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_role_root_group] CHECK CONSTRAINT [F1_mst_role_root_group]
GO
ALTER TABLE [dbo].[mst_role_root_group]  WITH CHECK ADD  CONSTRAINT [F2_mst_role_root_group] FOREIGN KEY([root_group_id])
REFERENCES [dbo].[mst_device_group] ([device_group_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_role_root_group] CHECK CONSTRAINT [F2_mst_role_root_group]
GO
ALTER TABLE [dbo].[mst_role_sensor_visual]  WITH CHECK ADD  CONSTRAINT [F1_mst_role_sensor_visual] FOREIGN KEY([role_id])
REFERENCES [dbo].[mst_role] ([role_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_role_sensor_visual] CHECK CONSTRAINT [F1_mst_role_sensor_visual]
GO
ALTER TABLE [dbo].[mst_role_sensor_visual]  WITH CHECK ADD  CONSTRAINT [F2_mst_role_sensor_visual] FOREIGN KEY([model_id], [serial_no], [sensor_id])
REFERENCES [dbo].[mst_sensor] ([model_id], [serial_no], [sensor_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_role_sensor_visual] CHECK CONSTRAINT [F2_mst_role_sensor_visual]
GO
ALTER TABLE [dbo].[mst_sensor]  WITH CHECK ADD  CONSTRAINT [F1_mst_sensor] FOREIGN KEY([model_id], [serial_no])
REFERENCES [dbo].[mst_device] ([model_id], [serial_no])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_sensor] CHECK CONSTRAINT [F1_mst_sensor]
GO
ALTER TABLE [dbo].[mst_sensor]  WITH CHECK ADD  CONSTRAINT [F2_mst_sensor] FOREIGN KEY([model_id], [sensor_id])
REFERENCES [dbo].[mst_base_sensor] ([model_id], [sensor_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_sensor] CHECK CONSTRAINT [F2_mst_sensor]
GO
ALTER TABLE [dbo].[mst_user_role]  WITH CHECK ADD  CONSTRAINT [F1_mst_user_role] FOREIGN KEY([role_id])
REFERENCES [dbo].[mst_role] ([role_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[mst_user_role] CHECK CONSTRAINT [F1_mst_user_role]
GO
ALTER TABLE [dbo].[std_devconfig_history]  WITH CHECK ADD  CONSTRAINT [F1_std_devconfig_history] FOREIGN KEY([model_id], [serial_no], [config_id])
REFERENCES [dbo].[mst_devconfig] ([model_id], [serial_no], [config_id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[std_devconfig_history] CHECK CONSTRAINT [F1_std_devconfig_history]

GO
ALTER TABLE [dbo].[mst_base_device] ENABLE TRIGGER [mst_base_device_all]

GO
ALTER TABLE [dbo].[mst_base_event] ENABLE TRIGGER [mst_base_event_all]

GO
ALTER TABLE [dbo].[mst_base_sensor] ENABLE TRIGGER [mst_base_sensor_all]

GO
ALTER TABLE [dbo].[mst_device] ENABLE TRIGGER [mst_device_all]

GO
ALTER TABLE [dbo].[mst_device_group] ENABLE TRIGGER [mst_device_group_all]

GO
ALTER TABLE [dbo].[mst_event] ENABLE TRIGGER [mst_event_all]

GO
ALTER TABLE [dbo].[mst_group_composition_device] ENABLE TRIGGER [mst_group_composition_device_all]

GO
ALTER TABLE [dbo].[mst_program_authority] ENABLE TRIGGER [mst_program_authority_all]

GO
ALTER TABLE [dbo].[mst_role] ENABLE TRIGGER [mst_role_all]

GO
ALTER TABLE [dbo].[mst_role_program_authority] ENABLE TRIGGER [mst_role_program_authority_all]

GO
ALTER TABLE [dbo].[mst_role_root_group] ENABLE TRIGGER [mst_role_root_group_all]

GO
ALTER TABLE [dbo].[mst_sensor] ENABLE TRIGGER [mst_sensor_all]

GO
ALTER TABLE [dbo].[mst_system_info] ENABLE TRIGGER [mst_system_info_all]

GO
ALTER TABLE [dbo].[mst_user_role] ENABLE TRIGGER [mst_user_role_all]





