INSERT [dbo].[mst_role] ( [role_id], [name_locale1], [name_locale2], [name_locale3], [description_locale1], [description_locale2], [description_locale3], [note], [version], [inserted], [updated]) 
SELECT 'ADMIN' as role_id, 'Administrator authority role' as name_locale1, '' as name_locale2, '' as name_locale3, '' as description_locale1, '' as description_locale2, '' as description_locale3, '', 0 as version, 'System' as inserted, 'System' as updated
 WHERE NOT EXISTS (SELECT 1 FROM [dbo].[mst_role] WHERE role_id = 'ADMIN');
 
INSERT INTO [dbo].[mst_program_authority] ([authority_id] ,[authority_type] ,[name_locale1] ,[url] ,[method] ,[version] ,[inserted] ,[updated])
SELECT a.authority_id, 'REST_API_PERMISSION' as authority_type, a.authority_id as name_locale1, a.url, a.method, 0 as version, 'System' as inserted, 'System' as updated
  FROM (
              SELECT 'baseDevconfigs_DELETE' as authority_id, '/v1/master-info/baseDevconfigs' as url, 'DELETE' as method 
        UNION SELECT 'baseDevconfigs_GET' as authority_id, '/v1/master-info/baseDevconfigs' as url, 'GET' as method 
        UNION SELECT 'baseDevconfigs_POST' as authority_id, '/v1/master-info/baseDevconfigs' as url, 'POST' as method 
        UNION SELECT 'baseDevconfigs_PUT' as authority_id, '/v1/master-info/baseDevconfigs' as url, 'PUT' as method 
        UNION SELECT 'baseDevices_DELETE' as authority_id, '/v1/master-info/baseDevices' as url, 'DELETE' as method 
        UNION SELECT 'baseDevices_GET' as authority_id, '/v1/master-info/baseDevices' as url, 'GET' as method 
        UNION SELECT 'baseDevices_POST' as authority_id, '/v1/master-info/baseDevices' as url, 'POST' as method 
        UNION SELECT 'baseDevices_PUT' as authority_id, '/v1/master-info/baseDevices' as url, 'PUT' as method 
        UNION SELECT 'baseEvents_DELETE' as authority_id, '/v1/master-info/baseEvents' as url, 'DELETE' as method 
        UNION SELECT 'baseEvents_GET' as authority_id, '/v1/master-info/baseEvents' as url, 'GET' as method 
        UNION SELECT 'baseEvents_POST' as authority_id, '/v1/master-info/baseEvents' as url, 'POST' as method 
        UNION SELECT 'baseEvents_PUT' as authority_id, '/v1/master-info/baseEvents' as url, 'PUT' as method 
        UNION SELECT 'baseSensors_DELETE' as authority_id, '/v1/master-info/baseSensors' as url, 'DELETE' as method 
        UNION SELECT 'baseSensors_GET' as authority_id, '/v1/master-info/baseSensors' as url, 'GET' as method 
        UNION SELECT 'baseSensors_POST' as authority_id, '/v1/master-info/baseSensors' as url, 'POST' as method 
        UNION SELECT 'baseSensors_PUT' as authority_id, '/v1/master-info/baseSensors' as url, 'PUT' as method 
        UNION SELECT 'devconfigs_DELETE' as authority_id, '/v1/master-info/devconfigs' as url, 'DELETE' as method 
        UNION SELECT 'devconfigs_GET' as authority_id, '/v1/master-info/devconfigs' as url, 'GET' as method 
        UNION SELECT 'devconfigs_POST' as authority_id, '/v1/master-info/devconfigs' as url, 'POST' as method 
        UNION SELECT 'devconfigs_PUT' as authority_id, '/v1/master-info/devconfigs' as url, 'PUT' as method 
        UNION SELECT 'devconfigHistories_GET' as authority_id, '/v1/master-info/devconfigHistories' as url, 'GET' as method 
        UNION SELECT 'deviceAlarmStatus_GET' as authority_id, '/v1/alarm-event-mgt/deviceAlarmStatus' as url, 'GET' as method 
        UNION SELECT 'deviceGroupAlarmStatus_GET' as authority_id, '/v1/alarm-event-mgt/deviceGroupAlarmStatus' as url, 'GET' as method 
        UNION SELECT 'deviceGroupDevice_GET' as authority_id, '/v1/device-group-structure-get/deviceGroupDevice' as url, 'GET' as method 
        UNION SELECT 'deviceGroups_DELETE' as authority_id, '/v1/master-info/deviceGroups' as url, 'DELETE' as method 
        UNION SELECT 'deviceGroups_GET' as authority_id, '/v1/master-info/deviceGroups' as url, 'GET' as method 
        UNION SELECT 'deviceGroups_POST' as authority_id, '/v1/master-info/deviceGroups' as url, 'POST' as method 
        UNION SELECT 'deviceGroups_PUT' as authority_id, '/v1/master-info/deviceGroups' as url, 'PUT' as method 
        UNION SELECT 'deviceGroupStructure_GET' as authority_id, '/v1/device-group-structure-get/deviceGroupStructure' as url, 'GET' as method 
        UNION SELECT 'devices_DELETE' as authority_id, '/v1/master-info/devices' as url, 'DELETE' as method 
        UNION SELECT 'devices_GET' as authority_id, '/v1/master-info/devices' as url, 'GET' as method 
        UNION SELECT 'devices_POST' as authority_id, '/v1/master-info/devices' as url, 'POST' as method 
        UNION SELECT 'devices_PUT' as authority_id, '/v1/master-info/devices' as url, 'PUT' as method 
        UNION SELECT 'deviceSensor_GET' as authority_id, '/v1/device-group-structure-get/deviceSensor' as url, 'GET' as method 
        UNION SELECT 'deviceStructure_GET' as authority_id, '/v1/device-group-structure-get/deviceStructure' as url, 'GET' as method 
        UNION SELECT 'event_POST' as authority_id, '/v1/alarm-event-mgt/event' as url, 'POST' as method 
        UNION SELECT 'eventHistory_GET' as authority_id, '/v1/alarm-event-mgt/eventHistory' as url, 'GET' as method 
        UNION SELECT 'events_DELETE' as authority_id, '/v1/master-info/events' as url, 'DELETE' as method 
        UNION SELECT 'events_GET' as authority_id, '/v1/master-info/events' as url, 'GET' as method 
        UNION SELECT 'events_POST' as authority_id, '/v1/master-info/events' as url, 'POST' as method 
        UNION SELECT 'events_PUT' as authority_id, '/v1/master-info/events' as url, 'PUT' as method 
        UNION SELECT 'eventStatus_GET' as authority_id, '/v1/alarm-event-mgt/eventStatus' as url, 'GET' as method 
        UNION SELECT 'expansionFile_POST' as authority_id, '/v1/sensor-data-file-mgt/expansionFile' as url, 'POST' as method 
        UNION SELECT 'file_GET' as authority_id, '/v1/sensor-data-file-mgt/file' as url, 'GET' as method 
        UNION SELECT 'file_POST' as authority_id, '/v1/sensor-data-file-mgt/file' as url, 'POST' as method 
        UNION SELECT 'fileInfoNotification_POST' as authority_id, '/v1/device/fileInfoNotification' as url, 'POST' as method 
        UNION SELECT 'groupCompositionDevices_DELETE' as authority_id, '/v1/master-info/groupCompositionDevices' as url, 'DELETE' as method 
        UNION SELECT 'groupCompositionDevices_GET' as authority_id, '/v1/master-info/groupCompositionDevices' as url, 'GET' as method 
        UNION SELECT 'groupCompositionDevices_POST' as authority_id, '/v1/master-info/groupCompositionDevices' as url, 'POST' as method 
        UNION SELECT 'groupCompositionDevices_PUT' as authority_id, '/v1/master-info/groupCompositionDevices' as url, 'PUT' as method 
        UNION SELECT 'latestSensorData_GET' as authority_id, '/v1/sensor-data-file-mgt/latestSensorData' as url, 'GET' as method 
        UNION SELECT 'latestSensorFile_GET' as authority_id, '/v1/sensor-data-file-mgt/latestSensorFile' as url, 'GET' as method 
        UNION SELECT 'measureFile_POST' as authority_id, '/v1/sensor-data-file-mgt/measureFile' as url, 'POST' as method 
        UNION SELECT 'opeInstructions_POST' as authority_id, '/v1/device/opeInstructions' as url, 'POST' as method 
        UNION SELECT 'roleRootGroups_DELETE' as authority_id, '/v1/master-info/roleRootGroups' as url, 'DELETE' as method 
        UNION SELECT 'roleRootGroups_GET' as authority_id, '/v1/master-info/roleRootGroups' as url, 'GET' as method 
        UNION SELECT 'roleRootGroups_POST' as authority_id, '/v1/master-info/roleRootGroups' as url, 'POST' as method 
        UNION SELECT 'roleRootGroups_PUT' as authority_id, '/v1/master-info/roleRootGroups' as url, 'PUT' as method 
        UNION SELECT 'roles_DELETE' as authority_id, '/v1/master-info/roles' as url, 'DELETE' as method 
        UNION SELECT 'roles_GET' as authority_id, '/v1/master-info/roles' as url, 'GET' as method 
        UNION SELECT 'roles_POST' as authority_id, '/v1/master-info/roles' as url, 'POST' as method 
        UNION SELECT 'roles_PUT' as authority_id, '/v1/master-info/roles' as url, 'PUT' as method 
        UNION SELECT 'sensorData_DELETE' as authority_id, '/v1/sensor-data-file-mgt/sensorData' as url, 'DELETE' as method 
        UNION SELECT 'sensorData_GET' as authority_id, '/v1/sensor-data-file-mgt/sensorData' as url, 'GET' as method 
        UNION SELECT 'sensorFile_GET' as authority_id, '/v1/sensor-data-file-mgt/sensorFile' as url, 'GET' as method 
        UNION SELECT 'sensors_DELETE' as authority_id, '/v1/master-info/sensors' as url, 'DELETE' as method 
        UNION SELECT 'sensors_GET' as authority_id, '/v1/master-info/sensors' as url, 'GET' as method 
        UNION SELECT 'sensors_POST' as authority_id, '/v1/master-info/sensors' as url, 'POST' as method 
        UNION SELECT 'sensors_PUT' as authority_id, '/v1/master-info/sensors' as url, 'PUT' as method 
        UNION SELECT 'statusMgt_PATCH' as authority_id, '/v1/alarm-event-mgt/statusMgt' as url, 'PATCH' as method 
        UNION SELECT 'statusMgt_PUT' as authority_id, '/v1/alarm-event-mgt/statusMgt' as url, 'PUT' as method 
        UNION SELECT 'userDeviceAuthorities_GET' as authority_id, '/v1/master-info/userDeviceAuthorities' as url, 'GET' as method 
        UNION SELECT 'userDeviceGroupAuthorities_GET' as authority_id, '/v1/master-info/userDeviceGroupAuthorities' as url, 'GET' as method 
        UNION SELECT 'userEventAuthorities_GET' as authority_id, '/v1/master-info/userEventAuthorities' as url, 'GET' as method 
        UNION SELECT 'userProgramAuthorities_GET' as authority_id, '/v1/master-info/userProgramAuthorities' as url, 'GET' as method 
        UNION SELECT 'userRoles_DELETE' as authority_id, '/v1/master-info/userRoles' as url, 'DELETE' as method 
        UNION SELECT 'userRoles_GET' as authority_id, '/v1/master-info/userRoles' as url, 'GET' as method 
        UNION SELECT 'userRoles_POST' as authority_id, '/v1/master-info/userRoles' as url, 'POST' as method 
        UNION SELECT 'userRoles_PUT' as authority_id, '/v1/master-info/userRoles' as url, 'PUT' as method 
        UNION SELECT 'userSensorAuthorities_GET' as authority_id, '/v1/master-info/userSensorAuthorities' as url, 'GET' as method
       ) a
 WHERE NOT EXISTS (SELECT 1 FROM mst_program_authority b
                           WHERE a.url = b.url
                             AND a.method = b.method);

INSERT [dbo].[mst_role_program_authority] ( [role_id], [authority_id], [version], [inserted], [updated]) 
SELECT [role_id]
      ,[authority_id]
      ,0 as [version]
      ,'System' AS [inserted]
      ,'System' AS [updated]
  FROM [dbo].[mst_program_authority] mpa,
       [mst_role] mr
 WHERE mr.role_id = 'ADMIN'
   AND mpa.authority_type = 'REST_API_PERMISSION'
   AND NOT EXISTS (SELECT 1 FROM [dbo].[mst_role_program_authority] b
                    WHERE b.role_id = 'ADMIN'
                      AND b.authority_id = mpa.authority_id); 


INSERT [dbo].[mst_system_info] ([key], [name_locale1], [item_type], [value_int], [value_string], [unit_locale1], [description_locale1], [version], [inserted], [updated])
SELECT a.[key], a.name_locale1, a.item_type, a.value_int, a.value_string, a.unit_locale1, a.description_locale1, 0 as version, 'System' as inserted, 'System' as updated
  FROM (
        SELECT 'DelayWaitSeconds'  as [key],       N'遅延待機秒数' as name_locale1,                'int' as item_type,      10 as value_int, NULL as value_string,                N'秒数' as unit_locale1, N'通信シーケンスチェック時の遅延待機秒数' as description_locale1
  UNION SELECT 'GwUnreceveSeconds' as [key],       N'GW未受信秒数' as name_locale1,                'int' as item_type,     300 as value_int, NULL as value_string,                N'秒数' as unit_locale1, N'GWからの未受信チェック秒数' as description_locale1
  UNION SELECT 'GwUnreceiveCreateInterval' as [key], N'GW未受信イベント履歴作成間隔' as name_locale1, 'int' as item_type, 86400 as value_int, NULL as value_string,               N'秒数' as unit_locale1, N'未受信時未回復時のイベント履歴作成間隔（未指定時は 999999999)' as description_locale1
  UNION SELECT 'GwUnreceiveEventId' as [key],      N'GW未受信イベントID' as name_locale1,          'string' as item_type, NULL as value_int, N'__GW-UNRECEIVE__' as value_string, NULL as unit_locale1,    N'Reception from GW is interrupted' as description_locale1
  UNION SELECT 'GwUnreceiveEventLevel' as [key],   N'GW未受信イベントレベル' as name_locale1,      'string' as item_type, NULL as value_int, N'1' as value_string,                NULL as unit_locale1,    NULL as description_locale1
  UNION SELECT 'GwSeqMissingEventId' as [key],     N'GW受信SEQ抜けイベントID' as name_locale1,     'string' as item_type, NULL as value_int, N'__GW-SEQMISS__' as value_string,   NULL as unit_locale1,    N'There is a missing in the reception sequence from GW' as description_locale1
  UNION SELECT 'GwSeqMissingEventLevel' as [key],  N'GW受信SEQ抜けイベントレベル' as name_locale1, 'string' as item_type, NULL as value_int, N'1' as value_string,                NULL as unit_locale1,    NULL as description_locale1
  UNION SELECT 'DeviceAbnormalEventId' as [key],   N'デバイス異常イベントID' as name_locale1,      'string' as item_type, NULL as value_int, N'__DEVICE-ABNORMAL__' as value_string, NULL as unit_locale1, N'Device abnormality' as description_locale1
  UNION SELECT 'DeviceAbnormalEventLevel' as [key], N'デバイス異常イベントレベル' as name_locale1, 'string' as item_type, NULL as value_int, N'3' as value_string,                NULL as unit_locale1,    NULL as description_locale1
  UNION SELECT 'Locale1Name' as [key],             N'ロケール１名' as name_locale1,                'string' as item_type, NULL as value_int, N'JA' as value_string,               NULL as unit_locale1,    NULL as description_locale1
  UNION SELECT 'Locale2Name' as [key],             N'ロケール２名' as name_locale1,                'string' as item_type, NULL as value_int, N'EN' as value_string,               NULL as unit_locale1,    NULL as description_locale1
  UNION SELECT 'Locale3Name' as [key],             N'ロケール３名' as name_locale1,                'string' as item_type, NULL as value_int, N'CH' as value_string,               NULL as unit_locale1,    NULL as description_locale1
  UNION SELECT 'DataHourMigrateWaite' as [key],    N'時間別移行待機時間' as name_locale1,          'int' as item_type,       1 as value_int, NULL as value_string,                N'時間(H)' as unit_locale1, NULL as description_locale1
  UNION SELECT 'DataBlobMigrateWaite' as [key],    N'月別Blob移行待機日数' as name_locale1,        'int' as item_type,     180 as value_int, NULL as value_string,                N'日数' as unit_locale1, NULL as description_locale1
  UNION SELECT 'DataBlobMigrateWaite2' as [key],   N'月別Blob移行待機日数２' as name_locale1,      'int' as item_type,     180 as value_int, NULL as value_string,                N'日数' as unit_locale1, N'時系列データを作成しないセンサーの計測データ　が対象' as description_locale1
       ) a
 WHERE NOT EXISTS (SELECT 1 FROM mst_system_info b
                           WHERE a.[key] = b.[key]);
						   
INSERT [dbo].[mst_device_group] ([device_group_id], [device_group_type], [name_locale1], [version], [inserted], [updated]) 
SELECT 'DefaultGroup' as device_group_id, 'default' as device_group_type, 'Default Group' name_locale1, 0 as version, 'System' as inserted, 'System' as updated
 WHERE NOT EXISTS (SELECT 1 FROM mst_device_group WHERE device_group_id = 'DefaultGroup');
 
 insert into mst_system_info 
([key],name_locale1,item_type,value_int,version,inserted,insert_time,updated,update_time) 
values ('EventAlertSendMailFlag',N'イベントアラームメール送信フラグ','i',1,0,'system',CURRENT_TIMESTAMP,'system',CURRENT_TIMESTAMP);
insert into mst_system_info 
([key],name_locale1,item_type,value_string,version,inserted,insert_time,updated,update_time) 
values ('EventAlertSendMailAddress',N'イベントアラームメール送信アドレス','s','no-reply@system.spinex.tdsl.co.jp',0,'system',CURRENT_TIMESTAMP,'system',CURRENT_TIMESTAMP);
update mst_system_info set value_int=0 where [key]='EventAlertSendMailFlag';

INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'area_dashboard_refer','UI_PERMISSION','area_dashboard_refer','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'area_dashboard_update','UI_PERMISSION','area_dashboard_update','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'deviceMasterManagement_sensor_refer','UI_PERMISSION','deviceMasterManagement_sensor_refer','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'deviceMasterManagement_sensor_update','UI_PERMISSION','deviceMasterManagement_sensor_update','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'deviceMasterManagement_event_refer','UI_PERMISSION','deviceMasterManagement_event_refer','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'deviceMasterManagement_event_update','UI_PERMISSION','deviceMasterManagement_event_update','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'deviceManagement_model_refer','UI_PERMISSION','deviceManagement_model_refer','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'deviceManagement_model_update','UI_PERMISSION','deviceManagement_model_update','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'deviceManagement_device_refer','UI_PERMISSION','deviceManagement_device_refer','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'deviceManagement_device_update','UI_PERMISSION','deviceManagement_device_update','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'deviceManagement_sensor_refer','UI_PERMISSION','deviceManagement_sensor_refer','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'deviceManagement_sensor_update','UI_PERMISSION','deviceManagement_sensor_update','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'deviceManagement_event_refer','UI_PERMISSION','deviceManagement_event_refer','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'deviceManagement_event_update','UI_PERMISSION','deviceManagement_event_update','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'deviceGroupManagement_deviceGroup_refer','UI_PERMISSION','deviceGroupManagement_deviceGroup_refer','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'deviceGroupManagement_deviceGroup_update','UI_PERMISSION','deviceGroupManagement_deviceGroup_update','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'deviceGroupManagement_deviceGroupC_refer','UI_PERMISSION','deviceGroupManagement_deviceGroupComposition_refer','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'deviceGroupManagement_deviceGroupC_update','UI_PERMISSION','deviceGroupManagement_deviceGroupComposition_update','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'deviceViewSettings_deviceStatusCard_refer','UI_PERMISSION','deviceViewSettings_deviceStatusCard_refer','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'deviceViewSettings_deviceStatusCard_update','UI_PERMISSION','deviceViewSettings_deviceStatusCard_update','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'processFlowManagement_stencil_refer','UI_PERMISSION','processFlowManagement_stencil_refer','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'processFlowManagement_stencil_update','UI_PERMISSION','processFlowManagement_stencil_update','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'processFlowManagement_processFlow_refer','UI_PERMISSION','processFlowManagement_processFlow_refer','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'processFlowManagement_processFlow_update','UI_PERMISSION','processFlowManagement_processFlow_update','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'userManagement_userRole_refer','UI_PERMISSION','userManagement_userRole_refer','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'userManagement_userRole_update','UI_PERMISSION','userManagement_userRole_update','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'userManagement_roleRootGroup_refer','UI_PERMISSION','userManagement_roleRootGroup_refer','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'userManagement_roleRootGroup_update','UI_PERMISSION','userManagement_roleRootGroup_update','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'mailManagement_mailAddress_refer','UI_PERMISSION','mailManagement_mailAddress_refer','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'mailManagement_mailAddress_update','UI_PERMISSION','mailManagement_mailAddress_update','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'mailManagement_mailFormat_refer','UI_PERMISSION','mailManagement_mailFormat_refer','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'mailManagement_mailFormat_update','UI_PERMISSION','mailManagement_mailFormat_update','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'roleManagement_role_refer','UI_PERMISSION','roleManagement_role_refer','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'roleManagement_role_update','UI_PERMISSION','roleManagement_role_update','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'roleManagement_program_refer','UI_PERMISSION','roleManagement_program_refer','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'roleManagement_program_update','UI_PERMISSION','roleManagement_program_update','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'roleManagement_roleProgram_refer','UI_PERMISSION','roleManagement_roleProgram_refer','','','0','System','System' )
INSERT INTO dbo.mst_program_authority ( authority_id,authority_type,name_locale1,url,method,version,inserted,updated ) VALUES ( 'roleManagement_roleProgram_update','UI_PERMISSION','roleManagement_roleProgram_update','','','0','System','System' )

/****** ADMINロールには全画面へのアクセスを許可する. ******/
INSERT INTO [dbo].[mst_role_program_authority] ([role_id],[authority_id] ,[version] ,[inserted] ,[updated])
SELECT 'ADMIN' as role_id, a.authority_id, 0 as version, 'System' as inserted, 'System' as updated
  FROM (
              SELECT 'area_dashboard_refer' as authority_id
        UNION SELECT 'area_dashboard_update' as authority_id
        UNION SELECT 'deviceMasterManagement_sensor_refer' as authority_id
        UNION SELECT 'deviceMasterManagement_sensor_update' as authority_id
        UNION SELECT 'deviceMasterManagement_event_refer' as authority_id
        UNION SELECT 'deviceMasterManagement_event_update' as authority_id
        UNION SELECT 'deviceManagement_model_refer' as authority_id
        UNION SELECT 'deviceManagement_model_update' as authority_id
        UNION SELECT 'deviceManagement_device_refer' as authority_id
        UNION SELECT 'deviceManagement_device_update' as authority_id
        UNION SELECT 'deviceManagement_sensor_refer' as authority_id
        UNION SELECT 'deviceManagement_sensor_update' as authority_id
        UNION SELECT 'deviceManagement_event_refer' as authority_id
        UNION SELECT 'deviceManagement_event_update' as authority_id
        UNION SELECT 'deviceGroupManagement_deviceGroup_refer' as authority_id
        UNION SELECT 'deviceGroupManagement_deviceGroup_update' as authority_id
        UNION SELECT 'deviceGroupManagement_deviceGroupC_refer' as authority_id
        UNION SELECT 'deviceGroupManagement_deviceGroupC_update' as authority_id
        UNION SELECT 'deviceViewSettings_deviceStatusCard_refer' as authority_id
        UNION SELECT 'deviceViewSettings_deviceStatusCard_update' as authority_id
        UNION SELECT 'processFlowManagement_stencil_refer' as authority_id
        UNION SELECT 'processFlowManagement_stencil_update' as authority_id
        UNION SELECT 'processFlowManagement_processFlow_refer' as authority_id
        UNION SELECT 'processFlowManagement_processFlow_update' as authority_id
        UNION SELECT 'userManagement_userRole_refer' as authority_id
        UNION SELECT 'userManagement_userRole_update' as authority_id
        UNION SELECT 'userManagement_roleRootGroup_refer' as authority_id
        UNION SELECT 'userManagement_roleRootGroup_update' as authority_id
        UNION SELECT 'mailManagement_mailAddress_refer' as authority_id
        UNION SELECT 'mailManagement_mailAddress_update' as authority_id
        UNION SELECT 'mailManagement_mailFormat_refer' as authority_id
        UNION SELECT 'mailManagement_mailFormat_update' as authority_id
        UNION SELECT 'roleManagement_role_refer' as authority_id
        UNION SELECT 'roleManagement_role_update' as authority_id
        UNION SELECT 'roleManagement_program_refer' as authority_id
        UNION SELECT 'roleManagement_program_update' as authority_id
        UNION SELECT 'roleManagement_roleProgram_refer' as authority_id
        UNION SELECT 'roleManagement_roleProgram_update' as authority_id
       ) a
 WHERE NOT EXISTS (SELECT 1 FROM mst_role_program_authority b
                           WHERE 'ADMIN' = b.role_id
                             AND a.authority_id = b.authority_id);

 
INSERT [dbo].[mst_system_info] ([key], [value_string], [item_type], [version], [inserted], [updated])
SELECT 'DBVersion' as [key], '1.1.0_201812031200' as value_string, 'string' as item_type, 0 as version, 'System' as inserted, 'System' as updated